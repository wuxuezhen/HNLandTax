//
//  MGMCommunityDetailPageController.m
//  MGMCommunity
//
//  Created by apple on 2018/12/19.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityDetailPageController.h"
#import "MGMCommunityDetailCommentCell.h"
#import "MGMCommunityDetailPageBottomView.h"
#import "MGMCommunityGotoLogin.h"
#import "MGMFilmReviewHotData+MGMCommitHeight.h"
#import <MGMDataProcessingKit/MGMLikeAndCommentDataManager.h>
#import <MGMDataProcessingKit/MGMDynamicAddParentCommentModel.h>
#import "MGMDynamicDetailDataManager.h"
#import "MGMCommunity.h"
#import "MGMCommunityResource.h"
#import "MGMCommunityReportManager.h"
#import "MGMCommunityRelationInfos.h"
#import "MGMPageController+MGMDynamic.h"
#import <MGMSocialModule/MGMDynamicFeedItem.h>
#import <MGMDataProcessingKit/MGMSocialVoteService.h>

#import <YYModel/YYModel.h>
#import <Masonry/Masonry.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/MGMCategories.h>
#import <MGMUIKit/MGMProgressHUD+MGMConfig.h>
#import <MGMRoute/MGMRoute.h>
#import <MGMRoute/MGMRouteUGCParams.h>
#import <MGMUIKit/MGMRefresh.h>
#import <MGMUIKit/MGMNoDataTableViewCell.h>
#import <MGMNavigation/MGMNavigationView.h>
#import <MGMUIKit/MGMCommentPublishView.h>
#import <MGMUIKit/MGMCustomerNoMoreDataFooter.h>
#import <MGMDataStore/MGMDSUser.h>
#import <MGMLogin/MGMLoginManager.h>
#import <MGUHttpApiCore/MGUHttpApi.h>
#import <MGUHttpApiCore/MGUHttpApiFactory.h>
#import <MGMHttpApiModel/MGMHttpResponse.h>
#import <MGMHttpApiModel/MGMCommentInfoBody.h>
#import <MGMHttpApiModel/MGMFilmReviewHotListDataModel.h>
#import <MGMDataProcessingKit/MGMDataSyncManager.h>
#import <MGMDataProcessingKit/MGMFixCommentListManager.h>

#import "MGMStagePhotoTimeLineCell.h"
#import "MGMImageAndTextTimeLineCell.h"
#import "MGMTimeLineImageTextModel.h"
#import "MGMTimeLineStagePhotoModel.h"
#import <MGMUserCertification/MGMUserCertification.h>
#import <MGMShare/MGMShare.h>
#import <MGMLoginSDK/WXApi.h>
#import <MGMUIKit/MGMUIKitResource.h>
#import <MGMUIKit/MGMUGCVote.h>
#import <MGMCategories/UIImage+MGMUIKit.h>
#import <MGMCategories/UIView+MGMToast.h>

/**
    详情页类型

 - MGMCommunityDetailStyleImageText:  图文混排
 - MGMCommunityDetailStyleStagePhoto: 剧照
 */
typedef NS_ENUM(NSInteger, MGMCommunityDetailType)
{
    MGMCommunityDetailTypeImageText,
    MGMCommunityDetailTypeStagePhoto
};

/**
    动态详情定位页数类型

- MGMCommunityDetailPostionPageTypeCurrent:  当前页
- MGMCommunityDetailPostionPageTypeNext:     下一页
*/
typedef NS_ENUM(NSInteger, MGMCommunityDetailPostionPageType)
{
    MGMCommunityDetailPostionPageTypeCurrent = 1,
    MGMCommunityDetailPostionPageTypeNext
};

@interface MGMCommunityDetailPageController ()<UITableViewDelegate, UITableViewDataSource,MGMCommunityDetailPageBottomViewDelegate, MGMLikeAndCommentDataManagerDelegate, MGMDynamicDetailDataManagerDelegate, MGMFixCommentListDelegate, MGMDynamicFeedItemDelegate,MGMSocialVoteServiceDelegate>

@property (nonatomic, strong) UITableView *dynamicDetailTableView;
@property (nonatomic, strong) MGMCommunityDetailPageBottomView *bottomView;
@property (nonatomic, strong) UIView *secondHeaderView;

@property (nonatomic, copy) NSString *topicId;
@property (nonatomic, copy) NSString *commentId;
@property (nonatomic, copy) NSString *trackEventLocation;
@property (nonatomic, strong) MGMTopicInfoModel *ugcTopic;
@property (nonatomic, assign) MGMCommunityDetailType detailType;
@property (nonatomic, strong) MGMDynamicModel *dynamicModel;
@property (nonatomic, strong) MGMDynamicFeedItem *feedItem;
@property (nonatomic, strong) NSMutableArray <MGMFilmReviewHotData *> *commitList;

@property (nonatomic, strong) MGMDynamicDetailDataManager *dynamicDetailManager;
@property (nonatomic, strong) MGMLikeAndCommentDataManager *likeDataManager;
@property (nonatomic, strong) MGMFixCommentListManager *fixCommentManager;
@property (nonatomic, strong) MGMCommunityRelationInfosFetcher *userDataManager;
@property (nonatomic, strong) UIView *maskView;
@property (nonatomic, strong) UIImageView *toastView;
@property (nonatomic, strong) UIButton *shareBtn;
@property (nonatomic, strong) UIButton *reportBtn;
@property (nonatomic, weak) UILabel *noDataLabel;
@property (nonatomic, strong) MGMCommentPublishView *commentPublishView;
@property (nonatomic, weak) MGMNavigationView *navigionView;

@property (nonatomic, assign) NSInteger contentPosition;
@property (nonatomic, assign) NSInteger pageIndex;
@property (nonatomic, assign) NSInteger commentCount;
@property (nonatomic, assign) BOOL isEmptyTable;
@property (nonatomic, assign, getter=isPosition) BOOL position;
@property (nonatomic, assign, getter=isShowKeyBoard) BOOL showKeyBoard;
@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, strong) NSArray *listArray;

@property (nonatomic, strong) MGMCommunityRelationInfos *userRelationship;
@property (nonatomic, strong) id userInfoChangObId;

/**
   投票服务
*/
@property (nonatomic, strong) MGMSocialVoteService *voteService;

@end

static NSString *MGMCommunityDetailPageControllerCellId = @"MGMCommunityDetailPageControllerCellId";
static NSString *MGMCommunityDetailPageControllerNoDataCellId = @"MGMCommunityDetailPageControllerNoDataCellId";

@implementation MGMCommunityDetailPageController

- (instancetype)init
{
    self = [super init];
    if (self) {
        _identifier = [NSUUID UUID].UUIDString;
    }
    __weak typeof(self)weakSelf = self;
    self.userInfoChangObId = [[NSNotificationCenter defaultCenter] addObserverForName:@"MGMUpdateFollowStatusNSNotification"
                                                                               object:nil
                                                                                queue:[NSOperationQueue mainQueue]
                                                                           usingBlock:^(NSNotification * _Nonnull note) {
                                                                               [weakSelf getBackFromUserMainWithInfo:note.userInfo];
                                                                           }];
    return self;
}

- (void)setupParameters:(MGMRouteUGCParams *)params
{
    _topicId = params.topicId;
    _commentId = params.commentId;
    _contentPosition = params.contentPosition;
    _trackEventLocation = params.trackEventLocation;
    _showKeyBoard = params.showKeyBoard;
    if (!self.commentId.length) return;
    
    self.position = YES;
}

#pragma mark - Cycle Life

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupUI];
    [self addNotificatonObserver];
    [self loadDynamicDetailData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    //  为了保证子评论数据和二级子评论列表数据同步, 页面将出现了重新获取评论
    if (self.dynamicModel)
    {
        [self loadCommentListData];
    }
    [[MGMDataSyncManager sharedManager] removeLikeObserverWithId:self.identifier];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (self.isShowKeyBoard)
    {
        self.showKeyBoard = NO;
        [self showCommentPublishView];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
    [self dismissCommentPublishView];
}

#pragma mark - Private

- (void)setupUI
{
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.dynamicDetailTableView];
    [self.view addSubview:self.bottomView];

    MGMNavigationView *customNav = [MGMNavigationView navigationViewForCommunity];
    customNav.title = @"动态详情";
    [self.view addSubview:customNav];
    self.navigionView = customNav;
    [self.bottomView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.view);
        make.bottom.mas_equalTo(-kVirtualHomeHeight);
        make.height.mas_equalTo(kMGMHBL(104));
    }];
    
    [self.dynamicDetailTableView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.view);
        make.top.equalTo(customNav.mas_bottom);
        make.bottom.equalTo(self.bottomView.mas_top);
    }];
}

- (void)addNotificatonObserver
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(notificationCenterUserInfo:)
                                                 name:MGMLoginSuccessNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(notificationCenterUserInfo:)
                                                 name:MGMUserLogoutNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
    selector:@selector(miniProgramDidShare)
        name:@"WechatMiniProgramDidShareNotification"
      object:nil];
}

- (void)loadDynamicDetailData
{
    [self.dynamicDetailManager fetchDynamicDetailInfoWithFeedId:self.topicId];
}


/// 加载定位评论数据
- (void)loadPostionCommentListDataWithType:(MGMCommunityDetailPostionPageType)type
{
    [self.fixCommentManager startFixParentCommentListWithCommentId:self.commentId
                                                              type:type
                                                            action:2
                                                          pageSize:10
                                                certificationTypes:[MGMUserCertification sharedUserCertification].cerTypeParams];
}

/**
    加载评论数据
 */
- (void)loadCommentListData
{
    _pageIndex = 1;
    self.position = NO;
    [self loadData];
}

/**
    上拉加载更多评论数据
 */
- (void)loadMoreCommentData
{
    if (self.isPosition)
    {
        [self loadPostionCommentListDataWithType:(MGMCommunityDetailPostionPageTypeNext)];
    }
    else
    {
        _pageIndex += 1;
        [self loadData];
    }
}

- (void)loadData
{
    NSString *contentType;
    NSString *mid;
    if (MGMCommunityDetailTypeStagePhoto == self.detailType)
    {
        contentType = @"70";
        mid = self.dynamicModel.feedId;
    }
    else
    {
        contentType = @"16";
        mid = self.dynamicModel.mid;
    }
    [self.likeDataManager startGetCommentListWithMId:mid
                                         contentType:contentType
                                                desc:@"NEW"
                                              pageNo:self.pageIndex
                                            pageSize:10
                                  certificationTypes:[MGMUserCertification sharedUserCertification].cerTypeParams];
}

- (void)refreshCommentListWithData:(MGMFilmReviewHotListBody *)data error:(NSError *)error
{
    BOOL isHeader = [self.dynamicDetailTableView.mj_header isRefreshing];
    BOOL isFooter = [self.dynamicDetailTableView.mj_footer isRefreshing];
    if (error) {
        [self endtableRefreshingWithList:nil isHeader:isHeader isFooter:isFooter withError:error];
        return;
    }
    self.commentCount = [data.commentCount integerValue];
    [self endtableRefreshingWithList:data.commentInfoList
                            isHeader:isHeader
                            isFooter:isFooter
                           withError:nil];
}

/// 列表数据处理展示
- (void)endtableRefreshingWithList:(NSArray *)list
                          isHeader:(BOOL)isHeader
                          isFooter:(BOOL)isFooter
                         withError:(NSError *)error
{
    if (error) {
        if (self.commitList.count == 0) {
            // 设置无数据界面
            [self.dynamicDetailTableView.mj_header endRefreshing];
            [self.dynamicDetailTableView.mj_footer endRefreshing];
            _isEmptyTable = YES;
            self.dynamicDetailTableView.mj_footer.hidden = YES;
            [self.dynamicDetailTableView reloadData];
        }
        return;
    }
    
    if (isHeader || (!isHeader && !isFooter)) {
        [self.commitList removeAllObjects];
        if (list.count == 0) {
            // 设置无数据界面
            _isEmptyTable = YES;
            self.dynamicDetailTableView.mj_footer.hidden = YES;
            [self.dynamicDetailTableView.mj_header endRefreshing];
        } else if (list.count < 10) {
            // 设置已加载全部
            _isEmptyTable = NO;
            self.dynamicDetailTableView.mj_footer.hidden = NO;
            [self.dynamicDetailTableView.mj_header endRefreshing];
            [self.dynamicDetailTableView.mj_footer endRefreshingWithNoMoreData];
            [self.commitList addObjectsFromArray:list];
        } else {
            // 添加数据
            _isEmptyTable = NO;
            self.dynamicDetailTableView.mj_footer.hidden = NO;
            [self.dynamicDetailTableView.mj_header endRefreshing];
            [self.dynamicDetailTableView.mj_footer resetNoMoreData];
            [self.commitList addObjectsFromArray:list];
        }
        [self.dynamicDetailTableView reloadData];
        self.listArray = list;
        [self getLikeCountsWithCommnetList:list];
        // 刷新数据
        return;
    }
    if (isFooter) {
        if (list.count == 0) {
            [self.dynamicDetailTableView.mj_footer endRefreshingWithNoMoreData];
        } else if (list.count < 10) {
            // 设置已加载全部
            [self.dynamicDetailTableView.mj_footer endRefreshingWithNoMoreData];
            [self.commitList addObjectsFromArray:list];
        } else {
            // 添加数据
            [self.commitList addObjectsFromArray:list];
            [self.dynamicDetailTableView.mj_footer endRefreshing];
        }
        // 刷新列表
        [self.dynamicDetailTableView reloadData];
        [self getLikeCountsWithCommnetList:list];
        return;
    }
}

- (void)followUser
{
    MGMWeakSelf;
    [self.dynamicDetailManager followUserCompletion:^(MGMSocialUser * _Nullable followUser, NSError * _Nullable error) {
        MGMStrongSelf;
        if (error)
        {
            NSLog(@"error = %@",error.localizedDescription);
            return;
        }
        
        [MGMProgressHUD showAutoHiddeText:@"关注成功"];
        
        //  上报动态详情关注埋点
        [self uploadDynamicEventTrackingWithType:@"INTERACTION_FOCUS"
                                        location:self.trackEventLocation
                                        position:self.contentPosition
                                       programId:nil
                                          pageId:nil
                                       dynamicId:self.dynamicModel.feedId];
        
        self.dynamicModel.relationType = MGMSocialUserRelationFollowing;
        NSIndexPath *reloadIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
        [UIView performWithoutAnimation:^{
            [self.dynamicDetailTableView reloadRowsAtIndexPaths:@[reloadIndexPath]
                                               withRowAnimation:(UITableViewRowAnimationNone)];
        }];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"MGMUpdateFollowStatusNSNotification"
                                                            object:nil
                                                          userInfo:@{@"userId":followUser.userId ?: @"",
                                                                     @"relationType":@"MYFOLLOW"}];
    }];
}

- (void)likeDynamicContent:(BOOL)like dynamicType:(MGMSocialDynamicContentType)dynamicType
{    
    MGMSocialLike likeType = [MGMSocialDynamicTools likeTypeForDynamicType:dynamicType];
    NSString *feedId = (MGMSocialDynamicContentTypeMicroblog == dynamicType) ? self.dynamicModel.mid : self.dynamicModel.feedId;
    if (like)
    {
        [self.feedItem likeWithObjectId:feedId
                                   type:likeType
                                  index:1
                              extension:@""];
    }
    else
    {
        [self.feedItem unlikeWithObjectId:feedId
                                     type:likeType
                                    index:1];
    }
}

- (void)showLoginPageController
{
    [[MGMLoginManager shareManager] loginFromViewController:self
                                                   showType:(MGMLoginShowTypePresent)
                                           isBackButtonHide:NO
                                                    success:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
        
                                                    } fail:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
        
                                                    }];
}

/**
    弹出评论弹框
 */
- (void)showCommentPublishView
{
    [self.view addSubview:self.commentPublishView];
    //  设置占位文字
    NSDictionary *attrs = @{
                            NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Regular" size: 12],
                            NSForegroundColorAttributeName: [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1.0]
                            };
    NSString *placeholder = @"说出你的想法，骚年";
    self.commentPublishView.attributePlaceholder = [[NSAttributedString alloc] initWithString:placeholder attributes:attrs];
    [self.commentPublishView popAnimationWithCompletion:nil];
}

/**
    移除评论弹框
 */
- (void)dismissCommentPublishView
{
    [self.commentPublishView dismissAnimationWithCompletion:nil];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MGMLoginSuccessNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MGMUserLogoutNotification object:nil];
}

- (void)miniProgramDidShare
{
    [self.view showAutoHideToastWithText:@"分享成功"];
}
#pragma mark - Getter&Setter

- (void)setDynamicModel:(MGMDynamicModel *)dynamicModel
{
    _dynamicModel = dynamicModel;
    //  复用上层控件, 不需要显示更多图标和评论列表
    dynamicModel.hideMore = YES;
    dynamicModel.hideComment = YES;
}

- (UILabel *)noDataLabel
{
    if (!_noDataLabel)
    {
        UILabel *noDataLabel = [[UILabel alloc] initWithFrame:self.dynamicDetailTableView.bounds];
        noDataLabel.text = @"抱歉，这条评论已经被删除了";
        noDataLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:15];
        noDataLabel.textColor = [UIColor mgu_colorWithHex:0x999999];
        noDataLabel.textAlignment = NSTextAlignmentCenter;
        noDataLabel.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:noDataLabel];
        _noDataLabel = noDataLabel;
        
        [noDataLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(self.view);
            make.top.equalTo(self.navigionView.mas_bottom);
            make.bottom.equalTo(self.view);
        }];
    }
    return _noDataLabel;
}

- (UIView *)maskView
{
    if (!_maskView)
    {
        _maskView = [[UIView alloc] initWithFrame:MGMScreenBounds];
        _maskView.hidden = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                              action:@selector(handleTapGesture)];
        [_maskView addGestureRecognizer:tap];
        [self.view addSubview:_maskView];
    }
    return _maskView;
}

- (MGMCommentPublishView *)commentPublishView
{
    if (!_commentPublishView)
    {
        CGFloat publishViewW = MGMScreenW;
        CGFloat publishViewH = 140;
        MGMWeakSelf;
        _commentPublishView = [MGMCommentPublishView commentPublishViewWithFrame:CGRectMake(0, MGMScreenH, publishViewW, publishViewH) completion:^(NSString *commentText) {
            MGMStrongSelf;
            BOOL login = [MGMDSUser user].isLogin;
            if (login)
            {
                [self publishNewComment:commentText];
            }
            else
            {
                [[MGMLoginManager shareManager] verifyLoginStateSuccess:^{
                    
                } failure:NULL];;
            }
            [self dismissCommentPublishView];
        }];
    }
    return _commentPublishView;
}

- (UIImageView *)toastView
{
    if (!_toastView)
    {
        CGFloat toastViewW = 54.f;
        CGFloat toastViewH = 88.5;
        UIView *rightBarButtonItem = self.navigionView.rightBarButtonItem;
        CGFloat toastViewCenterY = [rightBarButtonItem convertPoint:rightBarButtonItem.center
                                                             toView:self.view].y;
        CGFloat toastViewCenterX = rightBarButtonItem.centerX - toastViewW * 0.5 - 8 - rightBarButtonItem.width * 0.5;
       UIImageView *toastView = [[UIImageView alloc] initWithImage:[MGMCommunityResource imageNamed:@"img_fxjb_s"]];
        toastView.hidden = YES;
        toastView.frame = CGRectMake(toastViewCenterX, toastViewCenterY, toastViewW, toastViewH);
        toastView.userInteractionEnabled = YES;
        [toastView addSubview:self.reportBtn];
        [toastView addSubview:self.shareBtn];
        [self.shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.offset(MGMScaleValue(4));
            make.right.left.offset(0);
            make.height.equalTo(self.reportBtn);
        }];
        [self.reportBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.shareBtn.mas_bottom);
            make.left.bottom.right.offset(0);
            make.height.equalTo(self.shareBtn);
        }];
        
        UIView *separatorView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0.5, 20)];
        separatorView.backgroundColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0];
        [toastView addSubview:separatorView];
        [separatorView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.offset(0);
            make.top.equalTo(self.shareBtn.mas_bottom).offset(0);
            make.width.offset(MGMScaleValue(44));
            make.height.offset(0.5);
        }];
        [self.view addSubview:toastView];
        [toastView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.offset(MGMScaleValue(-5));
            make.size.mas_equalTo(CGSizeMake(toastViewW, toastViewH));
            make.top.equalTo(self.navigionView.mas_bottom).offset(MGMScaleValue(-4));
        }];
        _toastView = toastView;
    }
    return _toastView;
}

- (UIButton *)reportBtn {
    if (!_reportBtn) {
        UIButton *jbbtn = [UIButton buttonWithType:UIButtonTypeCustom];
        NSString *toastImageName = self.dynamicModel.isMine ? @"删除" : @"举报";
        [jbbtn setTitle:toastImageName forState:UIControlStateNormal];
        [jbbtn setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        jbbtn.titleLabel.font = [UIFont systemFontOfSize:12];
        [jbbtn addTarget:self action:@selector(toastViewDidClick) forControlEvents:UIControlEventTouchUpInside];
        _reportBtn = jbbtn;
    }
    return _reportBtn;
}

- (UIButton *)shareBtn {
    if (!_shareBtn) {
       UIButton *jbbtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [jbbtn setTitle:@"分享" forState:UIControlStateNormal];
        [jbbtn setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        jbbtn.titleLabel.font = [UIFont systemFontOfSize:12];
        [jbbtn addTarget:self action:@selector(shareDynamic) forControlEvents:UIControlEventTouchUpInside];
        _shareBtn = jbbtn;
    }
    return _shareBtn;
}

- (MGMDynamicFeedItem *)feedItem
{
    if (!_feedItem)
    {
        _feedItem = [[MGMDynamicFeedItem alloc] init];
        _feedItem.delegate = self;
        _feedItem.feedId = self.dynamicModel.feedId;
    }
    return _feedItem;
}

- (NSMutableArray *)commitList {
    if (!_commitList) {
        _commitList = @[].mutableCopy;
    }
    return _commitList;
}

- (UIView *)secondHeaderView {
    if (!_secondHeaderView) {
        UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth, kMGMHBL2X(36))];
        header.backgroundColor = [UIColor whiteColor];
        UILabel *label = [[UILabel alloc] init];
        [header addSubview:label];
        
        NSString *text = [NSString stringWithFormat:@"%ld条评论",self.commentCount];
        label.frame = CGRectMake(kMGMHBL2X(15),kMGMHBL2X(20),kMGMHBL2X(100),kMGMHBL2X(16));
        NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:text
                                                                                   attributes: @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Semibold" size: 16],
                                                                                                 NSForegroundColorAttributeName: [UIColor colorWithRed:26/255.0 green:26/255.0 blue:26/255.0 alpha:1.0]}];
        label.attributedText = string;
        _secondHeaderView = header;
    }
    return _secondHeaderView;
}

- (UITableView *)dynamicDetailTableView {
    if (!_dynamicDetailTableView) {
        _dynamicDetailTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _dynamicDetailTableView.delegate = self;
        _dynamicDetailTableView.dataSource = self;
        _dynamicDetailTableView.mj_footer.hidden = YES;
        _dynamicDetailTableView.estimatedRowHeight = 0;
        _dynamicDetailTableView.estimatedSectionFooterHeight = 0;
        _dynamicDetailTableView.estimatedSectionHeaderHeight = 0;
        _dynamicDetailTableView.separatorColor = [UIColor clearColor];
        _dynamicDetailTableView.backgroundColor = [UIColor mgu_colorWithHex:0xf5f5f5];
        [_dynamicDetailTableView registerClass:[MGMCommunityDetailCommentCell class] forCellReuseIdentifier:MGMCommunityDetailPageControllerCellId];
        [_dynamicDetailTableView registerClass:[MGMNoDataTableViewCell class] forCellReuseIdentifier:MGMCommunityDetailPageControllerNoDataCellId];
        [_dynamicDetailTableView registerClass:[MGMStagePhotoTimeLineCell class] forCellReuseIdentifier:MGMStagePhotoTimeLineCellID];
        [_dynamicDetailTableView registerClass:[MGMImageAndTextTimeLineCell class] forCellReuseIdentifier:MGMImageAndTextTimeLineCellID];
        _dynamicDetailTableView.mj_header = [MGMRefrshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadCommentListData)];
        _dynamicDetailTableView.mj_footer = [MGMCustomerNoMoreDataFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreCommentData)];
        if (@available(iOS 11.0, *)) {
            _dynamicDetailTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        } else {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
    }
    return _dynamicDetailTableView;
}

- (MGMCommunityDetailPageBottomView *)bottomView {
    if (!_bottomView) {
        _bottomView = [[MGMCommunityDetailPageBottomView alloc] initWithFrame:CGRectZero];
        _bottomView.deleaget = self;
    }
    return _bottomView;
}

- (MGMFixCommentListManager *)fixCommentManager
{
    if (!_fixCommentManager)
    {
        _fixCommentManager = [[MGMFixCommentListManager alloc] initWithDelegate:self];
    }
    return _fixCommentManager;
}

- (MGMDynamicDetailDataManager *)dynamicDetailManager
{
    if (!_dynamicDetailManager)
    {
        _dynamicDetailManager = [[MGMDynamicDetailDataManager alloc] initWithDelegate:self];
    }
    return _dynamicDetailManager;
}

- (MGMLikeAndCommentDataManager *)likeDataManager {
    if (!_likeDataManager) {
        _likeDataManager = [[MGMLikeAndCommentDataManager alloc] init];
        _likeDataManager.dataManagerDelegate = self;
    }
    return _likeDataManager;
}

- (MGMCommunityRelationInfosFetcher *)userDataManager {
    if (!_userDataManager) {
        _userDataManager = [[MGMCommunityRelationInfosFetcher alloc] init];
        _userDataManager.delegate = self;
    }
    return _userDataManager;
}

/// 获取当前用户对动态客户关注状态
- (void)fetchUserRelationships:(nullable NSArray *)list error:(nullable NSError *)error {
    if (!error) {
        self.userRelationship = list.firstObject;
    }
    [self.dynamicDetailTableView reloadData];
}

#pragma mark - Target Action

- (void)didGetLikeActionNotiWithInfo:(NSDictionary *)info
{
    NSString *objectId = [info valueForKey:@"objectId"];
    BOOL isAddid = [[info valueForKey:@"isAddid"] boolValue];
    if (objectId == nil) return;

    NSIndexPath *indexPath;
    for (MGMFilmReviewHotData *model in self.commitList) {
        if ([model.commentId isEqualToString:objectId]) {
            model.likeModel.mgm_has = isAddid;
            model.likeModel.mgm_likeCount += isAddid? 1 : -1;
            NSInteger index = [self.commitList indexOfObject:model];
            indexPath = [NSIndexPath indexPathForRow:index inSection:1];
        }
    }
    [UIView performWithoutAnimation:^{
        [self.dynamicDetailTableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:(UITableViewRowAnimationNone)];
    }];
}

- (void)getBackFromUserMainWithInfo:(NSDictionary *)info
{
    NSString *userId = info[@"userId"];
    NSString *relationType = info[@"relationType"];
    if (!userId) {
        return;
    }
    if ([self.ugcTopic.userId isEqualToString:userId]) {
        [self.userRelationship resetRelationshipWithString:relationType];
        [self.dynamicDetailTableView reloadData];
    }
}

- (void)notificationCenterUserInfo:(NSNotification *)notifi
{
    if (self.topicId && self.listArray.count>0) {
        [self.likeDataManager startFetchLikeCountWithObjectIds:@[self.topicId]];
        [self getLikeCountsWithCommnetList:self.listArray];
        [self.userDataManager fetchUserRealtionTypeWithUserIds:@[self.ugcTopic.userId?:@""]];
    }
}

- (void)toastViewDidClick
{
    self.toastView.hidden = self.maskView.hidden = YES;
    
    BOOL login = [MGMDSUser user].isLogin;
    if (!login)
    {
        [self showLoginPageController];
        return;
    }

    //  其他用户弹出举报, 当前用户弹出删除
    if (!self.dynamicModel.isMine)
    {
        [MGMCommunityReportManager resportUGCWithObjectOnVC:self handler:^(NSString * _Nonnull actionTitle) {}];
    }
    else
    {
        MGMWeakSelf;
        [self mgm_popDeleteAlertViewWithCancelHandler:nil confirmHandler:^(UIAlertAction * _Nonnull confirmAction) {
            MGMStrongSelf;
            self.feedItem.delegate = self;
            [self.feedItem remove];
        }];
    }
}

- (void)handleTapGesture
{
    self.maskView.hidden = self.toastView.hidden = YES;
}

/**
    发布评论

 @param comment 评论内容
 */
- (void)publishNewComment:(NSString *)comment
{
    if (comment.length < 1) {
        [MGMProgressHUD showText:@"评论字说不要小于1个哟..." containerSize:CGSizeMake(kMGMHBL2X(250), kMGMHBL2X(40)) radius:4.f autoHiddenDelay:0.8];
        return;
    }
    
    NSString *contentName = nil;
    NSString *contentId = nil;
    if (MGMCommunityDetailTypeImageText == self.detailType)
    {
        MGMTimeLineImageTextModel *imageTextModel = (MGMTimeLineImageTextModel *)self.dynamicModel;
        contentName = imageTextModel.textContent;
        contentId = @"100";
    }
    else if (MGMCommunityDetailTypeStagePhoto == self.detailType)
    {
        MGMTimeLineStagePhotoModel *stagePhotoModel = (MGMTimeLineStagePhotoModel *)self.dynamicModel;
        contentName = stagePhotoModel.stagePhotoOriginalName;
        contentId = stagePhotoModel.stagePhotoContentID;
    }
    
    NSString *contentType = (MGMCommunityDetailTypeImageText == self.detailType) ? @"16" : @"70";
    MGMDSUser *user = [MGMDSUser user];
    MGMDynamicAddParentCommentModel *addModel = [[MGMDynamicAddParentCommentModel alloc] init];
    addModel.body = comment;
    addModel.userId = user.userId;
    addModel.contentName = contentName;
    addModel.mId = (MGMTimeLineTypeStills == self.dynamicModel.timeLineType) ? self.dynamicModel.feedId : self.dynamicModel.mid;
    addModel.contentId = contentId;
    addModel.contentType = contentType;
    addModel.pictureType = 0;
    addModel.sendMessage = 1;
    [self.likeDataManager startPublishParrentComment:addModel];
}

- (void)routerEventWithName:(NSString *)eventName userInfo:(NSDictionary *)userInfo
{
    BOOL handle = [self mgm_shouldHandleEventName:eventName
                                         userInfo:userInfo
                                         position:self.contentPosition
                                         location:self.trackEventLocation];
    if (handle) return;
    
    MGMDynamicModel *extraInfo = userInfo[MGMCommunityExtraInfo];
    if ([eventName isEqualToString:MGMNavigationEventReportTap])
    {
        UIView *sender = userInfo[MGMNavigationEventSender];
        self.maskView.hidden = !self.maskView.isHidden;
        self.toastView.hidden = !self.toastView.isHidden;
    }
    else if ([MGMDSUser user].token == nil &&
             ![eventName isEqualToString:MGMCommunityImageTextClickEvent] &&
             ![eventName isEqualToString:MGMNavigationEventReportTap] &&
             ![eventName isEqualToString:MGMNavigationEventBackTap] &&
             ![eventName isEqualToString:MGMCommunityImageTextMainCommentEvent])
    {
        [[MGMLoginManager shareManager] verifyLoginStateSuccess:^{} failure:^{}];
        return;
    }
    //  关注事件
    else if ([eventName isEqualToString:MGMCommunityFollowEvent])
    {
        if ([MGMDSUser user].isLogin)
        {
            [self followUser];
        }
        else
        {
            [self showLoginPageController];
        }
    }
    if ([eventName isEqualToString:MGMCommunityDetailLikeSubCommentRouterName])
    {
        NSIndexPath *indexPath = userInfo[@"indexPath"];
        MGMFilmReviewHotData *model = self.commitList[indexPath.row];
        [self.likeDataManager startLikeActionWithId:model.commentId type:1 isAdd:!model.likeModel.mgm_has extension:@"ugc" index:indexPath];
        [self.dynamicDetailTableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
    }
    else if ([eventName isEqualToString:MGMCommunityLikeEvent])
    {
        if (![MGMCommunityGotoLogin shouldGotoLoginWithType:1 backButton:NO inController:self])
        {
            BOOL like = [userInfo[MGMCommunityLikeInfo] boolValue];
            MGMSocialDynamicContentType dynamicType = (MGMCommunityDetailTypeImageText == self.detailType) ? MGMSocialDynamicContentTypeMicroblog : MGMSocialDynamicContentTypeStills;
            [self likeDynamicContent:like dynamicType:dynamicType];
            
            NSString *type = like ? @"INTERACTION_LIKE" : @"INTERACTION_CANCEL_LIKE";
            //  上报动态详情点赞/取消点赞埋点
            [self uploadDynamicEventTrackingWithType:type
                                            location:self.trackEventLocation
                                            position:self.contentPosition
                                           programId:nil
                                              pageId:nil
                                           dynamicId:extraInfo.feedId];
        }
    }
   else if ([eventName isEqualToString:@"MGMCommunityDetailHeaderAddGunanzhu"])
   {
        if ([MGMDSUser user].isLogin) {
            [self.userDataManager addFansWithUserId:self.ugcTopic.userId];
        }
        else {
            [self showLoginPageController];
        }
   }else if ([eventName isEqualToString:MGMUIKitVoteClickEvent]){
       // 投票
        if ([MGMDSUser user].token == nil){
            [[MGMLoginManager shareManager] verifyLoginStateSuccess:^{} failure:^{}];
        }else{
            BOOL userClickEnbled = [userInfo[MGMUIKitVoteUserClickEnbled] boolValue];
            if (userClickEnbled) {
                NSString *voteId = userInfo[MGMUIKitVoteContentID];
                NSString *optionId = userInfo[MGMUIKitVoteOptionID];
                [self.voteService voteSocialContentWithVoteId:voteId optionId:optionId];
            }
        }
       return;
   }
    [super routerEventWithName:eventName userInfo:userInfo];
}

- (void)shareDynamic {
    self.toastView.hidden = self.maskView.hidden = YES;
    
    UIImage *image = [MGMCommunityResource imageNamed:@"APPlogo_1024x1024"];
    NSString *subtitle = @"《咪咕影院》动态频道，一个电影爱好者的互动社区，来这里说说你和电影的事吧";

    if ([self.dynamicModel isMemberOfClass:[MGMTimeLineStagePhotoModel class]]) {
        MGMTimeLineStagePhotoModel *imageModel = (MGMTimeLineStagePhotoModel *)self.dynamicModel;
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageModel.stagePhotoCoverUrl]];
        image = [UIImage imageWithData:data];
    } else if ([self.dynamicModel isMemberOfClass:[MGMTimeLineImageTextModel class]]) {
        MGMTimeLineImageTextModel *imageModel = (MGMTimeLineImageTextModel *)self.dynamicModel;
        NSString *imageUrl = [imageModel.picUrls mgu_objectOrNilAtIndex:0];
        if (imageUrl) {
            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageUrl]];
            image = [UIImage imageWithData:data];
        }
        if (imageModel.textContent.length > 0) {
            subtitle = imageModel.textContent;
        }
    }
    
    MGMWeakSelf;
    //灰度 http://117.131.17.174:40443/mgyy/share/details/prd/dynamicDetail.html?dynamicId=
    //@L_m 动态分享H5测试地址 http://117.131.17.174:8084/mgyy/share/details/prd/dynamicDetail.html?dynamicId=  小程序地址 /pages/webview/index?src=编码后的H5地址
    NSString *url = [[NSUserDefaults standardUserDefaults] objectForKey:@"MGM_UGC_PAGE_SHARE"];
    if (!url) {
        return;
    }
    NSString *feedid = self.dynamicModel.feedId;
    NSString *webUrl = [url stringByAppendingString:feedid.length > 0 ? feedid : @""];
    [MGMShareView showShareViewDidClickItemCallback:^(MGMUshareObject *model) {
        MGMStrongSelf;
        NSString *title = @"我在“咪咕影院”分享了一条动态，快来看看吧";
        if (MGMSocialPlatformType_Sina == model.platform)
        {
            [model shareToSinaWithStyle:(MGMShareSinaStyleNormal)
                                  title:title
                                  image:image
                                 webUrl:webUrl];
        }
        else if (MGMSocialPlatformType_WechatSession == model.platform)
        {
            NSString *userName = @"gh_04715ce2795f";
            NSString *path = [NSString stringWithFormat:@"/pages/webview/index?src=%@",[webUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            
            WXMiniProgramObject *object = [WXMiniProgramObject object];
            object.webpageUrl = webUrl;
            object.userName = userName;
            object.path = path;
            object.hdImageData = [image fetchImageDataOnSizeLimit:128.f / 1024.f];
            object.miniProgramType = WXMiniProgramTypeRelease;
            
            WXMediaMessage *message = [WXMediaMessage message];
            message.title = title;
            message.mediaObject = object;
            SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
            req.bText = NO;
            req.message = message;
            //  目前只支持会话
            req.scene = WXSceneSession;
            [WXApi sendReq:req completion:^(BOOL success) {
                
            }];
        }
        else
        {
            [model shareWithWebLink:webUrl
                              title:title
                              descr:subtitle
                           thumbURL:image
                         webpageUrl:webUrl];
        }
        
    } callback:^(id data, NSError *error) {
        NSLog(@"share error = %@",error.localizedDescription);
    } supportTimeLine:NO];
}

#pragma mark - MGMTimeLineVote Delegate
- (void)socialVoteServiceDidFinishVoteWithData:(NSArray<MGMSocialVoteOptionModel *> *)data
                                totalVoteCount:(NSInteger)totalVoteCount
                                         error:(NSError *)error{
    if (error) {
        [MGMProgressHUD showAutoHiddeText:[error.userInfo objectForKey:NSLocalizedDescriptionKey]];
    }else{
        self.dynamicModel.voteContent.voteOptions = data;
        self.dynamicModel.voteContent.totalVoteUserCount = totalVoteCount;
        for (MGMTimeLineBaseCell *cell in [self.dynamicDetailTableView visibleCells]) {
            if ([cell isKindOfClass:MGMTimeLineBaseCell.class]) {
                if ([cell.timeLineModel isEqual:self.dynamicModel]) {
                    cell.timeLineModel = self.dynamicModel;
                    break;
                }
            }
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:@"MGMUpdateVoteInfoNSNotification"
                                                            object:nil
                                                          userInfo:@{@"feedId":self.dynamicModel.feedId ?: @"",
                                                                     @"totalVoteCount":@(totalVoteCount),
                                                                     @"voteOptions":data}];
    }
    
}
#pragma mark - MGMDynamicFeedItem Delegate

- (void)removeDynamicFeedWithFeedId:(nullable NSString *)feedId Error:(nullable NSError *)error
{
    if (error)
    {
        [MGMProgressHUD showAutoHiddeText:@"删除失败"];
        NSLog(@"removeDynamic error = %@",error.localizedDescription);
        return;
    }
    
    [[MGMDataSyncManager sharedManager] deleteDynamicWithDynamicId:feedId];
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)likeDynamicFeedWithFeedId:(NSString *)feedId Error:(NSError *)error
{
    if (error)
    {
        NSLog(@"Detail likeDynamic error = %@",error.localizedDescription);
        return;
    }
}

- (void)unlikeDynamicFeedWithFeedId:(NSString *)feedId Error:(NSError *)error
{
    if (error)
    {
        NSLog(@"DetailunlikeDynamic error = %@",error.localizedDescription);
        return;
    }
}

#pragma mark - MGMFixCommentList Delegate

- (void)fixparentCommentListWithListModel:(nullable MGMFilmReviewHotListBody *)parentListModel Error:(nullable NSError *)error
{
    [self refreshCommentListWithData:parentListModel error:error];
}

#pragma mark - MGMDynamicDetailDataManager Delegate

- (void)dynamicDetailDataManager:(MGMDynamicDetailDataManager *)dataManage
            fetchDynamicFeedInfo:(nullable MGMDynamicModel *)dynamicModel
                           error:(nullable NSError *)error
{
    
    if (error)
    {
        NSLog(@"fetchDynamicFeedInfo error = %@",error.localizedDescription);
        return;
    }
    
    if (!dynamicModel)
    {
        self.dynamicDetailTableView.hidden = self.bottomView.hidden = self.navigionView.rightBarButtonItem.hidden = YES;
        [self.view addSubview:self.noDataLabel];
        return;
    }
    
    self.dynamicModel = dynamicModel;
    self.detailType = (MGMTimeLineTypeStills == self.dynamicModel.timeLineType) ? MGMCommunityDetailTypeStagePhoto : MGMCommunityDetailTypeImageText;
    [UIView performWithoutAnimation:^{
        [self.dynamicDetailTableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]]
                                           withRowAnimation:(UITableViewRowAnimationNone)];
    }];
    
    if (self.isPosition)
    {
        [self loadPostionCommentListDataWithType:(MGMCommunityDetailPostionPageTypeCurrent)];
    }
    else
    {
        [self loadCommentListData];
    }
}

#pragma mark - MGMLikeAndCommentDataManager Delegate

// 批量获取点赞数，包含动态点赞数和子评论点赞数
- (void)likeAndCommentdataManager:(MGMLikeAndCommentDataManager *)manager
                didFetchLikeCount:(NSDictionary *_Nullable)body
                            error:(NSError * _Nullable)eror
{
    if (!eror) {
        NSInteger topicId = self.topicId.integerValue;
        NSArray *likeModels = [NSArray yy_modelArrayWithClass:[MGMThumbData class] json: body[@"data"]];

        for (MGMThumbData *likeData in likeModels) {
            for (MGMFilmReviewHotData *commitData in self.commitList) {
                if (likeData.objectId_ == commitData.commentId.integerValue) {
                    commitData.likeModel = likeData;
                }
            }
        }
        NSIndexSet *reloadIndexSet = [NSIndexSet indexSetWithIndex:1];
        [UIView performWithoutAnimation:^{
            [self.dynamicDetailTableView reloadSections:reloadIndexSet withRowAnimation:(UITableViewRowAnimationNone)];
        }];
    }
}

/// 获取动态评论数目
//- (void)likeAndCommentdataManager:(MGMLikeAndCommentDataManager *)manager didFetchCommentCountAndDetail:(NSArray *)body error:(NSError * _Nullable)error {
//
//    if (!error) {
//        MGMHBCommentInfoBody *info = body.firstObject;
//        [self.bottomView setPlaceholderCommentCount:info.detail.commentCount];
//        [self.dynamicDetailTableView reloadData];
//        NSMutableDictionary *dict = @{}.mutableCopy;
//        [dict setValue:self.topicId forKey:@"topicId"];
//        [dict setValue:@(info.detail.commentCount) forKey:@"commentCount"];
//        [[MGMDataSyncManager sharedManager] updateLikeState:dict forTargetId:@"communty_comment_change"];
//    }
//}

- (void)likeAndCommentdataManager:(MGMLikeAndCommentDataManager *)manager
                           result:(BOOL)isOK
          didFetchPerCommentCount:(NSInteger)count
                            error:(NSError *)error
{
    if (!error) {
        [self.bottomView setPlaceholderCommentCount:count];
        [self.dynamicDetailTableView reloadData];
        NSMutableDictionary *dict = @{}.mutableCopy;
        [dict setValue:self.topicId forKey:@"topicId"];
        [dict setValue:@(count) forKey:@"commentCount"];
        [[MGMDataSyncManager sharedManager] updateLikeState:dict forTargetId:@"communty_comment_change"];
    }
}

/// 发布一级评论，即父评论
- (void)likeAndCommentdataManager:(MGMLikeAndCommentDataManager *)manager finishedAddParentCommentWithResult:(BOOL)result error:(NSError *)eror {
//    NSString *message = @"发布失败，请稍后重试";
    NSString *message = eror.userInfo[@"info"];
    if (!eror) {
        message = @"评论成功";
        [self loadCommentListData];
    }
    [MGMProgressHUD showAutoHiddeText:message];
}

/// 用户动态及评论点赞回调
- (void)likeAndCommentdataManager:(MGMLikeAndCommentDataManager *)manager
     finishedLikeActionWithResult:(BOOL)result
                            error:(NSError *)eror
{
    if (result) {
        NSIndexPath *index = manager.index;
        if (index) {
            MGMFilmReviewHotData *model = self.commitList[index.row];
            model.likeModel.mgm_has = manager.isAddLike;
            model.likeModel.mgm_likeCount += manager.isAddLike? 1 : -1;
            [self.dynamicDetailTableView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationNone];
            return;
        }
    }
}

/// 获取子评论列表数据
- (void)likeAndCommentdataManager:(MGMLikeAndCommentDataManager *)manager finishedGetParentCommentListWithBody:(MGMFilmReviewHotListBody *)body error:(NSError *)error
{
    [self refreshCommentListWithData:body error:error];
}

- (void)getLikeCountsWithCommnetList:(NSArray *)list {
    if (list.count == 0) {
        return;
    }
    NSArray *ids = [list mutableArrayValueForKey:@"commentId"];
    //  获取点赞数
    [self.likeDataManager startFetchLikeCountWithObjectIds:ids];
    //  获取评论数
    NSString *contentType = nil;
    NSString *mid = nil;
    if (MGMCommunityDetailTypeImageText == self.detailType)
    {
        contentType = @"16";
        mid = self.dynamicModel.mid;
    }
    else
    {
        contentType = @"70";
        mid = self.dynamicModel.feedId;
    }
    [self.likeDataManager startFetchPerCommentCountWithObjectIds:mid ?: @""contentType:contentType];
}

#pragma mark - MGMCommunityDetailPageBottomView Delegate

- (void)communityDetailPageBottomView:(MGMCommunityDetailPageBottomView *)bottomView shuldUpdateConstaitWithIsOpen:(BOOL)isOpen {
    if ([MGMCommunityGotoLogin shouldGotoLoginWithType:0 backButton:NO inController:self]) return;
    __weak typeof(self)weakSelf = self;
    [weakSelf showCommentPublishView];
}

/// 该方法已不再使用
- (void)communityDetailPageBottomView:(MGMCommunityDetailPageBottomView *)bottomView publishNewComment:(NSString *)comment
{
    [self publishNewComment:comment];
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (!section) return 1;
    return (_isEmptyTable) ? 1 : self.commitList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section) return self.commitList.count ? kMGMHBL2X(36) : CGFLOAT_MIN;
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!indexPath.section) return self.dynamicModel.rowHeight;
    
    if (_isEmptyTable) return kMGMHBL2X(155.f+88.5);
    MGMFilmReviewHotData *data = self.commitList[indexPath.row];
    return [MGMCommunityDetailCommentCell cellHeightWithData:data];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return section == 0 ? kMGMHBL2X(5.f) : CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section && self.commitList.count) return [self secondHeaderView];
    return [[UIView alloc] init];
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *footer = [[UIView alloc] init];
    footer.backgroundColor = [UIColor mgu_colorWithHex:0xF5F5F5];
    return footer;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!indexPath.section)
    {
        MGMTimeLineBaseCell *timeLineCell = nil;
        if (MGMCommunityDetailTypeStagePhoto == self.detailType)
        {
            timeLineCell = [tableView dequeueReusableCellWithIdentifier:MGMStagePhotoTimeLineCellID forIndexPath:indexPath];
        }
        else
        {
            timeLineCell = [tableView dequeueReusableCellWithIdentifier:MGMImageAndTextTimeLineCellID forIndexPath:indexPath];
        }
        timeLineCell.timeLineModel = self.dynamicModel;
        timeLineCell.hideSeperateLine = YES;
        return timeLineCell;
    }
    
    
    if (_isEmptyTable) {
        MGMNoDataTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MGMCommunityDetailPageControllerNoDataCellId forIndexPath:indexPath];
        NSMutableAttributedString *proms = [[NSMutableAttributedString alloc] initWithString:@"暂无热评，快来做第一个吃螃蟹的人吧"attributes: @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Regular" size: 15],NSForegroundColorAttributeName: [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1.0]}];
        [cell configImage:[MGMCommunityResource originalRenderingImageNamed:@"community_no_comment"] desc:proms topSpace:kMGMHBL2X(20+40) imageSize:CGSizeMake(kMGMHBL2X(114), kMGMHBL2X(75)) itemSpace:kMGMHBL2X(20) labelLeftMargin:kMGMHBL2X(60) labelRightMargin:kMGMHBL2X(60) bttomSpace:kMGMHBL2X(25+44.5)];
        cell.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    MGMCommunityDetailCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:MGMCommunityDetailPageControllerCellId forIndexPath:indexPath];
    cell.model = [self.commitList mgu_objectOrNilAtIndex:indexPath.row];
    __weak typeof(self) weakSelf = self;
    cell.indexPath = indexPath;
    cell.clickCallback = ^{
        [weakSelf tableView:weakSelf.dynamicDetailTableView didSelectRowAtIndexPath:indexPath];
    };
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    //隐藏最后一个底线
    UIView *bottomLine = [cell valueForKey:@"bottomLine"];
    if (indexPath.row == self.commitList.count - 1)
    {
        bottomLine.hidden = YES;
    }
    else
    {
        bottomLine.hidden = NO;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_isEmptyTable || !indexPath.section) return;

    // 二级评论页面已更由 MGMCommunityCommitDetailController(community_postReplyList) 换为 MGMSecondFilmDetailReviewPageController(film_detail_second_review_list)
    MGMFilmReviewHotData *model = self.commitList[indexPath.row];
    if (![model.status isEqualToString:@"1"] && ![model.status isEqualToString:@"3"]) {
        [MGMProgressHUD showAutoHiddeText:@"小编正在审核中，请稍后评论"];
        return;
    }
    NSMutableDictionary *params = @{}.mutableCopy;
    [params setValue:model.commentId forKey:@"commentId"];
    [params setValue:@"我也来插一嘴" forKey:@"textPlaceholder"];
    [params setValue:@"ugc" forKey:@"extension"];
    [params setValue:@"查看回复" forKey:@"navTitle"];
    [params setValue:model.contentName forKey:@"contentName"];
    [MGMRoute routePageControllerWithName:@"film_detail_second_review_list" parameters:params transitionStyle:MGURouteTransitionStyleNav];
    
    NSString *targetId = [NSString stringWithFormat:@"like_objectId_%@", model.commentId];
    __weak typeof(self)weakSelf = self;
    [[MGMDataSyncManager sharedManager] addLikeObserverWithId:self.identifier targetId:targetId callback:^(id  _Nonnull info) {
        NSLog(@"--");
        __strong typeof(weakSelf)strongSelf = weakSelf;
        [strongSelf didGetLikeActionNotiWithInfo:info];
    }];
}

#pragma mark - UIScrollView Delegate

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self dismissCommentPublishView];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // 有底线隐藏设置
    CGFloat sectionHeaderHeight = 41.f;
    if (scrollView.contentOffset.y<=sectionHeaderHeight && scrollView.contentOffset.y>=0) {
        scrollView.contentInset = UIEdgeInsetsMake(-scrollView.contentOffset.y, 0, 0, 0);
    } else if (scrollView.contentOffset.y>=sectionHeaderHeight) {
        scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, 0, 0);
    }
}

-(MGMSocialVoteService *)voteService{
    if (!_voteService) {
        _voteService = [[MGMSocialVoteService alloc]initWithDelegate:self];
    }
    return _voteService;
}
@end
