//
//  MGMTimeLineMainVC.h
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

//动态VC
#import <MGMDisplay/MGMPageController.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMTimeLineMainVC : MGMPageController

@end

NS_ASSUME_NONNULL_END
