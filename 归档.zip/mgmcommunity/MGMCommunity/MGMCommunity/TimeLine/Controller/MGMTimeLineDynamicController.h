//
//  MGMDiscoverController.h
//  MGMCommunity
// 职责：主要展示UGC列表，响应用户图片浏览、点赞、取消点赞、关注UGC用户，取消UGCh用户关注、举报UGC内容等事件
//  Created by apple on 2018/12/3.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MGMDisplay/MGMPageController.h>
#import <MGMSocialModule/MGMSocialFeeds.h>

typedef NS_ENUM(NSInteger, MGMTimeLineDynamicStyle)
{
    MGMTimeLineDynamicStyleRecommend,
    MGMTimeLineDynamicStyleFollow
};

@interface MGMTimeLineDynamicController : MGMPageController <MGMSocialFeedsDelegate>

@property (nonatomic, strong) MGMSocialFeeds *socialFeeds;

- (instancetype)initWithStyle:(MGMTimeLineDynamicStyle)style;

/**
 切换推荐，关注tab

 */
- (void)mgm_switchTimeLineStyle:(BOOL)appear;

@end
