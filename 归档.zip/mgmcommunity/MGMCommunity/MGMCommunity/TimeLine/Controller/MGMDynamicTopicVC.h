//
//  MGMDynamicTopicVC.h
//  MGMCommunity
//  动态话题页面
//  Created by YL on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMPageController.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMDynamicTopicVC : MGMPageController

@property (nonatomic, copy) NSString    *dynamicId;

- (void)mgm_switchTimeLineStyle:(BOOL)appear;

@end

NS_ASSUME_NONNULL_END
