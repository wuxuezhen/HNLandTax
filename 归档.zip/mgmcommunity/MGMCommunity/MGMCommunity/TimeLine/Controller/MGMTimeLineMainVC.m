//
//  MGMTimeLineMainVC.m
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLineMainVC.h"
#import "MGMTimeLineDynamicController.h"
#import "MGMTimeLineTabView.h"
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGMSocialModule/MGMSocialFollowFeeds.h>
#import <MGMSocialModule/MGMSocialRecommendFeeds.h>
#import <MGMStatistics/MGMPageController+MGMPV.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMDataStore/MGMDCommonSettingConfig.h>
#import <MGMDataStore/MGMDynamicTabsModel.h>
#import "MGMCommunity.h"
#import "MGMDynamicTopicVC.h"
#import <MGMRoute/MGMRoute.h>

#import "MGMDuiBaiRefreshEntranceView.h"
#import <YYCategories/YYCategories.h>
#import <MGMCategories/UIView+MGMFrame.h>

@interface MGMTimeLineMainVC ()<MGMTabPageSubtabSelection,UIScrollViewDelegate>

@property (nonatomic, strong) MGMTimeLineTabView           *topTabView;

@property (nonatomic, strong) UIScrollView                 *containerView;

@property (nonatomic, assign) NSInteger                    currentIndex;

@property (nonatomic, strong) NSMutableArray               *vcArrays;

@property (nonatomic, copy)  NSArray                       *tabsArray;

@property (nonatomic, assign) BOOL                         showRecommendTab;

@property (nonatomic, assign) BOOL                         showFollowTab;

@property (nonatomic, assign) BOOL                         isHiddenNavigation;
//记录隐藏Tabbar 当对白刷新入口时用到
@property (nonatomic,assign) BOOL                          isTabbarHidden;

@end

@implementation MGMTimeLineMainVC

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];

    if (self.isTabbarHidden)
    {
        [self mgm_hideTabbar:YES];
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
    else
    {
        [UIApplication sharedApplication].statusBarStyle = @available(iOS 13, *) ? UIStatusBarStyleDarkContent : UIStatusBarStyleDefault;
    }
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (self.isTabbarHidden)
    {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
    else
    {
        [UIApplication sharedApplication].statusBarStyle = @available(iOS 13, *) ? UIStatusBarStyleDarkContent : UIStatusBarStyleDefault;
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:self.isHiddenNavigation animated:YES];
    self.isHiddenNavigation = NO;
    [UIApplication sharedApplication].statusBarStyle = @available(iOS 13, *) ? UIStatusBarStyleDarkContent : UIStatusBarStyleDefault;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.isHiddenNavigation = NO;
    [self setupDynamicTabsWithArray:[MGMDCommonSettingConfig shareConfig].dynamicTabsArray];
    
    /**  http://jira.cmvideo.cn/browse/MGYYKF-971   */
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(routeMoviePage:) name:@"MGMTimeLineDynamicControllerDumpMoviePage" object:nil];
    
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)routeMoviePage:(NSNotification *)notifi{
    self.isHiddenNavigation = YES;
}

#pragma mark - Private
- (void)setupDynamicTabsWithArray:(NSArray <MGMDynamicTabsModel *>*)tabsArray {
    self.view.backgroundColor = [UIColor whiteColor];
    self.tabsArray = tabsArray;
    self.topTabView = [[MGMTimeLineTabView alloc] initWithFrame:CGRectMake(0, 0, MGMScreenW, MGMStatusBarH+MGMNavigationBarH) tabs:tabsArray];
    self.topTabView.backgroundColor = [UIColor whiteColor];
    MGMWeakSelf
    self.topTabView.dynamicTabClickHandler = ^(NSInteger index) {
        MGMStrongSelf
        [self mgm_switchDynamicTabIndex:index];
    };
    [self.view addSubview:self.topTabView];
    [self.view addSubview:self.containerView];
    
    CGFloat scrollHeight = MGMScreenH-MGMNavigationBarH-MGMStatusBarH-MGMTabBarH;
    [tabsArray enumerateObjectsUsingBlock:^(MGMDynamicTabsModel *tabModel, NSUInteger idx, BOOL * _Nonnull stop) {
        if([tabModel.dynamicId isEqualToString:MGMDynamicFollowId]) { // 关注
            MGMTimeLineDynamicController *followVc = [[MGMTimeLineDynamicController alloc] initWithStyle:(MGMTimeLineDynamicStyleFollow)];
            MGMSocialFollowFeeds *followFeeds = [[MGMSocialFollowFeeds alloc] initWithDelegate:followVc];
            followVc.socialFeeds = followFeeds;
            followVc.billboard = self.billboard;
            [self addChildViewController:followVc];
//            followVc.view.frame  = CGRectMake(idx*MGMScreenW, 0, MGMScreenW, scrollHeight);
//            [self.containerView addSubview:followVc.view];
            [self.vcArrays addObject:followVc];
            if(idx == 0) {
                [followVc mgm_switchTimeLineStyle:YES];
            }
        }
        else if ([tabModel.dynamicId isEqualToString:MGMDynamicRecommendId]) {//精选推荐
            MGMTimeLineDynamicController *recommendVc = [[MGMTimeLineDynamicController alloc] initWithStyle:(MGMTimeLineDynamicStyleRecommend)];
            MGMSocialRecommendFeeds *recommendFeeds = [[MGMSocialRecommendFeeds alloc] initWithDelegate:recommendVc];
            recommendVc.socialFeeds = recommendFeeds;
            recommendVc.billboard = self.billboard;
            [self.vcArrays addObject:recommendVc];
//            recommendVc.view.frame = CGRectMake(idx*MGMScreenW, 0, MGMScreenW, scrollHeight);
//            [self.containerView addSubview:recommendVc.view];
            [self addChildViewController:recommendVc];
            if(idx == 0) {
                [recommendVc mgm_switchTimeLineStyle:YES];
            }
        }
        else {//话题
            MGMDynamicTopicVC *topicVC = [[MGMDynamicTopicVC alloc] init];
            topicVC.dynamicId = tabModel.dynamicId;
            topicVC.billboard = self.billboard;
//            topicVC.view.frame = CGRectMake(idx*MGMScreenW, 0, MGMScreenW, scrollHeight);
//            [self.containerView addSubview:topicVC.view];
            [self addChildViewController:topicVC];
            [self.vcArrays addObject:topicVC];
            if(idx == 0) {
                [topicVC mgm_switchTimeLineStyle:YES];
            }
        }
    }];
    
    self.containerView.contentSize = CGSizeMake(MGMScreenW*self.vcArrays.count,scrollHeight );
    
    if (self.currentIndex == 0)
    {
        [self mgm_addTimeLinePVStatistics];
        [self mgm_controllerDidAppearWithTabIndex:0];
    }
    else
    {
        [self mgm_switchDynamicTabIndex:self.currentIndex];
    }
}

- (void)routerEventWithName:(NSString *)eventName userInfo:(NSDictionary *)userInfo
{
    //对白刷新入口隐藏tarbar和topTabView
    if ([eventName isEqualToString:@"MGMTimeLineDynamicDuiBaiHiddenNavigationAciton"])
    {
        NSString *hiddenStr = [userInfo mgu_objectOrNilForKey:@"isHidden"];
        [self mgm_duiBaiRefreshHidenNavitaionWithHiddenStr:hiddenStr];
    }
    
    //对白刷新时控底部View滚动能力
    if ([eventName isEqualToString:@"MGMTimeLineDynamicDuiBaiRefreshingBackViewScrollEnabledAciton"])
    {
        NSString *scrollEnabledStr = [userInfo mgu_objectOrNilForKey:@"scrollEnabled"];
        self.containerView.scrollEnabled = [scrollEnabledStr isEqualToString:@"yes"];
    }
    
    if ([eventName isEqualToString:MGMCommunityPhotoClickEvent])
    {
        self.isHiddenNavigation = YES;
    }
}

#pragma mark - Private methods
- (void)mgm_switchDynamicTabIndex:(NSInteger)index {
    CGRect scrollRect = CGRectMake(self.containerView.width*index, 0, self.containerView.width, self.containerView.height);
    [self.containerView scrollRectToVisible:scrollRect
                                    animated:YES];
    self.topTabView.currentIndex = index;
    [self mgm_addTimeLinePVStatistics];
}

//对白刷新导航栏和tabbar展示和隐藏处理
-(void)mgm_duiBaiRefreshHidenNavitaionWithHiddenStr:(NSString *)hiddenStr
{
    if([hiddenStr isEqualToString:@"yse"])
    {
        //隐藏
        self.extendedLayoutIncludesOpaqueBars = YES;
        self.edgesForExtendedLayout = UIRectEdgeBottom;
        self.containerView.scrollEnabled = NO;
        [self.view layoutIfNeeded];
        [UIView animateWithDuration:0.5 animations:^{
            self.topTabView.frame = CGRectMake(0, -(MGMStatusBarH+MGMNavigationBarH), MGMScreenW, MGMStatusBarH+MGMNavigationBarH);
            self.containerView.frame = CGRectMake(0, 0, MGMScreenW, MGMScreenH);
            [self.view layoutIfNeeded];
            [self mgm_hideTabbar:YES];
        }completion:^(BOOL finished) {
            [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
        }];
    }
    else
    {
        //展现
        self.extendedLayoutIncludesOpaqueBars = NO;
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.containerView.scrollEnabled = YES;
        [self.view layoutIfNeeded];
        [UIView animateWithDuration:0.5 animations:^{
            self.topTabView.frame = CGRectMake(0, 0, MGMScreenW, MGMStatusBarH+MGMNavigationBarH);
            self.containerView.frame = CGRectMake(0, MGMStatusBarH+MGMNavigationBarH, MGMScreenW, MGMScreenH - MGMStatusBarH - MGMNavigationBarH - MGMTabBarH);
            [self mgm_hideTabbar:NO];
            [self.view layoutIfNeeded];
        }completion:^(BOOL finished) {
            [UIApplication sharedApplication].statusBarStyle = @available(iOS 13, *) ? UIStatusBarStyleDarkContent : UIStatusBarStyleDefault;
        }];
    }
}

//动态隐藏Tabbar
- (void)mgm_hideTabbar:(BOOL)hide
{
    self.tabBarController.tabBar.hidden = hide;
    self.hidesBottomBarWhenPushed = hide;
    self.isTabbarHidden = hide;
    // 调整view的大小
    UIView *tabbarView = self.tabBarController.view;
    if (hide)
    {
        self.view.frame = tabbarView.bounds;
    }
    else
    {
        self.view.frame = CGRectMake(tabbarView.bounds.origin.x, tabbarView.bounds.origin.y, tabbarView.bounds.size.width, tabbarView.bounds.size.height - self.tabBarController.tabBar.frame.size.height);
    }
}

#pragma mark - UIScrollView Delegate
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    
    NSInteger currentIndex = scrollView.contentOffset.x / self.containerView.width;
    
    [self mgm_switchDynamicTabIndex:currentIndex];
    
    [self mgm_controllerDidAppearWithTabIndex:currentIndex];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    NSInteger currentIndex = scrollView.contentOffset.x / self.containerView.width;
    
    [self mgm_switchDynamicTabIndex:currentIndex];
    
    [self mgm_controllerDidAppearWithTabIndex:currentIndex];
}

- (void)mgm_controllerDidAppearWithTabIndex:(NSInteger)index {
    UIViewController *childVc = [self.vcArrays mgu_objectOrNilAtIndex:index];
    if (![childVc isViewLoaded])
    {
        childVc.view.frame = CGRectMake(index*MGMScreenW, 0, MGMScreenW, self.containerView.contentSize.height);
        [self.containerView addSubview:childVc.view];
    }
    
    UIViewController *lastVC = [self.vcArrays mgu_objectOrNilAtIndex:self.currentIndex];
    //disappear last index
    if([lastVC isKindOfClass:[MGMTimeLineDynamicController class]]) {
        MGMTimeLineDynamicController *dynamicVC = lastVC;
        [dynamicVC mgm_switchTimeLineStyle:NO];
    }
    else if ([lastVC isKindOfClass:[MGMDynamicTopicVC class]]) {
        MGMDynamicTopicVC *topicVC = lastVC;
        [topicVC mgm_switchTimeLineStyle:NO];
    }
    self.currentIndex = index;
    //appear currentIndex
    UIViewController *currentVC = [self.vcArrays mgu_objectOrNilAtIndex:self.currentIndex];
    if([currentVC isKindOfClass:[MGMTimeLineDynamicController class]]) {
        MGMTimeLineDynamicController *curDynamicVC = currentVC;
        [curDynamicVC mgm_switchTimeLineStyle:YES];
    }
    else if ([currentVC isKindOfClass:[MGMDynamicTopicVC class]]) {
        MGMDynamicTopicVC *curTopicVC = currentVC;
        [curTopicVC mgm_switchTimeLineStyle:YES];
    }
}

//添加动态PV埋点
- (void)mgm_addTimeLinePVStatistics {
    MGMDynamicTabsModel *tabModel = [self.tabsArray mgu_objectOrNilAtIndex:self.currentIndex];
    if([tabModel.dynamicId isEqualToString:MGMDynamicRecommendId] && !self.showRecommendTab ) {
        self.showRecommendTab = YES;
        [self mgm_addRootPVStatisticsWithLocation:@"MV_HOME_DYNAMIC_PAGE" pageId:@"MV_DISCOVERY_PAGE" index:1];
    }
    else if ([tabModel.dynamicId isEqualToString:MGMDynamicFollowId] && !self.showFollowTab) {
        self.showFollowTab = YES;
        [self mgm_addRootPVStatisticsWithLocation:@"MV_HOME_DYNAMIC_PAGE" pageId:@"MV_FOLLOW_PAGE" index:2];
    }
}

#pragma mark - MGMTabPageSubtabSelection
- (void)subtabSelectedIndex:(NSInteger)index
{
    if (self.tabsArray.count < 1)
    {
        self.currentIndex = index;
    }
    else
    {
        if(self.topTabView.currentIndex == index) {
            return;
        }
        [self mgm_switchDynamicTabIndex:index];
    }
}

#pragma mark - lazyload
- (UIScrollView *)containerView {
    if(!_containerView) {
        CGFloat containerViewY = CGRectGetMaxY(self.topTabView.frame);
        CGFloat containerViewH = MGMScreenH - containerViewY - MGMTabBarH;
        _containerView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, containerViewY, MGMScreenW, containerViewH)];
        _containerView.pagingEnabled = YES;
        _containerView.delegate = self;
        _containerView.showsHorizontalScrollIndicator = NO;
        _containerView.bounces = NO;
    }
    return _containerView;
}

- (NSMutableArray *)vcArrays {
    if(!_vcArrays) {
        _vcArrays = [[NSMutableArray alloc] initWithCapacity:1];
    }
    return _vcArrays;
}

@end
