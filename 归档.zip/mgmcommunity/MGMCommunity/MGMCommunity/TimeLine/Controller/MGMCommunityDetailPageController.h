//
//  MGMCommunityDetailPageController.h
//  MGMCommunity
// 职责：主要展示UGC详情、用户评论，
// 1. 响应用户图片浏览、点赞、取消点赞、关注UGC用户，取消UGCh用户关注、举报UGC内容等事件，
// 2. 添加对UGC的评论、以及对评论进行点赞和取消点赞
// 3. 查看评论详情跳转
//
//  Created by apple on 2018/12/19.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMPageController.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMCommunityDetailPageController : MGMPageController

@end

NS_ASSUME_NONNULL_END
