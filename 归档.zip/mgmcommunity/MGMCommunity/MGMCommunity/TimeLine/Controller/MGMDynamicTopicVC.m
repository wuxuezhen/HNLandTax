//
//  MGMDynamicTopicVC.m
//  MGMCommunity
//
//  Created by YL on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicTopicVC.h"
#import "MGMCommunity.h"
#import "MGMCommunityGotoLogin.h"
#import "MGMCommunityUGCModel.h"
#import "MGMTimeLineGKeModel.h"
#import "MGMTimeLineImageTextModel.h"

#import "MGMDynamicTopicHeadView.h"
#import "MGMCommentTabView.h"
#import "MGMCommunityResource.h"
#import "MGMPublishTimeLineVC.h"
#import "MGMGKeTimeLineCell.h"
#import "MGMImageAndTextTimeLineCell.h"
#import "MGMPageController+MGMDynamic.h"
#import "MGMCommunityReportManager.h"

#import <Masonry/Masonry.h>
#import <MGMRoute/MGMRoute.h>
#import <MGMRoute/MGMRouteUGCParams.h>
#import <MGMDataStore/MGMDSUser.h>
#import <MGMLogin/MGMLoginManager.h>
#import <MGMUIKit/MGMUGCVote.h>
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGMUIKit/MGMNetReloaderView.h>
#import <MGMUIKit/MGMRefrshGifHeader.h>
#import <MGMUIKit/MGMCommentEmptyView.h>
#import <MGMUIKit/MGMProgressHUD+MGMConfig.h>
#import <MGMUIKit/MGMRefreshAutoFooter.h>
#import <MGMCategories/UIView+MGMFrame.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMSocialModule/MGMSocialDynamicPub.h>
#import <MGMSocialModule/MGMSocialFetchTopicFeeds.h>
#import <MGMSocialModule/MGMDynamicFetchTopicListInfo.h>
#import <MGMDataProcessingKit/MGMDataSyncManager.h>
#import <MGThirdKit/AFNetworking_mgs.h>

#import <MGMDataProcessingKit/MGMSocialVoteService.h>
#import <MGMHttpApiModel/MGMSocialVoteContentModel.h>

#define MGMSectionHeaderViewH   51.f
#define MGMDynamicTopicHeadViewHeight (MGMScaleValue(97)+20)

@interface MGMDynamicTopicVC ()<UITableViewDelegate,UITableViewDataSource,MGMCommentTabViewDelegate,MGMPublishTimeLineVCDelegate,MGMSocialFeedsDelegate,MGMSocialDynamicPubDelegate,MGMDynamicFeedItemDelegate,MGMSocialDelegate,MGMDynamicFetchTopicListInfoDelegate,MGMSocialVoteServiceDelegate>

@property (nonatomic, assign) CGFloat lastContentOffsetY;
@property (nonatomic, assign) NSInteger publishCount;
@property (nonatomic, assign, getter=isDismissIndicator) BOOL dismissIndicator;

@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, weak) UIButton *publishBtn;
@property (nonatomic, weak) MGMTimeLineBaseCell *toastCell;
@property (nonatomic, strong) UIView *publishView;
@property (nonatomic, strong) UITableView *topicTableView;
@property (nonatomic, strong) UINavigationController *publishVc;
@property (nonatomic, strong) MGMCommentTabView *commentTabView;
@property (nonatomic, strong) MGMCommentEmptyView *commentEmptyView;
@property (nonatomic, strong) MGMDynamicTopicHeadView *topicHeadView;

@property (nonatomic, strong) MGMNetReloaderView *netReloadView;
@property (nonatomic, strong) MGMDynamicModel *deleteTopicModel;
@property (nonatomic, strong) NSMutableArray <__kindof MGMDynamicModel *>*topicModelM;
@property (nonatomic, strong) NSMutableArray <__kindof MGMDynamicModel *>*likeTopicModelM;
@property (nonatomic, strong) NSMutableArray <__kindof MGMDynamicModel *>*dislikeTopicModelM;
@property (nonatomic, strong) NSMutableArray <__kindof MGMDynamicModel *>*followTopicModelM;

@property (nonatomic, strong) MGMSocialDynamicPub *topicPublish;
@property (nonatomic, weak)  MGMSocialFetchTopicFeeds *topicFeeds;
@property (nonatomic, strong) MGMSocialFetchTopicFeeds *hotestTopicFeeds;
@property (nonatomic, strong) MGMSocialFetchTopicFeeds *latestTopicFeeds;

//获取话题信息
@property (nonatomic, strong) MGMDynamicFetchTopicListInfo *fetchDynamicTopicRequest;

/**
   投票服务
*/
@property (nonatomic, strong) MGMSocialVoteService *voteService;
@property (nonatomic, assign) NSInteger currentVoteIndex;
@property (nonatomic, strong) id voteInfoChangObId;

@end

@implementation MGMDynamicTopicVC

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self mgm_switchTimeLineStyle:NO];  //停止播放
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialize];
    [self addNotificationObserver];
    [self loadTopicCommentList];
}

#pragma mark - private methods
- (void)mgm_switchTimeLineStyle:(BOOL)appear {
    if(!appear) {
        [self.topicTableView reloadData];
    }
}

- (void)initialize {
    
    [self.view addSubview:self.topicTableView];
    
    UIButton *publishBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [publishBtn setBackgroundImage:[MGMCommunityResource imageNamed:@"icon_fb"] forState:UIControlStateNormal];
    [publishBtn addTarget:self
                   action:@selector(publishButtonAction)
         forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:publishBtn];
    self.publishBtn = publishBtn;
    
    [publishBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-8.f);
        make.bottom.offset(-11.f);
        make.size.mas_equalTo(CGSizeMake(64.f, 64.f));
    }];
    
    self.topicFeeds = self.latestTopicFeeds;
}

- (void)addNotificationObserver
{
    self.identifier = [NSString stringWithFormat:@"%p",self];
    MGMWeakSelf;
    [[MGMDataSyncManager sharedManager] observerDeleteDynamicWithIdentifer:self.identifier usingBlock:^(NSString * _Nonnull dynamicId) {
        MGMStrongSelf;
        //  动态详情点击删除, 进行删除操作
        [self deleteTopicCellWithFeedId:dynamicId];
    }];
    
    //  登录和注销时投票数据需要更新，所以需要监听登录和注销状态
    [[NSNotificationCenter defaultCenter] addObserver:self
                                              selector:@selector(loginSuccess)
                                                  name:MGMLoginSuccessNotification
                                                object:nil];
     
    [[NSNotificationCenter defaultCenter] addObserver:self
                                              selector:@selector(loginOut)
                                                  name:MGMUserLogoutNotification
                                                object:nil];
    
    self.voteInfoChangObId = [[NSNotificationCenter defaultCenter] addObserverForName:@"MGMUpdateVoteInfoNSNotification"
                                                                               object:nil
                                                                                queue:[NSOperationQueue mainQueue]
                                                                           usingBlock:^(NSNotification * _Nonnull note) {
        [weakSelf getBackFromDynamicDetailWithVoteInfo:note.userInfo];
    }];
}

/**
    加载话题评论列表
 */
- (void)loadTopicCommentList
{
    BOOL result = [self.topicFeeds fetchFeeds];
}

/**
    刷新列表
 */
- (void)mgm_pullDownToRefreshData
{
    [self loadTopicCommentList];
}

/**
   上拉加载更多
*/
- (void)mgm_sendMoreTopicData
{
    BOOL result = [self.topicFeeds fetchMore];
}

/**
    显示动态发布指示器
 */
- (void)showPublishViewWithStatus:(MGMDyanmicPublishStatus)status prompt:(NSString *)prompt
{
    [self mgm_showPublishView:self.publishView
                 publishCount:self.publishCount
                       status:status
                       prompt:prompt];
    
    CGFloat offsetY = self.publishView.mgm_height;
    [self mgm_adjustContentInset:UIEdgeInsetsMake(offsetY, 0, 0, 0)
                   contentOffset:CGPointMake(0, -offsetY)
                     forListView:self.topicTableView];
}

/**
    移除动态发布指示器
 */
- (void)dismissPublishView
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!self.isDismissIndicator) return;
        
        [self mgm_dismissPublishView:self.publishView];
        [self mgm_resetListView:self.topicTableView];
        _publishView = nil;
    });
}

/**
    点赞话题评论内容

 @param like       YES:点赞/NO:取消点赞
 @param topicModel 话题评论模型
 */
- (void)likeTopicComment:(BOOL)like topicModel:(MGMDynamicModel *)topicModel
{
    MGMDynamicFeedItem *feedItem = topicModel.feedItem;
    feedItem.delegate = self;
    MGMSocialLike likeType = [MGMSocialDynamicTools likeTypeForDynamicType:topicModel.feedItem.content.contentType];
    NSString *feedId = [feedItem.content fetchKeyId];
    //区分图文ugc和剧照
    NSString *extension = [NSString stringWithFormat:@"%ld",feedItem.content.contentType];
    if (like)
    {
        [self.likeTopicModelM addObject:topicModel];
        [feedItem likeWithObjectId:feedId type:likeType index:1 extension:extension];
    }
    else
    {
        [self.dislikeTopicModelM addObject:topicModel];
        [feedItem unlikeWithObjectId:feedId type:likeType index:1];
    }
}

/**
    删除动态内容
 */
- (void)deleteDynamicContent
{
    self.deleteTopicModel.feedItem.delegate = self;
    [self.deleteTopicModel.feedItem remove];
}

/**
    删除动态内容

 @param feedId 动态ID
 */
- (void)deleteTopicCellWithFeedId:(NSString *)feedId
{
    for (MGMDynamicModel *topicModel in self.topicModelM) {
        if ([topicModel.feedId isEqualToString:feedId])
        {
            self.deleteTopicModel = topicModel;
            break;
        }
      }
    if (!self.deleteTopicModel) return;
    
    [self.topicModelM removeObject:self.deleteTopicModel];
    self.deleteTopicModel = nil;
    
    [UIView performWithoutAnimation:^{
        [self.topicTableView reloadData];
    }];
}

/**
    关注用户

 @param topicModel 动态内容模型
 */
- (void)followUserWithTopicModel:(MGMDynamicModel *)topicModel
{
    [self.followTopicModelM addObject:topicModel];
    MGMSocialUser *user = topicModel.feedItem.user;
    user.delegate = self;
    [user follow];
}

/**
    跳转小视频详情页

 @param contentId   节目ID
 @param contentName 节目名字
 */
- (void)pushFilmPreviewPageControllerWithContentId:(NSString *)contentId
                                       contentName:(NSString *)contentName
                                              type:(NSString *)type
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MGMTimeLineDynamicControllerDumpMoviePage" object:nil userInfo:nil];
    [MGMRoute routePageControllerWithName:@"film_preview"
                               parameters:@{
                                            @"contentId": contentId,
                                            @"contentName": contentName,
                                            @"type": type
                                            }
                          transitionStyle:(MGURouteTransitionStyleNav)];
}

/**
    弹出举报alert
 */
- (void)popReportAlertView
{
    self.toastCell = nil;
    [MGMCommunityReportManager resportUGCWithObjectOnVC:self handler:^(NSString * _Nonnull actionTitle) {}];
}

/**
    弹出删除提示框
 */
- (void)popDeleteAlertView
{
    MGMWeakSelf;
    [self mgm_popDeleteAlertViewWithCancelHandler:^(UIAlertAction * _Nonnull cancelAction) {
        MGMStrongSelf;
        [self.toastCell dismissToastView];

    } confirmHandler:^(UIAlertAction * _Nonnull confirmAction) {
        MGMStrongSelf;
        [self.toastCell dismissToastView];
        [self deleteDynamicContent];
    }];
}

- (void)setDynamicId:(NSString *)dynamicId {
    _dynamicId = dynamicId;
    
    [self sendDynamicToipInfoRequest];
}

/// 用户从动态详情返回，如果投票状态改变则会回调该事件
- (void)getBackFromDynamicDetailWithVoteInfo:(NSDictionary *)voteInfo
{
    NSString *feedId         = voteInfo[@"feedId"];
    NSArray *voteOptions     = voteInfo[@"voteOptions"];
    NSInteger totalVoteCount = [voteInfo[@"totalVoteCount"] integerValue];
    if (!feedId) return;
    
    MGMDynamicModel *updateDynamicModel = nil;
    NSInteger index = NSNotFound;
    for (MGMDynamicModel *model in self.topicModelM) {
        if ([model.feedId isEqualToString:feedId]) {
            updateDynamicModel = model;
            index = [self.topicModelM indexOfObject:model];
            break;
        }
    }
    
    if (updateDynamicModel){
        updateDynamicModel.voteContent.voteOptions = voteOptions;
        updateDynamicModel.voteContent.totalVoteUserCount = totalVoteCount;
        [UIView performWithoutAnimation:^{
            [self.topicTableView reloadData];
        }];
    }
}

#pragma mark - Target Action

- (void)loginSuccess
{
    [self loadTopicCommentList];
}

- (void)loginOut
{
    [self loadTopicCommentList];
}

- (void)publishButtonAction
{
    [self mgm_presentPublishPageController:self.publishVc];
}

- (void)routerEventWithName:(NSString *)eventName userInfo:(NSDictionary *)userInfo
{
    MGMDynamicModel *extraInfo = userInfo[MGMCommunityExtraInfo];
    NSInteger index = [self.topicModelM indexOfObject:extraInfo];
    BOOL handle = [self mgm_shouldHandleEventName:eventName
                                         userInfo:userInfo
                                         position:NSNotFound
                                         location:nil];
    if (handle) return;
    
    //  小视频事件
     if ([eventName isEqualToString:MGMCommunityMiniVideoEvent])
     {
         NSString *contentId = userInfo[MGMCommunityMiniVideoContentID];
         [self pushFilmPreviewPageControllerWithContentId:contentId
                                              contentName:userInfo[MGMCommunityMiniVideoContentName]
                                                     type:userInfo[MGMCommunityMiniVideoType]];
     }
    //  图文或剧照整体事件
     else if ([eventName isEqualToString:MGMCommunityImageTextClickEvent] ||
              [eventName isEqualToString:MGMCommunityImageTextMainCommentEvent])
     {
         MGMRouteUGCParams *ugcParams = [[MGMRouteUGCParams alloc] init];
         ugcParams.topicId = extraInfo.mid;
         ugcParams.extraInfo = extraInfo;
         [MGMRoute routePageControllerWithName:@"community_postDetail"
                                    parameters:ugcParams
                               transitionStyle:(MGURouteTransitionStyleNav)];
     }
    //  更多事件
    else if ([eventName isEqualToString:MGMCommunityMoreEvent])
    {
        MGMTimeLineBaseCell *clickReportCell = userInfo[MGMCommunityMainInfo];
        if (![self.toastCell isEqual:clickReportCell])
        {
            [self.toastCell dismissToastView];
            self.toastCell = clickReportCell;
        }
    }
    //  举报事件
    else if ([eventName isEqualToString:MGMCommunityReportEvent])
    {
        [self popReportAlertView];
    }
    //  关注事件
    else if ([eventName isEqualToString:MGMCommunityFollowEvent])
    {
        if ([MGMDSUser user].isLogin)
        {
            if (!extraInfo) return;
            
            [self followUserWithTopicModel:extraInfo];
        }
        else
        {
            [[MGMLoginManager shareManager] loginFromViewController:self showType:(MGMLoginShowTypePresent) isBackButtonHide:NO success:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
                
            } fail:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
                
            }];
        }
    }
    //  点赞事件
    else if ([eventName isEqualToString:MGMCommunityLikeEvent])
    {
        if (![MGMCommunityGotoLogin shouldGotoLoginWithType:1 backButton:NO inController:self]) {
            BOOL like = [userInfo[MGMCommunityLikeInfo] boolValue];
            [self likeTopicComment:like topicModel:extraInfo];
        }
    }
    //  删除事件
    else if ([eventName isEqualToString:MGMCommunityDeleteEvent])
    {
        self.deleteTopicModel = extraInfo;
        [self popDeleteAlertView];
    }else if ([eventName isEqualToString:MGMUIKitVoteClickEvent])
    {   // 投票
       if ([MGMDSUser user].token == nil){
            [[MGMLoginManager shareManager] verifyLoginStateSuccess:^{} failure:^{}];
       }else{
           BOOL userClickEnbled = [userInfo[MGMUIKitVoteUserClickEnbled] boolValue];
           if (userClickEnbled) {
               self.currentVoteIndex = index;
               NSString *voteId = userInfo[MGMUIKitVoteContentID];
               NSString *optionId = userInfo[MGMUIKitVoteOptionID];
               [self.voteService voteSocialContentWithVoteId:voteId optionId:optionId];
           }
       }
    }
}

#pragma mark - MGMTimeLineVote Delegate
- (void)socialVoteServiceDidFinishVoteWithData:(NSArray<MGMSocialVoteOptionModel *> *)data
                                totalVoteCount:(NSInteger)totalVoteCount
                                         error:(NSError *)error{
    if (error) {
        [MGMProgressHUD showAutoHiddeText:[error.userInfo objectForKey:NSLocalizedDescriptionKey]];
    }else{
        MGMDynamicModel *contentBodyModel = [self.topicModelM mgu_objectOrNilAtIndex:self.currentVoteIndex];
        if (contentBodyModel) {
            contentBodyModel.voteContent.voteOptions = data;
            contentBodyModel.voteContent.totalVoteUserCount = totalVoteCount;
            for (MGMTimeLineBaseCell *cell in [self.topicTableView visibleCells]) {
                if ([cell isKindOfClass:MGMTimeLineBaseCell.class]) {
                    if ([cell.timeLineModel isEqual:contentBodyModel]) {
                        cell.timeLineModel = contentBodyModel;
                        break;
                    }
                }
            }
        }
    }
}

#pragma mark - UIScrollView Delegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //  下拉刷新发布按钮保持显示
    if (scrollView.contentOffset.y <= 0 )
    {
        self.publishBtn.hidden = NO;
        return;
    }
    //  向上滚动显示发布按钮
    self.publishBtn.hidden = !(self.lastContentOffsetY > scrollView.contentOffset.y);
    self.lastContentOffsetY = scrollView.contentOffset.y;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if (self.toastCell)
    {
        [self.toastCell dismissToastView];
        self.toastCell = nil;
    }
}

#pragma mark -UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.topicModelM.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *reuseID = nil;
    MGMDynamicModel *topicModel = [self.topicModelM mgu_objectOrNilAtIndex:indexPath.row];
    if (MGMTimeLineTypeImageText == topicModel.timeLineType)
    {
        reuseID = NSStringFromClass(MGMImageAndTextTimeLineCell.class);
    }
    else if (MGMTimeLineTypeGKe == topicModel.timeLineType)
    {
        reuseID = NSStringFromClass(MGMGKeTimeLineCell.class);
    }
    MGMTimeLineBaseCell *topicCell = [tableView dequeueReusableCellWithIdentifier:reuseID
                                                                forIndexPath:indexPath];
    topicCell.timeLineModel  = topicModel;
    topicCell.hideSeperateLine = ((self.topicModelM.count - 1) == indexPath.row);
    [topicCell setupBillboard:self.billboard];
    return topicCell;
}

#pragma mark -UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MGMDynamicModel *topicModel = [self.topicModelM mgu_objectOrNilAtIndex:indexPath.row];
    return topicModel.rowHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return MGMSectionHeaderViewH;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return self.commentTabView;
}

- (void)tableView:(UITableView *)tableView didEndDisplayingCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath*)indexPath {
    
    if([cell isKindOfClass:NSClassFromString(@"MGMGKeTimeLineCell")]) {
        MGMGKeTimeLineCell *gkeCell = cell;
        [gkeCell willDisappear];
    }
}
#pragma mark - MGMCommentTabView Delegate

- (void)commentTabView:(MGMCommentTabView *)commentTabView didSelectType:(MGMCommentType)type
{
    if (MGMCommentTypeLatest == type)
    {
        self.topicFeeds = self.latestTopicFeeds;
    }
    else
    {
        self.topicFeeds = self.hotestTopicFeeds;
    }
    [self loadTopicCommentList];
}

#pragma mark - MGMPublishTimeLineVC Delegate

- (void)dynamicPublishStart
 {
    self.publishCount++;
    [self showPublishViewWithStatus:(MGMDyanmicPublishStatusSending) prompt:nil];
    self.dismissIndicator = YES;
}

- (void)dynamicPublishEndWithError:(NSError *)error prompt:(nonnull NSString *)prompt{
    
    self.dismissIndicator = NO;
    //  通过延迟保证"正在发布动态文案显示"
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.publishCount--;
        if (!error)
        {
            [self showPublishViewWithStatus:(MGMDyanmicPublishStatusSuccess) prompt:@"发布成功，小编正在加速审核"];
            self.publishVc = nil;
        }
        else
        {
            [self showPublishViewWithStatus:(MGMDyanmicPublishStatusFailure) prompt:prompt];
        }
        [self dismissPublishView];
        self.dismissIndicator = YES;
    });
}

- (void)publishPageCloseButtonDidClicked
{
    self.publishVc = nil;
}

#pragma mark - MGMSocialFeeds Delegate
- (void)fetchFeedItems:(nullable NSArray <MGMDynamicFeedItem *> *)feedItems error:(nullable NSError *)error
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (error)
        {
            [self.topicTableView.mj_footer endRefreshing];
            [self.topicTableView.mj_header endRefreshing];

            if (error.code == MGMDMErrorCodeAPIResponseNoMoreData)
            {
                if (!self.topicModelM.count)
                {
                    self.topicTableView.mj_footer.hidden = YES;
                    self.topicTableView.tableFooterView = self.commentEmptyView;
                }
                else
                {
                    self.topicTableView.mj_footer.hidden = NO;
                    [self mgm_hideRefreshFooterWithListView:self.topicTableView
                                                 totalCount:self.topicModelM.count];
                }
            }
            else
            {
                [self.netReloadView showInView:self.view];
            }
        }
        else
        {
            //  移除无数据时的占位图
            if (_commentEmptyView)
            {
                _commentEmptyView = nil;
                self.topicTableView.mj_footer.hidden = NO;
                self.topicTableView.tableFooterView = nil;
            }
            
            //  下拉刷新
            if ([self.topicTableView.mj_header isRefreshing] || ![self.topicTableView.mj_footer isRefreshing])
            {
                [self.topicTableView.mj_header endRefreshing];
                [self mgm_resetRefreshFooterWithListView:self.topicTableView];
                [self.topicModelM removeAllObjects];
            }
            //  上拉加载
            else if ([self.topicTableView.mj_footer isRefreshing])
            {
                [self.topicTableView.mj_footer endRefreshing];
            }
            //  点击tab切换
            else if (![self.topicTableView.mj_header isRefreshing] || ![self.topicTableView.mj_footer isRefreshing])
            {
                [self.topicModelM removeAllObjects];
            }
            
            MGMDynamicModel *topicModel = nil;
            for (MGMDynamicFeedItem *item in feedItems)
            {
                switch (item.content.contentType) {
                        //  图文
                    case MGMSocialDynamicContentTypeMicroblog:
                    {
                        topicModel = [[MGMTimeLineImageTextModel alloc] initWithFeedItem:item];
                    }
                        break;

                    //  G客
                    case MGMSocialDynamicContentTypeGKeVideo:
                    {
                        topicModel = [[MGMTimeLineGKeModel alloc] initWithFeedItem:item];
                    }
                        break;
                }
                if (!topicModel) continue;
                
                //  防止数据重复问题
                NSArray <NSString *>*feedIds = [self.topicModelM valueForKeyPath:@"feedId"];
                if ([feedIds containsObject:topicModel.feedId]) continue;
                
                [self.topicModelM addObject:topicModel];
            }
            [self.topicTableView reloadData];
        }
    });
}

#pragma mark - MGMDynamicFetchTopicListInfoDelegate
- (void)fetchTopicList:(nullable NSArray <MGMDynamicTopicItemModel *>*)topics error:(nullable NSError *)error {
    if(topics.count > 0) {
        self.topicHeadView.topicItemModel = [topics mgu_objectOrNilAtIndex:0];
        self.topicTableView.tableHeaderView = self.topicHeadView;
        [self.topicTableView reloadData];
    }
}

#pragma mark - MGMSocial Delegate

- (void)followUser:(NSString *)userId withError:(NSError *)error
{
    if (error) return;
    
    MGMDynamicModel *followDynamicModel = nil;
    for (MGMDynamicModel *dynamicModel in self.followTopicModelM) {
        if ([dynamicModel.userId isEqualToString:userId])
        {
            followDynamicModel = dynamicModel;
            followDynamicModel.relationType = MGMSocialUserRelationFollowing;
            break;
        }
    }
    
    if (followDynamicModel)
    {
        NSString *dynamicId = followDynamicModel.feedId;
        [self.followTopicModelM removeObject:followDynamicModel];
        
        [self.topicTableView reloadData];
        [MGMProgressHUD showAutoHiddeText:@"关注成功"];
    }
}

#pragma mark - MGMDynamicFeedItem Delegate

- (void)removeDynamicFeedWithFeedId:(NSString *)feedId Error:(NSError *)error
{
    if (error)
    {
        NSLog(@"removeDynamic error = %@",error.localizedDescription);
        return;
    }
    [self deleteTopicCellWithFeedId:feedId];
}

- (void)likeDynamicFeedWithFeedId:(NSString *)feedId Error:(NSError *)error
{
    if (error)
    {
        NSLog(@"likeTopicComment error = %@",error.localizedDescription);
        return;
    }
}

- (void)unlikeDynamicFeedWithFeedId:(NSString *)feedId Error:(NSError *)error
{
    if (error)
    {
        NSLog(@"unlikeTopicComment error = %@",error.localizedDescription);
        return;
    }
}

#pragma mark - Dealloc

- (void)dealloc
{
    [[MGMDataSyncManager sharedManager] removeLikeObserverWithId:self.identifier];
    [[NSNotificationCenter defaultCenter] removeObserver:_voteInfoChangObId
                                                    name:@"MGMUpdateVoteInfoNSNotification" object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MGMLoginSuccessNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MGMUserLogoutNotification
                                                  object:nil];
}

#pragma mark - 获取话题信息
- (void)sendDynamicToipInfoRequest {
    if(![self.dynamicId mgu_isNotBlank]) {
        return;
    }
    [self.fetchDynamicTopicRequest fetchTopicInfoWithId:@[self.dynamicId]];
}

#pragma mark - lazyload
- (UINavigationController *)publishVc
{
    if (!_publishVc) {
        MGMPublishTimeLineVC *rootVC = [[MGMPublishTimeLineVC alloc] init];
        rootVC.delegate = self;
        rootVC.topicId = self.dynamicId;
        rootVC.topicName = self.topicHeadView.topicItemModel.name;
        _publishVc = [[UINavigationController alloc] initWithRootViewController:rootVC];
        _publishVc.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    return _publishVc;
}

- (NSMutableArray<MGMDynamicModel *> *)topicModelM
{
    if (!_topicModelM)
    {
        _topicModelM = [NSMutableArray array];
    }
    return _topicModelM;
}

- (NSMutableArray<MGMDynamicModel *> *)dislikeTopicModelM
{
    if (!_dislikeTopicModelM)
    {
        _dislikeTopicModelM = [NSMutableArray array];
    }
    return _dislikeTopicModelM;
}

- (NSMutableArray<MGMDynamicModel *> *)likeTopicModelM
{
    if (!_likeTopicModelM)
    {
        _likeTopicModelM= [NSMutableArray array];
    }
    return _likeTopicModelM;
}

- (NSMutableArray<MGMDynamicModel *> *)followTopicModelM
{
    if (!_followTopicModelM)
    {
        _followTopicModelM = [NSMutableArray array];
    }
    return _followTopicModelM;
}

- (MGMSocialFetchTopicFeeds *)latestTopicFeeds
{
    if (!_latestTopicFeeds)
    {
        _latestTopicFeeds = [[MGMSocialFetchTopicFeeds alloc] initWithTopicId:self.dynamicId
                                                                          sort:(MGMSocialFetchTopicSortNew)
                                                                      delegate:self];
    }
    return _latestTopicFeeds;
}

- (MGMSocialFetchTopicFeeds *)hotestTopicFeeds
{
    if (!_hotestTopicFeeds)
    {
        _hotestTopicFeeds = [[MGMSocialFetchTopicFeeds alloc] initWithTopicId:self.dynamicId
                                                                         sort:(MGMSocialFetchTopicSortHot)
                                                                     delegate:self];
    }
    return _hotestTopicFeeds;
}

- (MGMSocialDynamicPub *)topicPublish
{
    if (!_topicPublish)
    {
        _topicPublish = [[MGMSocialDynamicPub alloc] initDelegate:self];
    }
    return _topicPublish;
}

- (MGMDynamicTopicHeadView *)topicHeadView {
    if(!_topicHeadView) {
        _topicHeadView = [[MGMDynamicTopicHeadView alloc] initWithFrame:CGRectMake(0, 0, MGMScreenW , MGMDynamicTopicHeadViewHeight)];
    }
    return _topicHeadView;
}

- (MGMCommentEmptyView *)commentEmptyView
{
    if (!_commentEmptyView)
    {
        UIImage *noDataImage = [MGMCommunityResource imageNamed:@"img_ssk"];
        _commentEmptyView = [[MGMCommentEmptyView alloc] init];
        _commentEmptyView.topSpace = 210.f;
        _commentEmptyView.emptyImage = noDataImage;
        _commentEmptyView.text = @"小编偷懒了，还没有发布新内容";
        _commentEmptyView.mgm_height = MGMScreenH - MGMNavigationBarH - MGMStatusBarH - MGMTabBarH - MGMSectionHeaderViewH;
    }
    return _commentEmptyView;
}

- (MGMCommentTabView *)commentTabView
{
    if (!_commentTabView)
    {
        _commentTabView = [[MGMCommentTabView alloc] init];
        _commentTabView.delegate = self;
    }
    return _commentTabView;
}

- (UIView *)publishView
{
    if (!_publishView)
    {
        CGFloat height = 30.f;
        _publishView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, MGMScreenW, height)];
        _publishView.backgroundColor = [UIColor colorWithRed:254/255.0 green:242/255.0 blue:242/255.0 alpha:1.0];
        _publishView.userInteractionEnabled = NO;
        
        CGFloat publishIndicatorViewX = 16.f;
        CGFloat publishIndicatorViewW = MGMScreenW - publishIndicatorViewX;
        UIButton *publishIndicatorView = [[UIButton alloc] initWithFrame:CGRectMake(publishIndicatorViewX, 0, publishIndicatorViewW, height)];
        publishIndicatorView.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 12];
        publishIndicatorView.titleEdgeInsets = UIEdgeInsetsMake(0, 6, 0, 0);
        publishIndicatorView.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [publishIndicatorView setTitleColor:[UIColor colorWithRed:255/255.0 green:95/255.0 blue:95/255.0 alpha:1.0] forState:(UIControlStateNormal)];
        [publishIndicatorView addTarget:self
                                 action:@selector(publishButtonAction)
                       forControlEvents:UIControlEventTouchUpInside];
        [_publishView addSubview:publishIndicatorView];
        self.mgm_publishIndicatorView = publishIndicatorView;
    }
    return _publishView;
}

- (MGMNetReloaderView *)netReloadView
{
    if (!_netReloadView) {
        _netReloadView = [MGMNetReloaderView netReloader];
        _netReloadView.frame = self.view.bounds;
        NSMutableAttributedString *buttonTitle = [[NSMutableAttributedString alloc] initWithString:@"刷新"attributes: @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Semibold" size: 16],NSForegroundColorAttributeName: [UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1.0]}];
        [_netReloadView.reloadBtn setAttributedTitle:buttonTitle forState:UIControlStateNormal];
        NSMutableAttributedString *desc = [[NSMutableAttributedString alloc] initWithString:@"没有网络啦，快去检查下"
                                                                                 attributes: @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Regular" size: 15],
                                                                                               NSForegroundColorAttributeName: [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1.0]}];
        _netReloadView.networkMsgLabel.attributedText = desc;
        __weak typeof(self)weakSelf = self;
        _netReloadView.reloadButtonClickBlock = ^{
            if ([AFNetworkReachabilityManager_mgs sharedManager].reachable == NO) return;

            __strong typeof(self)strongSelf = weakSelf;
            [strongSelf.netReloadView dismiss];
            [strongSelf loadTopicCommentList];
        };
    }
    return _netReloadView;
}

- (UITableView *)topicTableView {
    if(!_topicTableView) {
        CGFloat topicTableViewH = MGMScreenH - MGMNavigationBarH - MGMStatusBarH - MGMTabBarH;
        _topicTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, MGMScreenW, topicTableViewH) style:UITableViewStylePlain];
        _topicTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _topicTableView.delegate = self;
        _topicTableView.dataSource = self;
        _topicTableView.estimatedRowHeight = 0.f;
        _topicTableView.estimatedSectionHeaderHeight = 0.f;
        _topicTableView.estimatedSectionFooterHeight = 0.f;
        [_topicTableView registerClass:[MGMImageAndTextTimeLineCell class] forCellReuseIdentifier:NSStringFromClass(MGMImageAndTextTimeLineCell.class)];
        [_topicTableView registerClass:[MGMGKeTimeLineCell class] forCellReuseIdentifier:NSStringFromClass(MGMGKeTimeLineCell.class)];
        if (@available(iOS 11.0, *)) {
            _topicTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        MGMWeakSelf
        _topicTableView.mj_header = [MGMRefrshGifHeader headerWithRefreshingBlock:^{
            MGMStrongSelf
            [self mgm_pullDownToRefreshData];
        }];
        
        _topicTableView.mj_footer = [MGMRefreshAutoFooter footerWithRefreshingBlock:^{
            MGMStrongSelf
            [self mgm_sendMoreTopicData];
        }];
    }
    return _topicTableView;
}

- (MGMDynamicFetchTopicListInfo *)fetchDynamicTopicRequest {
    if(!_fetchDynamicTopicRequest) {
        _fetchDynamicTopicRequest = [[MGMDynamicFetchTopicListInfo alloc] initWithDelegate:self];
    }
    return _fetchDynamicTopicRequest;
}

-(MGMSocialVoteService *)voteService{
    if (!_voteService) {
        _voteService = [[MGMSocialVoteService alloc]initWithDelegate:self];
    }
    return _voteService;
}

@end
