//
//  MGMDynamicTopicDetailVC.h
//  MGMCommunity
//  动态话题详情
//  Created by YL on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMPageController.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMDynamicTopicDetailVC : MGMPageController

@end

NS_ASSUME_NONNULL_END
