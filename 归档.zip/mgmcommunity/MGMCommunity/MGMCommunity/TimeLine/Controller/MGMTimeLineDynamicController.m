//
//  MGMDiscoverController.m
//  MGMCommunity
//
//  Created by apple on 2018/12/3.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLineDynamicController.h"
#import "MGMGKeTimeLineCell.h"
#import "MGMTopicTimeLineCell.h"
#import "MGMCommentTimeLineCell.h"
#import "MGMStagePhotoTimeLineCell.h"
#import "MGMImageAndTextTimeLineCell.h"
#import "MGMTimeLineLoginView.h"

#import "MGMCommunity.h"
#import "MGMTimeLineGKeModel.h"
#import "MGMTimeLineTopicModel.h"
#import "MGMTimeLineCommentModel.h"
#import "MGMTimeLineImageTextModel.h"
#import "MGMTimeLineStagePhotoModel.h"
#import "MGMPageController+MGMDynamic.h"

#import "MGMCommunityResource.h"
#import "MGMPublishTimeLineVC.h"

#import "MGMCommunityGotoLogin.h"
#import "MGMCommunityReportManager.h"

#import <Masonry/Masonry.h>
#import <YYModel/YYModel.h>
#import <MGMRoute/MGMRoute.h>
#import <MGMRoute/MGMRouteParams.h>
#import <MGMRoute/MGMRouteUGCParams.h>
#import <MGMRoute/MGMRouteTopicParams.h>
#import <MGMRoute/MGMRouteDuibaiParams.h>
#import <MGMUIKit/MGMUGCVote.h>
#import <MGMUIKit/MGMGlobalConst.h>
#import <MGMUIKit/MGMRefrshGifHeader.h>
#import <MGMUIKit/MGMNetReloaderView.h>
#import <MGMUIKit/MGMRefreshAutoFooter.h>
#import <MGMUIKit/MGMProgressHUD+MGMConfig.h>
#import <MGMUIKit/MSSAutoresizeLabelFlowConfig.h>
#import <MGUKeyValueStore/MGUKeyValueStore.h>
#import <MGMHttpApiModel/MGMFilmDetailContentInfo.h>
#import <MGMCategories/MGMCategories.h>
#import <MGMCategories/UIView+MGMFrame.h>
#import <MGMCategories/UIView+MGMPosition.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMDataProcessingKit/MGMSocialVoteService.h>
#import <MGMDataProcessingKit/MGMLikeAndCommentDataManager.h>
#import <MGMLegoModule/MGMLegoPageFragment.h>
#import <MGMLegoModule/MGMStatisticsLegoHelper.h>
#import <MGThirdKit/AFNetworking_mgs.h>
#import <MGMSocialModule/MGMDynamicFeedItem.h>
#import <MGMSocialModule/MGMSocialFeeds.h>
#import <MGMSocialModule/MGMFeedItemContentDefines.h>
#import <MGMSocialModule/MGMSocialDynamicPub.h>
#import <MGMHttpApiModel/MGMSocialVoteContentModel.h>
#import <MGMStatistics/MGMPageController+MGMPV.h>
#import <MGMCategories/UIView+MGMToast.h>

#import "MGMDuiBaiRefreshEntranceView.h"
#import <YYCategories/YYCategories.h>

static NSString *const MGMGKeTimeLineCellID = @"MGMGKeTimeLineCell";
static NSString *const MGMTopicTimeLineCellID = @"MGMTopicTimeLineCell";
static NSString *const MGMCommentTimeLineCellID = @"MGMCommentTimeLineCell";

@interface MGMTimeLineDynamicController ()<
UITableViewDelegate,
UITableViewDataSource,
MGMTimeLineLoginViewDelegate,
MGMLikeAndCommentDataManagerDelegate,
MGMDynamicFeedItemDelegate,
MGMSocialDelegate,
MGMPublishTimeLineVCDelegate,
MGMSocialDynamicPubDelegate,
MGMSocialVoteServiceDelegate>

@property (nonatomic, assign) CGFloat lastContentOffsetY;
//@property (nonatomic, assign) NSInteger totalPublishCount;
//@property (nonatomic, assign, getter=isHideFooter) BOOL hideFooter;

/**
    是否移除发布动态指示器
 */
@property (nonatomic, assign, getter=isDismissIndicator) BOOL dismissIndicator;

/**
    请求是否加载完成(关注页是否添加lego的cell需要根据此标记决定)
 */
//@property (nonatomic, assign, getter=isLoadFinish) BOOL loadFinish;
@property (nonatomic, assign) MGMTimeLineDynamicStyle style;

/**
    埋点位置
*/
@property (nonatomic, copy) NSString *trackEventLocation;
@property (nonatomic, weak) UIButton *publishBtn;

/**
    分享剧照次数
 */
@property (nonatomic, assign) NSInteger shareStagePhotoNum;

/**
    发布动态的条数
 */
@property (nonatomic, assign) NSUInteger publishCount;

@property (nonatomic, strong) UIView *noFollowView;
@property (nonatomic, strong) UITableView *dynamicListView;
@property (nonatomic, strong) UIView *legoSeperateLine;
@property (nonatomic, strong) UIView *publishView;
//@property (nonatomic, weak) UIButton *publishIndicatorView;
@property (nonatomic, strong) MGMTimeLineLoginView *loginView;
@property (nonatomic, strong) MGMNetReloaderView *netReloadView;
@property (nonatomic, strong) MGMLegoPageFragment *legoFragment;
@property (nonatomic, weak) MGMImageAndTextTimeLineCell *toastCell;
@property (nonatomic, strong) MGMDynamicModel *deleteDynamicModel;
@property (nonatomic, strong) MGMSocialDynamicPub *dynamicPublish;
@property (nonatomic, strong) NSMutableArray <__kindof MGMDynamicModel *>*followDynamicModels;
@property (nonatomic, strong) NSMutableArray <__kindof MGMDynamicModel *>*dynamicModels;
@property (nonatomic, strong) NSMutableArray <__kindof MGMDynamicModel *>*likeDynamicModels;
@property (nonatomic, strong) NSMutableArray <__kindof MGMDynamicModel *>*dislikeDynamicModels;

@property (nonatomic, strong) MGMLikeAndCommentDataManager *likeDataManger;
@property (nonatomic, assign) NSInteger currentIndex;
@property (nonatomic, strong) UINavigationController *publishVC;
/**
    关注的索引
 */
@property (nonatomic, assign) NSInteger currentFollowIndex;
@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, strong) id userInfoChangObId;

/**
   投票服务
*/
@property (nonatomic, strong) MGMSocialVoteService *voteService;
@property (nonatomic, assign) NSInteger currentVoteIndex;
@property (nonatomic, strong) id voteInfoChangObId;

//对白刷新入口view
@property (nonatomic, strong) MGMDuiBaiRefreshEntranceView *duiBaiRefresh;

@end

@implementation MGMTimeLineDynamicController

#pragma mark - Public

- (instancetype)initWithStyle:(MGMTimeLineDynamicStyle)style
{
    if (self = [self init])
    {
        _style = style;
        _trackEventLocation = (MGMTimeLineDynamicStyleRecommend == style) ? @"MV_DISCOVERY_PAGE" : @"MV_FOLLOW_PAGE";
//        _loadFinish = NO;
    }
    return self;
}

#pragma mark - Override

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        _identifier = [NSUUID UUID].UUIDString;
        [self registerNotication];
    }
    
    __weak typeof(self)weakSelf = self;
    self.userInfoChangObId = [[NSNotificationCenter defaultCenter] addObserverForName:@"MGMUpdateFollowStatusNSNotification"
                                                                               object:nil
                                                                                queue:[NSOperationQueue mainQueue]
                                                                           usingBlock:^(NSNotification * _Nonnull note) {
        [weakSelf getBackFromUserMainWithInfo:note.userInfo];
    }];
    self.voteInfoChangObId = [[NSNotificationCenter defaultCenter] addObserverForName:@"MGMUpdateVoteInfoNSNotification"
                                                                               object:nil
                                                                                queue:[NSOperationQueue mainQueue]
                                                                           usingBlock:^(NSNotification * _Nonnull note) {
        [weakSelf getBackFromDynamicDetailWithVoteInfo:note.userInfo];
    }];
    return self;
}

#pragma mark - Life Cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initialize];
    [self addNotificationObserver];
        
    //  关注页未登录显示登录引导界面
    if (![MGMDSUser user].isLogin && (MGMTimeLineDynamicStyleFollow == self.style))
    {
        [self.view addSubview:self.loginView];
        return;
    }
    [self loadDynamicList];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(miniProgramDidShare) name:@"WechatMiniProgramDidShareNotification" object:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[MGMStatisticsLegoHelper sharedHelper] clear];
    [MSSAutoresizeLabelFlowConfig shareConfig].flowType = MSSAutoresizeLabelFlowCellStyleTopic;
    [self.legoFragment willAppear];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    //  处理app启动首次双击动态tab不会自动刷新问题
    [self resetTabBarDelegate];
}

- (void)mgm_switchTimeLineStyle:(BOOL)appear {
    //对白刷新入口 控制
    if (self.style == MGMTimeLineDynamicStyleRecommend)
    {
        //精选
        self.dynamicListView.backgroundColor = [UIColor whiteColor];
        self.dynamicListView.mj_header.hidden = YES;
    }
    else
    {
        self.dynamicListView.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255.0 alpha:1.0];
        self.dynamicListView.mj_header.hidden = NO;
    }
    
    if(appear) {
        [self resetTabBarDelegate];
    }
    else {
        [self.legoFragment willDisappear];
        [self.dynamicListView reloadData];
    }
}

#pragma mark - Target Action

/**
    登录成功
 */
- (void)loginSuccess
{
    if (self.loginView)
    {
        [self dismissLoginView];
    }
    [self loadDynamicList];
}

/**
    注销
 */
- (void)loginOut
{
    //  动态关注页注销添加登录引导图
    if (MGMTimeLineDynamicStyleFollow == self.style)
    {
        [self.view addSubview:self.loginView];
        //  注销清除当前用户的数据
        [self.dynamicModels removeAllObjects];
        [UIView performWithoutAnimation:^{
            [self.dynamicListView reloadData];
        }];
    }
    else
    {
        [self loadDynamicList];
    }
}

- (void)routerEventWithName:(NSString *)eventName userInfo:(NSDictionary *)userInfo
{
    MGMDynamicModel *extraInfo = userInfo[MGMCommunityExtraInfo];
    NSInteger index = [self.dynamicModels indexOfObject:extraInfo];
    BOOL handle = [self mgm_shouldHandleEventName:eventName
                                         userInfo:userInfo
                                         position:index
                                         location:self.trackEventLocation];
    if (handle) return;
    
    //  图文或剧照整体事件
    if ([eventName isEqualToString:MGMCommunityImageTextClickEvent] ||
        [eventName isEqualToString:MGMCommunityStagePhotoEvent] ||
        [eventName isEqualToString:MGMCommunityImageTextMainCommentEvent])
    {
        MGMRouteUGCParams *ugcParams = [[MGMRouteUGCParams alloc] init];
        ugcParams.topicId = (MGMTimeLineTypeImageText == extraInfo.timeLineType) ? extraInfo.mid : extraInfo.feedId;
        ugcParams.extraInfo = extraInfo;
        ugcParams.contentPosition = index;
        ugcParams.trackEventLocation = self.trackEventLocation;
        ugcParams.showKeyBoard = [userInfo[MGMCommunityClickComment] boolValue];
        [MGMRoute routePageControllerWithName:@"community_postDetail"
                                   parameters:ugcParams
                              transitionStyle:(MGURouteTransitionStyleNav)];
        
        //  上报UGC文字内容埋点
        if ([eventName isEqualToString:MGMCommunityImageTextMainCommentEvent])
        {
            [self uploadDynamicEventTrackingWithType:@"JUMP_INNER_NEW_PAGE"
                                            location:self.trackEventLocation
                                            position:index
                                           programId:nil
                                              pageId:@"MV_DETAIL_COMMENT_UGC_PAGE"
                                           dynamicId:extraInfo.feedId];
        }
        
    }
    //  点赞事件
    else if ([eventName isEqualToString:MGMCommunityLikeEvent])
    {
        if (![MGMCommunityGotoLogin shouldGotoLoginWithType:1 backButton:NO inController:self]) {
            BOOL like = [userInfo[MGMCommunityLikeInfo] boolValue];
            NSString *type = like ? @"INTERACTION_LIKE" : @"INTERACTION_CANCEL_LIKE";
            [self likeDynamicContent:like dynamicModel:extraInfo];
            
            //  上报动态首页点赞/取消点赞埋点
            [self uploadDynamicEventTrackingWithType:type
                                            location:self.trackEventLocation
                                            position:index
                                           programId:nil
                                              pageId:nil
                                           dynamicId:extraInfo.feedId];
        }
    }
    else if ([eventName isEqualToString:MGMCommunityCommentTrackEvent])
    {
        //  上报动态首页评论按钮埋点
        [self uploadDynamicEventTrackingWithType:@"INTERACTION_COMMENT"
                                        location:self.trackEventLocation
                                        position:index
                                       programId:nil
                                          pageId:nil
                                       dynamicId:extraInfo.feedId];
    }
    else if ([eventName isEqualToString:MGMLegoDataLoaded])
    {
        [self.dynamicListView reloadData];
    }
    else if ([eventName isEqualToString:MGMCommunityCellToolBarShareRouterName] ||
             [eventName isEqualToString:MGMCommunityCellToolBarCommentRouterName])
    {
    }
    //  关注事件
    else if ([eventName isEqualToString:MGMCommunityFollowEvent])
    {
        if ([MGMDSUser user].isLogin)
        {
            if (!extraInfo) return;
            
            [self followUserWithDynamicModel:extraInfo];
        }
        else
        {
            [[MGMLoginManager shareManager] loginFromViewController:self showType:(MGMLoginShowTypePresent) isBackButtonHide:NO success:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
                
            } fail:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
                
            }];
        }
    }
    //  举报事件
    else if ([eventName isEqualToString:MGMCommunityReportEvent])
    {
        [self resportUGCWithObject];
    }
    //  删除事件
    else if ([eventName isEqualToString:MGMCommunityDeleteEvent])
    {
        self.deleteDynamicModel = extraInfo;
        [self popDeleteAlertView];
    }
    //  更多事件
    else if ([eventName isEqualToString:MGMCommunityMoreEvent])
    {
        MGMImageAndTextTimeLineCell *clickReportCell = userInfo[MGMCommunityMainInfo];
        if (![self.toastCell isEqual:clickReportCell])
        {
            [self.toastCell dismissToastView];
            self.toastCell = clickReportCell;
        }
    }
    //  话题、资讯事件
    else if ([eventName isEqualToString:MGMCommunityTopicEvent])
    {
        
        MGMTimeLineTopicModel *topicModel = (MGMTimeLineTopicModel *)extraInfo;
        NSString *pageId = nil;
        if (MGMTimeLineTypeNews == extraInfo.timeLineType)
        {
            pageId = @"MV_DETAIL_ZIXUN_PAGE";
            [self pushNewsDetailPageControllerWithContentId:topicModel.contentId];
        }
        else
        {
            pageId = @"MV_DETAIL_GAMBIT_PAGE";
            [self pushTopicDetailPageControllerWithMid:extraInfo.mid];
        }
        
        //  上报点击话题、资讯埋点
        [self uploadDynamicEventTrackingWithType:@"JUMP_INNER_NEW_PAGE"
                                        location:self.trackEventLocation
                                        position:index
                                       programId:nil
                                          pageId:pageId
                                       dynamicId:extraInfo.feedId];
    }
    //  小视频事件
    else if ([eventName isEqualToString:MGMCommunityMiniVideoEvent])
    {
        NSString *contentId = userInfo[MGMCommunityMiniVideoContentID];
        [self pushFilmPreviewPageControllerWithContentId:contentId
                                             contentName:userInfo[MGMCommunityMiniVideoContentName]
                                                    type:userInfo[MGMCommunityMiniVideoType]];
        
        //  上报点击小视频内容/G客视频文字内容埋点
        [self uploadDynamicEventTrackingWithType:@"JUMP_DETAIL_PAGE"
                                        location:self.trackEventLocation
                                        position:index
                                       programId:contentId
                                          pageId:@"MV_DETAIL_SHIPIN_PAGE"
                                       dynamicId:extraInfo.feedId];
    }
    else if ([eventName isEqualToString:MGMCommunityGeKePlayEvent])
    {
        //  上报G客视频内容埋点
        NSString *contentId = userInfo[MGMCommunityMiniVideoContentID];
        [self uploadDynamicEventTrackingWithType:@"INTERACTION_PLAY"
                                        location:self.trackEventLocation
                                        position:index
                                       programId:contentId
                                          pageId:nil
                                       dynamicId:extraInfo.feedId];
    }
    //  影单详情事件
    else if ([eventName isEqualToString:MGMCommunityFilmCollectionEvent])
    {
        [self pushFilmCollectionDetailWithCollectorId:userInfo[MGMCommunityFilmCollectionID]];
        
        //  上报影单内容埋点
        [self uploadDynamicEventTrackingWithType:@"JUMP_DETAIL_PAGE"
                                        location:self.trackEventLocation
                                        position:index
                                       programId:nil
                                          pageId:@"MV_YINGDAN_COMMENT_PAGE"
                                       dynamicId:extraInfo.feedId];
    }
    //  一级评论事件
    else if ([eventName isEqualToString:MGMCommunityMainCommentEvent])
    {
        [self positionCommentWithDynamicModel:extraInfo];
        
        //  上报影评，小视频，影单文字内容埋点
        [self uploadDynamicEventTrackingWithType:@"JUMP_INNER_NEW_PAGE"
                                        location:self.trackEventLocation
                                        position:index
                                       programId:nil
                                          pageId:@"MV_DETAIL_COMMENT_UGC_PAGE"
                                       dynamicId:extraInfo.feedId];
    }
    //  评论详情事件
    else if ([eventName isEqualToString:MGMCommunitySubCommentEvent])
    {
        [self pushCommentDetailPageControllerWithDynamicModel:extraInfo];
    }else if ([eventName isEqualToString:MGMUIKitVoteClickEvent])
    {   // 投票
        if ([MGMDSUser user].token == nil){
            [[MGMLoginManager shareManager] verifyLoginStateSuccess:^{} failure:^{}];
       }else{
           BOOL userClickEnbled = [userInfo[MGMUIKitVoteUserClickEnbled] boolValue];
           if (userClickEnbled) {
               self.currentVoteIndex = index;
               NSString *voteId = userInfo[MGMUIKitVoteContentID];
               NSString *optionId = userInfo[MGMUIKitVoteOptionID];
               [self.voteService voteSocialContentWithVoteId:voteId optionId:optionId];
           }
       }
    }
}

#pragma mark - Private

- (void)initialize
{
    UITableView *dynamicListView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    dynamicListView.dataSource = self;
    dynamicListView.delegate = self;
    dynamicListView.estimatedRowHeight = 0;
    dynamicListView.estimatedSectionFooterHeight = 0;
    dynamicListView.estimatedSectionHeaderHeight = 0;
    dynamicListView.separatorStyle = UITableViewCellSeparatorStyleNone;
    dynamicListView.backgroundColor = [UIColor whiteColor];
    dynamicListView.separatorColor = [UIColor colorWithRed:226/255.0 green:226/255.0 blue:226/255.0 alpha:1.0];
    [dynamicListView registerClass:[MGMGKeTimeLineCell class] forCellReuseIdentifier:MGMGKeTimeLineCellID];
    [dynamicListView registerClass:[MGMTopicTimeLineCell class] forCellReuseIdentifier:MGMTopicTimeLineCellID];
    [dynamicListView registerClass:[MGMCommentTimeLineCell class] forCellReuseIdentifier:MGMCommentTimeLineCellID];
    [dynamicListView registerClass:[MGMImageAndTextTimeLineCell class] forCellReuseIdentifier:MGMImageAndTextTimeLineCellID];
    [dynamicListView registerClass:[MGMStagePhotoTimeLineCell class] forCellReuseIdentifier:MGMStagePhotoTimeLineCellID];

    dynamicListView.mj_header = [MGMRefrshGifHeader headerWithRefreshingTarget:self
                                                                refreshingAction:@selector(pullDownToRefrsh)];
    
    MGMRefreshAutoFooter *footer = [MGMRefreshAutoFooter footerWithRefreshingTarget:self
                                                                   refreshingAction:@selector(loadMore)];
    footer.onlyRefreshPerDrag = YES;
    dynamicListView.mj_footer = footer;
    self.dynamicListView = dynamicListView;
    
    if (self.style == MGMTimeLineDynamicStyleRecommend)
     {
         self.duiBaiRefresh.frame = CGRectMake(0, 0, MGMScreenW, MGMScreenH + MGMStatusBarH + MGMNavigationBarH + MGMTabBarH);
         [self.view addSubview:self.duiBaiRefresh];
     }

    self.dynamicListView.frame = CGRectMake(0, 0, MGMScreenW, MGMScreenH - MGMStatusBarH - MGMNavigationBarH - MGMTabBarH);
    [self.view addSubview:self.dynamicListView];
    
    if (self.style == MGMTimeLineDynamicStyleRecommend)
    {
        self.duiBaiRefresh.contentView = self.dynamicListView;
    }
    
    [self setupPublishEntrance];
}

- (void)resetTabBarDelegate
{
    for (UIViewController *childVc in self.parentViewController.childViewControllers) {
        if (![childVc isViewLoaded]) continue;
        if (childVc.view.isVisibleOnScreen)
        {
            //  tab切换后双击动态tab有时无法自动滚动至顶部，所以需要重置代理,
            self.navigationController.tabBarController.delegate = childVc;
            break;
        }
    }
}

//对白刷新是否隐藏导航栏和tabbar
-(void)mgm_duiBaiRefreshHidenNavitaionWithIsHidden:(BOOL)isHidden
{
    if(isHidden)
    {
        self.publishBtn.hidden = YES;
        [self.nextResponder routerEventWithName:@"MGMTimeLineDynamicDuiBaiHiddenNavigationAciton" userInfo:@{@"isHidden":@"yse"}];
    }
    else
    {
        self.publishBtn.hidden = NO;
        [self.nextResponder routerEventWithName:@"MGMTimeLineDynamicDuiBaiHiddenNavigationAciton" userInfo:@{@"isHidden":@"no"}];
    }
}

//对白正在刷新时 控制底部scrollerview的滚动能力
-(void)mgm_duiBaiRefreshingBackViewScrollEnabled:(BOOL)scrollEnabled
{
    NSDictionary *userInfo = scrollEnabled ? @{@"scrollEnabled":@"yes"}:@{@"scrollEnabled":@"no"};
    [self.nextResponder routerEventWithName:@"MGMTimeLineDynamicDuiBaiRefreshingBackViewScrollEnabledAciton" userInfo:userInfo];
}

/// 用户从动态详情返回，如果投票状态改变则会回调该事件
- (void)getBackFromDynamicDetailWithVoteInfo:(NSDictionary *)voteInfo
{
    NSString *feedId         = voteInfo[@"feedId"];
    NSArray *voteOptions     = voteInfo[@"voteOptions"];
    NSInteger totalVoteCount = [voteInfo[@"totalVoteCount"] integerValue];
    if (!feedId) return;
    
    MGMDynamicModel *updateDynamicModel = nil;
    NSInteger index = NSNotFound;
    for (MGMDynamicModel *model in self.dynamicModels) {
        if ([model.feedId isEqualToString:feedId]) {
            updateDynamicModel = model;
            index = [self.dynamicModels indexOfObject:model];
            break;
        }
    }
    
    if (updateDynamicModel){
        updateDynamicModel.voteContent.voteOptions = voteOptions;
        updateDynamicModel.voteContent.totalVoteUserCount = totalVoteCount;
        [self refreshDynamicCellAtIndex:index];
    }
}

/// 用户从动态用户中心返回，如果关注状态改变则会回调该事件
- (void)getBackFromUserMainWithInfo:(NSDictionary *)info
{
    NSString *userId = info[@"userId"];
    NSString *relationType = info[@"relationType"];
    if (!userId) return;
    
    MGMDynamicModel *updateDynamicModel = nil;
    NSInteger index = NSNotFound;
    for (MGMDynamicModel *model in self.dynamicModels) {
        if ([model.userId isEqualToString:userId]) {
            updateDynamicModel = model;
            index = [self.dynamicModels indexOfObject:model];
            break;
        }
    }
    
    if (updateDynamicModel)
    {
        [updateDynamicModel udpateUserRelationWithType:relationType];
        [self refreshDynamicCellAtIndex:index];
    }
}

- (void)setupFragmentManagerAndPageContainer
{
    
}

- (void)addNotificationObserver
{
    MGMWeakSelf;
    [[MGMDataSyncManager sharedManager] observerDeleteDynamicWithIdentifer:self.identifier usingBlock:^(NSString * _Nonnull dynamicId) {
        MGMStrongSelf;
        //  动态详情点击删除, 进行删除操作
        [self deleteDynamicCellWithFeedId:dynamicId];
    }];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(loginSuccess)
                                                 name:MGMLoginSuccessNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(loginOut)
                                                 name:MGMUserLogoutNotification
                                               object:nil];
}

/**
    移除登陆引导界面
 */
- (void)dismissLoginView
{
    [self.loginView removeFromSuperview];
    self.loginView = nil;
}

/**
    加载动态列表数据
 */
- (void)loadDynamicList
{
    NSString *pageId = @"MV_DISCOVERY_PAGE";
    if (MGMTimeLineDynamicStyleFollow == self.style)
    {
        pageId = @"MV_FOLLOW_PAGE";
    }
    self.legoFragment = [[MGMLegoPageFragment alloc] init];
    [self.legoFragment onCreate];
    [self.legoFragment setupBillboard:self.billboard];
    [self.legoFragment setupLegoPageId:pageId];
    [self refreshTable];
}

// 下拉刷新
- (void)pullDownToRefrsh {
    [self refreshTable];
    [self mgm_addTimeLineListPVStatistics]; //下拉刷新添加页面pv埋点
}

/**
    刷新
 */
- (void)refreshTable
{
    self.hideFooter = NO;
    self.dynamicListView.mj_footer.hidden = NO;
    [self.dynamicListView.mj_footer resetNoMoreData];
    [self.socialFeeds fetchFeeds];
    [self.legoFragment loadData];
}

/**
    上拉加载
 */
- (void)loadMore
{
    BOOL result = [self.socialFeeds fetchMore];
    if (result) return;
    
    [self.dynamicListView.mj_footer endRefreshing];
}

/**
    移除无关注他人视图
 */
- (void)dismissNoFollowView
{
    self.dynamicListView.tableHeaderView = nil;
    self.noFollowView = nil;
}

/**
    显示动态发布指示器
 */
- (void)showPublishViewWithStatus:(MGMDyanmicPublishStatus)status prompt:(NSString *)prompt
{
    [self mgm_showPublishView:self.publishView
                 publishCount:self.publishCount
                       status:status
                       prompt:prompt];
    
    CGFloat offsetY = self.publishView.mgm_height;
    [self mgm_adjustContentInset:UIEdgeInsetsMake(offsetY, 0, 0, 0)
                   contentOffset:CGPointMake(0, -offsetY)
                     forListView:self.dynamicListView];
}

/**
    移除动态发布指示器
 */
- (void)dismissPublishView
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!self.isDismissIndicator) return;
        
        [self mgm_dismissPublishView:self.publishView];
        [self mgm_resetListView:self.dynamicListView];
        _publishView = nil;
    });
}

/**
    弹出举报alert
 */
- (void)resportUGCWithObject
{
    self.toastCell = nil;
    [MGMCommunityReportManager resportUGCWithObjectOnVC:self handler:^(NSString * _Nonnull actionTitle) {}];
}

/**
    点赞动态内容

 @param like       YES:点赞/NO:取消点赞
 @param dynamicModel 动态内容模型
 */
- (void)likeDynamicContent:(BOOL)like dynamicModel:(MGMDynamicModel *)dynamicModel
{
    MGMDynamicFeedItem *feedItem = dynamicModel.feedItem;
    feedItem.delegate = self;
    MGMSocialLike likeType = [MGMSocialDynamicTools likeTypeForDynamicType:dynamicModel.feedItem.content.contentType];
    NSString *feedId = [feedItem.content fetchKeyId];
    //区分图文ugc和剧照 
    NSString *extension = [NSString stringWithFormat:@"%ld",feedItem.content.contentType];
    if (like)
    {
        [self.likeDynamicModels addObject:dynamicModel];
        [feedItem likeWithObjectId:feedId type:likeType index:1 extension:extension];
    }
    else
    {
        [self.dislikeDynamicModels addObject:dynamicModel];
        [feedItem unlikeWithObjectId:feedId type:likeType index:1];
    }
}

/**
    删除动态内容
 */
- (void)deleteDynamicContent
{
    self.deleteDynamicModel.feedItem.delegate = self;
    [self.deleteDynamicModel.feedItem remove];
}

/**
    关注用户

 @param dynamicModel 动态内容模型
 */
- (void)followUserWithDynamicModel:(MGMDynamicModel *)dynamicModel
{
    [self.followDynamicModels addObject:dynamicModel];
    MGMSocialUser *user = dynamicModel.feedItem.user;
    user.delegate = self;
    [user follow];
}

/**
    刷新动态

 @param index 索引
 */
- (void)refreshDynamicCellAtIndex:(NSInteger)index
{
    if (index >= self.dynamicModels.count) return;

    NSIndexPath *reloadIndexPath = [NSIndexPath indexPathForRow:index inSection:1];
    [UIView performWithoutAnimation:^{
        [self.dynamicListView reloadData];
    }];
}

/**
    删除动态内容

 @param feedId 动态ID
 */
- (void)deleteDynamicCellWithFeedId:(NSString *)feedId
{
    for (MGMDynamicModel *dynamicModel in self.dynamicModels) {
        if ([dynamicModel.feedId isEqualToString:feedId])
        {
            self.deleteDynamicModel = dynamicModel;
            break;
        }
    }
    
    if (!self.deleteDynamicModel) return;
    
    [self.dynamicModels removeObject:self.deleteDynamicModel];
    self.deleteDynamicModel = nil;
    
    [UIView performWithoutAnimation:^{
        [self.dynamicListView reloadSections:[NSIndexSet indexSetWithIndex:1]
                            withRowAnimation:(UITableViewRowAnimationNone)];
    }];
}

/**
    弹出删除提示框
 */
- (void)popDeleteAlertView
{
    MGMWeakSelf;
    [self mgm_popDeleteAlertViewWithCancelHandler:^(UIAlertAction * _Nonnull cancelAction) {
        MGMStrongSelf;
        [self.toastCell dismissToastView];

    } confirmHandler:^(UIAlertAction * _Nonnull confirmAction) {
        MGMStrongSelf;
        [self.toastCell dismissToastView];
        [self deleteDynamicContent];
    }];
}

/**
    跳转话题资讯页

 @param mid 媒资ID
 */
- (void)pushTopicDetailPageControllerWithMid:(NSString *)mid
{
    MGMRouteToTopicDetailParams *params = [[MGMRouteToTopicDetailParams alloc] init];
    params.id = mid;
    [MGMRoute routePageControllerWithName:@"film_detail_topicDetail"
                               parameters:params
                          transitionStyle:MGURouteTransitionStyleNav];
}

- (void)pushNewsDetailPageControllerWithContentId:(NSString *)contentId
{
    MGMRouteFilmParams *routeParams = [[MGMRouteFilmParams alloc] init];
    routeParams.filmContentId = contentId;
    [MGMRoute routePageControllerWithName:@"film_zixun" parameters:routeParams
                          transitionStyle:MGURouteTransitionStyleNav];
}

/**
    跳转小视频详情页

 @param contentId   节目ID
 @param contentName 节目名字
 */
- (void)pushFilmPreviewPageControllerWithContentId:(NSString *)contentId
                                       contentName:(NSString *)contentName
                                              type:(NSString *)type
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MGMTimeLineDynamicControllerDumpMoviePage" object:nil userInfo:nil];
    [MGMRoute routePageControllerWithName:@"film_preview"
                               parameters:@{
                                            @"contentId": contentId,
                                            @"contentName": contentName,
                                            @"type": type
                                            }
                          transitionStyle:(MGURouteTransitionStyleNav)];
}

/**
    跳转影单详情页

 @param collectorId 影单ID
 */
- (void)pushFilmCollectionDetailWithCollectorId:(NSString *)collectorId
{
     [MGMRoute routePageControllerWithName:@"filmcollection_detail"
                                parameters:@{@"collectorId": collectorId}
                           transitionStyle:(MGURouteTransitionStyleNav)];
}

/**
    定位评论

 @param dynamicModel 动态模型
 */
- (void)positionCommentWithDynamicModel:(MGMDynamicModel *)dynamicModel
{
    //  话题、资讯评论
    if (MGMTimeLineTypeNews == dynamicModel.timeLineType ||
        MGMTimeLineTypeTopic == dynamicModel.timeLineType)
    {
        MGMTimeLineTopicModel *topicModel = (MGMTimeLineTopicModel *)dynamicModel;
        [self pushCommentPageControllerWithMId:topicModel.mid
                                     contentId:topicModel.contentId
                                     commentId:topicModel.commentId
                                   contentType:topicModel.contentType];
    }
    else if (MGMTimeLineTypeComment == dynamicModel.timeLineType)
    {
        MGMTimeLineCommentModel *commentModel = (MGMTimeLineCommentModel *)dynamicModel;
        //  影单评论
        if (MGMCommentTypeFilmAlbum == commentModel.type)
        {
            [self pushFilmCollectorCommentPageControllerWithCommentModel:commentModel];
        }
        //  小视频评论
        else if (MGMCommentTypeShortVideo == commentModel.type)
        {
            [self pushCommentPageControllerWithMId:commentModel.mid
                                         contentId:commentModel.contentId
                                         commentId:commentModel.commentId
                                       contentType:@"13"];
        }
        //  正片评论
        else if (MGMCommentTypeFilm == commentModel.type)
        {
            [self pushFilmCommentPageControllerWithMId:commentModel.mid
                                                  name:commentModel.filmContentModel.contentTitle
                                             commentId:commentModel.commentId];
        }
    }
}

/**
    跳转评论页

 @param mId         媒资ID
 @param contentId   内容ID
 @param commentId   评论ID
 @param contentType 内容类型
 */
- (void)pushCommentPageControllerWithMId:(NSString *)mId
                               contentId:(NSString *)contentId
                               commentId:(NSString *)commentId
                             contentType:(NSString *)contentType
{
    MGMRouteDuibaiParams *params = [[MGMRouteDuibaiParams alloc] init];
    params.desc = @"YES";
    params.isPositioning = YES;
    params.mid = mId;
    params.contentId = contentId;
    params.commentId = commentId;
    params.contentType = contentType;
    [MGMRoute routePageControllerWithName:@"main_duibai_detail_comment_list"
                               parameters:params
                          transitionStyle:(MGURouteTransitionStyleNav)];
}

/**
    跳转正片评论页

 @param mId  媒资ID
 @param name 节目名字
 */
- (void)pushFilmCommentPageControllerWithMId:(NSString *)mId
                                        name:(NSString *)name
                                   commentId:(NSString *)commentId
{
    MGMFilmDetailContentInfo *contentInfo = [[MGMFilmDetailContentInfo alloc]init];
    contentInfo.assetID = mId;
    contentInfo.name = name;
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params mgu_safe_setObject:contentInfo forKey:@"contentInfo"];
    [params mgu_safe_setObject:@"1" forKey:@"isWhetherReview"];
    [params mgu_safe_setObject:commentId forKey:@"commentId"];
    [params mgu_safe_setObject:@"1" forKey:@"isPositioning"];
    [MGMRoute routePageControllerWithName:@"film_detail_hot_review_list"
                               parameters:params
                          transitionStyle:MGURouteTransitionStyleNav];
}

/**
    跳转影单评论页

 @param commentModel 评论模型
 */
- (void)pushFilmCollectorCommentPageControllerWithCommentModel:(MGMTimeLineCommentModel *)commentModel
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params mgu_safe_setObject:commentModel.commentId forKey:@"commentId"];
    [params mgu_safe_setObject:commentModel.filmAlbumContentModel.objectId forKey:@"collectorId"];
    [params mgu_safe_setObject:commentModel.filmAlbumContentModel.filmListName forKey:@"collectorTitle"];
    [params mgu_safe_setObject:@(0) forKey:@"adjustPullPercent"];
    
    [MGMRoute routePageControllerWithName:@"filmcollection_comment"
                               parameters:params
                          transitionStyle:(MGURouteTransitionStyleNav)];
}

/**
    跳转评论详情页

 @param dynamicModel 动态模型
 */
- (void)pushCommentDetailPageControllerWithDynamicModel:(MGMDynamicModel *)dynamicModel
{
    NSString *commentId = nil;
    NSString *contentName = nil;
    
    if (MGMTimeLineTypeNews == dynamicModel.timeLineType ||
        MGMTimeLineTypeTopic == dynamicModel.timeLineType)
    {
        MGMTimeLineTopicModel *topicModel = (MGMTimeLineTopicModel *)dynamicModel;
        commentId = topicModel.commentId;
        contentName = topicModel.contentName;
    }
    else if (MGMTimeLineTypeComment == dynamicModel.timeLineType)
    {
        MGMTimeLineCommentModel *commentModel = (MGMTimeLineCommentModel *)dynamicModel;
        commentId = commentModel.commentId;
        contentName = commentModel.commentWord;
    }
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params mgu_safe_setObject:commentId forKey:@"commentId"];
    [params mgu_safe_setObject:contentName forKey:@"contentName"];
    [MGMRoute routePageControllerWithName:@"film_detail_second_review_list"
                               parameters:params
                          transitionStyle:(MGURouteTransitionStyleNav)];
}

- (void)setupPublishEntrance
{
    UIButton *publishBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [publishBtn setBackgroundImage:[MGMCommunityResource imageNamed:@"icon_fb"] forState:UIControlStateNormal];
    [publishBtn addTarget:self action:@selector(publishButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:publishBtn];
    self.publishBtn = publishBtn;
    [publishBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-8.f);
        make.bottom.offset(-11.f);
        make.size.mas_equalTo(CGSizeMake(64.f, 64.f));
    }];
}

- (void)publishButtonAction {
    [self mgm_presentPublishPageController:self.publishVC];
}

/// 动态评论数变化通知g
- (void)registerNotication
{
    __weak typeof(self)weakSelf = self;
    [[MGMDataSyncManager sharedManager] addLikeObserverWithId:self.identifier targetId:@"communty_comment_change" callback:^(NSDictionary *info) {
        __weak typeof(self)strongSelf = weakSelf;
        NSArray *cells = strongSelf.dynamicListView.visibleCells;
        NSInteger Mid = [info[@"topicId"] integerValue];
        NSInteger commentCount = [info[@"commentCount"] integerValue];
        for (MGMTimeLineBaseCell *cell in cells) {
            if ([cell isKindOfClass:[MGMImageAndTextTimeLineCell class]]) {
                MGMTimeLineImageTextModel *imageTextModel = (MGMTimeLineImageTextModel *)cell.timeLineModel;
                if (imageTextModel.id == Mid) {
                    imageTextModel.commentCount = commentCount;
                }
            }
        }
    }];
}

- (void)dealloc
{
    [[MGMDataSyncManager sharedManager] removeObserverForDeleteDynamicWithIdentifer:self.identifier];
    [[MGMDataSyncManager sharedManager] removeLikeObserverWithId:self.identifier];
    [[NSNotificationCenter defaultCenter] removeObserver:_userInfoChangObId name:@"MGMUpdateFollowStatusNSNotification" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:_voteInfoChangObId name:@"MGMUpdateVoteInfoNSNotification" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MGMLoginSuccessNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MGMUserLogoutNotification object:nil];
}

- (void)miniProgramDidShare
{
    [self.view showAutoHideToastWithText:@"分享成功"];
}

#pragma mark - Lazy
-(MGMDuiBaiRefreshEntranceView *)duiBaiRefresh
{
    if(!_duiBaiRefresh)
    {
        _duiBaiRefresh = [[MGMDuiBaiRefreshEntranceView alloc]init];
        @weakify(self);
        _duiBaiRefresh.duiBaiRefreshHandle = ^(BOOL isHidden) {
            @strongify(self);
            if (isHidden && self.netReloadView)
            {
                [self.netReloadView dismiss];
            }
            [self mgm_duiBaiRefreshHidenNavitaionWithIsHidden:isHidden];
        };
        
        _duiBaiRefresh.duiBaiRefreshingBackViewScrollEnabledHandle = ^(BOOL scrollEnabled) {
            @strongify(self);
            [self mgm_duiBaiRefreshingBackViewScrollEnabled:scrollEnabled];
        };
        
        _duiBaiRefresh.refreshLoadingHandle = ^{
            @strongify(self);
            [self pullDownToRefrsh];
        };
    }
    return _duiBaiRefresh;
}

- (UIView *)legoSeperateLine
{
    if (!_legoSeperateLine)
    {
        _legoSeperateLine = [[UIView alloc] initWithFrame:CGRectMake(16, 0, MGMScreenW - 12 - 16, 1 / [UIScreen mainScreen].scale)];
        _legoSeperateLine.backgroundColor = [UIColor mgu_colorWithHex:0xE2E2E2];
    }
    return _legoSeperateLine;
}

- (MGMLikeAndCommentDataManager *)likeDataManger
{
    if (!_likeDataManger) {
        _likeDataManger = [[MGMLikeAndCommentDataManager alloc] init];
        _likeDataManger.dataManagerDelegate = self;
    }
    return _likeDataManger;
}

- (NSMutableArray<MGMDynamicModel *> *)followDynamicModels
{
    if (!_followDynamicModels)
    {
        _followDynamicModels = [NSMutableArray array];
    }
    return _followDynamicModels;
}

- (NSMutableArray <MGMDynamicModel *>*)dynamicModels
{
    if (!_dynamicModels)
    {
        _dynamicModels = [NSMutableArray array];
    }
    return _dynamicModels;
}

- (NSMutableArray<MGMDynamicModel *> *)dislikeDynamicModels
{
    if (!_dislikeDynamicModels)
    {
        _dislikeDynamicModels = [NSMutableArray array];
    }
    return _dislikeDynamicModels;
}

- (NSMutableArray<MGMDynamicModel *> *)likeDynamicModels
{
    if (!_likeDynamicModels)
    {
        _likeDynamicModels= [NSMutableArray array];
    }
    return _likeDynamicModels;
}

- (MGMSocialDynamicPub *)dynamicPublish
{
    if (!_dynamicPublish)
    {
        _dynamicPublish = [[MGMSocialDynamicPub alloc] initDelegate:self];
    }
    return _dynamicPublish;
}

- (UIView *)publishView
{
    if (!_publishView)
    {
        CGFloat height = 30.f;
        _publishView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, MGMScreenW, height)];
        _publishView.backgroundColor = [UIColor colorWithRed:254/255.0 green:242/255.0 blue:242/255.0 alpha:1.0];
        _publishView.userInteractionEnabled = NO;
        
        CGFloat publishIndicatorViewX = 16.f;
        CGFloat publishIndicatorViewW = MGMScreenW - publishIndicatorViewX;
        UIButton *publishIndicatorView = [[UIButton alloc] initWithFrame:CGRectMake(publishIndicatorViewX, 0, publishIndicatorViewW, height)];
        publishIndicatorView.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 12];
        publishIndicatorView.titleEdgeInsets = UIEdgeInsetsMake(0, 6, 0, 0);
        publishIndicatorView.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [publishIndicatorView setTitleColor:[UIColor colorWithRed:255/255.0 green:95/255.0 blue:95/255.0 alpha:1.0] forState:(UIControlStateNormal)];
        [publishIndicatorView addTarget:self
                                 action:@selector(publishButtonAction)
                       forControlEvents:UIControlEventTouchUpInside];
        [_publishView addSubview:publishIndicatorView];
        self.mgm_publishIndicatorView = publishIndicatorView;
    }
    return _publishView;
}

- (UIView *)noFollowView
{
    if (!_noFollowView)
    {
        _noFollowView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, MGMScreenW, 106)];
        _noFollowView.backgroundColor = [UIColor colorWithRed:245/255.0 green:245/255.0 blue:245/255.0 alpha:1.0];
        UILabel *noFollowLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, MGMScreenW, 100)];
        noFollowLabel.text = @"你还没有关注他人～";
        noFollowLabel.textAlignment = NSTextAlignmentCenter;
        noFollowLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 15];
        noFollowLabel.textColor = [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1.0];
        noFollowLabel.backgroundColor = [UIColor whiteColor];
        [_noFollowView addSubview:noFollowLabel];
    }
    return _noFollowView;
}

- (MGMTimeLineLoginView *)loginView
{
    if (!_loginView)
    {
        _loginView = [[MGMTimeLineLoginView alloc] initWithFrame:CGRectMake(0, 0, MGMScreenW, MGMScreenH - MGMStatusBarH - MGMNavigationBarH - MGMTabBarH)];
        _loginView.delegate = self;
    }
    return _loginView;
}

- (MGMNetReloaderView *)netReloadView
{
    if (!_netReloadView) {
        _netReloadView = [MGMNetReloaderView netReloader];
        _netReloadView.frame = CGRectMake(0, -44.f, kMainScreenWidth, kMainScreenHeight-kTabarHeight+44.f);
        NSMutableAttributedString *buttonTitle = [[NSMutableAttributedString alloc] initWithString:@"刷新"attributes: @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Semibold" size: 16],NSForegroundColorAttributeName: [UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1.0]}];
        [_netReloadView.reloadBtn setAttributedTitle:buttonTitle forState:UIControlStateNormal];
        NSMutableAttributedString *desc = [[NSMutableAttributedString alloc] initWithString:@"没有网络啦，快去检查下"attributes: @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Regular" size: 15],NSForegroundColorAttributeName: [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1.0]}];
        _netReloadView.networkMsgLabel.attributedText = desc;
        __weak typeof(self)weakSelf = self;
        _netReloadView.reloadButtonClickBlock = ^{
            if ([AFNetworkReachabilityManager_mgs sharedManager].reachable == NO) return;

            __strong typeof(self)strongSelf = weakSelf;
            [strongSelf.netReloadView dismiss];
            [strongSelf.legoFragment loadData];
            [strongSelf refreshTable];
        };
    }
    return _netReloadView;
}

- (UINavigationController *)publishVC {
    if (!_publishVC) {
        MGMPublishTimeLineVC *rootVC = [[MGMPublishTimeLineVC alloc] init];
        rootVC.delegate = self;
        _publishVC = [[UINavigationController alloc] initWithRootViewController:rootVC];
        _publishVC.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    return _publishVC;
}

#pragma mark - MGMPublishTimeLineVC Delegate

- (void)dynamicPublishStart
 {
    self.publishCount++;
    [self showPublishViewWithStatus:(MGMDyanmicPublishStatusSending) prompt:nil];
    self.dismissIndicator = YES;
}

- (void)dynamicPublishEndWithError:(NSError *)error prompt:(nonnull NSString *)prompt{
    
    self.dismissIndicator = NO;
    //  通过延迟保证"正在发布动态文案显示"
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.publishCount--;
        if (!error)
        {
            [self showPublishViewWithStatus:(MGMDyanmicPublishStatusSuccess) prompt:@"发布成功，小编正在加速审核"];
            self.publishVC = nil;
        }
        else
        {
            [self showPublishViewWithStatus:(MGMDyanmicPublishStatusFailure) prompt:prompt];
        }
        [self dismissPublishView];
        self.dismissIndicator = YES;
    });
}

- (void)publishPageCloseButtonDidClicked {
    self.publishVC = nil;
}
#pragma mark - MGMTimeLineLoginView Delegate

- (void)timeLineLoginViewDidClickLogin:(MGMTimeLineLoginView *)loginView
{
    MGMWeakSelf;
    [[MGMLoginManager shareManager]loginFromViewController:self
                                                  showType:(MGMLoginShowTypePresent)
                                          isBackButtonHide:NO
                                                   success:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
                                                       MGMStrongSelf;
                                                       [self dismissLoginView];
                                                       [self loadDynamicList];
                                                   } fail:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
        
                                                   }];
}

#pragma mark - MGMTimeLineVote Delegate
- (void)socialVoteServiceDidFinishVoteWithData:(NSArray<MGMSocialVoteOptionModel *> *)data
                                totalVoteCount:(NSInteger)totalVoteCount
                                         error:(NSError *)error{
    if (error) {
        [MGMProgressHUD showAutoHiddeText:[error.userInfo objectForKey:NSLocalizedDescriptionKey]];
    }else{
        MGMDynamicModel *contentBodyModel = [self.dynamicModels mgu_objectOrNilAtIndex:self.currentVoteIndex];
        if (contentBodyModel) {
            contentBodyModel.voteContent.voteOptions = data;
            contentBodyModel.voteContent.totalVoteUserCount = totalVoteCount;
            for (MGMTimeLineBaseCell *cell in [self.dynamicListView visibleCells]) {
                if ([cell isKindOfClass:MGMTimeLineBaseCell.class]) {
                    if ([cell.timeLineModel isEqual:contentBodyModel]) {
                        cell.timeLineModel = contentBodyModel;
                        break;
                    }
                }
            }
        }
    }
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) return 1;
    self.legoSeperateLine.hidden = !self.dynamicModels.count;
    return self.dynamicModels.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        UITableViewCell *normalCell = [tableView dequeueReusableCellWithIdentifier:@"legoCell"];
        if (!normalCell)
        {
            normalCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"legoCell"];
        }
        
        UITableView *legoFragmentTableView = (UITableView *)[self.legoFragment getFragmentView];
        legoFragmentTableView.scrollEnabled = NO;
        [normalCell.contentView addSubview:legoFragmentTableView];
            
        //  关注页添加lego分割线
        if (MGMTimeLineDynamicStyleFollow == self.style)
        {
            [normalCell.contentView addSubview:self.legoSeperateLine];
        }
        
        return normalCell;
    }
    
    MGMDynamicModel *contentBodyModel = [self.dynamicModels mgu_objectOrNilAtIndex:indexPath.row];
    MGMTimeLineBaseCell *timelineCell = nil;
    switch (contentBodyModel.timeLineType) {
        case MGMTimeLineTypeImageText:
        {
            timelineCell = [tableView dequeueReusableCellWithIdentifier:MGMImageAndTextTimeLineCellID forIndexPath:indexPath];
        }
            break;
            
        case MGMTimeLineTypeGKe:
        {
            timelineCell = [tableView dequeueReusableCellWithIdentifier:MGMGKeTimeLineCellID forIndexPath:indexPath];
            [timelineCell setupBillboard:self.billboard];
        }
            break;
        
        case MGMTimeLineTypeNews:
        case MGMTimeLineTypeTopic:
        {
            timelineCell = [tableView dequeueReusableCellWithIdentifier:MGMTopicTimeLineCellID forIndexPath:indexPath];
        }
            break;
            
        case MGMTimeLineTypeComment:
        {
            timelineCell = [tableView dequeueReusableCellWithIdentifier:MGMCommentTimeLineCellID forIndexPath:indexPath];
        }
            break;
            
        case MGMTimeLineTypeStills:
        {
            timelineCell = [tableView dequeueReusableCellWithIdentifier:MGMStagePhotoTimeLineCellID forIndexPath:indexPath];
        }
            break;
    }
    timelineCell.timeLineModel = contentBodyModel;
    timelineCell.hideSeperateLine = ((self.dynamicModels.count - 1) == indexPath.row);
    return timelineCell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        CGFloat legoFragmentH = [self.legoFragment getFragmentHeight];
        self.legoSeperateLine.mgm_y = legoFragmentH - self.legoSeperateLine.mgm_height;
        return legoFragmentH;
    }
    else
    {
        MGMDynamicModel *dynamicModel = [self.dynamicModels mgu_objectOrNilAtIndex:indexPath.row];;
        return dynamicModel.rowHeight;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return CGFLOAT_MIN;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section)
    {
        MGMDynamicModel *dynamicModel = [self.dynamicModels mgu_objectOrNilAtIndex:indexPath.row];
        //  节目曝光，避免重复曝光
        if (dynamicModel.isExpose) return;
        dynamicModel.expose = YES;
        [self uploadDynamicEventTrackingWithType:@"EXPOSE_PROGRAM_DATA"
                                        location:self.trackEventLocation
                                        position:indexPath.row
                                       programId:nil
                                          pageId:nil
                                       dynamicId:dynamicModel.feedId];
    }
}

- (void)tableView:(UITableView *)tableView didEndDisplayingCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath*)indexPath {
    
    if([cell isKindOfClass:NSClassFromString(@"MGMGKeTimeLineCell")]) {
        MGMGKeTimeLineCell *gkeCell = cell;
        [gkeCell willDisappear];
    }
}

#pragma mark - UIScrollView Delegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //对白刷新入口滑动监听
    if (self.dynamicListView.mj_header.hidden && self.style == MGMTimeLineDynamicStyleRecommend) {
        [self.duiBaiRefresh mgm_showDuibaiViewWithContentOffsetY:scrollView.contentOffset.y];
    }
    
    //  下拉刷新发布按钮保持显示
    if (scrollView.contentOffset.y <= 0 )
    {
        self.publishBtn.hidden = NO;
        return;
    }
    
    

    //  向上滚动显示发布按钮
    self.publishBtn.hidden = !(self.lastContentOffsetY > scrollView.contentOffset.y);
    self.lastContentOffsetY = scrollView.contentOffset.y;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if (self.toastCell)
    {
        [self.toastCell dismissToastView];
        self.toastCell = nil;
    }
}

#pragma mark - MGMSocialFeeds Delegate

- (void)fetchFeedItems:(NSArray<MGMDynamicFeedItem *> *)feedItems error:(NSError *)error
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (error)
        {
            [self.dynamicListView.mj_footer endRefreshing];
            [self.dynamicListView.mj_header endRefreshing];
            //对白刷新入口 只针对精选 双击动态tabbar mj_header网络加载动画显示，加载结束隐藏
            if (!self.dynamicListView.mj_header.hidden && self.style == MGMTimeLineDynamicStyleRecommend) {
                self.dynamicListView.mj_header.hidden = YES;
                self.dynamicListView.backgroundColor = [UIColor whiteColor];
            }
            
            if (error.code == MGMDMErrorCodeAPIResponseNoMoreData)
            {
                [self.dynamicListView.mj_footer endRefreshingWithNoMoreData];
                
                [self mgm_hideRefreshFooterWithListView:self.dynamicListView
                                             totalCount:self.dynamicModels.count];
            
                //  没有关注他人
                if (!self.dynamicModels.count && MGMTimeLineDynamicStyleFollow == self.style)
                {
                    self.dynamicListView.tableHeaderView = self.noFollowView;
                }
                
                //  刷新lego
                [UIView performWithoutAnimation:^{
                    [self.dynamicListView reloadData];
                }];
                return;
            }
           else
           {
               if (self.duiBaiRefresh.isShowNetworkError)
               {
                   [self.netReloadView showInView:self.view];
               }
           }
        }
        else
        {
            //  下拉刷新
            if ([self.dynamicListView.mj_header isRefreshing] || ![self.dynamicListView.mj_footer isRefreshing])
            {
                [self.dynamicListView.mj_header endRefreshing];
                //对白刷新入口 只针对精选 双击动态tabbar mj_header网络加载动画显示，加载结束隐藏
                if (!self.dynamicListView.mj_header.hidden && self.style == MGMTimeLineDynamicStyleRecommend) {
                    self.dynamicListView.mj_header.hidden = YES;
                    self.dynamicListView.backgroundColor = [UIColor whiteColor];
                }
                
                [self mgm_resetRefreshFooterWithListView:self.dynamicListView];
                [self.dynamicModels removeAllObjects];
            }
            //  上拉加载
            else if ([self.dynamicListView.mj_footer isRefreshing])
            {
                [self.dynamicListView.mj_footer endRefreshing];
            }

            MGMDynamicModel *contentModel = nil;
            for (MGMDynamicFeedItem *item in feedItems)
            {
                switch (item.content.contentType) {
                        //  图文
                    case MGMSocialDynamicContentTypeMicroblog:
                    {
                        contentModel = [[MGMTimeLineImageTextModel alloc] initWithFeedItem:item];
                    }
                        break;
                        
                      //  影片评论、G客、影单评论、创建影单、收藏影单、小视频
                    case MGMSocialDynamicContentTypeFilmComment:
                    case MGMSocialDynamicContentTypeGKeVideoComment:
                    case MGMSocialDynamicContentTypeShortVideoComment:
                    case MGMSocialDynamicContentTypeFilmCollectionComment:
                    case MGMSocialDynamicContentTypeFilmCollectionCreate:
                    case MGMSocialDynamicContentTypeFilmCollectionCollect:
                    {
                        contentModel = [[MGMTimeLineCommentModel alloc] initWithFeedItem:item];
                    }
                        break;
                        
                    //  资讯
                    case MGMSocialDynamicContentTypeNewsComment:
                    {
                        contentModel = [[MGMTimeLineTopicModel alloc] initWithFeedItem:item timeLineType:(MGMTimeLineTypeNews)];
                    }
                        break;

                    //  话题
                    case MGMSocialDynamicContentTypeTopicComment:
                    {
                        contentModel = [[MGMTimeLineTopicModel alloc] initWithFeedItem:item timeLineType:(MGMTimeLineTypeTopic)];
                    }
                        break;

                    //  G客
                    case MGMSocialDynamicContentTypeGKeVideo:
                    {
                        contentModel = [[MGMTimeLineGKeModel alloc] initWithFeedItem:item];
                    }
                        break;
                        
                    //  剧照
                    case MGMSocialDynamicContentTypeStills:
                    {
                        contentModel = [[MGMTimeLineStagePhotoModel alloc] initWithFeedItem:item];
                    }
                        break;
                        
                    case MGMSocialDynamicContentTypeFollow:
                    {
                        contentModel = nil;
                    }
                        break;
                }
                if (!contentModel) continue;
                
                //  防止数据重复问题
                NSArray <NSString *>*feedIds = [self.dynamicModels valueForKeyPath:@"feedId"];
                if ([feedIds containsObject:contentModel.feedId]) continue;
                
                [self.dynamicModels addObject:contentModel];
            }
            
            //  没有关注他人
            if (!self.dynamicModels.count && MGMTimeLineDynamicStyleFollow == self.style)
            {
                self.dynamicListView.tableHeaderView = self.noFollowView;
            }
            
            if (self.dynamicModels.count && MGMTimeLineDynamicStyleFollow == self.style)
            {
                [self dismissNoFollowView];
            }
            [self.dynamicListView reloadData];
        }
    });
}

#pragma mark - MGMSocial Delegate

- (void)followUser:(NSString *)userId withError:(NSError *)error
{
    if (error) return;
    
    MGMDynamicModel *followDynamicModel = nil;
    for (MGMDynamicModel *dynamicModel in self.followDynamicModels) {
        if ([dynamicModel.userId isEqualToString:userId])
        {
            followDynamicModel = dynamicModel;
            followDynamicModel.relationType = MGMSocialUserRelationFollowing;
            break;
        }
    }
    
    if (followDynamicModel)
    {
        NSString *dynamicId = followDynamicModel.feedId;
        [self.followDynamicModels removeObject:followDynamicModel];
        NSInteger reloadIndex = [self.dynamicModels indexOfObject:followDynamicModel];
        [self refreshDynamicCellAtIndex:reloadIndex];
        [MGMProgressHUD showAutoHiddeText:@"关注成功"];
        [self uploadDynamicEventTrackingWithType:@"INTERACTION_FOCUS"
                                        location:self.trackEventLocation
                                        position:reloadIndex
                                       programId:nil
                                          pageId:nil
                                       dynamicId:dynamicId];
    }
}

#pragma mark - MGMDynamicFeedItem Delegate

- (void)removeDynamicFeedWithFeedId:(NSString *)feedId Error:(NSError *)error
{
    if (error)
    {
        NSLog(@"removeDynamic error = %@",error.localizedDescription);
        return;
    }
    
    [self deleteDynamicCellWithFeedId:feedId];
}

- (void)likeDynamicFeedWithFeedId:(NSString *)feedId Error:(NSError *)error
{
    if (error)
    {
        NSLog(@"likeDynamic error = %@",error.localizedDescription);
        return;
    }
}

- (void)unlikeDynamicFeedWithFeedId:(NSString *)feedId Error:(NSError *)error
{
    if (error)
    {
        NSLog(@"unlikeDynamic error = %@",error.localizedDescription);
        return;
    }
}

#pragma mark - UITabBarDelegate 双击tabbar事件处理-刷新列表

-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
    
    if (MGMTimeLineDynamicStyleFollow == self.style && ![MGMDSUser user].isLogin) return;

    if ([self doubleClick])
    {
        self.dynamicListView.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255.0 alpha:1.0];
        self.dynamicListView.mj_header.hidden = NO;
        [self.dynamicListView.mj_header beginRefreshing];
    }
}

/*判断是否是双击(因为系统并没有提供双击的方法, 可以通过点击的时间间隔来判断)*/
- (BOOL)doubleClick
{
    static NSDate *lastDate;
    NSDate *date = [NSDate date];
    if (date.timeIntervalSince1970 - lastDate.timeIntervalSince1970 < 0.5) {
        //完成一次双击后，重置第一次单击的时间，区分3次或多次的单击
        lastDate = [NSDate dateWithTimeIntervalSince1970:0];
        return YES;
    }
    
    lastDate = date;
    return NO;
}

//添加动态PV埋点
- (void)mgm_addTimeLineListPVStatistics {
    BOOL isRecommend = (self.style  == MGMTimeLineDynamicStyleRecommend);
    [self mgm_addRootPVStatisticsWithLocation:@"MV_HOME_DYNAMIC_PAGE" pageId:isRecommend ? @"MV_DISCOVERY_PAGE":@"MV_FOLLOW_PAGE" index:isRecommend ? 1 :2];
}

-(MGMSocialVoteService *)voteService{
    if (!_voteService) {
        _voteService = [[MGMSocialVoteService alloc]initWithDelegate:self];
    }
    return _voteService;
}

@end
