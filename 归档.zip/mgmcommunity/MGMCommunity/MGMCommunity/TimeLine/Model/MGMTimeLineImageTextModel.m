//
//  MGMTimeLineImageTextModel.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLineImageTextModel.h"
#import "MGMCommunity.h"
#import "MGMDynamicContent.h"
#import "MGMDynamicDetailResponseModel.h"
#import <YYText/YYText.h>
#import <MGMDataStore/MGMDSUser.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/NSString+MGMStringData.h>
#import <MGMSocialModule/MGMDynamicFeedItem.h>
#import <MGMSocialModule/MGMFeedItemContentMicroblog.h>
#import <MGMHttpApiModel/MGMSocialVoteContentModel.h>
#import <MGMHttpApiModel/MGMSocialVoteOptionModel.h>

#define MGMMaxPictureCount      9
#define MGMSinglePictureWidth   227.f

@interface MGMTimeLineImageTextModel()

/**
    是否隐藏全文按钮
 */
@property (nonatomic, assign, getter=isHideAllText) BOOL hideAllText;
@property (nonatomic, assign) CGFloat longTextHeight;
@property (nonatomic, assign) CGFloat photosHeight;
@property (nonatomic, assign) CGFloat voteHeight;
@property (nonatomic, assign) CGSize pictureSize;
@property (nonatomic, assign) CGFloat imageTextHeight;

@end

@implementation MGMTimeLineImageTextModel

#pragma mark - Public

- (instancetype)initWithFeedItem:(MGMDynamicFeedItem *)feedItem
{
    if (self = [super initWithFeedItem:feedItem])
    {
        _content = (MGMFeedItemContentMicroblog *)feedItem.content;
        self.mid = _content.mid;
        self.timeLineType = MGMTimeLineTypeImageText;
        
        _picItems = _content.pictures;
        [self setText:_content.text];
        
        NSArray *picUrls = [_content.pictures valueForKeyPath:@"src"];
        MGMFeedItemPicture *pictureItem = _picItems.firstObject;
        [self setPictureWithUrls:picUrls
               firstPictureWidth:pictureItem.width
              firstPictureHeight:pictureItem.height];
        self.voteContent = feedItem.voteContent;
        if (feedItem.voteContent) {
             CGFloat heightAdd = [self titleMutiLineHeightAddWithTitle:feedItem.voteContent.voteContent];
             self.voteHeight = feedItem.voteContent.voteOptions.count * 50 + 87 + heightAdd;
        }else{
             self.voteHeight  = 0;
        }
       
        [self setTotalHeight];
    }
    return self;
}

+ (instancetype)imageTextModelWithDynamicDetailResponseModel:(MGMDynamicDetailResponseModel *)dynamicDetailResponseModel
{
    return [[self alloc] initWithDynamicDetailResponseModel:dynamicDetailResponseModel];
}

- (instancetype)initWithDynamicDetailResponseModel:(MGMDynamicDetailResponseModel *)dynamicDetailResponseModel
{
    if (self = [super init])
    {
        //  动态详情不隐藏
        _hideAllText = NO;
        
        self.showAll = YES;
        self.clickAllTopic = YES;
        self.feedId = dynamicDetailResponseModel.dynamicId;
        self.userId = dynamicDetailResponseModel.userId;
        self.timeLineType = MGMTimeLineTypeImageText;
        self.mine = [[MGMDSUser user].userId isEqualToString:self.userId];
        self.createTime = dynamicDetailResponseModel.createTime;
        self.timeLineType = MGMTimeLineTypeImageText;
        
        MGMDynamicContent *dynamicCont = dynamicDetailResponseModel.dynamicContent;
        self.mid = dynamicCont.mid;
        NSArray *picUrls = [dynamicCont.pictures valueForKeyPath:@"src"];
        [self setText:dynamicCont.content];
    
        MGMPicture *picture = dynamicCont.pictures.firstObject;
        [self setPictureWithUrls:picUrls
               firstPictureWidth:[picture.width floatValue]
              firstPictureHeight:[picture.height floatValue]];
        
        if (dynamicDetailResponseModel.topicLabels.count)
        {
            self.topicLabels = dynamicDetailResponseModel.topicLabels;
            self.topics = [dynamicDetailResponseModel.topicLabels valueForKeyPath:@"topicName"];
            [self setHotTopicHeightWithTities:self.topics];
        }
        self.voteContent = dynamicDetailResponseModel.voteContent;
        if (dynamicDetailResponseModel.voteContent) {
             CGFloat heightAdd = [self titleMutiLineHeightAddWithTitle:dynamicDetailResponseModel.voteContent.voteContent];
             self.voteHeight = dynamicDetailResponseModel.voteContent.voteOptions.count * 50 + 87 + heightAdd;
        }else{
             self.voteHeight  = 0;
        }
        [self setTotalHeight];
    }
    return self;
}

- (void)setTotalHeight
{
    CGFloat commentHeight = self.hideComment ? 0 : self.commentHeight;
    CGFloat space = 12.f;
    CGFloat rowHeight = MGMUserProfileH + self.longTextHeight + self.photosHeight + self.voteHeight + self.hotTopicHeight + commentHeight + 55.f;
    //  图片、文字、话题标签都有设置2处间距
    if (self.longTextHeight && self.photosHeight && self.hotTopicHeight)
    {
        rowHeight += (space * 2);
    }
    //  只有图片、文字设置1处间距
    else if (self.longTextHeight && self.photosHeight)
    {
        rowHeight += space;
    }
    //  只有图片、话题标签设置1处间距
    else if (self.photosHeight && self.hotTopicHeight)
    {
        rowHeight += space;
    }
    //  只有文字、话题标签设置1处间距
    else if (self.longTextHeight && self.hotTopicHeight)
    {
        rowHeight += space;
    }
    if (self.voteHeight) {
        rowHeight += space;
    }
    self.flowTopicViewY = rowHeight - (self.hotTopicHeight + commentHeight + 55.f);
    self.imageTextHeight = rowHeight;
}

#pragma mark - Getter

- (CGFloat)rowHeight
{
    return self.imageTextHeight;
}

#pragma mark - MGMTimeLineDataSource

- (CGFloat)timeLineTopicViewOriginY
{
    return self.flowTopicViewY;
}

- (CGFloat)timeLineTextHeight
{
    return self.longTextHeight;
}

- (CGSize)timeLinePhotoSize
{
    return self.pictureSize;
}

- (CGFloat)timeLinePhotoHeight
{
    return self.photosHeight;
}

-(CGFloat)timeLineVoteHeight{
    return self.voteHeight;
}

- (NSArray<NSString *> *)timeLinePhotoUrls
{
    return self.picUrls;
}

- (NSArray<NSString *> *)timeLineTopics
{
    return self.topics;
}

- (YYTextLayout *)timeLineTextLayout
{
    return self.textLayout;
}

- (BOOL)isHideAllTextBtn
{
    return self.isHideAllText;
}

#pragma mark - Private

- (void)setText:(NSString *)text
{
    _textContent = text;
    //  设置富文本
    _textLayout = [self textLayoutWithText:_textContent];
    _longTextHeight = ceilf(self.textLayout.textBoundingSize.height);
    //  是否隐藏全文按钮
    _hideAllText = !_textLayout.truncatedLine;
}

- (void)setPictureWithUrls:(nullable NSArray *)picUrls
         firstPictureWidth:(CGFloat)pictureWidth
        firstPictureHeight:(CGFloat)pictureHeight
{
    //  长图调试代码
//    NSMutableArray *testArrayM = [NSMutableArray arrayWithArray:picUrls];
//    testArrayM[0] = @"http://img1.mydrivers.com/img/20171008/s_da7893ed38074cbc994e0ff3d85adeb5.jpg";
//    _picUrls = [testArrayM copy];
    _picUrls = picUrls;
    
    if (!picUrls.count) return;
    
    //  单图图片尺寸为0，设置单图默认的尺寸
    if ((!pictureWidth || !pictureHeight) && 1 == picUrls.count)
    {
        _pictureSize = CGSizeMake(MGMSinglePictureWidth, MGMSinglePictureWidth);
        _photosHeight = MGMSinglePictureWidth;
        return;
    }
    
    //  略缩图最多显示9张
    NSInteger picCount = MIN(picUrls.count, MGMMaxPictureCount);
    //  根据图片数量设置高度
    if (picUrls.count > 1)
    {
        _pictureSize =  CGSizeMake(MGMItemSizeW, MGMItemSizeW);
        _photosHeight = [self calculatePictureViewHeightWithCount:picCount];
    }
    else if (1 == picUrls.count)
    {
        CGFloat singlePictureHeight = [self calculateSinglePictureSizeForOriginalWidth:pictureWidth OriginalHeight:pictureHeight];
        _pictureSize = CGSizeMake(MGMSinglePictureWidth, singlePictureHeight);
        _photosHeight = singlePictureHeight;
    }
    else
    {
        _photosHeight = 0.f;
        _pictureSize = CGSizeZero;
    }
}

- (CGFloat)calculatePictureViewHeightWithCount:(NSInteger)count
{
    NSInteger rows = ceil(count/3.0);
    CGFloat height = rows * MGMItemSizeW + (rows - 1) * 7.5;
    return height;
}

- (CGFloat)calculateSinglePictureSizeForOriginalWidth:(CGFloat)width
                                       OriginalHeight:(CGFloat)height
{
    CGFloat singlePictureMaxHeight = 303.f;
    CGFloat singlePictureHeight = ceilf(MGMSinglePictureWidth * height / width);
    return MIN(singlePictureHeight, singlePictureMaxHeight);
}


-(CGFloat)titleMutiLineHeightAddWithTitle:(NSString *)title{
    BOOL isMutiLine = [self isMutiLineWithTitle:title];
    return isMutiLine ? (MGMScaleValue(45)-22.5) :0;
}

-(BOOL)isMutiLineWithTitle:(NSString *)title{
    NSDictionary *attributes= @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Semibold" size:MGMScaleValue(15)]};
    CGRect rect  = [title boundingRectWithSize:CGSizeMake(MGMScreenW - 60, MAXFLOAT)
                                              options:NSStringDrawingUsesLineFragmentOrigin
                                           attributes:attributes
                                              context:nil];
    return rect.size.height > MGMScaleValue(22.5);
}
@end
