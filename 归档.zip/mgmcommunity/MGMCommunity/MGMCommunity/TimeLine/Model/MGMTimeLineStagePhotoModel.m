//
//  MGMTimeLineStagePhotoModel.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLineStagePhotoModel.h"
#import <MGMDataStore/MGMDSUser.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/NSString+MGMStringData.h>
#import <MGMSocialModule/MGMDynamicFeedItem.h>
#import <MGMSocialModule/MGMFeedItemContentStills.h>

#import "MGMDynamicContent.h"
#import "MGMDynamicDetailResponseModel.h"

@interface MGMTimeLineStagePhotoModel()

@property (nonatomic, copy) NSString *stagePhotoCoverUrl;
@property (nonatomic, copy) NSString *stagePhotoContentID;
@property (nonatomic, copy) NSString *stagePhotoName;
@property (nonatomic, copy) NSString *stagePhotoMid;
@property (nonatomic, copy) NSString *stagePhotoKId;

@end

@implementation MGMTimeLineStagePhotoModel

#pragma mark - Public

+ (instancetype)stagePhotoModelWithDynamicDetailResponseModel:(MGMDynamicDetailResponseModel *)dynamicDetailResponseModel
{
    return [[self alloc] initWithDynamicDetailResponseModel:dynamicDetailResponseModel];
}

#pragma mark - Private

- (instancetype)initWithDynamicDetailResponseModel:(MGMDynamicDetailResponseModel *)dynamicDetailResponseModel
{
    if (self = [super init])
    {
        self.showAll = YES;
        self.timeLineType = MGMTimeLineTypeStills;
        self.feedId = dynamicDetailResponseModel.dynamicId;
        self.userId = dynamicDetailResponseModel.userId;
        self.mine = [[MGMDSUser user].userId isEqualToString:self.userId];
//        self.createTime = [NSString mgm_categoriesTimeStampToDataStringBiaoZhun:dynamicDetailResponseModel.createTime];
        self.createTime = dynamicDetailResponseModel.createTime;
        self.timeLineType = MGMTimeLineTypeStills;
        
        MGMDynamicContent *dynamicCont = dynamicDetailResponseModel.dynamicContent;
        self.mid = dynamicCont.mid;
        self.stagePhotoKId = dynamicDetailResponseModel.dynamicContent.kId;
        [self setCoverUrl:dynamicCont.coverUrl
                contentId:dynamicCont.contentID
                     name:dynamicCont.name];
    }
    return self;
}

#pragma mark - Override

- (instancetype)initWithFeedItem:(MGMDynamicFeedItem *)feedItem
{
    if (self = [super initWithFeedItem:feedItem])
    {
        self.timeLineType = MGMTimeLineTypeStills;
        _stillsContentModel = (MGMFeedItemContentStills *)feedItem.content;
        self.mid = _stillsContentModel.mid;

        [self setCoverUrl:_stillsContentModel.coverUrl
                contentId:_stillsContentModel.contentID
                     name:_stillsContentModel.name];
    }
    return self;
}

- (void)setCoverUrl:(NSString *)coverUrl
          contentId:(NSString *)contentId
               name:(NSString *)name
{
    _stagePhotoCoverUrl = [coverUrl mgu_urlEncodeString];
    _stagePhotoContentID = contentId;
    _stagePhotoOriginalName = name;
    _stagePhotoName = [NSString stringWithFormat:@"《%@》",name];
}

#pragma mark - Getter

- (CGFloat)rowHeight
{
    CGFloat commentHeight = self.hideComment ? 0 : self.commentHeight;
    return 322.f + commentHeight;
}

@end
