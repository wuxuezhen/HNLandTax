//
//  MGMTimeLineGKeModel.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLineGKeModel.h"
#import "MGMCommunity.h"
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMSocialModule/MGMFeedItemContentGKeVideo.h>

@implementation MGMTimeLineGKeModel

#pragma mark - Override

- (instancetype)initWithFeedItem:(MGMDynamicFeedItem *)feedItem
{
    if (self = [super initWithFeedItem:feedItem])
    {
        self.timeLineType = MGMTimeLineTypeGKe;

        _gKeContentModel = (MGMFeedItemContentGKeVideo *)feedItem.content;
        _gKeName = _gKeContentModel.name;
        _gKeCoverUrl = [_gKeContentModel.pics.lowResolutionV mgu_urlEncodeString];
        self.mid = _gKeContentModel.mid;
        
        NSInteger duration = [_gKeContentModel.cDuration integerValue];
        _gKeDuration = [NSString stringWithFormat:@"%02ld:%02ld",duration / 60, duration % 60];
        _gKeVideoViewHeight = ceilf((MGMScreenW - 2 * MGMItemSpace) * 210 / 345);
    }
    return self;
}

#pragma mark - Getter

- (CGFloat)rowHeight
{
    return 155 + self.gKeVideoViewHeight + self.commentHeight;
}

@end
