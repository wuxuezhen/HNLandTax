//
//	MGMRootClass.h
//
//	Create by apple on 4/12/2018
//	Copyright © 2018. All rights reserved.
//
#import <MGMHttpApiModel/MGMUGCDetailModel.h>
#import <MGMSocialModule/MGMDynamicFeedItem.h>
#import <MGMHttpApiModel/MGMSocialVoteContentModel.h>
#import "MGMTimeLineDataSource.h"

@class YYTextLayout, MGMCommunityRelationInfos, MGMDynamicFeedItem;

NS_ASSUME_NONNULL_BEGIN

/**
    动态式样类型

 - MGMTimeLineTypeImageText: 图文
 - MGMTimeLineTypeComment:   评论
 - MGMTimeLineTypeNews:      资讯
 - MGMTimeLineTypeTopic:     话题
 - MGMTimeLineTypeGKe:       G客
 - MGMTimeLineTypeStills:    剧照
 */
typedef NS_ENUM(NSInteger, MGMTimeLineType)
{
    MGMTimeLineTypeImageText,
    MGMTimeLineTypeComment,
    MGMTimeLineTypeNews,
    MGMTimeLineTypeTopic,
    MGMTimeLineTypeGKe,
    MGMTimeLineTypeStills
};

@interface MGMDynamicModel : NSObject<MGMTimeLineDataSource, MGMTimeLineDelegate>

@property (nonatomic, assign) MGMTimeLineType timeLineType;
@property (nonatomic, assign) NSInteger likeCount;
@property (nonatomic, assign) NSInteger commentCount;

/**
   上报埋点是否已经曝光过
*/
@property (nonatomic, assign, getter=isExpose) BOOL expose;

/**
    是否当前用户
 */
@property (nonatomic, assign, getter=isMine) BOOL mine;

@property (nonatomic, assign) BOOL hasLike;

/**
    是否隐藏更多
 */
@property (nonatomic, assign, getter=isHideMore) BOOL hideMore;

/**
    隐藏评论列表
 */
@property (nonatomic, assign, getter=isHideComment) BOOL hideComment;

/**
    显示所有文本
 */
@property (nonatomic, assign, getter=isShowAll) BOOL showAll;

/**
    话题是否都可点击
 */
@property (nonatomic, assign, getter=isClickAllTopic) BOOL clickAllTopic;
@property (nonatomic, assign, readonly) CGFloat rowHeight;
@property (nonatomic, assign, readonly) CGFloat commentHeight;
@property (nonatomic, assign, readonly) CGFloat hotTopicHeight;
@property (nonatomic, assign) CGFloat flowTopicViewY;
@property (nonatomic, copy) NSArray <NSString *>*topics;
@property (nonatomic, copy) NSArray <MGMFeedItemLabel *>* _Nullable topicLabels;
@property (nonatomic, strong, readonly) MGMDynamicFeedItem *feedItem;
@property (nonatomic, strong, readwrite) MGMSocialVoteContentModel *voteContent;
@property (nonatomic, copy, readonly) NSArray <NSAttributedString *>*commentTexts;
@property (nonatomic, copy) NSString *mid;
@property (nonatomic, copy) NSString *userId;
@property (nonatomic, copy) NSString *feedId;
@property (nonatomic, copy) NSString *author;
@property (nonatomic, copy) NSString *createTime;
@property (nonatomic, copy) NSString *summaryImages;
@property (nonatomic, copy) NSString *identiftyIconUrl;
@property (nonatomic, strong) UIColor *identifyNickNameColor;
@property (nonatomic, assign) NSInteger id;
@property (nonatomic, assign) MGMSocialUserRelation relationType;

- (instancetype)initWithFeedItem:(MGMDynamicFeedItem *)feedItem;
- (void)udpateUserRelationWithType:(NSString *)type;
- (void)setHotTopicHeightWithTities:(NSArray <NSString *>*)titles;
- (YYTextLayout *)textLayoutWithText:(NSString *)text;

/**
    设置动态标签

 @param tag 标签文本
 */
- (void)setDynamicTagTextWithTag:(NSString *)tag;

@end

NS_ASSUME_NONNULL_END
