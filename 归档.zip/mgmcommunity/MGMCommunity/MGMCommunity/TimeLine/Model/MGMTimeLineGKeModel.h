//
//  MGMTimeLineGKeModel.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityUGCModel.h"

NS_ASSUME_NONNULL_BEGIN

@class MGMFeedItemContentGKeVideo;

@interface MGMTimeLineGKeModel : MGMDynamicModel

@property (nonatomic, copy, readonly) NSString *gKeName;
@property (nonatomic, copy, readonly) NSString *gKeDuration;
@property (nonatomic, copy, readonly) NSString *gKeHot;
@property (nonatomic, copy, readonly) NSString *gKeCoverUrl;
@property (nonatomic, assign, readonly) CGFloat gKeVideoViewHeight;
@property (nonatomic, strong, readonly) MGMFeedItemContentGKeVideo *gKeContentModel;

@end

NS_ASSUME_NONNULL_END
