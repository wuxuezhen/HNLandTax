//
//  MGMTimeLineTopicModel.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLineTopicModel.h"
#import <YYText/YYText.h>
#import <MGMSocialModule/MGMFeedItemContentNewsComment.h>
#import <MGMSocialModule/MGMFeedItemContentTopicComment.h>

@implementation MGMTimeLineTopicModel

#pragma mark - Public

- (instancetype)initWithFeedItem:(MGMDynamicFeedItem *)feedItem timeLineType:(MGMTimeLineType)timeLineType
{
    if (self = [super initWithFeedItem:feedItem])
    {
        self.timeLineType = timeLineType;
        switch (timeLineType) {
            case MGMTimeLineTypeTopic:
            {
                _newsContentModel = nil;
                _topicContentModel = (MGMFeedItemContentTopicComment *)feedItem.content;
                _commentId = _topicContentModel.commentId;
                _contentId = _topicContentModel.contentId;
                _contentType = @"17";
                self.mid = _topicContentModel.mid;
                [self setDataWithComment:_topicContentModel.comment
                             commentTime:_topicContentModel.commentTime
                            contentTitle:_topicContentModel.contentTitle];
            }
                break;
                
            default:
            {
                _topicContentModel = nil;
                _newsContentModel = (MGMFeedItemContentNewsComment *)feedItem.content;
                _commentId = _newsContentModel.commentId;
                _contentId = _newsContentModel.contentId;
                _contentType = @"11";
                self.mid = _newsContentModel.mid;
                [self setDataWithComment:_newsContentModel.comment
                             commentTime:_newsContentModel.commentTime
                            contentTitle:_newsContentModel.contentTitle];
            }
                break;
        }
    }
    return self;
}

#pragma mark - Private

- (void)setDataWithComment:(NSString *)comment
               commentTime:(NSDate *)commentTime
              contentTitle:(NSString *)contentTitle
{
    _comment = comment;
    _commentTime = commentTime;
    char *cTitle = NULL;
    _contentName = comment;
    _contentTitle = contentTitle;
    _topicCommentLayout = [self textLayoutWithText:_comment];
    _textHeight = ceilf(_topicCommentLayout.textBoundingSize.height);
}

#pragma mark - Getter

- (CGFloat)rowHeight
{
    return 72.f + 24.f + 14.f + self.textHeight + 52.f + self.commentHeight;
}

@end
