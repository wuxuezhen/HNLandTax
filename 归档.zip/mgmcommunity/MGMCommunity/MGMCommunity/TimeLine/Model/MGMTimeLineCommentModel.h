//
//  MGMTimeLineCommentModel.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityUGCModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, MGMCommentType)
{
    MGMCommentTypeShortVideo,
    MGMCommentTypeFilm,
    MGMCommentTypeFilmAlbum,
    MGMCommentTypeCollect,
    MGMCommentTypeCreate
};

@class MGMFeedItemContentShortVideoComment, MGMFeedItemContentFilmComment, MGMFeedItemContentFilmCollectionComment;
@class MGMFeedItemContentFilmCollectionCollected, MGMFeedItemContentFilmCollectionCreate, MGMFeedItemContent;

@interface MGMTimeLineCommentModel : MGMDynamicModel

/**
    是否隐藏全文按钮
 */
@property (nonatomic, assign, getter=isHideAllText) BOOL hideAllText;
@property (nonatomic, assign, readonly) MGMCommentType type;
@property (nonatomic, copy, readonly) YYTextLayout *commentTextLayout;
@property (nonatomic, assign, readonly) CGFloat commentTextHeight;
@property (nonatomic, copy, readonly) NSString *coverUrl;
@property (nonatomic, copy, readonly) NSString *shortInfo;
@property (nonatomic, copy, readonly) NSString *commentId;
@property (nonatomic, copy, readonly) NSString *contentId;
@property (nonatomic, copy, readonly) NSString *commentWord;
@property (nonatomic, strong, readonly) MGMFeedItemContentShortVideoComment *shortVideoContentModel;
@property (nonatomic, strong, readonly) MGMFeedItemContentFilmComment *filmContentModel;
@property (nonatomic, strong, readonly) MGMFeedItemContentFilmCollectionComment *filmAlbumContentModel;
@property (nonatomic, strong, readonly) MGMFeedItemContentFilmCollectionCreate *filmAlbumCreateContentModel;
@property (nonatomic, strong, readonly) MGMFeedItemContentFilmCollectionCollected *filmAlbumCollectContentModel;

@end

NS_ASSUME_NONNULL_END
