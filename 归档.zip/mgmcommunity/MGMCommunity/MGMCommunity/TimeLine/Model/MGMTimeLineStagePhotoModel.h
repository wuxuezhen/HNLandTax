//
//  MGMTimeLineStagePhotoModel.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityUGCModel.h"

NS_ASSUME_NONNULL_BEGIN

@class MGMFeedItemContentStills, MGMDynamicDetailResponseModel;

@interface MGMTimeLineStagePhotoModel : MGMDynamicModel<NSCopying>

@property (nonatomic, copy, readonly) NSString *stagePhotoCoverUrl;
@property (nonatomic, copy, readonly) NSString *stagePhotoContentID;
@property (nonatomic, copy,readonly)  NSString *stagePhotoKId;
@property (nonatomic, copy, readonly) NSString *stagePhotoName;
@property (nonatomic, copy, readonly) NSString *stagePhotoOriginalName;
@property (nonatomic, strong, readonly) MGMFeedItemContentStills *stillsContentModel;

+ (instancetype)stagePhotoModelWithDynamicDetailResponseModel:(MGMDynamicDetailResponseModel *)dynamicDetailResponseModel;

@end

NS_ASSUME_NONNULL_END
