//
//	MGMRootClass.m
//
//	Create by apple on 4/12/2018
//	Copyright © 2018. All rights reserved.
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport



#import "MGMCommunityUGCModel.h"
#import "MGMCommunity.h"
#import "MGMDynamicContent.h"
#import "MGMDynamicDetailResponseModel.h"
#import <YYText/YYText.h>
#import <MGMDataStore/MGMDSUser.h>
#import <MGMCategories/MGMCategories.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/NSString+MGMStringData.h>
#import <MGMCategories/UIColor+MGMColorExtension.h>

@interface MGMDynamicModel()

@property (nonatomic, copy) NSArray <NSString *>*dynamicTags;
@property (nonatomic, copy) NSArray <NSNumber *>*dynamicTagWidths;

@end

@implementation MGMDynamicModel

@synthesize commentTexts = _commentTexts;

#pragma mark - Public

- (instancetype)initWithFeedItem:(MGMDynamicFeedItem *)feedItem
{
    if (self = [super init])
    {
        //  评论数为0，类型非UGC或剧照都不显示一级评论列表
        _hideComment = (feedItem.comments.count == 0 ||
                        (feedItem.content.contentType != MGMSocialDynamicContentTypeMicroblog &&
                        feedItem.content.contentType != MGMSocialDynamicContentTypeStills));
        _expose = NO;
        _hideMore = NO;
        _showAll = NO;
        _clickAllTopic = NO;
        _hotTopicHeight = 0.f;
        _topics = nil;
        _feedItem = feedItem;
        _feedId = feedItem.feedId;
        _hasLike = feedItem.hasLike;
        _userId = feedItem.user.userId;
        _author = feedItem.user.nickname;
        _likeCount = feedItem.likeCount;
        _commentCount = feedItem.commentCount;
        _relationType = feedItem.user.relationType;
        _summaryImages = [feedItem.user.avatar mgu_urlEncodeString];
        _identiftyIconUrl = feedItem.user.certificationIcon;
        NSString *colorInfo = feedItem.user.colour;
        _identifyNickNameColor = colorInfo ? [UIColor dealHexString:colorInfo] : [UIColor mgu_colorWithHex:0x1A1A1A];
        _createTime = @(feedItem.publishTime ?: feedItem.time).stringValue;
        if (!_hideComment)
        {
            _commentHeight = [self commentHeightWithCount:feedItem.comments.count];
            _commentTexts = [self commentTextsWithMainComments:feedItem.comments];
        }
        _mine = [[MGMDSUser user].userId isEqualToString:feedItem.user.userId];
        
        [self setDynamicTagTextWithTag:self.feedItem.user.movieTag];
        
        if (feedItem.topicLabels.count)
        {
            _topics = [feedItem.topicLabels valueForKeyPath:@"topicName"];
            self.topicLabels = feedItem.topicLabels;
            [self setHotTopicHeightWithTities:_topics];
        }
    }
    return self;
}

- (void)udpateUserRelationWithType:(NSString *)type
{
    if ([type isEqualToString:@"NORELATION"]) {
        _relationType = MGMSocialUserRelationStranger;
    }else if ([type isEqualToString:@"MYFOLLOW"]) {
        _relationType = MGMSocialUserRelationFollowing;
    }else if ([type isEqualToString:@"MYFANS"]) {
        _relationType = MGMSocialUserRelationFollowed;
    }else if ([type isEqualToString:@"FUNSEACHOTHER"]) {
        _relationType = MGMSocialUserRelationFollowEachother;
    } else {
        _relationType = MGMSocialUserRelationInvalid;
    }
}

#pragma MGMTimeLineDelegate

- (void)updateCommentCount:(NSInteger)commentCount
{
    self.commentCount = commentCount;
}

- (void)updateLikeCount:(NSInteger)likeCount isLike:(BOOL)isLike
{
    self.hasLike = isLike;
    self.likeCount += likeCount;
}

#pragma MGMTimeLineDataSource
- (id)voteModels{
    return self.voteContent.yy_modelToJSONObject;
}

- (UIColor *)nicknameColor
{
    return self.identifyNickNameColor;
}

- (NSString *)timeLineMid
{
    return self.mid;
}

- (NSString *)timeLineFeedId
{
    return self.feedId;
}

- (NSString *)nickname
{
    return self.author;
}

- (NSString *)avatarUrl
{
    return self.summaryImages;
}

- (NSString *)userIdentiftyIconUrl
{
    return self.identiftyIconUrl;
}

- (BOOL)isCurrentUser
{
    return self.isMine;
}

- (BOOL)isLike
{
    return self.hasLike;
}

- (BOOL)isStills
{
    return (MGMTimeLineTypeStills == self.timeLineType);
}

- (BOOL)isHideMoreBtn
{
    return self.isHideMore;
}

- (BOOL)isHideFollowBtn
{
    return ((self.relationType == MGMSocialUserRelationFollowing ||
             self.relationType == MGMSocialUserRelationFollowEachother) ||
            self.isMine);
}

- (BOOL)isHideCommentView
{
    return self.isHideComment;
}

- (NSInteger)timeLineLikeCount
{
    return self.likeCount;
}

- (NSInteger)timeLineCommentCount
{
    return self.commentCount;
}

- (NSArray<NSString *> *)timeLineTags
{
    return self.dynamicTags;
}

- (NSArray<NSNumber *> *)timeLineTagWidths
{
    return self.dynamicTagWidths;
}

- (NSString *)timeLineCreateTime
{
    return self.createTime;
}

- (NSArray<NSAttributedString *> *)timeLineCommentTexts
{
    return self.commentTexts;
}

- (CGFloat)timeLineCommentHeight
{
    return self.commentHeight;
}

- (CGFloat)timeLineTopicHeight
{
    return self.hotTopicHeight;
}

#pragma mark - Private

- (void)setHotTopicHeightWithTities:(NSArray <NSString *>*)titles
{
    _hotTopicHeight = [self hotTopicHeightWithTopics:titles];
}

- (CGFloat)hotTopicHeightWithTopics:(NSArray <NSString *>*)topics
{
    if (!topics.count) return 0.f;
    
    NSString *title = nil;
    UIFont *font = [UIFont fontWithName:@"PingFangSC-Regular" size:12.f];
    NSInteger lineNum = 1;
    CGFloat space = 10.f;
    CGFloat outerSpace = 15.f;
    CGFloat topicWidth = 0.f;
    CGFloat totalWidth = 0.f;
    for (NSInteger i = 0; i < topics.count; i++) {
        title = topics[i];
        topicWidth = [self calculateTopicWidthWithTitle:title font:font];
        if ((topicWidth + space > MGMScreenW - 2 * outerSpace) && (topics.count > 1))
        {
            lineNum++;
            totalWidth = 0.f;
            continue;
        }
        
        if (topicWidth + space < MGMScreenW - (totalWidth + outerSpace))
        {
            totalWidth += (topicWidth + space);
        }
        else
        {
            totalWidth = 0.f;
            lineNum++;
        }
    }
    return lineNum * 24 + (lineNum - 1) * 10;
}

- (CGFloat)calculateTopicWidthWithTitle:(NSString *)title font:(UIFont *)font
{
    CGRect rect = [title boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, 24)
                                      options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin
                                   attributes:@{NSFontAttributeName:font} context:nil];
    return ceilf(rect.size.width + 35);
}

- (NSUInteger)calculateCharacterLengthWithString:(NSString *)string
{
    NSUInteger asciiLength = 0;
    for (NSUInteger i = 0; i < string.length; i++)
    {
        unichar uc = [string characterAtIndex: i];
        asciiLength += isascii(uc) ? 1 : 2;
    }
    NSUInteger unicodeLength = asciiLength;
    return unicodeLength;
}

/**
    设置标签
 */
- (void)setDynamicTagTextWithTag:(NSString *)tag
{
    if ([tag hasSuffix:@","])
    {
       tag = [tag stringByReplacingCharactersInRange:NSMakeRange(tag.length - 1, 1) withString:@""];
    }
    if (!tag.length) return;
    
    CGFloat space = 5.f;
    CGFloat rightSpace = self.isHideMore ? 15.f : 54.f;
    CGFloat maxWidth = MGMScreenW - 65.f - 50.f - rightSpace;
    CGFloat tagTextWidth = 0.f;
    CGFloat tagTextTotalWidth = 0.f;
    NSInteger index = 0;
    NSArray *dynamicTags = [tag componentsSeparatedByString:@","];
    NSMutableArray *tagM = [NSMutableArray arrayWithCapacity:dynamicTags.count];
    NSMutableArray *tagTextWidthM = [NSMutableArray array];
    for (NSString *tag in dynamicTags) {
        tagTextWidth = [tag mgu_sizeForFont:[UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size:8]
                                        size:CGSizeMake(CGFLOAT_MAX, 8)
                                        mode:(NSLineBreakByWordWrapping)].width + 2 * space;
        tagTextWidth = ceilf(tagTextWidth);
        tagTextTotalWidth += (tagTextWidth + index * space);
        if (tagTextTotalWidth > maxWidth)
        {
            break;
        }
        
        [tagM addObject:tag];
        [tagTextWidthM addObject:@(tagTextWidth)];
        index++;
    }
    
    _dynamicTags = [tagM copy];
    _dynamicTagWidths = [tagTextWidthM copy];
}

- (CGFloat)commentHeightWithCount:(NSInteger)commentCount
{
    if (commentCount == 1) return (15 + 16 + 15 + 20);
    if (commentCount == 2) return (15 + 16*2 + 11 + 15 + 20);
    return (15 + 16*3 + 11*2 + 15 + 20);
}

- (NSArray <NSAttributedString *>*)commentTextsWithMainComments:(NSArray <MGMSocialMainComment *>*)mainComments
{
    NSInteger showCommentMaxCount = 2;
    NSInteger count = mainComments.count;
    NSMutableArray *commentTextM = [NSMutableArray arrayWithCapacity:count];
    MGMSocialMainComment *mainComment = nil;
    NSAttributedString *commentAttr = nil;
    for (NSInteger i = 0; i < count; i++)
    {
        //  超过2条，第3条显示查看全部
        if (showCommentMaxCount == commentTextM.count)
        {
            [commentTextM addObject:[self checkAllAttributeText]];
            break;
        }
        mainComment = mainComments[i];
        commentAttr = [self commentStringWihtName:mainComment.userName body:mainComment.commentWord];
        if (commentAttr)
        {
            [commentTextM addObject:commentAttr];
        }
    }
    return [commentTextM copy];
}

- (YYTextLayout *)textLayoutWithText:(NSString *)text
{
    if (!text.length) return nil;
    
    NSString *textContent = [text stringByReplacingOccurrencesOfString:@"<br>" withString:@"\n"];
    textContent = [textContent stringByReplacingOccurrencesOfString:@"<p>" withString:@""];
    textContent = [textContent stringByReplacingOccurrencesOfString:@"</p>" withString:@""];

    NSMutableAttributedString *attrM = [[NSMutableAttributedString alloc] initWithString:textContent];
    attrM.yy_font = [UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size:14];
    attrM.yy_color = [UIColor mgu_colorWithHex:0x333333 opacity:1.f];
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.firstLineHeadIndent = CGFLOAT_MIN;
    style.minimumLineHeight = 25;
    attrM.yy_paragraphStyle = style;
    YYTextLayout *textLayout = [self textLayoutWithAttrText:attrM showAll:self.showAll];
    return textLayout;
}

- (YYTextLayout *)textLayoutWithAttrText:(NSAttributedString *)text showAll:(BOOL)showAll
{
    NSAttributedString *attrText = text ?: [[NSAttributedString alloc] initWithString:@""];
    YYTextContainer *container = [YYTextContainer containerWithSize:CGSizeMake(kMainScreenWidth-kMGMHBL2X(30), CGFLOAT_MAX)];
    if (!showAll)
    {
        container.maximumNumberOfRows = 3;
        container.truncationType = YYTextTruncationTypeEnd;
        container.truncationToken = [self addSeeMoreButton];
    }
    YYTextLayout *layout = [YYTextLayout layoutWithContainer:container text:attrText];
    return layout;
}

- (NSAttributedString *)addSeeMoreButton
{
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:@"...全文"];
    YYTextHighlight *hi = [YYTextHighlight new];
    [text yy_setColor:[UIColor clearColor] range:[text.string rangeOfString:@"全文"]];
    [text yy_setTextHighlight:hi range:[text.string rangeOfString:@"全文"]];
    text.yy_font = [UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size:14];
    
    YYLabel *seeMore = [YYLabel new];
    seeMore.attributedText = text;
    [seeMore sizeToFit];
    return [NSAttributedString yy_attachmentStringWithContent:seeMore contentMode:UIViewContentModeCenter attachmentSize:seeMore.size alignToFont:text.yy_font alignment:YYTextVerticalAlignmentCenter];
}

- (NSAttributedString *)checkAllAttributeText
{
    NSDictionary *attr = @{NSForegroundColorAttributeName: [UIColor mgu_colorWithHex:333333],
                           NSFontAttributeName: [UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size:12]};
    return [[NSAttributedString alloc] initWithString:@"查看全部 >" attributes:attr];
}

- (NSAttributedString *)commentStringWihtName:(NSString *)name body:(NSString *)body
{
    if (body.length==0 || [name isEqual:[NSNull null]]) {
        return nil;
    }
    NSString *prefixStr = [(name.length > 0) ? name : @"咪咕用户" stringByAppendingString:@": "];
    NSString *topStr = [prefixStr stringByAppendingString:body];
    
    NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:topStr];
    NSRange nameRange = NSMakeRange(0, prefixStr.length);    
    [attrStr addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0] range:NSMakeRange(0, topStr.length)];
    [attrStr addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1/1.0] range:nameRange];
    return attrStr;
}

@end
