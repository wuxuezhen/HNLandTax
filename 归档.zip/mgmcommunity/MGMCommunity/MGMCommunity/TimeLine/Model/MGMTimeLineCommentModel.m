//
//  MGMTimeLineCommentModel.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLineCommentModel.h"
#import "MGMFeedItemContentFilmComment.h"
#import "MGMFeedItemContentShortVideoComment.h"
#import "MGMFeedItemContentFilmCollectionComment.h"
#import "MGMFeedItemContentFilmCollectionCreate.h"
#import "MGMFeedItemContentFilmCollectionCollected.h"
#import <YYText/YYText.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>

@implementation MGMTimeLineCommentModel

#pragma mark - Override

- (instancetype)initWithFeedItem:(MGMDynamicFeedItem *)feedItem
{
    if (self = [super initWithFeedItem:feedItem])
    {
        self.timeLineType = MGMTimeLineTypeComment;

        MGMFeedItemContent *content = feedItem.content;
        if ([content isKindOfClass:[MGMFeedItemContentShortVideoComment class]])
        {
            MGMFeedItemContentShortVideoComment *shortVideoContent = (MGMFeedItemContentShortVideoComment *)content;
            _type = MGMCommentTypeShortVideo;
            _shortVideoContentModel = shortVideoContent;
            _commentId = shortVideoContent.commentID;
            _contentId = shortVideoContent.contentID;
            _shortInfo = shortVideoContent.name;
            _commentWord = shortVideoContent.parentCommentTxt;
            _coverUrl = [shortVideoContent.pics.highResolutionV mgu_urlEncodeString];
            _commentTextLayout = [self textLayoutWithText:_commentWord];
            self.mid = shortVideoContent.mid;
        }
        else if ([content isKindOfClass:[MGMFeedItemContentFilmComment class]])
        {
            MGMFeedItemContentFilmComment *filmContent = (MGMFeedItemContentFilmComment *)content;
            _type = MGMCommentTypeFilm;
            _commentId = filmContent.commentId;
            _contentId = filmContent.contentId;
            _commentWord = filmContent.comment;
            _filmContentModel = filmContent;
            _coverUrl = [filmContent.pics.highResolutionV mgu_urlEncodeString];
            
            //  返回nil的处理
            NSString *releaseTime = filmContent.releaseTime ?: @"";
            NSString *country = filmContent.country ?: @"";
            NSString *filmType = filmContent.typeName ?: @"";
            if (filmType.length)
            {
                filmType = [filmType stringByReplacingOccurrencesOfString:@"," withString:@" / "];
            }
            _shortInfo = [NSString stringWithFormat:@"%@ %@ %@",releaseTime, country, filmType];

            _commentTextLayout = [self textLayoutWithText:_commentWord];
            self.mid = filmContent.mid;
        }
        else if ([content isKindOfClass:[MGMFeedItemContentFilmCollectionComment class]])
        {
            MGMFeedItemContentFilmCollectionComment *filmAlbumContent = (MGMFeedItemContentFilmCollectionComment *)content;
            _type = MGMCommentTypeFilmAlbum;
            _filmAlbumContentModel = filmAlbumContent;
            _commentId = filmAlbumContent.commentID;
            _contentId = filmAlbumContent.contentID;
            _commentWord = filmAlbumContent.parentCommentTxt;
            _coverUrl = [filmAlbumContent.pics.highResolutionV mgu_urlEncodeString];
            _shortInfo = [self filmCollectionInfoWithfilmNum:filmAlbumContent.filmNum filmUserName:filmAlbumContent.sname];
            _commentTextLayout = [self textLayoutWithText:_commentWord];
            self.mid = filmAlbumContent.objectId;
        }
        else if ([content isKindOfClass:[MGMFeedItemContentFilmCollectionCollected class]])
        {
            MGMFeedItemContentFilmCollectionCollected *filmAlbumCollectedContent = (MGMFeedItemContentFilmCollectionCollected *)content;
            _type = MGMCommentTypeCollect;
            _coverUrl = [filmAlbumCollectedContent.pics.highResolutionV mgu_urlEncodeString];
            _shortInfo = [self filmCollectionInfoWithfilmNum:filmAlbumCollectedContent.filmNum filmUserName:filmAlbumCollectedContent.sname];
            _filmAlbumCollectContentModel = filmAlbumCollectedContent;
            _commentTextLayout = [self textLayoutWithText:@"收藏了影单"];
        }
        else
        {
            MGMFeedItemContentFilmCollectionCreate *filmAlbumCreateContent = (MGMFeedItemContentFilmCollectionCreate *)content;
            _type = MGMCommentTypeCreate;
            _coverUrl = [filmAlbumCreateContent.pics.highResolutionV mgu_urlEncodeString];
            _shortInfo = [self filmCollectionInfoWithfilmNum:filmAlbumCreateContent.filmNum filmUserName:filmAlbumCreateContent.sname];
            _filmAlbumCreateContentModel = filmAlbumCreateContent;
            _commentTextLayout = [self textLayoutWithText:@"创建了影单"];
        }
        _commentTextHeight = ceilf(_commentTextLayout.textBoundingSize.height) ?: 25.f;
        _hideAllText = !_commentTextLayout.truncatedLine;

    }
    return self;
}

#pragma mark - Private

- (NSString *)filmCollectionInfoWithfilmNum:(NSString *)filmNum
                               filmUserName:(NSString *)filmUserName
{
    NSString *info = [NSString stringWithFormat:@"%@创建",filmUserName];
    return info;
}

#pragma mark - Getter

- (CGFloat)rowHeight
{
    return 72.f + 14.f + 70 + 55.f + self.commentTextHeight + self.commentHeight;
}

@end
