//
//  MGMTimeLineImageTextModel.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityUGCModel.h"

NS_ASSUME_NONNULL_BEGIN

@class MGMFeedItemContentMicroblog, MGMDynamicDetailResponseModel, MGMFeedItemPicture;

@interface MGMTimeLineImageTextModel : MGMDynamicModel

@property (nonatomic, copy, readonly) NSString *textContent;
@property (nonatomic, strong) YYTextLayout *textLayout;
@property (nonatomic, copy, readonly) NSArray <NSString *>*picUrls;
@property (nonatomic, copy, readonly) NSArray <NSString *>*topics;
@property (nonatomic, copy, readonly) NSArray <MGMFeedItemPicture *>*picItems;
@property (nonatomic, strong, readonly) MGMFeedItemContentMicroblog *content;

+ (instancetype)imageTextModelWithDynamicDetailResponseModel:(MGMDynamicDetailResponseModel *)dynamicDetailResponseModel;

@end

NS_ASSUME_NONNULL_END
