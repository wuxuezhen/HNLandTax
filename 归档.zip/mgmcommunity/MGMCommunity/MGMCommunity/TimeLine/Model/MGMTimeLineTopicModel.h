//
//  MGMTimeLineTopicModel.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityUGCModel.h"

NS_ASSUME_NONNULL_BEGIN

@class MGMFeedItemContentNewsComment, MGMFeedItemContentTopicComment;

@interface MGMTimeLineTopicModel : MGMDynamicModel

@property (nonatomic, copy, readonly)  NSString *comment;
@property (nonatomic, strong, readonly) NSDate *commentTime;
@property (nonatomic, copy, readonly) NSString *commentId;
@property (nonatomic, copy, readonly)  NSString *contentTitle;
@property (nonatomic, copy, readonly) NSString *contentType;
@property (nonatomic, copy, readonly) NSString *contentId;
@property (nonatomic, copy, readonly) NSString *contentName;
@property (nonatomic, strong, readonly) YYTextLayout *topicCommentLayout;
@property (nonatomic, strong, readonly) MGMFeedItemContentNewsComment *newsContentModel;
@property (nonatomic, strong, readonly) MGMFeedItemContentTopicComment *topicContentModel;
@property (nonatomic, assign, readonly) CGFloat textHeight;

- (instancetype)initWithFeedItem:(MGMDynamicFeedItem *)feedItem
                    timeLineType:(MGMTimeLineType)timeLineType;

@end

NS_ASSUME_NONNULL_END
