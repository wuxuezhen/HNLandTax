//
//  MGMGKeTimeLineCell.m
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMGKeTimeLineCell.h"
#import "MGMCommunity.h"
#import "MGMCommunityResource.h"
#import "MGMTimeLineGKeModel.h"
#import <MGMUIKit/MGMGlabalMacro.h>

#import <YYText/YYText.h>
#import <YYWebImage/YYWebImage.h>
#import <MGMCategories/UIView+MGMFrame.h>

#import <MGMLegoModule/MGMLittleVideoFragment.h>
#import <MGMCategories/UIView+MGMToast.h>
#import <MGMCategories/UIView+MGMPosition.h>
#import <MGKit/UIView+Gradient.h>
#import <MGMSocialModule/MGMFeedItemContentGKeVideo.h>

#define MGMGkeMaskViewHeight 30.f

@interface MGMGKeTimeLineCell()

@property (nonatomic, weak) YYLabel *videoNameLabel;
@property (nonatomic, weak) UIButton *videoHotView;
@property (nonatomic, weak) UILabel *videoDurationLabel;
@property (nonatomic, weak) UIImageView *videoImgView;
@property (nonatomic, weak) UIView *bottomMaskView;
@property (nonatomic, weak) UIButton *playBtn;

@property (nonatomic, strong) MGMLittleVideoFragment *littleVideoFragment;

@end

@implementation MGMGKeTimeLineCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self setSubviews];
    }
    return self;
}

//页面滑动，cell消失调用
- (void)willDisappear {
    if(self.littleVideoFragment.isFullScreen) {
        return;
    }
    MGMTimeLineGKeModel *gkeModel = self.timeLineModel;
    if(![self.littleVideoFragment.currentPlayContenId isEqualToString:gkeModel.gKeContentModel.contentID]) {
        return;
    }
    [self.littleVideoFragment onDestroy];
}

- (void)setupBillboard:(MGUFragmentBillboard *)billboard {
    [super setupBillboard:billboard];
    
    [self.littleVideoFragment setupBillboard:billboard];
}

#pragma mark - Private

- (void)setSubviews {
    UILabel *videoTextLabel = [[UILabel alloc] init];
    videoTextLabel.text = @"发布了视频";
    videoTextLabel.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
    videoTextLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 14];
    videoTextLabel.frame = CGRectMake(MGMItemSpace, 70.f, 80, 18);
    [self.contentView addSubview:videoTextLabel];
    
    UIImageView *videoImgView = [[UIImageView alloc] initWithFrame:CGRectMake(MGMItemSpace, CGRectGetMaxY(videoTextLabel.frame) + 12, MGMScreenW - 2 * MGMItemSpace, 0.f)];
    videoImgView.userInteractionEnabled = YES;
    videoImgView.backgroundColor = [UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1.0];;
    videoImgView.layer.cornerRadius = 4.f;
    videoImgView.layer.masksToBounds = YES;
    [self.contentView addSubview:videoImgView];
    self.videoImgView = videoImgView;

    //  顶部遮罩
    UIView *topMaskView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, videoImgView.mgm_width, MGMGkeMaskViewHeight)];
    [topMaskView setGradientBackgroundWithColors:@[[UIColor mgu_colorWithHex:0x00000 opacity:.7], [UIColor mgu_colorWithHex:0x000000 opacity:0]]
                                       locations:@[@(0), @(1.0f)]
                                      startPoint:CGPointMake(.5, .06)
                                        endPoint:CGPointMake(0.5, 1)];
    [videoImgView addSubview:topMaskView];
    
    //  底部遮罩
    UIView *bottomMaskView = [[UIView alloc] init];
    [bottomMaskView setGradientBackgroundWithColors:@[[UIColor mgu_colorWithHex:0x000000 opacity:0],[UIColor mgu_colorWithHex:0x00000 opacity:.7]]
                                          locations:@[@(0), @(1.0f)]
                                         startPoint:CGPointMake(.5, .06)
                                           endPoint:CGPointMake(0.5, 1)];
    [videoImgView addSubview:bottomMaskView];
    self.bottomMaskView = bottomMaskView;
    
    YYLabel *videoNameLabel = [[YYLabel alloc] initWithFrame:CGRectMake(10, 10, videoImgView.mgm_width - 2 * 10, 50)];
    videoNameLabel.textColor = [UIColor whiteColor];
    videoNameLabel.numberOfLines = 2;
    videoNameLabel.textVerticalAlignment = YYTextVerticalAlignmentTop;
    videoNameLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size: 15];
    [videoImgView addSubview:videoNameLabel];
    self.videoNameLabel = videoNameLabel;
    
    UIButton *playBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 35, 35)];
    playBtn.center = CGPointMake(videoImgView.mgm_width * 0.5, videoImgView.mgm_height * 0.5);
    [playBtn setImage:[MGMCommunityResource imageNamed:@"movie_play_icon"] forState:(UIControlStateNormal)];
    [playBtn addTarget:self
                action:@selector(playAction)
      forControlEvents:(UIControlEventTouchUpInside)];
    [videoImgView addSubview:playBtn];
    self.playBtn = playBtn;
    
    UIButton *videoHotView = [[UIButton alloc] initWithFrame:CGRectMake(10, videoImgView.mgm_height - 9, 10, 35)];
    videoHotView.hidden = YES;
    videoHotView.titleEdgeInsets = UIEdgeInsetsMake(0, 2, 0, 0);
    videoHotView.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    videoHotView.enabled = NO;
    videoHotView.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 10];
    [videoHotView setTitle:@"0" forState:(UIControlStateDisabled)];
    [videoHotView setImage:[MGMCommunityResource imageNamed:@"icon_hot"] forState:(UIControlStateDisabled)];
    [videoImgView addSubview:videoHotView];
    
    UILabel *videoDurationLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    videoDurationLabel.textColor = [UIColor whiteColor];
    videoDurationLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:10];
    [videoImgView addSubview:videoDurationLabel];
    self.videoDurationLabel = videoDurationLabel;
}

- (void)relayoutSubviews
{
    [self.videoDurationLabel sizeToFit];
    CGFloat space = 10.f;
    CGFloat videoDurationLabelW = self.videoDurationLabel.mgm_width;
    CGFloat videoDurtaionLabelH = self.videoDurationLabel.mgm_height;
    self.videoDurationLabel.frame = CGRectMake(self.videoImgView.mgm_width - space - videoDurationLabelW,
                                               self.videoImgView.mgm_height - space - videoDurtaionLabelH,
                                               videoDurationLabelW,
                                               videoDurtaionLabelH);
    self.playBtn.mgm_centerY = self.videoImgView.mgm_height * 0.5;
    self.videoImgView.contentMode = UIViewContentModeCenter;
}

#pragma mark - Target Action

 - (void)playAction
{
     MGMWeakSelf
     MGMTimeLineGKeModel *gkeModel = self.timeLineModel;
    [self routerEventWithName:MGMCommunityGeKePlayEvent
                     userInfo:@{
                                MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel,
                                MGMCommunityMiniVideoContentID: gkeModel.gKeContentModel.contid ?: @"",
                                }];
    
     self.littleVideoFragment.jid = [NSString stringWithFormat:@"%@%.0f",[[UIDevice currentDevice] identifierForVendor].UUIDString,[[NSDate date] timeIntervalSince1970]];
     [self.littleVideoFragment showPlayLoadingView];
     [self.littleVideoFragment sendGetPlayUrlInfoWithContId:gkeModel.gKeContentModel.contentID  handler:^(NSArray<MGMMediaPlayModel *> * _Nonnull mediaArray) {
         MGMStrongSelf
         MGMMediaPlayModel *mediaModel = [mediaArray mgu_objectOrNilAtIndex:0];
         [self mgm_gkeVideoRequestFinished:mediaModel];
     }];
}

- (void)handleTapGestureForGKe:(UITapGestureRecognizer *)gesture
{
    CGPoint touchP = [gesture locationInView:self.contentView];
    if (CGRectContainsPoint(self.videoImgView.frame, touchP))
    {
        if (self.littleVideoFragment.currentPlayContenId.length > 0) { //当前播放节目
            return;
        }
    }
    
    MGMTimeLineGKeModel *gkeModel = self.timeLineModel;
    [self routerEventWithName:MGMCommunityMiniVideoEvent
                     userInfo:@{
                                MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel,
                                MGMCommunityMiniVideoContentID: gkeModel.gKeContentModel.contid ?: @"",
                                MGMCommunityMiniVideoContentName: gkeModel.gKeContentModel.name ?: @"",
                                MGMCommunityMiniVideoType: @"15"
                                }];
}

- (void)mgm_gkeVideoRequestFinished:(MGMMediaPlayModel *)mediaModel
{
    if(mediaModel && [mediaModel isKindOfClass:[MGMMediaPlayModel class]]) {
        self.littleVideoFragment.mediaModel = mediaModel;
        [self.littleVideoFragment mgm_setVideoSetting];
        [self.littleVideoFragment mgm_startPlayVideo];
    }
    else {
        [self.littleVideoFragment hidePlayLoadingView];
        [self.littleVideoFragment onDestroy];
        [self showAutoToastInWindowWithText:@"网络异常，请稍后重试~"];
    }
}

#pragma mark - Setter&Getter

- (void)setTimeLineModel:(id<MGMTimeLineDataSource,MGMTimeLineDelegate>)timeLineModel
{
    [super setTimeLineModel:timeLineModel];
    MGMTimeLineGKeModel *gkeModel = (MGMTimeLineGKeModel *)timeLineModel;
    self.videoNameLabel.text = gkeModel.gKeName;
    self.videoDurationLabel.text = gkeModel.gKeDuration;
    self.videoImgView.mgm_height = gkeModel.gKeVideoViewHeight;
    self.bottomMaskView.frame = CGRectMake(0, self.videoImgView.mgm_height - MGMGkeMaskViewHeight, self.videoImgView.mgm_width, MGMGkeMaskViewHeight);
    self.videoImgView.contentMode = UIViewContentModeCenter;
    [self relayoutSubviews];
    
    MGMWeakSelf;
    UIImage *placeholder = [MGMCommunityResource imageNamed:@"img_zwt"];
    [self.videoImgView yy_setImageWithURL:gkeModel.gKeCoverUrl
                              placeholder:placeholder
                                  options:0
                               completion:^(UIImage * _Nullable image, NSURL * _Nonnull url, YYWebImageFromType from, YYWebImageStage stage, NSError * _Nullable error) {
                                   MGMStrongSelf;
                                   self.videoImgView.contentMode = UIViewContentModeScaleAspectFill;
                               }];
    
    self.littleVideoFragment.lowResolutionV = gkeModel.gKeContentModel.pics.lowResolutionV;
    if(!self.videoImgView.isVisible) {
        [self willDisappear];
    }
}

- (SEL)tapSelector
{
    return @selector(handleTapGestureForGKe:);
}

- (MGMLittleVideoFragment *)littleVideoFragment
{
    if(!_littleVideoFragment) {
        _littleVideoFragment = [[MGMLittleVideoFragment alloc] init];
        _littleVideoFragment.containView = self.videoImgView;
        MGMWeakSelf
        _littleVideoFragment.reloadPlayUrlHandler = ^{
            MGMStrongSelf
            [self playAction];
        };
    }
    return _littleVideoFragment;
}

@end
