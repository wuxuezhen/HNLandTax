//
//  MGMTimeLineTabView.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/1.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLineTabView.h"
#import <MGMUIKit/MGMGlabalMacro.h>
#import "MGMCommunityResource.h"
#import <MGMDataStore/MGMDynamicTabsModel.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <YYWebImage/UIImageView+YYWebImage.h>
#import <Masonry/Masonry.h>
#import <MGKit/MGKit.h>

@interface MGMDynamicBaseTabsCell:UICollectionViewCell
//是否选中
@property (nonatomic, assign) BOOL                  isSelect;

@property (nonatomic, strong) UILabel               *dynamicLabel;

@property (nonatomic, strong) UIImageView           *dynamicLineView;

@property (nonatomic, strong) MGMDynamicTabsModel  *dynamicTabModel;

@end

@implementation MGMDynamicBaseTabsCell

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        [self.contentView addSubview:self.dynamicLineView];
        [self.dynamicLineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.centerX.equalTo(self);
            make.size.mas_equalTo(CGSizeMake(27, 3));
        }];
    }
    return self;
}

- (void)setIsSelect:(BOOL)isSelect {
    _isSelect = isSelect;
    
    self.dynamicLineView.hidden = !isSelect;
    self.dynamicLabel.font = isSelect ? [UIFont fontWithName:@"PingFangSC-Semibold" size:16] : [UIFont fontWithName:@"PingFangSC-Regular" size:16];;
    self.dynamicLabel.textColor = isSelect ? [UIColor mgu_colorWithHex:0x1A1A1A] : [UIColor mgu_colorWithHex:0xB2B2B2];
}

- (void)setDynamicTabModel:(MGMDynamicTabsModel *)dynamicTabModel {
    _dynamicTabModel = dynamicTabModel;
}

#pragma mark - lazyload
- (UIImageView *)dynamicLineView {
    if(!_dynamicLineView) {
        _dynamicLineView = [[UIImageView alloc] init];
        _dynamicLineView.image = [MGMCommunityResource originalRenderingImageNamed:@"community_Line"];
        _dynamicLineView.hidden = YES;
    }
    return _dynamicLineView;
}

- (UILabel *)dynamicLabel {
    if(!_dynamicLabel) {
        _dynamicLabel = [[UILabel alloc] init];
        _dynamicLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _dynamicLabel;
}

@end

@interface MGMDynamicLabelTabsCell:MGMDynamicBaseTabsCell

@end

@implementation MGMDynamicLabelTabsCell

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        [self.contentView addSubview:self.dynamicLabel];
        [self.dynamicLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self);
            make.width.mas_equalTo(frame.size.width);
            make.height.mas_equalTo(16);
            make.bottom.equalTo(self).offset(-14);
        }];
    }
    return self;
}

- (void)setDynamicTabModel:(MGMDynamicTabsModel *)dynamicTabModel {
    [super setDynamicTabModel:dynamicTabModel];
    
    self.dynamicLabel.text = dynamicTabModel.label;
    
    [self.dynamicLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(dynamicTabModel.dynamicWidth);
    }];
}

@end


@interface MGMDynamicIconTabsCell:MGMDynamicBaseTabsCell

@property (nonatomic, strong) UIImageView    *dynamicImageView;

@end

@implementation MGMDynamicIconTabsCell

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        [self.contentView addSubview:self.dynamicImageView];
        [self.dynamicImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self);
            make.size.mas_equalTo(CGSizeMake(frame.size.width, 44));
            make.bottom.equalTo(self);
        }];
    }
    return self;
}

- (void)setDynamicTabModel:(MGMDynamicTabsModel *)dynamicTabModel {
    [super setDynamicTabModel:dynamicTabModel];
    
    if([dynamicTabModel.icon mgu_isNotBlank]) {
        [self.dynamicImageView yy_setImageWithURL:[NSURL URLWithString:dynamicTabModel.icon] options:(YYWebImageOptionSetImageWithFadeAnimation)];
    }
    [self.dynamicImageView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(dynamicTabModel.dynamicWidth, 44));
    }];
}

#pragma mark - layload
- (UIImageView *)dynamicImageView {
    if(!_dynamicImageView) {
        _dynamicImageView = [[UIImageView alloc] init];
    }
    return _dynamicImageView;
}

@end

@interface MGMTimeLineTabView()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic, copy) NSArray    <MGMDynamicTabsModel *>*tabsArray;

@property (nonatomic, strong) UICollectionView                *tabCollectionView;

@property (nonatomic, strong) UICollectionViewFlowLayout      *tabFlowLayout;
    
@property (nonatomic, strong) UIView                          *lineView;

@end

@implementation MGMTimeLineTabView

- (instancetype)initWithFrame:(CGRect)frame
                         tabs:(NSArray <MGMDynamicTabsModel *>*)tabsArray {
    if(self = [super initWithFrame:frame]) {
        [self addSubview:self.tabCollectionView];
        [self addSubview:self.lineView];
        self.tabsArray = tabsArray;
        for (NSInteger index = 0; index < tabsArray.count; index++) {
            MGMDynamicTabsModel *tabModel =[tabsArray mgu_objectOrNilAtIndex:index];
            if([tabModel.icon mgu_isNotBlank]) {
                NSURL *imageUrl = [NSURL URLWithString:tabModel.icon];
                if(imageUrl) {
                    [[YYWebImageManager sharedManager] requestImageWithURL:imageUrl options:(YYWebImageOptionSetImageWithFadeAnimation) progress:NULL transform:NULL completion:^(UIImage * _Nullable image, NSURL * _Nonnull url, YYWebImageFromType from, YYWebImageStage stage, NSError * _Nullable error) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            if(image.size.height <=0) {
                                tabModel.dynamicWidth = image.size.width;
                            }
                            else {
                                tabModel.dynamicWidth = image.size.width / image.size.height*44;
                            }
                            [self.tabCollectionView reloadData];
                        });
                    }];
                }
            }
            else {
                NSString *tabName = tabModel.label;
                if(tabModel.label.length > 11) {
                    tabName = [tabModel.label substringToIndex:11];
                }
                tabModel.dynamicWidth = [tabName boundingRectWithSize:CGSizeMake(1000, 16) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:@{NSFontAttributeName:[UIFont fontWithName:@"PingFangSC-Regular" size:16]} context:nil].size.width+1;
            }
        }
    }
    return self;
}

- (void)setCurrentIndex:(NSInteger)currentIndex {
    if(_currentIndex == currentIndex) {
        return;
    }
    _currentIndex = currentIndex;
    
    [self.tabCollectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:currentIndex inSection:0] atScrollPosition:(UICollectionViewScrollPositionCenteredHorizontally) animated:YES];
    [self.tabCollectionView reloadData];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.tabsArray.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    MGMDynamicTabsModel *tabModel = [self.tabsArray mgu_objectOrNilAtIndex:indexPath.item];
    if([tabModel.icon mgu_isNotBlank]) {
        MGMDynamicIconTabsCell *iconTabCel = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([MGMDynamicIconTabsCell class]) forIndexPath:indexPath];
        iconTabCel.isSelect = (self.currentIndex == indexPath.item);
        iconTabCel.dynamicTabModel = tabModel;
        return iconTabCel;
    }
    MGMDynamicLabelTabsCell *labelTabCell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([MGMDynamicLabelTabsCell class]) forIndexPath:indexPath];
    labelTabCell.isSelect = (self.currentIndex == indexPath.item);
    labelTabCell.dynamicTabModel = tabModel;
    return labelTabCell;
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    MGMDynamicTabsModel *tabModel = [self.tabsArray mgu_objectOrNilAtIndex:indexPath.item];
    [collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:(UICollectionViewScrollPositionCenteredHorizontally) animated:YES];
    if(self.dynamicTabClickHandler) {
        self.dynamicTabClickHandler(indexPath.item);
    }
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    MGMDynamicTabsModel *tabModel = [self.tabsArray mgu_objectOrNilAtIndex:indexPath.item];
    if(SYSTEM_VERSION >= 9.0 &&  SYSTEM_VERSION < 11.0) {
       return CGSizeMake(tabModel.dynamicWidth, 16);
    }
    return CGSizeMake(tabModel.dynamicWidth, MGMNavigationBarH);
}

#pragma mark - lazy load
- (UICollectionView *)tabCollectionView {
    if(!_tabCollectionView) {
        _tabCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, MGMStatusBarH, MGMScreenW, MGMNavigationBarH) collectionViewLayout:self.tabFlowLayout];
        _tabCollectionView.contentInset = UIEdgeInsetsMake(0, 15, 0, 15);
        _tabCollectionView.backgroundColor = [UIColor whiteColor];
        _tabCollectionView.delegate = self;
        _tabCollectionView.dataSource = self;
        _tabCollectionView.showsHorizontalScrollIndicator = NO;
        if (@available(iOS 11.0, *)) {
            _tabCollectionView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        [_tabCollectionView registerClass:[MGMDynamicLabelTabsCell class] forCellWithReuseIdentifier:NSStringFromClass([MGMDynamicLabelTabsCell class])];
        [_tabCollectionView registerClass:[MGMDynamicIconTabsCell class] forCellWithReuseIdentifier:NSStringFromClass([MGMDynamicIconTabsCell class])];
    }
    return _tabCollectionView;
}

- (UICollectionViewFlowLayout *)tabFlowLayout {
    if(!_tabFlowLayout) {
        _tabFlowLayout = [[UICollectionViewFlowLayout alloc] init];
        _tabFlowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        _tabFlowLayout.minimumInteritemSpacing = 30;
    }
    return _tabFlowLayout;
}
    
- (UIView *)lineView {
    if(!_lineView) {
        _lineView = [[UIView alloc] initWithFrame:CGRectMake(0, self.height-1.0/[UIScreen mainScreen].scale, MGMScreenW, 1.0/[UIScreen mainScreen].scale)];
        _lineView.backgroundColor = [UIColor mgu_colorWithHex:0xE2E2E2];
    }
    return _lineView;
}

@end
