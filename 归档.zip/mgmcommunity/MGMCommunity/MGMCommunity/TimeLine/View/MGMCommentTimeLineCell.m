//
//  MGMCommentTimeLineCell.m
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommentTimeLineCell.h"
#import "MGMFilmThumbView.h"
#import "MGMVideoThumbView.h"
#import "MGMFilmAlbumThumbView.h"
#import "MGMTimeLineCommentModel.h"
#import "MGMFeedItemContentFilmComment.h"
#import "MGMFeedItemContentShortVideoComment.h"
#import "MGMFeedItemContentFilmCollectionComment.h"
#import "MGMFeedItemContentFilmCollectionCreate.h"
#import "MGMFeedItemContentFilmCollectionCollected.h"

@interface MGMCommentTimeLineCell()

@property (nonatomic, weak) UILabel *allTextLabel;
@property (nonatomic, weak) YYLabel *commentTextLabel;

/**
    影片
 */
@property (nonatomic, weak) MGMFilmThumbView *filmThumbView;

/**
    小视频
 */
@property (nonatomic, weak) MGMVideoThumbView *videoThumbView;

/**
    影单
 */
@property (nonatomic, weak) MGMFilmAlbumThumbView *albumThumbView;


@end

@implementation MGMCommentTimeLineCell

#pragma mark - Override

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self setSubviews];
    }
    return self;
}

#pragma mark - Private

- (void)setSubviews
{
    YYLabel *commentTextLabel = [[YYLabel alloc] init];
    commentTextLabel.numberOfLines = 0;
    commentTextLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 14];
    UITapGestureRecognizer *commentTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleCommentTapGesture)];
    [commentTextLabel addGestureRecognizer:commentTapGesture];
    commentTextLabel.textColor = [UIColor mgu_colorWithHex:0x333333];
    [self.contentView addSubview:commentTextLabel];
    self.commentTextLabel = commentTextLabel;
    
    [commentTextLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.right.offset(-15);
        make.top.equalTo(self.topContainerView.mas_bottom).offset(-1);
    }];
    
    UILabel *allTextLabel = [[UILabel alloc] init];
    allTextLabel.text = @"全文";
    allTextLabel.textColor = [UIColor mgu_colorWithHex:0x63ADEF];
    allTextLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 14];
    [commentTextLabel addSubview:allTextLabel];
    self.allTextLabel = allTextLabel;
    
    [allTextLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.offset(25);
        make.right.offset(0);
        make.bottom.offset(-3);
    }];
    
    CGFloat cornerRadius = 3.f;
    MGMFilmThumbView *filmThumbView = [[MGMFilmThumbView alloc] init];
    filmThumbView.hidden = YES;
    filmThumbView.layer.cornerRadius = cornerRadius;
    [self.contentView addSubview:filmThumbView];
    self.filmThumbView = filmThumbView;
    
    [filmThumbView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(commentTextLabel);
        make.top.equalTo(commentTextLabel.mas_bottom).offset(12);
        make.height.offset(70);
    }];
    
    MGMVideoThumbView *videoThumbView = [[MGMVideoThumbView alloc] init];
    videoThumbView.hidden = YES;
    videoThumbView.layer.cornerRadius = cornerRadius;
    [self.contentView addSubview:videoThumbView];
    self.videoThumbView = videoThumbView;
    
    [videoThumbView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(filmThumbView);
    }];
    
    MGMFilmAlbumThumbView *albumThumbView = [[MGMFilmAlbumThumbView alloc] init];
    albumThumbView.layer.cornerRadius = cornerRadius;
    [self.contentView addSubview:albumThumbView];
    self.albumThumbView = albumThumbView;

    [albumThumbView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(filmThumbView);
    }];
}

- (void)setTimeLineModel:(id<MGMTimeLineDataSource,MGMTimeLineDelegate>)timeLineModel
{
    [super setTimeLineModel:timeLineModel];
    MGMTimeLineCommentModel *commentModel = (MGMTimeLineCommentModel *)timeLineModel;
    self.albumThumbView.hidden = NO;
    self.filmThumbView.hidden = self.videoThumbView.hidden = YES;
    self.allTextLabel.hidden = commentModel.isHideAllText;
    self.commentTextLabel.textLayout = commentModel.commentTextLayout;
    switch (commentModel.type) {
        case MGMCommentTypeCreate:
        {
            self.commentTextLabel.userInteractionEnabled = NO;
            self.likeCountBtn.hidden = self.commentCountBtn.hidden = YES;
            [self setFilmAlbumViewName:commentModel.filmAlbumCreateContentModel.filmListName
                                  info:commentModel.shortInfo
                              coverUrl:commentModel.coverUrl];
        }
            break;
        
        case MGMCommentTypeCollect:
        {
            self.commentTextLabel.userInteractionEnabled = NO;
            self.likeCountBtn.hidden = self.commentCountBtn.hidden = YES;
            [self setFilmAlbumViewName:commentModel.filmAlbumCollectContentModel.filmListName
                                  info:commentModel.shortInfo
                              coverUrl:commentModel.coverUrl];
        }
            break;
            
        case MGMCommentTypeFilmAlbum:
        {
            self.commentTextLabel.userInteractionEnabled = YES;
            self.likeCountBtn.hidden = self.commentCountBtn.hidden = NO;
            [self setFilmAlbumViewName:commentModel.filmAlbumContentModel.filmListName
                                  info:commentModel.shortInfo
                              coverUrl:commentModel.coverUrl];
        }
            break;
            
        case MGMCommentTypeFilm:
        {
            self.commentTextLabel.userInteractionEnabled = YES;
            self.filmThumbView.hidden = NO;
            self.likeCountBtn.hidden = self.commentCountBtn.hidden = NO;
            self.albumThumbView.hidden = self.videoThumbView.hidden = YES;
            if (MGMSocialSourceStatusOffline == commentModel.filmContentModel.sourceDelFlag)
            {
                self.filmThumbView.filmScoreLabel.hidden = YES;
                self.filmThumbView.filmInfoLabel.text = @"暂无影片信息";
                self.filmThumbView.filmNameLabel.text = @"内容已下线";
                self.filmThumbView.filmCoverView.contentMode = UIViewContentModeScaleToFill;
                self.filmThumbView.filmCoverView.image = [MGMCommunityResource imageNamed:@"img_ydbg"];
            }
            else
            {
                self.filmThumbView.filmInfoLabel.text = commentModel.shortInfo;
                self.filmThumbView.filmScoreLabel.hidden = NO;
                self.filmThumbView.filmScoreLabel.text = commentModel.filmContentModel.score;
                self.filmThumbView.filmNameLabel.text = commentModel.filmContentModel.contentTitle;
                self.filmThumbView.filmCoverView.contentMode = UIViewContentModeScaleAspectFill;
                [self.filmThumbView.filmCoverView yy_setImageWithURL:[NSURL URLWithString:commentModel.coverUrl] options:0];
            }
        }
            break;
            
        case MGMCommentTypeShortVideo:
        {
            self.commentTextLabel.userInteractionEnabled = YES;
            self.videoThumbView.hidden = NO;
            self.likeCountBtn.hidden = self.commentCountBtn.hidden = NO;
            self.albumThumbView.hidden = self.filmThumbView.hidden = YES;
            [self.videoThumbView.videoCoverView yy_setImageWithURL:[NSURL URLWithString:commentModel.coverUrl] options:0];
            self.videoThumbView.videoInfoLabel.text = commentModel.shortInfo;
        }
            break;
    }
    
    [self.commentTextLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.offset(commentModel.commentTextHeight);
    }];
}

- (void)setFilmAlbumViewName:(NSString *)name
                        info:(NSString *)info
                    coverUrl:(NSString *)coverUrl
{
    self.albumThumbView.albumNameLabel.text = name;
    self.albumThumbView.albumInfoLabel.text = info;
    [self.albumThumbView.albumCoverView yy_setImageWithURL:[NSURL URLWithString:coverUrl]
                                               placeholder:[MGMCommunityResource imageNamed:@"img_ydbg"]];
}

#pragma mark - Target Action

- (void)handleTapGestureForComment:(UITapGestureRecognizer *)gesture
{
    NSString *collectionId = nil;
    NSString *commentId = nil;
    MGMTimeLineCommentModel *commentModel = (MGMTimeLineCommentModel *)self.timeLineModel;
    switch (commentModel.type) {
        case MGMCommentTypeCreate:
        {
            collectionId = commentModel.filmAlbumCreateContentModel.contentID;
        }
            break;
            
        case MGMCommentTypeCollect:
        {
            collectionId = commentModel.filmAlbumCollectContentModel.contentID;
        }
            break;
            
        case MGMCommentTypeFilmAlbum:
        {
            collectionId = commentModel.filmAlbumContentModel.objectId;
        }
            break;
        
        case MGMCommentTypeFilm:
        {
            [self routerEventWithName:MGMCommunityFilmEvent
                             userInfo:@{
                                        MGMCommunityFilmContentID: commentModel.filmContentModel.contentId ?: @"",
                                        MGMCommunityFilmKID: commentModel.filmContentModel.kId ?: @"",
                                        MGMCommunityFilmContentName: commentModel.filmContentModel.contentTitle ?: @"",
                                        MGMCommunityExtraInfo: self.timeLineModel
                                        }];
            return;
        }
            break;
            
        case MGMCommentTypeShortVideo:
        {
            [self routerEventWithName:MGMCommunityMiniVideoEvent
                             userInfo:@{
                                        MGMCommunityMainInfo: self,
                                        MGMCommunityExtraInfo: self.timeLineModel,
                                        MGMCommunityMiniVideoContentID: commentModel.shortVideoContentModel.contid ?: @"",
                                        MGMCommunityMiniVideoContentName: commentModel.shortVideoContentModel.name ?: @"",
                                        MGMCommunityMiniVideoType: @"13"
                                        }];
            return;
        }
            break;;
    }
    [self routerEventWithName:MGMCommunityFilmCollectionEvent
                     userInfo:@{
                                MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel,
                                MGMCommunityFilmCollectionID: collectionId ?: @""
                                }];
}

- (void)handleCommentTapGesture
{
    [self routerEventWithName:MGMCommunityMainCommentEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)handleSubCommentAction
{
    [self routerEventWithName:MGMCommunitySubCommentEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

#pragma mark - Getter

- (SEL)tapSelector
{
    return @selector(handleTapGestureForComment:);
}

- (SEL)commentTapSelector
{
    MGMTimeLineCommentModel *commentModel = (MGMTimeLineCommentModel *)self.timeLineModel;
    return (MGMCommentTypeCreate == commentModel.type || MGMCommentTypeCollect == commentModel.type) ? nil : @selector(handleSubCommentAction);
}

- (SEL)commentListTapSelector
{
    return @selector(handleCommentTapGesture);
}

@end
