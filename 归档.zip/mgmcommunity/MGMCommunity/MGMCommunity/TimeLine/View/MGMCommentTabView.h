//
//  MGMCommentTabView.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class  MGMCommentTabView;

/**
    评论标签类型

- MGMCommentTypeLatest: 最新
- MGMCommentTypeHotest: 最热
*/
typedef NS_ENUM(NSInteger, MGMCommentType)
{
    MGMCommentTypeLatest,
    MGMCommentTypeHotest
};

@protocol MGMCommentTabViewDelegate <NSObject>

- (void)commentTabView:(MGMCommentTabView *)commentTabView didSelectType:(MGMCommentType)type;

@end

@interface MGMCommentTabView : UIView

@property (nonatomic, weak) id <MGMCommentTabViewDelegate>delegate;

@end

NS_ASSUME_NONNULL_END
