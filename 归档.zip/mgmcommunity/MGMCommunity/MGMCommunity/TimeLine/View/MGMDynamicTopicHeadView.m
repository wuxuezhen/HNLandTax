//
//  MGMDynamicTopicHeadView.m
//  MGMCommunity
//
//  Created by YL on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicTopicHeadView.h"
#import "MGMCommunityResource.h"
#import <Masonry/Masonry.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGMRoute/MGMRoute.h>
#import <MGMSocialModule/MGMDynamicTopicItemModel.h>
#import "MGMCommunity.h"

@interface MGMDynamicTopicHeadView ()

@property (nonatomic, strong) UIImageView  *topicBgView;

@property (nonatomic, strong) UILabel      *topicNameLabel;

@property (nonatomic, strong) UIImageView  *topicIconView;

@property (nonatomic, strong) UILabel      *watchPeopleLabel;

@end

@implementation MGMDynamicTopicHeadView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        [self addSubview:self.topicBgView];
        [self addSubview:self.topicNameLabel];
        [self addSubview:self.topicIconView];
        [self addSubview:self.watchPeopleLabel];
        
        [self.topicBgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(20);
            make.left.mas_equalTo(15);
            make.right.equalTo(self).offset(-15);
            make.height.mas_equalTo(MGMScaleValue(97));
        }];
        
        [self.topicNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.equalTo(self.topicBgView).offset(10);
            make.right.equalTo(self.topicBgView).offset(-10);
            make.height.mas_greaterThanOrEqualTo(10);
        }];
        
        [self.topicIconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.topicNameLabel);
            make.bottom.equalTo(self.topicBgView).offset(-15);
            make.size.mas_equalTo(CGSizeMake(15, 12));
        }];
        
        [self.watchPeopleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.topicIconView);
            make.left.equalTo(self.topicIconView.mas_right).offset(6);
            make.right.equalTo(self.topicBgView).offset(-10);
            make.height.mas_equalTo(12);
        }];
    }
    return self;
}

- (void)setTopicItemModel:(MGMDynamicTopicItemModel *)topicItemModel {
    _topicItemModel = topicItemModel;
    
    self.topicNameLabel.text = [NSString stringWithFormat:@"#%@#",topicItemModel.name];
    
    self.watchPeopleLabel.text = [NSString stringWithFormat:@"已有%ld位小伙伴围观",topicItemModel.dynamicCount];
}

#pragma mark - lazyload
- (UIImageView *)topicBgView {
    if(!_topicBgView) {
        _topicBgView = [[UIImageView alloc] init];
        _topicBgView.image = [MGMCommunityResource imageNamed:@"mgm_dynamic_topic_bg"];
    }
    return _topicBgView;
}

- (UILabel *)topicNameLabel {
    if(!_topicNameLabel) {
        _topicNameLabel = [[UILabel alloc] init];
        _topicNameLabel.textAlignment = NSTextAlignmentLeft;
        _topicNameLabel.backgroundColor = [UIColor clearColor];
        _topicNameLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:16];
        _topicNameLabel.textColor = [UIColor mgu_colorWithHex:0x1A1A1A];
        _topicNameLabel.numberOfLines = 2;
        _topicNameLabel.lineBreakMode = NSLineBreakByWordWrapping;
    }
    return _topicNameLabel;
}

- (UIImageView *)topicIconView {
    if(!_topicIconView) {
        _topicIconView = [[UIImageView alloc] init];
        _topicIconView.image = [MGMCommunityResource imageNamed:@"mgm_dynamic_topic_blue_icon"];
    }
    return _topicIconView;
}

- (UILabel *)watchPeopleLabel {
    if(!_watchPeopleLabel) {
        _watchPeopleLabel = [[UILabel alloc] init];
        _watchPeopleLabel.textAlignment = NSTextAlignmentLeft;
        _watchPeopleLabel.backgroundColor = [UIColor clearColor];
        _watchPeopleLabel.font = [UIFont systemFontOfSize:12];
        _watchPeopleLabel.textColor = [UIColor mgu_colorWithHex:0x666666];
    }
    return _watchPeopleLabel;
}


@end
