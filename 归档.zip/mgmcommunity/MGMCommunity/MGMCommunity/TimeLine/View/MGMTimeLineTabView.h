//
//  MGMTimeLineTabView.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/1.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
    标签类型

 - MGMTimeLineTabTypeRecommend: 推荐
 - MGMTimeLineTabTypeFollow:    关注
 */
typedef NS_ENUM(NSInteger, MGMTimeLineTabType) {
    MGMTimeLineTabTypeRecommend,
    MGMTimeLineTabTypeFollow
};

@class MGMDynamicTabsModel,TYTabPagerBar_mgs;

typedef void(^MGMDynamicTabClickHandler)(NSInteger index);

NS_ASSUME_NONNULL_BEGIN

@interface MGMTimeLineTabView : UIView

@property (nonatomic, assign) NSInteger   currentIndex;

@property (nonatomic, copy)   MGMDynamicTabClickHandler  dynamicTabClickHandler;

- (instancetype)initWithFrame:(CGRect)frame
                         tabs:(NSArray <MGMDynamicTabsModel *>*)tabsArray;

@end

NS_ASSUME_NONNULL_END
