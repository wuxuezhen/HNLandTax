//
//  MGMTimeLineTopicFragment.m
//  Aspects
//
//  Created by 袁飞扬 on 2020/1/7.
//

#import "MGMTimeLineTopicFragment.h"
#import <MGMHttpApiModel/MGMLegoPage.h>
#import "MGMTimeLineViewCarousel.h"
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGUHttpApiCore/MGUHttpApiFactory.h>
#import <MGUHttpApiCore/MGUHttpApi.h>
#import <MGMSocialModule/MGMDynamicFetchTopicListInfo.h>

@interface MGMTimeLineTopicFragment ()<MGMDynamicFetchTopicListInfoDelegate>

@property (nonatomic, strong)MGMTimeLineViewCarousel *fragmentView;
@property (nonatomic, strong) MGMComponent *comp;

@property (nonatomic, strong)MGMDynamicFetchTopicListInfo *topicListInfo;

@property (nonatomic, strong)NSArray *topicIdArray;

@end

@implementation MGMTimeLineTopicFragment

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (void)setupData:(id)data{
    //h话题标签comp
    if ([data isKindOfClass:[MGMComponent class]]) {
        self.comp = data;
        MGMComponent *comp = data;
        if ([comp.compStyle isEqualToString:@"SLIDER_IMG-MV12"]) {
            if (comp.data.count>0) {
                self.fragmentView.data = comp;
                NSMutableArray *mutArray = [[NSMutableArray alloc]init];
                for (MGMData *mgmData in comp.data) {
                    MGMAction *action = mgmData.action;
                    [mutArray mgu_safe_addObject:action.params.contentID];
                }
                self.topicIdArray = mutArray.mutableCopy;
                [self.topicListInfo fetchTopicParticipantCountWithId:mutArray.mutableCopy];
            }
        }
    }
}

- (MGMTimeLineViewCarousel *)fragmentView{
    if (!_fragmentView) {
        _fragmentView = [[MGMTimeLineViewCarousel alloc]init];
    }
    return _fragmentView;
}

- (MGMDynamicFetchTopicListInfo *)topicListInfo{
    if (!_topicListInfo) {
        _topicListInfo = [[MGMDynamicFetchTopicListInfo alloc]initWithDelegate:self];
    }
    return _topicListInfo;
}


- (UIView *)getFragmentView{
    return self.fragmentView;
}
- (CGFloat)getFragmentHeight{
    return self.fragmentView.frame.size.height;
}

- (CGFloat)getEstimatedFragmentHeight{
    return self.fragmentView.frame.size.height;
}



- (void)fetchTopicParticipantCount:(NSDictionary *)participantCountInfo error:(NSError *)error{
    if (!error) {
        if (self.topicIdArray && participantCountInfo) {
            NSMutableArray *mutArray = [[NSMutableArray alloc]init];
            for (NSString *tagTopicId in self.topicIdArray) {
                [mutArray mgu_safe_addObject:[participantCountInfo mgu_objectOrNilForKey:tagTopicId]];
            }
            [self.fragmentView updateDynamicTopicCount:mutArray.mutableCopy];
        }
    }
}


@end
