//
//  MGMTimeLineTopicView.h
//  Aspects
//
//  Created by 袁飞扬 on 2020/1/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMTimeLineTopicView : UIView

@property(nonatomic, strong) id model;

@property (nonatomic, assign)NSInteger index;

@property(nonatomic, strong) NSString *dynamicTopicCount;


@end

NS_ASSUME_NONNULL_END
