//
//  MGMVideoThumbView.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/9.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YYLabel;

NS_ASSUME_NONNULL_BEGIN

@interface MGMVideoThumbView : UIView

@property (nonatomic, weak, readonly) YYLabel *videoInfoLabel;
@property (nonatomic, weak, readonly) UIImageView *videoCoverView;

@end

NS_ASSUME_NONNULL_END
