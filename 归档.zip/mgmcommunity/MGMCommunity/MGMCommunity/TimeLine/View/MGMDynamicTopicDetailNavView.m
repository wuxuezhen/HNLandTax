//
//  MGMDynamicTopicDetailNavView.m
//  MGMCommunity
//
//  Created by YL on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicTopicDetailNavView.h"
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMNavigation/MGMNavigationResource.h>

@interface MGMDynamicTopicDetailNavView()
//返回
@property (nonatomic, strong) UIButton      *p_backBtn;

@property (nonatomic, strong) UILabel       *p_navTitleLabel;

@end

@implementation MGMDynamicTopicDetailNavView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        self.p_backBtn.frame = CGRectMake(0, MGMStatusBarH, 42, 44);
        self.p_navTitleLabel.frame = CGRectMake(54, MGMStatusBarH+14, MGMScreenW-108, 16);
        [self addSubview:self.p_backBtn];
        [self addSubview:self.p_navTitleLabel];
    }
    return self;
}

- (void)p_backBtnDidPressed:(id)sender {
    if(self.backHandler) {
        self.backHandler();
    }
}

- (void)setNavTitle:(NSString *)navTitle {
    _navTitle = navTitle;
    
    self.p_navTitleLabel.text = navTitle;
}

- (void)setNavigationViewAlpha:(CGFloat)alpha {
    if(alpha <= 0) {
        alpha = 0;
    }
    if (alpha >=.5) {
        alpha = 1;
    }
    self.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:alpha];
    UIColor *editTextColor = (alpha <=.5) ? [UIColor whiteColor] : [UIColor blackColor];
    NSString *backImage = (alpha <= .5) ? [MGMNavigationResource imageNamed:@"nav_back_white"]: [MGMNavigationResource imageNamed:@"nav_back"];
    [self.p_backBtn setImage:backImage forState:UIControlStateNormal];
    self.p_navTitleLabel.hidden = (alpha < .5);
    
    UIStatusBarStyle style = (alpha < .5) ? UIStatusBarStyleLightContent:@available(iOS 13, *) ? UIStatusBarStyleDarkContent : UIStatusBarStyleDefault;
    [[UIApplication sharedApplication] setStatusBarStyle:style];
}

#pragma mark - lazy
- (UIButton *)p_backBtn {
    if(!_p_backBtn) {
        _p_backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_p_backBtn setImage:[MGMNavigationResource imageNamed:@"nav_back_white"] forState:UIControlStateNormal];
        _p_backBtn.adjustsImageWhenHighlighted = NO;
        _p_backBtn.exclusiveTouch = YES;
        [_p_backBtn addTarget:self
                       action:@selector(p_backBtnDidPressed:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _p_backBtn;
}

- (UILabel *)p_navTitleLabel {
    if(!_p_navTitleLabel) {
        _p_navTitleLabel = [[UILabel alloc] init];
        _p_navTitleLabel.backgroundColor = [UIColor clearColor];
        _p_navTitleLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:16];
        _p_navTitleLabel.textColor = [UIColor blackColor];
        _p_navTitleLabel.textAlignment = NSTextAlignmentCenter;
        _p_navTitleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    }
    return _p_navTitleLabel;
}

@end
