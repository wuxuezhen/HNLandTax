//
//  MGMFilmAlbumThumbView.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/9.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFilmAlbumThumbView.h"
#import "MGMCommunity.h"
#import "MGMCommunityResource.h"
#import <Masonry/Masonry.h>

@interface MGMFilmAlbumThumbView()

@property (nonatomic, weak) UILabel *albumNameLabel;
@property (nonatomic, weak) UILabel *albumInfoLabel;
@property (nonatomic, weak) UIImageView *albumCoverView;

@end

@implementation MGMFilmAlbumThumbView

#pragma mark - Override

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        [self initialize];
    }
    return self;
}

- (void)initialize
{
    self.backgroundColor = [UIColor colorWithRed:245/255.0 green:245/255.0 blue:245/255.0 alpha:1.0];
    
    UIImageView *albumCoverView = [[UIImageView alloc] init];
    albumCoverView.contentMode = UIViewContentModeScaleAspectFill;
    albumCoverView.layer.cornerRadius = 2.f;
    albumCoverView.layer.masksToBounds = YES;
    [self addSubview:albumCoverView];
    self.albumCoverView = albumCoverView;
    
    [albumCoverView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.offset(5);
        make.size.sizeOffset(CGSizeMake(60, 60));
    }];
    
    UIImageView *albumBottomBgView = [[UIImageView alloc] init];
    albumBottomBgView.image = [MGMCommunityResource imageNamed:@"img_dtydbg"];
    [self addSubview:albumBottomBgView];
    
    [albumBottomBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(albumCoverView).offset(0);
        make.left.equalTo(albumCoverView.mas_right).offset(0);
        make.size.sizeOffset(CGSizeMake(8, 60));
    }];
    
    UILabel *albumLabel = [[UILabel alloc] init];
    albumLabel.text = @"影单";
    albumLabel.textColor = [UIColor whiteColor];
    albumLabel.textAlignment = NSTextAlignmentCenter;
    albumLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:10];
    albumLabel.backgroundColor = [UIColor colorWithRed:242/255.0 green:162/255.0 blue:79/255.0 alpha:1.0];
    albumLabel.layer.cornerRadius = 2.5;
    albumLabel.layer.masksToBounds = YES;
    [self addSubview:albumLabel];
    
    [albumLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset(16);
        make.left.equalTo(albumBottomBgView.mas_right).offset(10);
        make.size.sizeOffset(CGSizeMake(28, 14));
    }];
    
    UILabel *albumNameLabel = [[UILabel alloc] init];
    albumNameLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 14];
    albumNameLabel.textColor = [UIColor colorWithRed:26/255.0 green:26/255.0 blue:26/255.0 alpha:1.0];
    [self addSubview:albumNameLabel];
    self.albumNameLabel = albumNameLabel;
    
    [albumNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(albumLabel);
        make.left.equalTo(albumLabel.mas_right).offset(6);
        make.right.mas_lessThanOrEqualTo(self).offset(-10);
    }];
    
    UILabel *albumInfoLabel = [[UILabel alloc] init];
    albumInfoLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
    albumInfoLabel.textColor = [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1.0];
    [self addSubview:albumInfoLabel];
    self.albumInfoLabel = albumInfoLabel;
    
    [albumInfoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(albumLabel);
        make.bottom.offset(-14);
    }];
}

@end
