//
//  MGMTimeLineViewCarousel.m
//  Aspects
//
//  Created by 袁飞扬 on 2020/1/7.
//
#define MAS_SHORTHAND_GLOBALS
#import "MGMTimeLineViewCarousel.h"
#import "MGMTimeLineTopicView.h"
#import <Masonry/Masonry.h>
#import <MGMHttpApiModel/MGMLegoPage.h>
#import <MGMUIKit/MGMSliderView.h>
#import <MGMCategories/MGMCategories.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>

@interface MGMTimeLineViewCarousel ()<UICollectionViewDelegate>

@property (nonatomic, strong)MGMSliderView *sliderView;

@property (nonatomic, strong)MGMTimeLineTopicView *topicView;

@property (nonatomic, strong) MGMComponent *compData;

@end


@implementation MGMTimeLineViewCarousel


- (void)setData:(id)data{
    _data = data;
    self.compData = data;
    if (self.compData && [self.compData isKindOfClass:[MGMComponent class]] && self.compData.data.count>0) {
        self.frame = CGRectMake(0, 0, kMainScreenWidth, kMGMHBL2X(125));
        NSMutableArray *mutable = [NSMutableArray array];
        for (int i = 0; i < self.compData.data.count; i++) {
            MGMTimeLineTopicView *topicView = [[MGMTimeLineTopicView alloc] init];
            topicView.model = [self.compData.data mgu_objectOrNilAtIndex:i];
            topicView.index = i;
            //silderImageBgImgView.compData = self.compData;
            [mutable mgu_safe_addObject:topicView];
        }
        self.sliderView.collectionView.contentOffset = CGPointMake(0, 0);
        self.sliderView.dataArray = mutable;
        [self.sliderView.collectionView reloadData];
        self.sliderView.collectionView.backgroundColor = [UIColor clearColor];
    }else{
        self.frame = CGRectMake(0, 0, 0, 0);
    }
}
- (void)updateDynamicTopicCount:(NSArray *)dynamicCounts{
    
    if (self.compData && [self.compData isKindOfClass:[MGMComponent class]] && self.compData.data.count>0) {
        self.frame = CGRectMake(0, 0, kMainScreenWidth, kMGMHBL2X(125));
        NSMutableArray *mutable = [NSMutableArray array];
        for (int i = 0; i < dynamicCounts.count; i++) {
            MGMTimeLineTopicView *topicView = [[MGMTimeLineTopicView alloc] init];
            topicView.model = [self.compData.data mgu_objectOrNilAtIndex:i];
            topicView.index = i;
            topicView.dynamicTopicCount = [dynamicCounts mgu_objectOrNilAtIndex:i];
            //silderImageBgImgView.compData = self.compData;
            [mutable mgu_safe_addObject:topicView];
        }
        self.sliderView.collectionView.contentOffset = CGPointMake(0, 0);
        self.sliderView.dataArray = mutable;
        [self.sliderView.collectionView reloadData];
        self.sliderView.collectionView.backgroundColor = [UIColor clearColor];
    }else{
        self.frame = CGRectMake(0, 0, 0, 0);
    }
    
}

- (instancetype)init{
    if (self = [super init]) {
        self.frame = CGRectMake(0, 0, kMainScreenWidth, kMGMHBL2X(125));
        self.backgroundColor = [UIColor whiteColor];
        MGMSliderView *sliderView = [[MGMSliderView alloc] init];
        sliderView.backgroundColor = [UIColor clearColor];
        sliderView.frame = CGRectMake(kMGMHBL2X(0), kMGMHBL2X(19),kMainScreenWidth, self.topicView.frame.size.height+kMGMHBL2X(2));
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
        layout.estimatedItemSize = CGSizeMake(self.topicView.frame.size.width,self.topicView.frame.size.height);
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 0;
        layout.sectionInset = UIEdgeInsetsMake(0, kMGMHBL2X(15), 0, 0);
        sliderView.collectionView.showsVerticalScrollIndicator = NO;
        sliderView.collectionView.backgroundColor = [UIColor whiteColor];
        sliderView.collectionView.showsHorizontalScrollIndicator = NO;
        sliderView.collectionView.delegate = self;
        [sliderView.collectionView setCollectionViewLayout:layout];
        
        //        NSMutableArray *mutable = [NSMutableArray array];
        //        for (int i = 0; i < 10; i++) {
        //            MGMUserREcommendView *userREcommendView = [[MGMUserREcommendView alloc] init];
        //            userREcommendView.data = @"";
        //            [mutable addObject:userREcommendView];
        //        }
        //        sliderView.dataArray = mutable;
        
        [self addSubview:sliderView];
        self.sliderView = sliderView;
    }
    return self;
}


- (MGMSliderView *)sliderView{
    if (!_sliderView) {
        _sliderView = [[MGMSliderView alloc]init];
    }
    return _sliderView;
}
- (MGMTimeLineTopicView *)topicView{
    if (!_topicView) {
        _topicView = [[MGMTimeLineTopicView alloc]init];
    }
    return _topicView;
}





@end
