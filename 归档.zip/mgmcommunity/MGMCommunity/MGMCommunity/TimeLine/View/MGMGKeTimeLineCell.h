//
//  MGMGKeTimeLineCell.h
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

//G客小视频
#import "MGMTimeLineBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMGKeTimeLineCell : MGMTimeLineBaseCell

/**
 G客Cell消失
 */
- (void)willDisappear;

@end

NS_ASSUME_NONNULL_END
