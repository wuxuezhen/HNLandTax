//
//  MGMVideoThumbView.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/9.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMVideoThumbView.h"
#import "MGMCommunityResource.h"
#import <Masonry/Masonry.h>
#import <YYText/YYText.h>

@interface MGMVideoThumbView()

@property (nonatomic, weak, readwrite) YYLabel *videoInfoLabel;
@property (nonatomic, weak, readwrite) UIImageView *videoCoverView;

@end

@implementation MGMVideoThumbView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        [self initialize];
    }
    return self;
}

- (void)initialize
{
    self.backgroundColor = [UIColor colorWithRed:245/255.0 green:245/255.0 blue:245/255.0 alpha:1.0];
    
    UIImageView *videoCoverView = [[UIImageView alloc] init];
    videoCoverView.backgroundColor = [UIColor colorWithRed:226/255.0 green:226/255.0 blue:226/255.0 alpha:1.0];
    videoCoverView.contentMode = UIViewContentModeScaleAspectFill;
    videoCoverView.clipsToBounds = YES;
    [self addSubview:videoCoverView];
    self.videoCoverView = videoCoverView;
    
    [videoCoverView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.offset(5);
        make.bottom.offset(-5);
        make.width.offset(70);
    }];
    
    UIImageView *playImgView = [[UIImageView alloc] init];
    playImgView.image = [MGMCommunityResource imageNamed:@"movie_play_icon"];
    [videoCoverView addSubview:playImgView];
    
    [playImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(videoCoverView);
        make.size.sizeOffset(CGSizeMake(20, 20));
    }];
    
    YYLabel *videoInfoLabel = [[YYLabel alloc] init];
    videoInfoLabel.numberOfLines = 2;
    videoInfoLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
    videoInfoLabel.textColor = [UIColor colorWithRed:26/255.0 green:26/255.0 blue:26/255.0 alpha:1.0];
    [self addSubview:videoInfoLabel];
    self.videoInfoLabel = videoInfoLabel;
    
    [videoInfoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(videoCoverView.mas_right).offset(10);
        make.right.offset(-10);
        make.top.offset(10);
        make.bottom.offset(-10);
    }];
}

@end
