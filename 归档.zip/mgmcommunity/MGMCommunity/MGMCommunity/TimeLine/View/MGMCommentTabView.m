//
//  MGMCommentTabView.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommentTabView.h"
#import <Masonry/Masonry.h>

@interface MGMCommentTabView ()

@property (nonatomic, weak) UIButton *hotestBtn;
@property (nonatomic, weak) UIButton *latestBtn;
@property (nonatomic, weak) UIButton *selectedBtn;

@end

@implementation MGMCommentTabView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        [self initialize];
    }
    return self;
}

#pragma mark - Private

- (void)initialize
{
    self.backgroundColor = [UIColor whiteColor];
    
    UIButton *latestBtn = [self commentButtonWithType:(MGMCommentTypeLatest)];
    [self addSubview:latestBtn];
    self.latestBtn = latestBtn;
    [self setCommentSelectedButton:latestBtn];
    
    [latestBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.bottom.offset(0);
        make.width.offset(64);
        make.height.offset(50);
    }];
    
    UIView *seperateLine = [[UIView alloc] init];
    seperateLine.backgroundColor = [UIColor colorWithRed:226/255.0 green:226/255.0 blue:226/255.0 alpha:1.0];
    [self addSubview:seperateLine];
    
    [seperateLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(89);
        make.width.offset(0.5);
        make.height.offset(16);
        make.centerY.equalTo(latestBtn).offset(0);
    }];
    
    UIButton *hotestBtn = [self commentButtonWithType:(MGMCommentTypeHotest)];
    [self addSubview:hotestBtn];
    self.hotestBtn = hotestBtn;
    
    [hotestBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(latestBtn);
        make.size.equalTo(latestBtn);
        make.left.equalTo(seperateLine.mas_right).offset(10);
    }];
}

- (UIButton *)commentButtonWithType:(MGMCommentType)type
{
    NSString *title = nil;
    if (MGMCommentTypeLatest == type)
    {
        title = @"最新讨论";
    }
    else if (MGMCommentTypeHotest == type)
    {
        title = @"最热讨论";
    }
    UIButton *commentBtn = [UIButton buttonWithType:(UIButtonTypeCustom)];
    commentBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];;
    [commentBtn setTitle:title forState:(UIControlStateNormal)];
    [commentBtn setTitleColor:[UIColor colorWithRed:178/255.0 green:178/255.0 blue:178/255.0 alpha:1.0]
                     forState:(UIControlStateNormal)];
    [commentBtn setTitleColor:[UIColor colorWithRed:26/255.0 green:26/255.0 blue:26/255.0 alpha:1.0]
                     forState:UIControlStateDisabled];
    [commentBtn addTarget:self
                   action:@selector(commentBtnDidClick:)
         forControlEvents:(UIControlEventTouchUpInside)];
    return commentBtn;
}

#pragma mark - Target Action

- (void)commentBtnDidClick:(UIButton *)btn
{
    [self setCommentSelectedButton:btn];
    
    MGMCommentType type = (self.latestBtn == btn) ? MGMCommentTypeLatest : MGMCommentTypeHotest;
    if ([self.delegate respondsToSelector:@selector(commentTabView:didSelectType:)])
    {
        [self.delegate commentTabView:self didSelectType:type];
    }
}

- (void)setCommentSelectedButton:(UIButton *)btn
{
    if (self.selectedBtn)
    {
        self.selectedBtn.enabled = YES;
        self.selectedBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];
    }
    btn.enabled = NO;
    btn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:16];
    self.selectedBtn = btn;
}

@end
