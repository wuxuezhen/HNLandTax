//
//  MGMDynamicTopicDetailNavView.h
//  MGMCommunity
//
//  Created by YL on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMDynamicTopicDetailNavView : UIView

@property (nonatomic, copy) NSString        *navTitle;

@property (nonatomic, copy) dispatch_block_t backHandler;

/**
 设置导航栏透明度
 
 @param alpha alpha
 */
- (void)setNavigationViewAlpha:(CGFloat)alpha;

@end

NS_ASSUME_NONNULL_END
