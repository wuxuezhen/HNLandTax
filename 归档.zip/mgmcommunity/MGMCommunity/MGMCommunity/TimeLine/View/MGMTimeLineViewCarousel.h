//
//  MGMTimeLineViewCarousel.h
//  Aspects
//
//  Created by 袁飞扬 on 2020/1/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMTimeLineViewCarousel : UIView

@property (nonatomic, strong)id data;

- (void)updateDynamicTopicCount:(NSArray *)dynamicCounts;

@end

NS_ASSUME_NONNULL_END
