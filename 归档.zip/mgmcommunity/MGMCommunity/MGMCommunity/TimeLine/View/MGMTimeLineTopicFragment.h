//
//  MGMTimeLineTopicFragment.h
//  Aspects
//
//  Created by 袁飞扬 on 2020/1/7.
//

#import "MGUBaseFragment.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTimeLineTopicFragment : MGUBaseFragment



@end

NS_ASSUME_NONNULL_END
