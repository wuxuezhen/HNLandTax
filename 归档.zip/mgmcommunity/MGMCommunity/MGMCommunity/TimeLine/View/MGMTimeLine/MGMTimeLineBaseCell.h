//
//  MGMTimeLineBaseCell.h
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <YYText/YYText.h>
#import <Masonry/Masonry.h>
#import <YYWebImage/YYWebImage.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMUIKit/MSSAutoresizeLabelFlow.h>

#import "MGMCommunity.h"
#import "MGMCommunityResource.h"
#import "MGMTimeLineDataSource.h"

NS_ASSUME_NONNULL_BEGIN

@class MGMDynamicModel, MGUFragmentBillboard;

@interface MGMTimeLineBaseCell : UITableViewCell

/**
    点赞数
 */
@property (nonatomic, weak, readonly) UIButton *likeCountBtn;

/**
    评论数
 */
@property (nonatomic, weak, readonly) UIButton *commentCountBtn;

/**
    举报
 */

@property (nonatomic, strong, readonly) UIImageView *toastbgView;
@property (nonatomic, weak, readonly) UIView *topContainerView;
@property (nonatomic, weak, readonly) UIView *toolBar;

@property (nonatomic, weak, readonly) MSSAutoresizeLabelFlow *flowTopicView;

@property (nonatomic, assign, readonly) SEL tapSelector;
@property (nonatomic, assign, readonly) SEL commentTapSelector;
@property (nonatomic, assign, readonly) SEL commentListTapSelector;

@property (nonatomic, assign) BOOL hideSeperateLine;
@property (nonatomic, assign, getter=isHideShareView) BOOL hideShareView;
@property (nonatomic, strong) id <MGMTimeLineDataSource, MGMTimeLineDelegate>timeLineModel;

@property (nonatomic, strong, readonly) UIImage *shareImage;

/**
    举报
 */
- (void)mgm_reportNoGoodMessage;

/**
    关注
 */
- (void)mgm_followTimeLineUser;

/**
    分享
 */
- (void)mgm_shareTimeLine;

/**
    更新关注视图
 */
- (void)updateFollowView;

/**
    移除toast
 */
- (void)dismissToastView;

/**
    billboard传递
 
 @param billboard MGUFragmentBillboard
 */
- (void)setupBillboard:(MGUFragmentBillboard *)billboard;

@end

NS_ASSUME_NONNULL_END
