//
//  MGMImageAndTextTimeLineCell.m
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMImageAndTextTimeLineCell.h"
#import "MGMTimeLineImageTextModel.h"
#import "MGMTimeLinePictureView.h"
#import <MGMCategories/UIView+MGMFrame.h>
#import <MGMUIKit/MGMUGCVote.h>
#import <MGMUIKit/MGMUGCVoteView.h>

@interface MGMImageAndTextTimeLineCell()

@property (nonatomic, weak) UILabel *allTextLabel;
@property (nonatomic, weak) YYLabel *textContentLabel;
@property (nonatomic, weak) MGMTimeLinePictureView *pictureView;
@property (nonatomic, weak) MGMUGCVoteView *voteView;

@end

@implementation MGMImageAndTextTimeLineCell

#pragma mark - Override

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self setSubviews];
    }
    return self;
}

#pragma mark - Private

- (void)setSubviews
{
    YYLabel *textContentLabel = [[YYLabel alloc] initWithFrame:CGRectMake(MGMItemSpace, MGMUserProfileH, MGMScreenW - 2 * MGMItemSpace, 0)];
    textContentLabel.numberOfLines = 0;
    textContentLabel.textVerticalAlignment = YYTextVerticalAlignmentCenter;
    UITapGestureRecognizer *textTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTextTapGesture)];
    [textContentLabel addGestureRecognizer:textTap];
    [self.contentView addSubview:textContentLabel];
    self.textContentLabel = textContentLabel;
    
    UILabel *allTextLabel = [[UILabel alloc] init];
    allTextLabel.text = @"全文";
    allTextLabel.textColor = [UIColor mgu_colorWithHex:0x63ADEF];
    allTextLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 14];
    [self.textContentLabel addSubview:allTextLabel];
    self.allTextLabel = allTextLabel;
    
    [allTextLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(0);
        make.bottom.offset(-3);
    }];
    
    MGMTimeLinePictureView *pictureView = [[MGMTimeLinePictureView alloc] init];
    [self.contentView addSubview:pictureView];
    self.pictureView = pictureView;
    
    MGMUGCVoteView *voteView = [[MGMUGCVoteView alloc] init];
    [self.contentView addSubview:voteView];
    self.voteView = voteView;

}

#pragma mark - Target Action

- (void)handleTapGesture:(UITapGestureRecognizer *)gesture
{    
    [self routerEventWithName:MGMCommunityImageTextClickEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)handleCommentTapGesture
{
    [self routerEventWithName:MGMCommunityImageTextClickEvent
                        userInfo:@{MGMCommunityMainInfo: self,
                                   MGMCommunityExtraInfo: self.timeLineModel,
                                   MGMCommunityClickComment: @(YES)}];
}

- (void)handleTextTapGesture
{
    [self routerEventWithName:MGMCommunityImageTextMainCommentEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)routerEventWithName:(NSString *)eventName userInfo:(NSDictionary *)userInfo
{
    if ([eventName isEqualToString:MGMCommunityPhotoClickEvent])
    {
        NSInteger picIndex = [userInfo[MGMCommunityPhotoClickIndex] integerValue];
        //  点击的图片索引不存在, 以点击cell内容视图的方式处理事件
        if (NSNotFound == picIndex)
        {
            [self handleTapGesture:nil];
            return;
        }
    }
    if ([eventName isEqualToString:MGMUIKitVoteClickEvent])
    {
        NSMutableDictionary *aUserInfo = @{MGMCommunityExtraInfo: self.timeLineModel}.mutableCopy;
        [aUserInfo addEntriesFromDictionary:userInfo];
        [super routerEventWithName:eventName userInfo:aUserInfo];
        return;
    }
    [super routerEventWithName:eventName userInfo:userInfo];
}

#pragma mark - Setter&Getter

- (void)setTimeLineModel:(id<MGMTimeLineDataSource,MGMTimeLineDelegate>)timeLineModel
{
    [super setTimeLineModel:timeLineModel];
    
    CGFloat textHeight = timeLineModel.timeLineTextHeight;
    self.textContentLabel.textLayout = timeLineModel.timeLineTextLayout;
    self.textContentLabel.mgm_height = textHeight;
    self.allTextLabel.hidden = timeLineModel.isHideAllTextBtn;
    CGFloat pictureViewY =  CGRectGetMaxY(self.textContentLabel.frame) + (textHeight ? 12.f : 0.f);
    self.pictureView.frame = CGRectMake(MGMItemSpace,
                                        pictureViewY,
                                        MGMScreenW - 2 * MGMItemSpace,
                                        timeLineModel.timeLinePhotoHeight);
    self.pictureView.timeLineModel = timeLineModel;
    
    CGFloat voteHeight = timeLineModel.timeLineVoteHeight;
    CGFloat voteViewY  = pictureViewY;
    if (timeLineModel.timeLinePhotoHeight > 0) {
        voteViewY =  CGRectGetMaxY(self.pictureView.frame) + (voteHeight ? 12.f : 0.f);
    }
    self.voteView.frame = CGRectMake(MGMItemSpace,
                                     voteViewY,
                                     MGMScreenW - 2 * MGMItemSpace,
                                     timeLineModel.timeLineVoteHeight);
    
    self.voteView.voteData    = timeLineModel.voteModels;
    
    CGFloat topicHeight = timeLineModel.timeLineTopicHeight;
    self.flowTopicView.frame = CGRectMake(MGMItemSpace,
                                          timeLineModel.timeLineTopicViewOriginY,
                                          MGMScreenW - 2 * MGMItemSpace,
                                          topicHeight);
    if (timeLineModel.timeLineTopics.count)
    {
        [self.flowTopicView reloadAllWithTitles:timeLineModel.timeLineTopics];
    }
}

- (SEL)tapSelector
{
    return @selector(handleTapGesture:);
}

- (SEL)commentTapSelector
{
    return @selector(handleCommentTapGesture);
}

- (BOOL)isHideShareView
{
    return NO;
}

@end
