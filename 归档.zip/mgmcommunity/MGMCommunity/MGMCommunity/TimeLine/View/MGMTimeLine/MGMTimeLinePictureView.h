//
//  MGMTimeLinePictureView.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/6.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MGMTimeLineDataSource.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTimeLinePictureView : UIView

@property (nonatomic, strong) id <MGMTimeLineDataSource>timeLineModel;

@end

NS_ASSUME_NONNULL_END
