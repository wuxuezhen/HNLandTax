//
//  MGMTimeLineBaseCell.m
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLineBaseCell.h"
#import "MGMCommunityUGCModel.h"
#import "MGMCommunityRelationInfos.h"
#import <MGMUIKit/MGMUIKitResource.h>
#import <MGMUIKit/MGMCommentReplyView.h>
#import <MGMCategories/MGMCategories.h>
#import <MGMCategories/NSString+MGMValidation.h>
#import <MGMCategories/NSString+MGMStringData.h>
#import <MGMDataProcessingKit/MGMDataSyncManager.h>
#import "MGMTimeLineStagePhotoModel.h"
#import "MGMTimeLineStagePhotoModel.h"

typedef NS_ENUM(NSInteger, MGMTimeLineButtonType)
{
    MGMTimeLineButtonLike,
    MGMTimeLineButtonComment
};

@interface MGMTimeLineBaseCell()<UIGestureRecognizerDelegate>

/**
    头像
 */
@property (nonatomic, weak) UIImageView *avatarView;

/**
    用户标识
 */
@property (nonatomic, weak) UIImageView *identifierImgView;

/**
    更多图片
 */
@property (nonatomic, weak) UIImageView *moreImgView;

/**
    昵称
 */
@property (nonatomic, weak) UILabel *nickNameLabel;

/**
    关注
 */
@property (nonatomic, weak) UIButton *followBtn;

/**
    更多
 */
@property (nonatomic, weak) UIButton *moreBtn;

/**
    分享
 */
@property (nonatomic, strong) UIButton *shareBtn;
@property (nonatomic, strong) UIButton *reportBtn;
@property (nonatomic, strong, readwrite) UIImageView *toastbgView;
/**
    日期
 */
@property (nonatomic, weak) UILabel *dateLabel;

/**
    评论
 */
@property (nonatomic, weak) MGMCommentReplyView *commentView;

@property (nonatomic, weak) UIView *seperateLine;

@property (nonatomic, weak) UITapGestureRecognizer *tapGesture;
@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, strong) NSMutableArray <UILabel *>*tagLabelM;
@property (nonatomic, assign, getter=isClickAvatar) BOOL clickAvatar;

@end

@implementation MGMTimeLineBaseCell

#pragma mark - Public

- (void)dismissToastView
{
    self.toastbgView.hidden = YES;
    [self updateFollowView];
}

- (void)updateFollowView
{
    self.followBtn.hidden = self.timeLineModel.isHideFollowBtn;
}

#pragma mark - Override

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self initialize];
    }
    return self;
}

#pragma mark - Private
- (void)initialize
{
    _identifier = [NSString stringWithFormat:@"%p",self];
    _hideShareView = YES;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.exclusiveTouch = YES;
    
    UIView *topContainerView = [[UIView alloc] init];
    [self.contentView addSubview:topContainerView];
    _topContainerView = topContainerView;
    
    [topContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.offset(0);
        make.height.offset(MGMUserProfileH);
    }];
    
    //  头像
    CGFloat avatarViewW = 40.f;
    UIImageView *avatarView = [[UIImageView alloc] init];
    [avatarView setupCornerWithRadius:avatarViewW * 0.5];
    [self addTapGestureOnView:avatarView];
    [topContainerView addSubview:avatarView];
    self.avatarView = avatarView;
    [avatarView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.top.offset(20);
        make.size.sizeOffset(CGSizeMake(avatarViewW, avatarViewW));
    }];
    
    //  昵称
    UILabel *nickNameLabel = [[UILabel alloc] init];
    nickNameLabel.text = @"咪咕用户";
    nickNameLabel.textColor = [UIColor mgu_colorWithHex:0x1A1A1A];
    nickNameLabel.font = [UIFont mgu_safeFontWithName:@"PingFangSC-Semibold" size: 15];
    [self addTapGestureOnView:nickNameLabel];
    [topContainerView addSubview:nickNameLabel];
    self.nickNameLabel = nickNameLabel;
    
    [nickNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(avatarView.mas_right).offset(10);
        make.right.mas_lessThanOrEqualTo(-120);
    }];
    
    //  用户标识
    CGFloat identifyImgViewW = 13.f;
    UIImageView *identifyImgView = [[UIImageView alloc] init];
    identifyImgView.layer.cornerRadius = identifyImgViewW * 0.5;
    identifyImgView.layer.borderColor = [UIColor whiteColor].CGColor;
    identifyImgView.layer.borderWidth = 1.f;
    identifyImgView.layer.masksToBounds = YES;
    [topContainerView addSubview:identifyImgView];
    self.identifierImgView = identifyImgView;
    [identifyImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.avatarView).offset(1);
        make.right.equalTo(self.avatarView).offset(1);
        make.size.sizeOffset(CGSizeMake(identifyImgViewW, identifyImgViewW));
    }];
    
    //  更多图片
    UIImageView *moreImgView = [[UIImageView alloc] initWithImage:[MGMCommunityResource imageNamed:@"community_more"]];
    [topContainerView addSubview:moreImgView];
    self.moreImgView = moreImgView;
    
    [moreImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.offset(0);
        make.right.offset(-15);
        make.size.mas_equalTo(CGSizeMake(kMGMHBL(48), kMGMHBL(48)));
    }];
    
    //  更多
    UIButton *moreBtn = [UIButton buttonWithType:(UIButtonTypeCustom)];
    [moreBtn addTarget:self
                action:@selector(moreBtnDidClick)
      forControlEvents:(UIControlEventTouchUpInside)];
    [topContainerView addSubview:moreBtn];
    self.moreBtn = moreBtn;
    
    [moreBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(moreImgView);
        make.right.mas_equalTo(kMGMHBL(0));
        make.size.mas_equalTo(CGSizeMake(kMGMHBL(108), kMGMHBL(108)));
    }];
    
    //  关注
    UIButton *followBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [followBtn setImage:[MGMCommunityResource imageNamed:@"timeline_follow"] forState:UIControlStateNormal];
    [followBtn addTarget:self
                  action:@selector(followBtnDidClick)
        forControlEvents:UIControlEventTouchUpInside];
    [topContainerView addSubview:followBtn];
    self.followBtn = followBtn;
    
    [followBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(moreImgView);
    }];
    
    //  举报
    [topContainerView addSubview:self.toastbgView];
    CGFloat width =  self.isHideShareView ? 59 : 113;
    [self.toastbgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(moreImgView.mas_left).offset(0);
        make.top.mas_equalTo(kMGMHBL(40));
        make.size.mas_equalTo(CGSizeMake(MGMScaleValue(width), kMGMHBL(70)));
    }];
    
    MGMWeakSelf;
    //  话题标签
    MSSAutoresizeLabelFlow *flowTopicView = [[MSSAutoresizeLabelFlow alloc] initWithFrame:CGRectZero titles:@[@""] type:(MSSAutoresizeLabelFlowCellStyleTopic) selectedHandler:^(NSUInteger index, NSString *title) {
        MGMStrongSelf;
        [self routerEventWithName:MGMCommunityTopicClickEvent
                         userInfo:@{MGMCommunityMainInfo: self,
                                    MGMCommunityExtraInfo: self.timeLineModel,
                                    MGMCommunityTopicClickIndex: @(index)}];
    }];
    [self.contentView addSubview:flowTopicView];
    _flowTopicView = flowTopicView;
    
    UIView *toolBar = [[UIView alloc] init];
    toolBar.backgroundColor = [UIColor whiteColor];
    [self.contentView addSubview:toolBar];
    _toolBar = toolBar;
    
    [toolBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.offset(55);
        make.bottom.offset(0);
        make.left.right.offset(0);
    }];
    
    //  日期
    UILabel *dateLabel = [[UILabel alloc] init];
    dateLabel.font = [UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size:14];
    dateLabel.textColor = [UIColor mgu_colorWithHex:0xB2B2B2];
    [toolBar addSubview:dateLabel];
    self.dateLabel = dateLabel;
    
    [dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.centerY.offset(0);
        make.height.offset(28);
        make.width.mas_greaterThanOrEqualTo(100);
    }];
    
    //  评论
    UIButton *commentCountBtn = [self toolBarButtonForType:(MGMTimeLineButtonComment)];
    [toolBar addSubview:commentCountBtn];
    _commentCountBtn = commentCountBtn;
    
    [commentCountBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.offset(0);
        make.centerY.offset(0);
        make.right.offset(-15);
    }];
    
    //  点赞
    UIButton *likeCountBtn = [self toolBarButtonForType:(MGMTimeLineButtonLike)];
    [toolBar addSubview:likeCountBtn];
    _likeCountBtn = likeCountBtn;
    
    [likeCountBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(commentCountBtn);
        make.right.equalTo(commentCountBtn.mas_left).offset(-20);
        make.centerY.equalTo(commentCountBtn).offset(0);
    }];
    
    //  评论视图
    MGMCommentReplyView *commentView = [[MGMCommentReplyView alloc] init];
    UITapGestureRecognizer *commentListTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                            action:@selector(handleCommentListTapGesture)];
    [commentView addGestureRecognizer:commentListTapGesture];
    [self.contentView addSubview:commentView];
    self.commentView = commentView;
    
    [commentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.right.offset(-15);
        make.bottom.offset(-20);
    }];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
    tap.delegate = self;
    [self.contentView addGestureRecognizer:tap];
    self.tapGesture = tap;
    
    UIView *seperateLine = [[UIView alloc] init];
    seperateLine.backgroundColor = [UIColor mgu_colorWithHex:0xE2E2E2];
    [self.contentView addSubview:seperateLine];
    self.seperateLine = seperateLine;
    
    [seperateLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.right.offset(-15);
        make.bottom.offset(0);
        make.height.offset(1 / [UIScreen mainScreen].scale);
    }];
}

- (void)addTapGestureOnView:(UIView *)view
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapUserProfileAction:)];
    [view addGestureRecognizer:tap];
    view.userInteractionEnabled = YES;
}

- (UIButton *)toolBarButtonForType:(MGMTimeLineButtonType)type
{
    UIButton *btn = [UIButton buttonWithType:(UIButtonTypeCustom)];
    btn.titleLabel.font = [UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size: 14];
    btn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 6);
    btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [btn setTitleColor:[UIColor mgu_colorWithHex:0xB2B2B2] forState:(UIControlStateNormal)];
    if (MGMTimeLineButtonLike == type)
    {
        [btn setTitleColor:[UIColor mgu_colorWithHex:0xFF3E40] forState:(UIControlStateSelected)];
        [btn setImage:[MGMCommunityResource originalRenderingImageNamed:@"community_like_normal"] forState:UIControlStateNormal];
        [btn setImage:[MGMCommunityResource originalRenderingImageNamed:@"community_like_selected"] forState:UIControlStateSelected];
        [btn addTarget:self
                action:@selector(likeCountBtnDidClick)
      forControlEvents:(UIControlEventTouchUpInside)];
    }
    else
    {
        [btn addTarget:self
                action:@selector(commentCountBtnDidClick)
      forControlEvents:(UIControlEventTouchUpInside)];
        [btn setImage:[MGMCommunityResource originalRenderingImageNamed:@"community_message"] forState:UIControlStateNormal];
    }
    return btn;
}

- (void)updateWidthConstraintForButton:(UIButton *)button
{
    NSString *title = [button titleForState:(UIControlStateDisabled)];
    CGFloat titleLength = [title mgu_sizeForFont:[UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size: 14]
                                            size:CGSizeMake(CGFLOAT_MAX, 14)
                                            mode:(NSLineBreakByWordWrapping)].width + 20.f;
    
    [button mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset(ceilf(titleLength));
    }];
}

- (void)refreshToolBar
{
    [self updateLikeView];
    [self updateCommentView];
}

/**
    更新点赞视图
 */
- (void)updateLikeView
{
    NSString *likeCountText = [NSString stringWithFormat:@"%ld", self.timeLineModel.timeLineLikeCount];
    self.likeCountBtn.selected = self.timeLineModel.isLike;
    [self.likeCountBtn setTitle:likeCountText forState:(UIControlStateNormal)];
    [self updateWidthConstraintForButton:self.likeCountBtn];
}

/**
    更新评论视图
 */
- (void)updateCommentView
{
    NSString *commentCountText = [NSString stringWithFormat:@"%ld", self.timeLineModel.timeLineCommentCount];
    [self.commentCountBtn setTitle:commentCountText forState:(UIControlStateNormal)];
    [self updateWidthConstraintForButton:self.commentCountBtn];
}

- (void)addTagLabels
{
    for (UILabel *tagLabel in self.tagLabelM) {
        tagLabel.hidden = YES;
    }
    NSArray <NSString *>*dynamicTagTexts = self.timeLineModel.timeLineTags;
    NSArray <NSNumber *>*dynamicTagTextWidths = self.timeLineModel.timeLineTagWidths;
    if (!dynamicTagTexts.count)
    {
        [self.nickNameLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.offset(31);
        }];
        return;
    }
    
    [self.nickNameLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.offset(20.5);
    }];
    
    UILabel *tagLabel = nil;
    if (self.tagLabelM.count < dynamicTagTexts.count)
    {
        NSInteger delta = dynamicTagTexts.count - self.tagLabelM.count;
        for (NSInteger i = 0; i < delta; i++) {
            tagLabel = [[UILabel alloc] init];
            tagLabel.textAlignment = NSTextAlignmentCenter;
            tagLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:8];
            tagLabel.textColor = [UIColor colorWithRed:115/255.0 green:183/255.0 blue:243/255.0 alpha:1.0];
            tagLabel.backgroundColor = [UIColor colorWithRed:235/255.0 green:241/255.0 blue:248/255.0 alpha:1.0];
            tagLabel.layer.cornerRadius = 2.f;
            tagLabel.layer.masksToBounds = YES;
            [self.topContainerView addSubview:tagLabel];
            
            [tagLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                if (!self.tagLabelM.count)
                {
                    make.left.equalTo(self.nickNameLabel);
                }
                else
                {
                    make.left.equalTo(self.tagLabelM.lastObject.mas_right).offset(5);
                }
                make.top.equalTo(self.nickNameLabel.mas_bottom).offset(3);
                make.height.offset(13);
            }];
            
            [self.tagLabelM addObject:tagLabel];
        }
    }
   
    CGFloat tagLabelW = 0;
    for (NSInteger i = 0; i < dynamicTagTexts.count; i++) {
        tagLabel = self.tagLabelM[i];
        tagLabel.hidden = NO;
        tagLabel.text = dynamicTagTexts[i];
        tagLabelW = [dynamicTagTextWidths[i] floatValue];
        [tagLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.width.offset(tagLabelW);
        }];
    }
}

#pragma mark - Setter

- (void)setTimeLineModel:(id<MGMTimeLineDataSource>)timeLineModel
{
    _timeLineModel = timeLineModel;
    self.nickNameLabel.text = timeLineModel.nickname;
    self.nickNameLabel.textColor = timeLineModel.nicknameColor;
    NSURL *avatarUrl = [NSURL URLWithString:timeLineModel.avatarUrl];
    UIImage *placeholder = [UIImage miguDefaultPortraitImage];
    [self.avatarView yy_setImageWithURL:avatarUrl placeholder:placeholder];
    self.moreBtn.hidden = timeLineModel.isHideMoreBtn;
    self.moreImgView.hidden = timeLineModel.isHideMoreBtn;

    NSString *toastImageName = timeLineModel.isCurrentUser ? @"删除" : @"举报";
    [self.reportBtn setTitle:toastImageName forState:UIControlStateNormal];
    if (timeLineModel.userIdentiftyIconUrl.length)
    {
        MGMWeakSelf;
        [self.identifierImgView yy_setImageWithURL:[NSURL URLWithString:timeLineModel.userIdentiftyIconUrl] placeholder:nil options:0 completion:^(UIImage * _Nullable image, NSURL * _Nonnull url, YYWebImageFromType from, YYWebImageStage stage, NSError * _Nullable error) {
            MGMStrongSelf;
            self.identifierImgView.hidden = NO;
            self.identifierImgView.image = image;
        }];
    }
    else
    {
        self.identifierImgView.image = nil;
        self.identifierImgView.hidden = YES;
    }
    
    CGFloat rightSpace = timeLineModel.isHideMoreBtn ? 15 : 60;
    [self.followBtn mas_updateConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-rightSpace);
    }];
    
    //  添加标签
    [self addTagLabels];
    
    if (timeLineModel.timeLineMid)
      {
          //  监听点赞数
          NSString *feedId = (timeLineModel.isStills) ? timeLineModel.timeLineFeedId : timeLineModel.timeLineMid;
          NSString *targetId = [NSString stringWithFormat:@"like_objectId_%@", feedId];
          __weak typeof(self)weakSelf = self;
          [[MGMDataSyncManager sharedManager] addLikeObserverWithId:self.identifier targetId:targetId callback:^(NSDictionary *info) {
              __strong typeof(weakSelf)strongSelf = weakSelf;
              NSString *currentFeedId = [info valueForKey:@"feedId"];
              if ([feedId isEqualToString:currentFeedId])
              {
                  BOOL isAdd = [[info valueForKey:@"isAddid"] boolValue];
                  NSInteger addCount = isAdd ? 1 : -1;
                  if ([strongSelf.timeLineModel respondsToSelector:@selector(updateLikeCount:isLike:)])
                  {
                      [strongSelf.timeLineModel updateLikeCount:addCount isLike:isAdd];
                  }
                  [strongSelf updateLikeView];
              }
          }];
          //  监听评论数
//          NSString *commentTargetId = [NSString stringWithFormat:@"review_objectId_%@", feedId];
//          NSString *identifer = [commentTargetId stringByAppendingString:self.identifier];
//          [[MGMDataSyncManager sharedManager] addLikeObserverWithId:identifer targetId:commentTargetId callback:^(NSDictionary *info) {
//              __strong typeof(weakSelf)strongSelf = weakSelf;
//              NSString *currentFeedId = [info valueForKey:@"feedId"];
//              if ([feedId isEqualToString:currentFeedId])
//              {
//                  NSInteger updateCommentCount = [[info valueForKey:@"reviewLinkCount"] integerValue];
//                  if ([strongSelf.timeLineModel respondsToSelector:@selector(updateCommentCount:)])
//                  {
//                      [strongSelf.timeLineModel updateCommentCount:updateCommentCount];
//                  }
//                  [strongSelf updateCommentView];
//              }
//          }];
      }
    
    [self updateFollowView];
    [self refreshToolBar];
    
    NSString *updateTime = [timeLineModel.timeLineCreateTime mgm_timeStampStrToUGCTimeString];
    self.dateLabel.text = updateTime;
    
    self.commentView.replys = timeLineModel.timeLineCommentTexts;
    self.commentView.hidden = timeLineModel.isHideCommentView;
    CGFloat commentViewH = 0.f;
    CGFloat toolBarBottomSpace = 0.f;
    //  有子评论同时不隐藏子评论,则更新高度约束(是否隐藏子评论为了动态首页和动态详情顶部视图复用)
    if (timeLineModel.timeLineCommentTexts.count && !timeLineModel.isHideCommentView)
    {
        commentViewH = timeLineModel.timeLineCommentHeight - 20;
        toolBarBottomSpace = -timeLineModel.timeLineCommentHeight;
    }
    [self.commentView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.offset(commentViewH);
    }];

    [self.toolBar mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.offset(toolBarBottomSpace);
    }];
}

- (void)setHideSeperateLine:(BOOL)hideSeperateLine
{
    _hideSeperateLine = hideSeperateLine;
    self.seperateLine.hidden = hideSeperateLine;
}

- (void)setupBillboard:(MGUFragmentBillboard *)billboard {
    
}

#pragma mark - Lazy

- (NSMutableArray *)tagLabelM
{
    if (!_tagLabelM)
    {
        _tagLabelM = [NSMutableArray array];
    }
    return _tagLabelM;
}

#pragma mark - UIGestureRecognizer Delegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    CGPoint touchP = [touch locationInView:self.contentView];
    CGPoint toPoint = [self.contentView convertPoint:touchP toView:self.flowTopicView];
    return CGRectContainsPoint(self.flowTopicView.bounds, toPoint) ? NO : YES;
}

- (UIImageView *)toastbgView {
    if (!_toastbgView) {
        _toastbgView = [[UIImageView alloc] initWithImage:[MGMCommunityResource imageNamed:@"img_fxjb"]];
        _toastbgView.hidden = YES;
        _toastbgView.userInteractionEnabled = YES;
        [_toastbgView addSubview:self.reportBtn];
        if (self.isHideShareView) {
            _toastbgView.image = [MGMCommunityResource imageNamed:@"img_jb"];
           [self.reportBtn mas_makeConstraints:^(MASConstraintMaker *make) {
               make.top.left.bottom.offset(0);
               make.right.offset(MGMScaleValue(-4));
            }];
        } else {
            [_toastbgView addSubview:self.shareBtn];
            [self.reportBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.left.bottom.offset(0);
                make.width.equalTo(self.shareBtn);
            }];
            [self.shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(self.reportBtn.mas_right);
                make.top.bottom.offset(0);
                make.right.offset(MGMScaleValue(-4));
                make.width.equalTo(self.reportBtn);
            }];
            
            UIView *separatorView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0.5, 20)];
            separatorView.backgroundColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0];
            [_toastbgView addSubview:separatorView];
            [separatorView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.offset(0);
                make.left.equalTo(self.reportBtn.mas_right);
                make.width.offset(0.5);
                make.height.offset(MGMScaleValue(20.f));
            }];
        }
    }
    return _toastbgView;
}

- (UIButton *)reportBtn {
    if (!_reportBtn) {
        UIButton *jbbtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [jbbtn setTitle:@"举报" forState:UIControlStateNormal];
        [jbbtn setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        jbbtn.titleLabel.font = [UIFont systemFontOfSize:12];
        [jbbtn addTarget:self action:@selector(toastViewDidClick) forControlEvents:UIControlEventTouchUpInside];
        _reportBtn = jbbtn;
    }
    return _reportBtn;
}

- (UIButton *)shareBtn {
    if (!_shareBtn) {
       UIButton *jbbtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [jbbtn setTitle:@"分享" forState:UIControlStateNormal];
        [jbbtn setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        jbbtn.titleLabel.font = [UIFont systemFontOfSize:12];
        [jbbtn addTarget:self action:@selector(shareBtnDidClick) forControlEvents:UIControlEventTouchUpInside];
        _shareBtn = jbbtn;
    }
    return _shareBtn;
}

#pragma mark - Target Action

- (void)tapAction
{
    if (!self.toastbgView.hidden)
    {
        [self dismissToastView];
        return;
    }
    
    [self performSelector:self.tapSelector withObject:self.tapGesture];
}

- (void)handleCommentListTapGesture
{
    if ([self respondsToSelector:self.commentListTapSelector])
    {
        [self performSelector:self.commentListTapSelector];
        return;
    }
    [self tapAction];
}

- (void)tapUserProfileAction:(UITapGestureRecognizer *)gesture
{
    NSString *eventName = (gesture.view == self.avatarView) ? MGMCommunityUserAvatarEvent : MGMCommunityUserNameEvent;
    [self routerEventWithName:eventName
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)followBtnDidClick
{
    [self routerEventWithName:MGMCommunityFollowEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)moreBtnDidClick
{
    self.toastbgView.hidden = !self.toastbgView.hidden;
    [self routerEventWithName:MGMCommunityMoreEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)likeCountBtnDidClick
{
    BOOL selected = !self.likeCountBtn.selected;
    [self routerEventWithName:MGMCommunityLikeEvent
                     userInfo:@{MGMCommunityLikeInfo: selected ? @(YES) : @(NO),
                                MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)shareBtnDidClick
{
    if (!self.toastbgView.hidden)
    {
        [self dismissToastView];
    }
    UIImage *shareImage = [MGMCommunityResource imageNamed:@"APPlogo_1024x1024"];
    if ([self.timeLineModel isMemberOfClass:[MGMTimeLineStagePhotoModel class]]) {
        MGMTimeLineStagePhotoModel *imageModel = (MGMTimeLineStagePhotoModel *)self.timeLineModel;
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageModel.stagePhotoCoverUrl]];
        shareImage = [UIImage imageWithData:data];
    } else {
        NSString *imageUrl = [self.timeLineModel.timeLinePhotoUrls mgu_objectOrNilAtIndex:0];
        if (imageUrl) {
            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageUrl]];
            shareImage = [UIImage imageWithData:data];
        }
    }
    
    NSMutableDictionary *userInfo = @{}.mutableCopy;
    [userInfo mgu_safe_setObject:self.timeLineModel forKey:MGMCommunityExtraInfo];
    [userInfo mgu_safe_setObject:shareImage forKey:MGMCommunityShareImage];
    [self routerEventWithName:MGMCommunityShareEvent userInfo:userInfo];
}

- (void)commentCountBtnDidClick
{
    [self routerEventWithName:MGMCommunityCommentTrackEvent userInfo:@{MGMCommunityMainInfo: self,
                                                                       MGMCommunityExtraInfo: self.timeLineModel}];
    
    //  子类根据自身业务决定是否实现
    if ([self respondsToSelector:self.commentTapSelector])
    {
        SEL commentTapSelector = self.commentTapSelector;
        if (commentTapSelector)
        {
            [self performSelector:self.commentTapSelector];
            return;
        }
    }
    [self tapAction];
}

- (void)toastViewDidClick
{
    [self dismissToastView];
    NSString *eventName = self.timeLineModel.isCurrentUser ? MGMCommunityDeleteEvent : MGMCommunityReportEvent;
    [self routerEventWithName:eventName
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

@end
