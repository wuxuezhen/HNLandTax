//
//  MGMTimeLinePictureView.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/6.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTimeLinePictureView.h"
#import "MGMCommunity.h"
#import "MGMCommunityResource.h"
#import "MGMTimeLineImageTextModel.h"
#import <YYWebImage/YYWebImage.h>
#import <YYCategories/YYCategories.h>
#import <MGMCategories/UIView+MGMFrame.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>

@interface MGMTimeLinePictureView()

@property (nonatomic, copy) NSArray <UIImageView *>*pictures;

@end

@implementation MGMTimeLinePictureView

#pragma mark - Override

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        [self initialize];
    }
    return self;
}

#pragma mark - Private

- (void)initialize
{
    NSInteger picMaxCount = 9;
    CGFloat picImgViewX = 0.f;
    CGFloat picImgViewY = 0.f;
    YYAnimatedImageView *picImgView = nil;
    NSMutableArray <UIImageView *>*pictureM = [NSMutableArray arrayWithCapacity:picMaxCount];
    for (NSInteger i = 0; i < picMaxCount; i++)
    {
        picImgViewX = (i % MGMRowCount) * (MGMItemSizeW + MGMItemInnerSpace);
        picImgViewY = (i / MGMRowCount) * (MGMItemSizeW + MGMItemInnerSpace);
        picImgView = [[YYAnimatedImageView alloc] initWithFrame:CGRectMake(picImgViewX, picImgViewY, MGMItemSizeW, MGMItemSizeW)];
        picImgView.contentMode = UIViewContentModeTop;
        picImgView.layer.cornerRadius = 4.f;
        picImgView.clipsToBounds = YES;
        picImgView.autoPlayAnimatedImage = YES;
        picImgView.backgroundColor = [UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1.0];
        [self addSubview:picImgView];
        [pictureM addObject:picImgView];
    }
    self.pictures = pictureM;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                          action:@selector(handleTapGesture:)];
    [self addGestureRecognizer:tap];
}

- (void)setTimeLineModel:(id<MGMTimeLineDataSource>)timeLineModel
{
    _timeLineModel = timeLineModel;
    YYAnimatedImageView *picImgView = nil;
    UIImage *placeholder = [MGMCommunityResource imageNamed:@"img_zwt"];
    NSInteger picCount = timeLineModel.timeLinePhotoUrls.count;
    NSString *picUrl = nil;
    for (NSInteger i = 0; i < self.pictures.count; i++)
    {
        picImgView = self.pictures[i];
        picImgView.mgm_Size = timeLineModel.timeLinePhotoSize;
        if (i < picCount)
        {
            picImgView.hidden = NO;
            picUrl = timeLineModel.timeLinePhotoUrls[i];
            picImgView.contentMode = UIViewContentModeCenter;
            @weakify(picImgView);
            [picImgView yy_setImageWithURL:[NSURL URLWithString:picUrl]
                               placeholder:placeholder
                                   options:YYWebImageOptionAvoidSetImage
                                completion:^(UIImage * _Nullable image, NSURL * _Nonnull url, YYWebImageFromType from, YYWebImageStage stage, NSError * _Nullable error) {
                                    @strongify(picImgView);
                                    if (!image) return;
                                    picImgView.contentMode = UIViewContentModeScaleAspectFill;
                                    if ([url.absoluteString hasSuffix:@".gif"] || image.size.width > image.size.height)
                                    {
                                        picImgView.image = image;
                                    }
                                    else
                                    {
                                        CGSize imageSize = picImgView.size;
                                        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                            UIImage *drawImage = [image mgm_drawContentTopImageWithSize:imageSize];
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                picImgView.image = drawImage;
                                            });
                                        });
                                    }
                                }];
        }
        else
        {
            picImgView.hidden = YES;
        }
    }
}

#pragma mark - Target Action

- (void)handleTapGesture:(UITapGestureRecognizer *)gesture
{
    CGPoint clickPoint = [gesture locationInView:self];
    UIImageView *picImgView = nil;
    NSInteger clickIndex = NSNotFound;
    for (NSInteger i = 0; i < self.pictures.count; i++)
    {
        picImgView = self.pictures[i];
        if (CGRectContainsPoint(picImgView.frame, clickPoint) && !picImgView.hidden)
        {
            clickIndex = i;
            break;
        }
    }
    
    [self routerEventWithName:MGMCommunityPhotoClickEvent
                     userInfo:@{MGMCommunityPhotoClickIndex: @(clickIndex),
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

#pragma mark - Getter

- (NSArray *)allPics
{
    NSMutableArray *picM = [NSMutableArray array];
    NSArray *pics = [self.pictures valueForKeyPath:@"image"];
    [pics enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:[UIImage class]])
        {
            [picM addObject:obj];
        }
    }];
    return picM;
}

@end
