//
//  MGMTimeLineCellDataSource.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2020/1/7.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#ifndef MGMTimeLineDataSource_h
#define MGMTimeLineDataSource_h

#import <UIKit/UIKit.h>
#import <YYText/YYTextLayout.h>

@protocol MGMTimeLineDataSource <NSObject>

@property (nonatomic, copy) NSString *nickname;
@property (nonatomic, copy) NSString *timeLineCreateTime;
@property (nonatomic, copy) NSString *avatarUrl;
@property (nonatomic, copy) NSString *userIdentiftyIconUrl;

/**
    是否是剧照
 */
@property (nonatomic, assign) BOOL isStills;
@property (nonatomic, assign) BOOL isHideMoreBtn;
@property (nonatomic, assign) BOOL isHideCommentView;
@property (nonatomic, assign) BOOL isHideFollowBtn;
@property (nonatomic, assign) BOOL isCurrentUser;
@property (nonatomic, assign) BOOL isHideAllTextBtn;

/**
    是否点赞
 */
@property (nonatomic, assign) BOOL isLike;

/**
    点赞数
 */
@property (nonatomic, assign) NSInteger timeLineLikeCount;

/**
    评论数
*/
@property (nonatomic, assign) NSInteger timeLineCommentCount;

@property (nonatomic, copy) NSString *timeLineMid;
@property (nonatomic, copy) NSString *timeLineFeedId;
@property (nonatomic, assign) CGFloat timeLineTopicHeight;
@property (nonatomic, assign) CGFloat timeLineTextHeight;
@property (nonatomic, assign) CGFloat timeLineCommentHeight;
@property (nonatomic, assign) CGFloat timeLinePhotoHeight;
@property (nonatomic, assign) CGFloat timeLineVoteHeight;
@property (nonatomic, assign) CGSize timeLinePhotoSize;
@property (nonatomic, assign) CGFloat timeLineTopicViewOriginY;
@property (nonatomic, strong) UIColor *nicknameColor;
@property (nonatomic, strong) YYTextLayout *timeLineTextLayout;
@property (nonatomic, copy) NSArray <NSAttributedString *>*timeLineCommentTexts;
@property (nonatomic, copy) NSArray <NSString *>*timeLinePhotoUrls;

/**
    标签集合
 */
@property (nonatomic, copy) NSArray <NSString *> *timeLineTags;

/**
    话题集合
 */
@property (nonatomic, copy) NSArray <NSString *>*timeLineTopics;

/**
    标签宽度
 */
@property (nonatomic, copy) NSArray <NSNumber *>*timeLineTagWidths;

@property (nonatomic, copy) id voteModels;
@end

@protocol MGMTimeLineDelegate <NSObject>

- (void)updateCommentCount:(NSInteger)commentCount;
- (void)updateLikeCount:(NSInteger)likeCount isLike:(BOOL)isLike;

@end

#endif /* MGMTimeLineDataSource_h */
