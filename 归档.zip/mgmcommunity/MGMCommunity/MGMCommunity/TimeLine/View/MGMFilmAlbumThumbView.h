//
//  MGMFilmAlbumThumbView.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/9.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMFilmAlbumThumbView : UIView

@property (nonatomic, weak, readonly) UILabel *albumNameLabel;
@property (nonatomic, weak, readonly) UILabel *albumInfoLabel;
@property (nonatomic, weak, readonly) UIImageView *albumCoverView;

@end

NS_ASSUME_NONNULL_END
