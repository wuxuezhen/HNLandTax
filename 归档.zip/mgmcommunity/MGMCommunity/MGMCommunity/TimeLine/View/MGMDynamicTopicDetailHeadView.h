//
//  MGMDynamicTopicDetailHeadView.h
//  MGMCommunity
//
//  Created by YL on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class MGMDynamicTopicItemModel;

@interface MGMDynamicTopicDetailHeadView : UIView

@property (nonatomic, strong) MGMDynamicTopicItemModel  *topicItemModel;

@end

NS_ASSUME_NONNULL_END
