//
//  MGMTimeLineTopicView.m
//  Aspects
//
//  Created by 袁飞扬 on 2020/1/7.
//

#define MAS_SHORTHAND_GLOBALS
#import "MGMTimeLineTopicView.h"
#import <Masonry/Masonry.h>
#import <MGMCategories/MGMCategories.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMHttpApiModel/MGMLegoPage.h>
#import <MGMRoute/MGMRoute.h>
#import <MGMDataStore/MGMDCommonSettingConfig.h>
#import "MGMCommunityResource.h"

@interface MGMTimeLineTopicView()

@property (nonatomic, strong)UIImageView *viewBg;

@property (nonatomic, strong)UILabel *titleLabel;
@property (nonatomic, strong)UILabel *subTitleLabel;

@property (nonatomic, strong)MGMData *data;

@end


@implementation MGMTimeLineTopicView


- (instancetype)init{
    if (self = [super init]) {
        self.frame = CGRectMake(0, 0, kMGMHBL2X(140), kMGMHBL2X(85));
        self.backgroundColor = [UIColor whiteColor];
        self.titleLabel.text = @"#话题名称话题名称话题名称#";
        self.subTitleLabel.text = @"37372人参与";
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickItemView:)];
        self.userInteractionEnabled = YES;
        [self addGestureRecognizer:tap];
        
    }
    return self;
}
- (void)clickItemView:(UITapGestureRecognizer *)tap{
    if([[MGMDCommonSettingConfig shareConfig].dynamicIdArray containsObject:self.data.action.params.contentID]) {
        NSInteger scrollIndex = [[MGMDCommonSettingConfig shareConfig].dynamicIdArray indexOfObject:self.data.action.params.contentID];
         [MGMRoute routePageControllerWithTabIndex:3 subTabIndex:scrollIndex];
    }
    else {
        NSString *topicId = self.data.action.params.contentID;
        NSMutableDictionary *paramM = [NSMutableDictionary dictionary];
        [paramM mgu_safe_setObject:topicId forKey:@"MGMCommunityRouteTopicId"];
        [MGMRoute routePageControllerWithName:@"community_topicDetail_page"
                                   parameters:paramM
                              transitionStyle:(MGURouteTransitionStyleNav)];
    }
}
- (void)setDynamicTopicCount:(NSString *)dynamicTopicCount{
    _dynamicTopicCount = dynamicTopicCount;
    self.subTitleLabel.text = [NSString stringWithFormat:@"%@人参与",[self digitalConversionWithDynamicTopicCount:dynamicTopicCount]];
}

-(void)setModel:(id)model{
    _model = model;
    
    MGMData *data = model;
    
    if (data) {
        self.titleLabel.text = data.name;
    }
    self.data = data;
}


- (UIImageView *)viewBg{
    if (!_viewBg) {
        _viewBg = [[UIImageView alloc]init];
        //_viewBg.backgroundColor = [UIColor mgu_colorWithHex:0xE6F2FC opacity:1.0];
        _viewBg.layer.cornerRadius = kMGMHBL2X(4);
        _viewBg.layer.masksToBounds = YES;
        _viewBg.userInteractionEnabled = YES;
        _viewBg.image = [MGMCommunityResource originalRenderingModeImageWithName:@"mgm_img_rmhtbg"];
        [self addSubview:_viewBg];
        [_viewBg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.bottom.equalTo(0);
            make.right.equalTo(-kMGMHBL2X(10));
        }];
    }
    return _viewBg;
}

- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.numberOfLines = 2;
        _titleLabel.textColor = [UIColor mgu_colorWithHex:0x1A1A1A opacity:1.0];
        _titleLabel.textAlignment = NSTextAlignmentJustified;
        _titleLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:13];
        [self.viewBg addSubview:_titleLabel];
        [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(kMGMHBL2X(10));
            make.top.equalTo(kMGMHBL2X(13));
            make.right.equalTo(-kMGMHBL2X(10));
            make.height.mas_greaterThanOrEqualTo(kMGMHBL2X(18));
        }];
        
    }
    return _titleLabel;
}

- (UILabel *)subTitleLabel{
    if (!_subTitleLabel) {
        _subTitleLabel = [[UILabel alloc]init];
        _subTitleLabel.numberOfLines = 1;
        _subTitleLabel.textColor = [UIColor mgu_colorWithHex:0x666666 opacity:1.0];
        _subTitleLabel.textAlignment = NSTextAlignmentLeft;
        _subTitleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        [self.viewBg addSubview:_subTitleLabel];
        [_subTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(kMGMHBL2X(10));
            make.bottom.equalTo(-kMGMHBL2X(15));
            make.right.equalTo(-kMGMHBL2X(10));
            make.height.equalTo(kMGMHBL2X(12));
        }];
    }
    return _subTitleLabel;
}


- (NSString *)digitalConversionWithDynamicTopicCount:(NSString *)count{
    long number = [count longLongValue];
    if (number<10000) {
        return count;
    }else{
        double topicCount = number/10000.0;
        return [NSString stringWithFormat:@"%.0f万",topicCount];
    }
}


@end
