//
//  MGMFilmThumbView.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/9.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFilmThumbView.h"
#import <Masonry/Masonry.h>
#import <YYWebImage/YYWebImage.h>

@interface MGMFilmThumbView()

@property (nonatomic, weak) UILabel *filmNameLabel;
@property (nonatomic, weak) UILabel *filmInfoLabel;
@property (nonatomic, weak) UILabel *filmScoreLabel;
@property (nonatomic, weak) UIImageView *filmCoverView;

@end

@implementation MGMFilmThumbView

#pragma mark - Override

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        [self initialize];
    }
    return self;
}

#pragma mark - Private

- (void)initialize
{
    self.backgroundColor = [UIColor colorWithRed:245/255.0 green:245/255.0 blue:245/255.0 alpha:1.0];
    
    UIImageView *filmCoverView = [[UIImageView alloc] init];
    filmCoverView.contentMode = UIViewContentModeScaleAspectFill;
    filmCoverView.layer.masksToBounds = YES;
    [self addSubview:filmCoverView];
    self.filmCoverView = filmCoverView;
    
    [filmCoverView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset(5);
        make.left.offset(6);
        make.size.sizeOffset(CGSizeMake(40, 60));
    }];
    
    UILabel *filmLabel = [[UILabel alloc] init];
    filmLabel.text = @"电影";
    filmLabel.textColor = [UIColor whiteColor];
    filmLabel.textAlignment = NSTextAlignmentCenter;
    filmLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:10];
    filmLabel.backgroundColor = [UIColor colorWithRed:255/255.0 green:95/255.0 blue:95/255.0 alpha:1.0];
    filmLabel.layer.cornerRadius = 2.5;
    filmLabel.layer.masksToBounds = YES;
    [self addSubview:filmLabel];
    
    [filmLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset(16);
        make.left.equalTo(filmCoverView.mas_right).offset(10);
        make.size.sizeOffset(CGSizeMake(28, 14));
    }];
    
    UILabel *filmNameLabel = [[UILabel alloc] init];
    filmNameLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 14];
    [self addSubview:filmNameLabel];
    self.filmNameLabel = filmNameLabel;
    
    [filmNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(filmLabel);
        make.left.equalTo(filmLabel.mas_right).offset(6);
        make.right.lessThanOrEqualTo(self).offset(-64);
    }];
    
    UILabel *filmScoreLabel = [[UILabel alloc] init];
    filmScoreLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size: 14];
    filmScoreLabel.textColor = [UIColor colorWithRed:255/255.0 green:62/255.0 blue:64/255.0 alpha:1.0];
    [self addSubview:filmScoreLabel];
    self.filmScoreLabel = filmScoreLabel;
    
    [filmScoreLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(filmNameLabel);
        make.left.equalTo(filmNameLabel.mas_right).offset(7);
    }];
    
    UILabel *filmInfoLabel = [[UILabel alloc] init];
    filmInfoLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 12];
    filmInfoLabel.textColor = [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1.0];
    [self addSubview:filmInfoLabel];
    self.filmInfoLabel = filmInfoLabel;
    
    [filmInfoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(filmLabel);
        make.bottom.offset(-14);
    }];
}

@end
