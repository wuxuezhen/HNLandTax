//
//  MGMTimeLineLoginView.h
//  AFNetworking
//
//  Created by WangDa Mac on 2019/8/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class MGMTimeLineLoginView;

@protocol MGMTimeLineLoginViewDelegate <NSObject>

- (void)timeLineLoginViewDidClickLogin:(MGMTimeLineLoginView *)loginView;

@end

@interface MGMTimeLineLoginView : UIView

@property (nonatomic, weak) id <MGMTimeLineLoginViewDelegate>delegate;

@end

NS_ASSUME_NONNULL_END
