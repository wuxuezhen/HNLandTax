//
//  MGMDynamicTopicDetailHeadView.m
//  MGMCommunity
//
//  Created by YL on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicTopicDetailHeadView.h"
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import "MGMCommunityResource.h"
#import <Masonry/Masonry.h>
#import <MGMCategories/UIVIew+MGMSetRoundedCorners.h>
#import <MGMSocialModule/MGMDynamicTopicItemModel.h>
#import <MGMCategories/NSString+MGMValidation.h>

@interface MGMDynamicTopicDetailHeadView()

@property (nonatomic, strong) UIImageView     *topicBgImageView;

@property (nonatomic, strong) UILabel         *topicNameLabel;

@property (nonatomic, strong) UIImageView     *topicIconView;

@property (nonatomic, strong) UILabel         *watchPeopleLabel;

@property (nonatomic, strong) UIView         *topicCornerView;

@end

@implementation MGMDynamicTopicDetailHeadView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        [self addSubview:self.topicBgImageView];
        [self addSubview:self.topicNameLabel];
        [self addSubview:self.topicIconView];
        [self addSubview:self.watchPeopleLabel];
        [self addSubview:self.topicCornerView];
        
        [self.topicBgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self);
        }];
        
        [self.topicNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_greaterThanOrEqualTo(10);
            make.top.mas_equalTo(MGMNavigationBarH+MGMStatusBarH+ 4.5);
            make.left.mas_equalTo(15);
            make.right.equalTo(self).offset(-15);
        }];
        
        [self.topicIconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(15);
            make.bottom.equalTo(self).offset(-33);
            make.size.mas_equalTo(CGSizeMake(15, 12));
        }];
        
        [self.watchPeopleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.topicIconView.mas_right).offset(6);
            make.bottom.equalTo(self.topicIconView);
            make.right.equalTo(self.topicBgImageView).offset(-10);
            make.height.mas_equalTo(12);
        }];
    }
    return self;
}

- (void)setTopicItemModel:(MGMDynamicTopicItemModel *)topicItemModel {
    _topicItemModel = topicItemModel;
    
    NSInteger topicLength = self.topicItemModel.topicId.length;
    NSString *lastIdC = [self.topicItemModel.topicId substringFromIndex:topicLength-1];
    if([lastIdC mgm_judgeIsNumberByRegularExpression]) {
        self.topicBgImageView.image = [MGMCommunityResource imageNamed:@"mgm_dynamic_topic_detail_blue_bg"];
    }
    else {
        self.topicBgImageView.image = [MGMCommunityResource imageNamed:@"mgm_dynamic_topic_detail_red_bg"];
    }
    self.topicNameLabel.text = [NSString stringWithFormat:@"#%@#",topicItemModel.name];
    self.watchPeopleLabel.text = [NSString stringWithFormat:@"已有%ld位小伙伴围观",topicItemModel.dynamicCount];
}

#pragma mark - lazyload
- (UIImageView *)topicBgImageView {
    if(!_topicBgImageView) {
        _topicBgImageView = [[UIImageView alloc] init];
        _topicBgImageView.image = [MGMCommunityResource imageNamed:@"mgm_dynamic_topic_detail_red_bg"];
    }
    return _topicBgImageView;
}

- (UILabel *)topicNameLabel {
    if(!_topicNameLabel) {
        _topicNameLabel = [[UILabel alloc] init];
        _topicNameLabel.textAlignment = NSTextAlignmentLeft;
        _topicNameLabel.backgroundColor = [UIColor clearColor];
        _topicNameLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:16];
        _topicNameLabel.textColor = [UIColor whiteColor];
        _topicNameLabel.numberOfLines = 2;
        _topicNameLabel.lineBreakMode = NSLineBreakByWordWrapping;
    }
    return _topicNameLabel;
}

- (UIImageView *)topicIconView {
    if(!_topicIconView) {
        _topicIconView = [[UIImageView alloc] init];
        _topicIconView.image = [MGMCommunityResource imageNamed:@"mgm_dynamic_topic_white_icon"];
    }
    return _topicIconView;
}

- (UILabel *)watchPeopleLabel {
    if(!_watchPeopleLabel) {
        _watchPeopleLabel = [[UILabel alloc] init];
        _watchPeopleLabel.textAlignment = NSTextAlignmentLeft;
        _watchPeopleLabel.backgroundColor = [UIColor clearColor];
        _watchPeopleLabel.font = [UIFont systemFontOfSize:12];
        _watchPeopleLabel.textColor = [UIColor whiteColor];
    }
    return _watchPeopleLabel;
}

- (UIView *)topicCornerView {
    if(!_topicCornerView) {
        _topicCornerView = [[UIView alloc] initWithFrame:CGRectMake(0, self.height-13, MGMScreenW, 51)];
        _topicCornerView.clipsToBounds = YES;
        _topicCornerView.backgroundColor = [UIColor whiteColor];
        [_topicCornerView setCornerRadius:12.5 addRectCorners:UIRectCornerTopLeft|UIRectCornerTopRight];
    }
    return _topicCornerView;
}


@end
