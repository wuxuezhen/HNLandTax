//
//  MGMStagePhotoTimeLineCell.h
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

//剧照
#import "MGMTimeLineBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMStagePhotoTimeLineCell : MGMTimeLineBaseCell

@end

NS_ASSUME_NONNULL_END
