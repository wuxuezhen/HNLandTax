//
//  MGMTopicTimeLineCell.m
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTopicTimeLineCell.h"
#import "MGMTimeLineTopicModel.h"

@interface MGMTopicTimeLineCell()

/**
    话题内容
 */
@property (nonatomic, weak) YYLabel *topicTextLabel;

/**
    话题视图
 */
@property (nonatomic, weak) UIButton *topicBtn;

/**
    话题标题
 */
@property (nonatomic, weak) UILabel *titleLabel;

@end

@implementation MGMTopicTimeLineCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self setSubviews];
    }
    return self;
}

#pragma mark - Private

- (void)setSubviews
{
    UIButton *topicBtn = [UIButton buttonWithType:(UIButtonTypeCustom)];
    topicBtn.enabled = NO;
    topicBtn.backgroundColor = [UIColor colorWithRed:99/255.0 green:173/255.0 blue:239/255.0 alpha:0.1];
    topicBtn.layer.cornerRadius = 12;
    topicBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    topicBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [topicBtn setImage:[MGMCommunityResource imageNamed:@"icon_ht"] forState:(UIControlStateDisabled)];
    [self.contentView addSubview:topicBtn];
    self.topicBtn = topicBtn;
    
    [topicBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.topContainerView.mas_bottom).offset(0);
        make.left.offset(15);
        make.height.offset(24);
    }];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.textColor = [UIColor colorWithRed:99/255.0 green:173/255.0 blue:239/255.0 alpha:1.0];
    titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 12];
    [topicBtn addSubview:titleLabel];
    self.titleLabel = titleLabel;
    
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(28);
        make.right.offset(-10);
        make.height.offset(12);
        make.centerY.offset(0);
    }];
    
    YYLabel *topicTextLabel = [[YYLabel alloc] init];
    topicTextLabel.numberOfLines = 0;
    topicTextLabel.textVerticalAlignment = YYTextVerticalAlignmentCenter;
    topicTextLabel.textColor = [UIColor mgu_colorWithHex:0x333333];
    topicTextLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *commentTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleCommentTapGesture)];
    [topicTextLabel addGestureRecognizer:commentTapGesture];
    [self.contentView addSubview:topicTextLabel];
    self.topicTextLabel = topicTextLabel;
    
    [topicTextLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.right.offset(-15);
        make.top.equalTo(topicBtn.mas_bottom).offset(12);
    }];
}

#pragma mark - Target Action

- (void)handleTapGestureForTopic:(UITapGestureRecognizer *)gesture
{
    [self routerEventWithName:MGMCommunityTopicEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)handleCommentTapGesture
{
    [self routerEventWithName:MGMCommunityMainCommentEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)handleSubCommentAction
{
    [self routerEventWithName:MGMCommunitySubCommentEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

#pragma mark - Setter&Getter

- (void)setTimeLineModel:(id<MGMTimeLineDataSource,MGMTimeLineDelegate>)timeLineModel
{
    [super setTimeLineModel:timeLineModel];
    MGMTimeLineTopicModel *topicModel = (MGMTimeLineTopicModel *)timeLineModel;
    self.titleLabel.text = topicModel.contentTitle;
    CGFloat width = [topicModel.contentTitle mgu_sizeForFont:[UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size: 12]
                                                              size:CGSizeMake(CGFLOAT_MAX, 12)
                                                              mode:(NSLineBreakByWordWrapping)].width;
    
    width = (ceilf(width) + 40);
    CGFloat maxWidth = MGMScreenW - (2 * MGMItemSpace);
    
    [self.topicBtn mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset(MIN(width, maxWidth));
    }];
    self.topicTextLabel.textLayout = topicModel.topicCommentLayout;
    [self.topicTextLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.offset(topicModel.textHeight);
    }];
}

- (SEL)tapSelector
{
    return @selector(handleTapGestureForTopic:);
}

- (SEL)commentTapSelector
{
    return @selector(handleSubCommentAction);
}

- (SEL)commentListTapSelector
{
    return @selector(handleCommentTapGesture);
}

@end
