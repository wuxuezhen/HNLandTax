//
//  MGMStagePhotoTimeLineCell.m
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMStagePhotoTimeLineCell.h"
#import "MGMTimeLineStagePhotoModel.h"
#import <YYWebImage/YYWebImage.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>

#define MGMPhotoStageSize   CGSizeMake(228, 160)

@interface MGMStagePhotoTimeLineCell()

/**
    剧照图片
 */
@property (nonatomic, weak) UIImageView *photoImgView;

/**
    剧照标题
 */
@property (nonatomic, weak) UIButton *photoTitleView;

@end

@implementation MGMStagePhotoTimeLineCell

#pragma mark - Override

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self setSubviews];
    }
    return self;
}

#pragma mark - Private

- (void)setSubviews
{
    UIButton *photoTitleView = [UIButton buttonWithType:(UIButtonTypeCustom)];
    
    photoTitleView.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 12];;
    [photoTitleView setTitleColor:[UIColor colorWithRed:255/255.0 green:95/255.0 blue:95/255.0 alpha:1.0] forState:(UIControlStateNormal)];
    [photoTitleView setImage:[MGMCommunityResource imageNamed:@"icon_jz"] forState:(UIControlStateNormal)];
    photoTitleView.backgroundColor = [UIColor colorWithRed:255/255.0 green:95/255.0 blue:95/255.0 alpha:0.1];
    photoTitleView.layer.cornerRadius = 12;
    [photoTitleView addTarget:self
                       action:@selector(photoTitleDidClick)
             forControlEvents:(UIControlEventTouchUpInside)];
    [self.contentView addSubview:photoTitleView];
    self.photoTitleView = photoTitleView;
    
    [photoTitleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.topContainerView.mas_bottom).offset(-1);
        make.left.offset(15);
        make.height.offset(24);
    }];
    
    UIImageView *photoImgView = [[UIImageView alloc] init];
    photoImgView.contentMode = UIViewContentModeScaleAspectFill;
    photoImgView.backgroundColor = [UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1.0];;
    photoImgView.layer.cornerRadius = 4;
    photoImgView.layer.masksToBounds = YES;
    [self.contentView addSubview:photoImgView];
    self.photoImgView = photoImgView;

    [photoImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.top.equalTo(photoTitleView.mas_bottom).offset(12);
        make.size.sizeOffset(MGMPhotoStageSize);
    }];
    
    UILabel *stagephotoLabel = [[UILabel alloc] init];
    stagephotoLabel.layer.cornerRadius = 2;
    stagephotoLabel.layer.masksToBounds = YES;
    stagephotoLabel.backgroundColor = [UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:0.8];
    stagephotoLabel.text = @"咪咕剧照";
    stagephotoLabel.textAlignment = NSTextAlignmentCenter;
    stagephotoLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:9];
    [photoImgView addSubview:stagephotoLabel];
    
    [stagephotoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset(5);
        make.right.offset(-6);
        make.size.sizeOffset(CGSizeMake(48, 15));
    }];
}

#pragma mark - Setter

- (void)setTimeLineModel:(id<MGMTimeLineDataSource,MGMTimeLineDelegate>)timeLineModel
{
    [super setTimeLineModel:timeLineModel];

    MGMTimeLineStagePhotoModel *stagePhotoModel = (MGMTimeLineStagePhotoModel *)timeLineModel;
    UIImage *placeholder = [MGMCommunityResource imageNamed:@"img_zwt"];
    MGMWeakSelf;
    [self.photoImgView yy_setImageWithURL:[NSURL URLWithString:stagePhotoModel.stagePhotoCoverUrl] placeholder:placeholder options:YYWebImageOptionAvoidSetImage completion:^(UIImage * _Nullable image, NSURL * _Nonnull url, YYWebImageFromType from, YYWebImageStage stage, NSError * _Nullable error) {
        MGMStrongSelf;
        if (image.size.height > image.size.width)
        {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                UIImage *drawImage = [image mgm_drawContentTopImageWithSize:MGMPhotoStageSize];
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.photoImgView.image = drawImage;
                });
            });
        }
        else
        {
            self.photoImgView.image = image;
        }
    }];
    
    NSString *title = stagePhotoModel.stagePhotoName;
    [self.photoTitleView setTitle:title forState:(UIControlStateNormal)];
    CGFloat titleLength = [title mgu_sizeForFont:[UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size: 12]
                                            size:CGSizeMake(CGFLOAT_MAX, 12)
                                            mode:(NSLineBreakByWordWrapping)].width + 30.f;
    
    [self.photoTitleView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset(ceilf(titleLength));
    }];
}

#pragma mark - Target Action

- (void)photoTitleDidClick
{
    MGMTimeLineStagePhotoModel *stagePhotoModel = (MGMFeedItemContentStills *)self.timeLineModel;
    [self routerEventWithName:MGMCommunityFilmEvent
                     userInfo:@{MGMCommunityFilmContentID: stagePhotoModel.stagePhotoContentID ?: @"",
                                MGMCommunityFilmKID: stagePhotoModel.stagePhotoKId ?: @"",
                                MGMCommunityFilmContentName: stagePhotoModel.stagePhotoOriginalName ?: @"",
                                MGMCommunityExtraInfo: self.timeLineModel
                                }];
}

- (void)handleTapGestureForStagePhoto:(UITapGestureRecognizer *)gesture
{
    CGPoint touchP = [gesture locationInView:self.contentView];
    if (CGRectContainsPoint(self.photoImgView.frame, touchP))
    {
        [self routerEventWithName:MGMCommunityStagePhotoClickEvent
                         userInfo:@{MGMCommunityPhotoClickIndex: @(0),
                                    MGMCommunityExtraInfo: self.timeLineModel
                                    }];
        return;
    }
    [self routerEventWithName:MGMCommunityStagePhotoEvent
                     userInfo:@{MGMCommunityMainInfo: self,
                                MGMCommunityExtraInfo: self.timeLineModel}];
}

- (void)handleCommentTapGesture
{
    [self routerEventWithName:MGMCommunityImageTextClickEvent
                        userInfo:@{MGMCommunityMainInfo: self,
                                   MGMCommunityExtraInfo: self.timeLineModel,
                                   MGMCommunityClickComment: @(YES)}];
}

#pragma mark - Getter

- (SEL)tapSelector
{
    return @selector(handleTapGestureForStagePhoto:);
}

- (SEL)commentTapSelector
{
    return @selector(handleCommentTapGesture);
}

- (BOOL)isHideShareView
{
    return NO;
}

- (UIImage *)shareImage
{
    return self.photoImgView.image;
}

@end
