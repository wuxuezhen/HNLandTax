//
//  MGMFilmThumbView.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/9.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMFilmThumbView : UIView

@property (nonatomic, weak, readonly) UILabel *filmNameLabel;
@property (nonatomic, weak, readonly) UILabel *filmInfoLabel;
@property (nonatomic, weak, readonly) UILabel *filmScoreLabel;
@property (nonatomic, weak, readonly) UIImageView *filmCoverView;

@end

NS_ASSUME_NONNULL_END
