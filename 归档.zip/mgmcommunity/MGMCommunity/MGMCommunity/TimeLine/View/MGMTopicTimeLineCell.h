//
//  MGMTopicTimeLineCell.h
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

//话题和资讯
#import "MGMTimeLineBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTopicTimeLineCell : MGMTimeLineBaseCell

@end

NS_ASSUME_NONNULL_END
