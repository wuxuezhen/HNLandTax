//
//  MGMTimeLineLoginView.m
//  AFNetworking
//
//  Created by WangDa Mac on 2019/8/15.
//

#import "MGMTimeLineLoginView.h"
#import "MGMCommunityResource.h"
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGMCategories/UIView+MGMFrame.h>

@implementation MGMTimeLineLoginView

#pragma mark - Override

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        [self initialize];
    }
    return self;
}

#pragma mark - Private

- (void)initialize
{
    self.backgroundColor = [UIColor whiteColor];
    
    CGFloat ratio = 0.515;
    UILabel *textLabel = [[UILabel alloc] init];
    textLabel.text = @"您还没有登录，登录后发现更大的世界";
    textLabel.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0];
    textLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: 15];
    [textLabel sizeToFit];
    textLabel.center = CGPointMake(self.mgm_width * 0.5, ceilf(ratio * self.mgm_height));
    [self addSubview:textLabel];
    
    UIImageView *placeHolderImgView = [[UIImageView alloc] initWithImage:[MGMCommunityResource imageNamed:@"img_qdl"]];
    [self addSubview:placeHolderImgView];
    placeHolderImgView.center = CGPointMake(self.mgm_width * 0.5, textLabel.mgm_centerY - 70);
    
    CGFloat loginBtnW = 100.f;
    CGFloat loginBtnH = 40.f;
    CGFloat loginBtnX = (self.mgm_width - loginBtnW) * 0.5;
    CGFloat loginBtnY = CGRectGetMaxY(textLabel.frame) + 12.f;
    UIButton *loginBtn = [[UIButton alloc] initWithFrame:CGRectMake(loginBtnX, loginBtnY, loginBtnW, loginBtnH)];
    [loginBtn setTitle:@"去登录" forState:(UIControlStateNormal)];
    [loginBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    loginBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size: 16];
    loginBtn.backgroundColor = [UIColor colorWithRed:255/255.0 green:62/255.0 blue:64/255.0 alpha:1.0];
    loginBtn.layer.cornerRadius = 20.f;
    [loginBtn addTarget:self
                 action:@selector(loginAction)
       forControlEvents:(UIControlEventTouchUpInside)];
    [self addSubview:loginBtn];
}

#pragma mark - Target Action

- (void)loginAction
{
    if ([self.delegate respondsToSelector:@selector(timeLineLoginViewDidClickLogin:)])
    {
        [self.delegate timeLineLoginViewDidClickLogin:self];
    }
}

@end
