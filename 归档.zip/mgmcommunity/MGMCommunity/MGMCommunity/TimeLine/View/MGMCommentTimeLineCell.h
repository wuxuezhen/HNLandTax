//
//  MGMCommentTimeLineCell.h
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

//评论影单，评论影片，评论小视频，创建影单，收藏影单
#import "MGMTimeLineBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMCommentTimeLineCell : MGMTimeLineBaseCell


@end

NS_ASSUME_NONNULL_END
