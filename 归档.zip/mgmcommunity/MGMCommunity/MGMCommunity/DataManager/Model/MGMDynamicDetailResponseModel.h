//
//  MGMDynamicDetailResponseModel.h
//  AFNetworking
//
//  Created by WangDa Mac on 2019/8/16.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class MGMDynamicContent, MGMFeedItemLabel, MGMSocialVoteContentModel;

@interface MGMDynamicDetailResponseModel : NSObject

@property (nonatomic, copy) NSString *userId;
@property (nonatomic, copy) NSString *dynamicId;
@property (nonatomic, copy) NSString *externalId;
@property (nonatomic, copy) NSString *clientType;
@property (nonatomic, copy) NSString *dynamicType;
@property (nonatomic, strong) MGMDynamicContent *dynamicContent;
@property (nonatomic, strong) MGMSocialVoteContentModel *voteContent;

/*
    存放该item对应的话题标签，数量无上限，可能未空
 */
@property (nonatomic, strong) NSArray <MGMFeedItemLabel *>* _Nullable topicLabels;
@property (nonatomic, copy) NSString *createTime;

@end

NS_ASSUME_NONNULL_END
