//
//  MGMDynamicDetailResponseModel.m
//  AFNetworking
//
//  Created by WangDa Mac on 2019/8/16.
//

#import "MGMDynamicDetailResponseModel.h"
#import <MGMSocialModule/MGMFeedItemLabel.h>

@implementation MGMDynamicDetailResponseModel

+ (nullable NSDictionary<NSString *, id> *)modelCustomPropertyMapper
{
    return @{
                @"topicLabels": @"labels",
                @"voteContent": @"voteConfigurationResponse"
            };
}

+ (NSDictionary *)modelContainerPropertyGenericClass
{
    return @{@"topicLabels": [MGMFeedItemLabel class]};
}

@end
