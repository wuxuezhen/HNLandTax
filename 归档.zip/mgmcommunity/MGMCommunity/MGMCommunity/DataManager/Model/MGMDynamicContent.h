//
//  MGMDynamicContent.h
//  AFNetworking
//
//  Created by WangDa Mac on 2019/8/16.
//

#import <Foundation/Foundation.h>
#import <MGMHttpApiModel/MGMUGCDetailModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMDynamicContent : NSObject

@property (nonatomic, assign) BOOL isSelected;
@property (nonatomic, copy) NSString *mid;
@property (nonatomic, copy) NSString *kId; //媒资壳ID
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, copy) NSString *contentID;
@property (nonatomic, copy) NSString *contentType;
@property (nonatomic, copy) NSString *coverUrl;
@property (nonatomic, copy) NSArray *associateContentId;
@property (nonatomic, copy) NSArray <MGMPicture *>*pictures;

@end

NS_ASSUME_NONNULL_END
