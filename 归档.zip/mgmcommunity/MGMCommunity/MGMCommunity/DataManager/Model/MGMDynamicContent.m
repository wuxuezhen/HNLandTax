//
//  MGMDynamicContent.m
//  AFNetworking
//
//  Created by WangDa Mac on 2019/8/16.
//

#import "MGMDynamicContent.h"

@implementation MGMDynamicContent

+ (NSDictionary *)modelContainerPropertyGenericClass
{
    return @{@"pictures" : [MGMPicture class]};
}

@end
