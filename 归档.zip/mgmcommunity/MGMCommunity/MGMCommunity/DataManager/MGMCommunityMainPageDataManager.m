//
//  MGMCommunityMainPageDataManager.m
//  MGMCommunity
//
//  Created by apple on 2018/12/4.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityMainPageDataManager.h"
#import <MGUHttpApiCore/MGUHttpApi.h>
#import <MGUHttpApiCore/MGUHttpApiFactory.h>

@interface MGMCommunityMainPageDataManager () <MGUHttpApiDelegate>
@property (nonatomic, strong, readwrite) MGUHttpApi *httpApi;
@end

@implementation MGMCommunityMainPageDataManager

- (MGUHttpApi *)httpApi {
    if (!_httpApi) {
        MGUHttpApiFactory *factory = [MGUHttpApiFactory apiFactory];
        _httpApi = [factory createApiWithName:@"MGM_Film_Topic_List_Api" parameters:nil urlPathParam:nil];
    }
    return _httpApi;
}

- (void)stopAllTask {
    [_httpApi stop];
}

- (void)startWithPageIndex:(NSInteger)index pageCount:(NSInteger)pageSize {
    NSInteger _pageSize = pageSize;
    if (_pageSize == 0) {
        _pageSize = 5;
    }
    [self.httpApi addRequestParameters:@{@"start":@(index),@"limit":@(_pageSize)}];
    _httpApi.apiDelegate = self;
    [_httpApi start];
}

- (void)httpApiFinished:(__kindof MGUHttpApi *)httpApi {
    if ([_mainPageDelegate respondsToSelector:@selector(communityMainPageDataManager:error:)]) {
        [_mainPageDelegate communityMainPageDataManager:self error:nil];
    }
}

- (void)httpApiFailed:(__kindof MGUHttpApi *)httpApi {
    if ([_mainPageDelegate respondsToSelector:@selector(communityMainPageDataManager:error:)]) {
        [_mainPageDelegate communityMainPageDataManager:self error:httpApi.error];
    }
}

@end
