//
//  MGMDynamicDetailDataManager.m
//  AFNetworking
//
//  Created by WangDa Mac on 2019/8/16.
//

#import "MGMDynamicDetailDataManager.h"
#import "MGMDynamicContent.h"
#import "MGMTimeLineImageTextModel.h"
#import "MGMTimeLineStagePhotoModel.h"
#import "MGMDynamicDetailResponseModel.h"
#import <YYModel/YYModel.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/UIColor+MGMColorExtension.h>
#import <MGUHttpApiCore/MGUHttpApi.h>
#import <MGMHttpApiModel/MGMHttpResponse.h>
#import <MGUHttpApiCore/MGUHttpApiFactory.h>
#import <MGMSocialModule/MGMSocialUser.h>
#import <MGMSocialModule/MGMFeedItemContentDefines.h>
#import <MGMSocialModule/MGMSocialLikeAndCommentCountModel.h>
#import <MGMUserCertification/MGMUserCertification.h>

static NSString *const MGMSocialFetchLikeAndCommentCountApiName = @"MGM_Social_FetchLikeAndCommentCount_Api";

@interface MGMDynamicDetailDataManager()<MGUHttpApiDelegate, MGMSocialDelegate>

@property (nonatomic, strong) MGMDynamicModel *dynamicModel;
@property (nonatomic, strong) MGUHttpApi *dynamicInfoApi;
@property (nonatomic, strong) MGUHttpApi *dynamicLikeCommentApi;
@property (nonatomic, weak) id <MGMDynamicDetailDataManagerDelegate>delegate;
@property (nonatomic, strong) MGMSocialUser *socialUser;
@property (nonatomic, strong) dispatch_group_t dynamicInfoGroup;
@property (nonatomic, copy) NSString *mid;
@property (nonatomic, copy) void(^completion)(MGMSocialUser *followUser, NSError *error);
@end

@implementation MGMDynamicDetailDataManager

#pragma mark - Public

- (instancetype)initWithDelegate:(id<MGMDynamicDetailDataManagerDelegate>)delegate
{
    if (self = [super init])
    {
        _delegate = delegate;
    }
    return self;
}

- (BOOL)fetchDynamicDetailInfoWithFeedId:(NSString *)feedId
{
    if (!feedId.length) return NO;
    
    NSMutableDictionary *paramM = [NSMutableDictionary dictionary];
    [paramM setObject:feedId forKey:@"dynamicId"];
    NSString *paramJson = [paramM yy_modelToJSONString];
    self.dynamicInfoApi = [[MGUHttpApiFactory apiFactory] createApiWithName:@"MGM_Social_FetchDynamicInfo_Api"
                                                                 parameters:@{@"request":paramJson}
                                                               urlPathParam:nil];
    self.dynamicInfoApi.apiDelegate = self;
    [self.dynamicInfoApi start];
    return YES;
}

- (void)followUserCompletion:(void (^)(MGMSocialUser * _Nullable, NSError * _Nullable))completion
{
    self.completion = completion;
    [self.socialUser follow];
}

#pragma mark - Private

- (BOOL)fetchDynamicDetailLikeAndCommentCountWithMid:(NSString *)mid
{
    if (!mid.length) return NO;
    
    NSString *contentType = (MGMTimeLineTypeStills == self.dynamicModel.timeLineType) ? @"70" : @"16";
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSMutableDictionary *paramList = [NSMutableDictionary dictionary];
    [paramList mgu_safe_setObject:mid forKey:@"mId"];
    [paramList mgu_safe_setObject:contentType forKey:@"contentType"];
    [paramList mgu_safe_setObject:@(16) forKey:@"type"];
    
    //终端类型 1:咪咕视频 2:咪咕影院
    [params mgu_safe_setObject:@(MGMSocialClientTypeMovie) forKey:@"clientType"];
    [params mgu_safe_setObject:@[paramList] forKey:@"paramList"];
    self.dynamicLikeCommentApi = [[MGUHttpApiFactory apiFactory] createApiWithName:MGMSocialFetchLikeAndCommentCountApiName
                                                                  parameters:params
                                                                urlPathParam:nil];
    self.dynamicLikeCommentApi.apiDelegate = self;
    dispatch_group_enter(self.dynamicInfoGroup);
    [self.dynamicLikeCommentApi start];
    return YES;
}

- (void)fetchDynamicUserInfo
{
    __weak typeof(self) weakSelf = self;
    dispatch_group_enter(self.dynamicInfoGroup);
    
    NSArray <NSString *>*certificationTypes = [MGMUserCertification sharedUserCertification].cerTypeParams;
    [self.socialUser updateUserInfoWithCerTypes:certificationTypes completion:^(NSError * _Nullable error) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        strongSelf.dynamicModel.author = strongSelf.socialUser.nickname;
        strongSelf.dynamicModel.summaryImages = strongSelf.socialUser.avatar;
        strongSelf.dynamicModel.relationType = strongSelf.socialUser.relationType;
        strongSelf.dynamicModel.identiftyIconUrl = strongSelf.socialUser.certificationIcon;
        
        NSString *colorInfo = strongSelf.socialUser.colour;
        strongSelf.dynamicModel.identifyNickNameColor = colorInfo ? [UIColor dealHexString:colorInfo] : [UIColor mgu_colorWithHex:0x1A1A1A];
        [strongSelf.dynamicModel setDynamicTagTextWithTag:strongSelf.socialUser.movieTag];;
        dispatch_group_leave(strongSelf.dynamicInfoGroup);
    }];
}

#pragma mark - Lazy

- (MGMSocialUser *)socialUser
{
    if (!_socialUser)
    {
        _socialUser = [[MGMSocialUser alloc] initWithUserId:self.dynamicModel.userId];
        _socialUser.delegate = self;
    }
    return _socialUser;
}

- (dispatch_group_t)dynamicInfoGroup
{
    if (!_dynamicInfoGroup)
    {
        _dynamicInfoGroup = dispatch_group_create();
    }
    return _dynamicInfoGroup;
}

#pragma mark - MGMSocial Delegate

- (void)followUser:(NSString *)userId withError:(nullable NSError *)error
{
    MGMSocialUser *followUser = nil;
    if (!error)
    {
        followUser = self.socialUser;
    }
    
    !self.completion ?: self.completion(followUser, error);
}

#pragma mark - MGUHttpApi Delegate

- (void)httpApiFinished:(__kindof MGUHttpApi *)httpApi
{
    MGMHttpResponse *response = [MGMHttpResponse yy_modelWithJSON:httpApi.responseJSONObject];
    
    if (httpApi.apiName.length != MGMSocialFetchLikeAndCommentCountApiName.length ||
        ![httpApi.apiName isEqualToString:MGMSocialFetchLikeAndCommentCountApiName])
    {
        NSString *code = response.body[@"resultCode"];
        if ([code isEqualToString:@"FAILED"])
        {
            if ([self.delegate respondsToSelector:@selector(dynamicDetailDataManager:fetchDynamicFeedInfo:error:)])
            {
                [self.delegate dynamicDetailDataManager:self fetchDynamicFeedInfo:nil error:nil];
            }
            return;
        }
        
        MGMDynamicDetailResponseModel *dynamicDetailModel = [MGMDynamicDetailResponseModel yy_modelWithDictionary:response.body[@"data"]];
        MGMDynamicModel *dynamicModel = nil;
        if ([dynamicDetailModel.dynamicContent.contentType isEqualToString:@"70"])
        {
            dynamicModel = [MGMTimeLineStagePhotoModel stagePhotoModelWithDynamicDetailResponseModel:dynamicDetailModel];
            self.mid = dynamicDetailModel.dynamicId;
        }
        else
        {
            dynamicModel = [MGMTimeLineImageTextModel imageTextModelWithDynamicDetailResponseModel:dynamicDetailModel];
            self.mid = dynamicDetailModel.dynamicContent.mid;
        }
        self.dynamicModel = dynamicModel;
        [self fetchDynamicUserInfo];
        [self fetchDynamicDetailLikeAndCommentCountWithMid:self.mid];
        return;
    }
    NSDictionary *likeCommentInfo = [response.body mgu_objectOrNilForKey:self.mid];
    MGMSocialLikeAndCommentCountModel *likeCommentModel = [MGMSocialLikeAndCommentCountModel yy_modelWithDictionary:likeCommentInfo];
    self.dynamicModel.commentCount = likeCommentModel.commentCount;
    self.dynamicModel.likeCount = likeCommentModel.likeCount;
    self.dynamicModel.hasLike = likeCommentModel.hasLike;
    dispatch_group_leave(self.dynamicInfoGroup);
    
    if ([self.delegate respondsToSelector:@selector(dynamicDetailDataManager:fetchDynamicFeedInfo:error:)])
    {
        [self.delegate dynamicDetailDataManager:self fetchDynamicFeedInfo:self.dynamicModel error:nil];
    }
}

- (void)httpApiFailed:(__kindof MGUHttpApi *)httpApi
{
    if ([httpApi.apiName isEqualToString:MGMSocialFetchLikeAndCommentCountApiName])
    {
        dispatch_group_leave(self.dynamicInfoGroup);
        return;
    }
    
    if ([self.delegate respondsToSelector:@selector(dynamicDetailDataManager:fetchDynamicFeedInfo:error:)])
    {
        [self.delegate dynamicDetailDataManager:self fetchDynamicFeedInfo:nil error:httpApi.error];
    }
}


@end
