//
//  MGMCommunityRelationInfos.h
//  AFNetworking
//
//
//
//  职责(MGMCommunityRelationInfosFetcher): 主要获取当前用户和指定用的关注关系、和指定用户建立和接触已有的关注关系
//  Created by WangDa Mac on 2019/6/21.
//

#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, MGMUserRelationship) {
    MGMUserRelationrhip_NORELATION,
    MGMUserRelationrhip_MYFOLLOW,
    MGMUserRelationrhip_MYFANS,
    MGMUserRelationrhip_FUNSEACHOTHER
};

@interface MGMCommunityRelationInfos : MGMBase

@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *relationType;
@property (nonatomic, assign) MGMUserRelationship relationship;
- (void)resetRelationshipWithString:(NSString *)stringType;
+ (NSArray *)createRalationInfoWithUserIds:(NSArray *)userIds relationship:(MGMUserRelationship)relationship;
@end

@interface MGMCommunityRelationsBody : MGMBase
@property (nonatomic, strong) NSArray *relationInfos;
@end



@protocol MGMCommunityRelationInfosFetcherDelegate <NSObject>

- (void)fetchUserRelationships:(nullable NSArray *)list error:(nullable NSError *)error;
- (void)addhFunsResult:(BOOL)result error:(nullable NSError *)error;
- (void)cancelhFunsResult:(BOOL)result error:(nullable NSError *)error;

@end

@interface MGMCommunityRelationInfosFetcher : NSObject

@property (nonatomic, weak, nullable) id <MGMCommunityRelationInfosFetcherDelegate> delegate;
- (void)fetchUserRealtionTypeWithUserIds:(NSArray *)userIds;
- (void)addFansWithUserId:(NSString *)userId;
- (void)cancelFansWithUserId:(NSString *)userId;

@end

NS_ASSUME_NONNULL_END
