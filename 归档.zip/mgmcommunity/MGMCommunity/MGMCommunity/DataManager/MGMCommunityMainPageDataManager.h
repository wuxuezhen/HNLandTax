//
//  MGMCommunityMainPageDataManager.h
//  MGMCommunity
//
// 职责：获取UGC主页展示数据
//  Created by apple on 2018/12/4.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MGUHttpApi;

@class MGMCommunityMainPageDataManager;

@protocol MGMCommunityMainPageDataManagerDelegate <NSObject>

- (void)communityMainPageDataManager:(MGMCommunityMainPageDataManager *)manager error:(NSError *) error;

@end

/**
 发现首页数据
 */
@interface MGMCommunityMainPageDataManager : NSObject

@property (nonatomic, strong, readonly) MGUHttpApi *httpApi;
@property (nonatomic, weak, readwrite) id <MGMCommunityMainPageDataManagerDelegate> mainPageDelegate;
- (void)startWithPageIndex:(NSInteger)index pageCount:(NSInteger)pageSize;
- (void)stopAllTask;
@end
