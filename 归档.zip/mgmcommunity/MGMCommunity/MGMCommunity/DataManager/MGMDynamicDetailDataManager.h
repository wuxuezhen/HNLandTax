//
//  MGMDynamicDetailDataManager.h
//  AFNetworking
//
//  Created by WangDa Mac on 2019/8/16.
//

#import <Foundation/Foundation.h>
#import <MGMSocialModule/MGMSocialDynamicDefines.h>

@class MGMDynamicModel, MGMDynamicDetailDataManager, MGMSocialUser;

@protocol MGMDynamicDetailDataManagerDelegate <NSObject>

- (void)dynamicDetailDataManager:(MGMDynamicDetailDataManager *)dataManager
            fetchDynamicFeedInfo:(nullable MGMDynamicModel *)dynamicModel
                           error:(nullable NSError *)error;

@end

NS_ASSUME_NONNULL_BEGIN

@interface MGMDynamicDetailDataManager : NSObject

- (instancetype)initWithDelegate:(id<MGMDynamicDetailDataManagerDelegate>)delegate;

- (BOOL)fetchDynamicDetailInfoWithFeedId:(nonnull NSString *)feedId;
- (void)followUserCompletion:(void(^)(MGMSocialUser *_Nullable followUser, NSError * _Nullable error))completion;

@end

NS_ASSUME_NONNULL_END
