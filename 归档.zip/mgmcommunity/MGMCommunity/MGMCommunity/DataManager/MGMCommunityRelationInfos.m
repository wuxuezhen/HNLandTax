//
//  MGMCommunityRelationInfos.m
//  AFNetworking
//
//  Created by WangDa Mac on 2019/6/21.
//

#import "MGMCommunityRelationInfos.h"
#import <MGUHttpApiCore/MGUHttpApi.h>
#import <MGUHttpApiCore/MGUHttpApiFactory.h>
#import <MGMHttpApiModel/MGMHttpResponse.h>
#import <MGMHttpApiModel/MGMMacroserviceResponse.h>
#import <YYModel/YYModel.h>
#import <MGMDataStore/MGMDSUser.h>

@implementation MGMCommunityRelationInfos

+ (NSArray *)createRalationInfoWithUserIds:(NSArray *)userIds relationship:(MGMUserRelationship)relationship {
    NSMutableArray *array = [@[] mutableCopy];
    for (NSString *userId in userIds) {
        MGMCommunityRelationInfos *info = [[MGMCommunityRelationInfos alloc] init];
        info.userId = [NSString stringWithFormat:@"%@",userId?:@""];
        info.relationship = relationship;
        [array addObject:info];
    }
    return array;
}

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    [self resetRelationshipWithString:_relationType];
    
    return YES;
}

- (void)resetRelationshipWithString:(NSString *)stringType {
    if ([stringType isEqualToString:@"NORELATION"]) {
        _relationship = MGMUserRelationrhip_NORELATION;
    }else if ([stringType isEqualToString:@"MYFOLLOW"]) {
        _relationship = MGMUserRelationrhip_MYFOLLOW;
    }else if ([stringType isEqualToString:@"MYFANS"]) {
        _relationship = MGMUserRelationrhip_MYFANS;
    }else if ([stringType isEqualToString:@"FUNSEACHOTHER"]) {
        _relationship = MGMUserRelationrhip_FUNSEACHOTHER;
    } else {
        _relationship = MGMUserRelationrhip_NORELATION;
    }
}


@end
@implementation MGMCommunityRelationsBody

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"relationInfos" : [MGMCommunityRelationInfos class]
             };
}

@end

@interface MGMCommunityRelationInfosFetcher () <MGUHttpApiDelegate>


@end

@implementation MGMCommunityRelationInfosFetcher

- (void)fetchUserRealtionTypeWithUserIds:(NSArray *)userIds {
    
    if (![MGMDSUser user].isLogin) {
        if ([self.delegate respondsToSelector:@selector(fetchUserRelationships:error:)]) {
            [self.delegate fetchUserRelationships:[MGMCommunityRelationInfos createRalationInfoWithUserIds:userIds relationship:MGMUserRelationrhip_NORELATION] error:nil];
        }
        return;
    }
    
    MGUHttpApiFactory *factory = [MGUHttpApiFactory apiFactory];
    MGUHttpApi *httpApi = [factory createApiWithName:@"MGM_UserProfile_checkRelations_Api" parameters:nil urlPathParam:nil];
    // NSString *userIdString = [userIds componentsJoinedByString:@","];
    [httpApi addRequestParameters:@{@"checkedUserIds":userIds?:@""}];
    httpApi.apiDelegate = self;
    [httpApi start];
}

- (void)addFansWithUserId:(NSString *)userId {
    if (!userId) {
        return;
    }
    MGUHttpApiFactory *factory = [MGUHttpApiFactory apiFactory];
    MGUHttpApi *httpApi = [factory createApiWithName:@"MGM_UserProfile_AddFans_Api" parameters:nil urlPathParam:nil];
    [httpApi addRequestParameters:@{@"followerId":userId?:@""}];
    httpApi.apiDelegate = self;
    [httpApi start];
}

- (void)cancelFansWithUserId:(NSString *)userId {
    if (!userId) {
        return;
    }
    MGUHttpApiFactory *factory = [MGUHttpApiFactory apiFactory];
    MGUHttpApi *httpApi = [factory createApiWithName:@"MGM_UserProfile_CancelFans_Api" parameters:nil urlPathParam:nil];
    [httpApi addRequestParameters:@{@"followerId":userId?:@""}];
    httpApi.apiDelegate = self;
    [httpApi start];
}

- (void)httpApiFinished:(__kindof MGUHttpApi *)httpApi {
    NSString *httpApiName = httpApi.apiName;
    MGMHttpResponse *response = [MGMHttpResponse yy_modelWithJSON:httpApi.responseObject];
    if ([httpApiName isEqualToString:@"MGM_UserProfile_checkRelations_Api"]) {
        [self fetchUserRelationshipResponse:response];
    }
    if ([httpApiName isEqualToString:@"MGM_UserProfile_AddFans_Api"]) {
        [self addFansResponse:response];
    }
    if ([httpApiName isEqualToString:@"MGM_UserProfile_CancelFans_Api"]) {
        
    }
}

- (void)httpApiFailed:(__kindof MGUHttpApi *)httpApi {
    NSString *httpApiName = httpApi.apiName;
    if ([httpApiName isEqualToString:@"MGM_UserProfile_checkRelations_Api"]) {
        
    }
    if ([httpApiName isEqualToString:@"MGM_UserProfile_AddFans_Api"]) {
        
    }
    if ([httpApiName isEqualToString:@"MGM_UserProfile_CancelFans_Api"]) {
        
    }
}


- (void)fetchUserRelationshipResponse:(MGMHttpResponse *)response {
    if ([response.code isEqualToString:@"200"]) {
        MGMMacroserviceResponse *microResponse = [MGMMacroserviceResponse yy_modelWithJSON:response.body];
        if (microResponse.isSuccess) {
            MGMCommunityRelationsBody *relations = [MGMCommunityRelationsBody yy_modelWithJSON:microResponse.data];
            if ([self.delegate respondsToSelector:@selector(fetchUserRelationships:error:)]) {
                [self.delegate fetchUserRelationships:relations.relationInfos error:nil];
            }
            
        } else {
            if ([self.delegate respondsToSelector:@selector(fetchUserRelationships:error:)]) {
                NSError *error = [MGMMacroserviceResponse macroserviceErrorWithCode:microResponse.resultCode.integerValue customerDesc:microResponse.resultDesc];
                [self.delegate fetchUserRelationships:nil error:error];
            }
        }
    } else {
        if ([self.delegate respondsToSelector:@selector(fetchUserRelationships:error:)]) {
            NSError *error = [MGMMacroserviceResponse macroserviceErrorWithCode:0 customerDesc:response.message];
            [self.delegate fetchUserRelationships:nil error:error];
        }
    }
}

- (void)addFansResponse:(MGMHttpResponse *)response {
    if ([response.code isEqualToString:@"200"]) {
        MGMMacroserviceResponse *microResponse = [MGMMacroserviceResponse yy_modelWithJSON:response.body];
        if (microResponse.isSuccess) {
            if ([self.delegate respondsToSelector:@selector(addhFunsResult:error:)]) {
                [self.delegate addhFunsResult:YES error:nil];
            }
            
        } else {
            if ([self.delegate respondsToSelector:@selector(addhFunsResult:error:)]) {
                NSError *error = [MGMMacroserviceResponse macroserviceErrorWithCode:microResponse.resultCode.integerValue customerDesc:microResponse.resultDesc];
                [self.delegate addhFunsResult:NO error:error];
            }
        }
    } else {
        if ([self.delegate respondsToSelector:@selector(addhFunsResult:error:)]) {
            NSError *error = [MGMMacroserviceResponse macroserviceErrorWithCode:0 customerDesc:response.message];
            [self.delegate addhFunsResult:NO error:error];
        }
    }
}

@end
