//
//  MGMCommunityDetailControllerBottomView.h
//  MGMCommunity
//
//  Created by apple on 2018/12/20.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MGMCommunityDetailPageBottomView;

NS_ASSUME_NONNULL_BEGIN

@protocol MGMCommunityDetailPageBottomViewDelegate <NSObject>

@optional
- (void)communityDetailPageBottomView:(MGMCommunityDetailPageBottomView *)bottomView shuldUpdateConstaitWithIsOpen:(BOOL) isOpen;

- (void)communityDetailPageBottomView:(MGMCommunityDetailPageBottomView *)bottomView publishNewComment:(NSString *)comment;

@end


@interface MGMCommunityDetailPageBottomView : UIView

@property (nonatomic, weak, readwrite) id<MGMCommunityDetailPageBottomViewDelegate> deleaget;

- (void)setPlaceholderCommentCount:(NSInteger)count;

@end

NS_ASSUME_NONNULL_END
