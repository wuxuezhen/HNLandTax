//
//  MGMCommunitySelectePictureCollectionViewCell.h
//  AFNetworking
//
//  Created by Banana on 2019/8/2.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMCommunitySelectePictureCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) NSDictionary *imageDic;
@property (nonatomic, strong) void(^deleteBlock)(NSDictionary *imageDic);
@end

NS_ASSUME_NONNULL_END
