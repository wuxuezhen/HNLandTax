//
//  MGMCommunityDetailCommentCell.h
//  MGMCommunity
//
//  Created by apple on 2018/12/19.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MGMFilmReviewHotData;
typedef void(^MGMCommunityDetailCommentCellClickCallback)(void);
NS_ASSUME_NONNULL_BEGIN

@interface MGMCommunityDetailCommentCell : UITableViewCell

@property (nonatomic, strong, readwrite) MGMFilmReviewHotData *model;

@property (nonatomic, strong, readwrite) NSIndexPath *indexPath;
@property (nonatomic, strong, readwrite) MGMCommunityDetailCommentCellClickCallback clickCallback;
+ (CGFloat)cellHeightWithData:(MGMFilmReviewHotData *)data;
@end

NS_ASSUME_NONNULL_END
