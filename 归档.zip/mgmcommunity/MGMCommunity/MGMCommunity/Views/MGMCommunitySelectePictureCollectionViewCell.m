//
//  MGMCommunitySelectePictureCollectionViewCell.m
//  AFNetworking
//
//  Created by Banana on 2019/8/2.
//

#import "MGMCommunitySelectePictureCollectionViewCell.h"
#import <Masonry/Masonry.h>
#import "MGMCommunityResource.h"

@interface MGMCommunitySelectePictureCollectionViewCell()
@property (nonatomic, strong) UIButton *deleteBtn;
@property (nonatomic, strong) UIImageView *pictureImgView;
@end

@implementation MGMCommunitySelectePictureCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.contentView.layer.cornerRadius = 2.f;
        self.contentView.layer.masksToBounds = YES;
        _pictureImgView = [UIImageView new];
        _pictureImgView.userInteractionEnabled = YES;
        _pictureImgView.contentMode = UIViewContentModeScaleAspectFill;
        [self.contentView addSubview:_pictureImgView];
        [_pictureImgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.contentView);
        }];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setBackgroundImage:[MGMCommunityResource imageNamed:@"icon_sc"] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(deleteButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        _deleteBtn = btn;
        [self.contentView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.right.offset(0);
            make.size.mas_equalTo(CGSizeMake(22.f, 22.f));
        }];
    }
    return self;
}

- (void)deleteButtonAction:(UIButton *)sender {
    if (self.deleteBlock) {
        self.deleteBlock(self.imageDic);
    }
}

#pragma setter

- (void)setImageDic:(NSDictionary *)imageDic{
    _imageDic = imageDic;
    self.pictureImgView.image = [imageDic valueForKey:@"png"];
    
}
@end
