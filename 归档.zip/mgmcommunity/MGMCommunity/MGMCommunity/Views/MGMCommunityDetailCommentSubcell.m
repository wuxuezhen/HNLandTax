//
//  MGMCommunityDetailCommentSubcell.m
//  MGMCommunity
//
//  Created by apple on 2018/12/19.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityDetailCommentSubcell.h"
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <YYText/YYText.h>

@implementation MGMCommunityDetailCommentSubcell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //  self.backgroundColor = [UIColor colorWithRed:245/255.0 green:245/255.0 blue:245/255.0 alpha:1.0];
        //  设置上面背景色XR显示有问题
        self.backgroundColor = [UIColor clearColor];
        [self layoutIfNeeded];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.textLabel.x = 10.f;
}

- (void)setTextWithUserName:(NSString *)userName commit:(NSString *)commit respondentUserName:(nonnull NSString *)respondentUserName{

    NSString *_respondentUserName = nil;
    if (respondentUserName) {
        //_respondentUserName = [NSString stringWithFormat:@"%@ 回复 %@：", userName,respondentUserName];
        _respondentUserName = [NSString stringWithFormat:@"%@：", userName];

    } else {
        _respondentUserName = [NSString stringWithFormat:@"%@：", (userName? userName : @"")];
    }
    NSString *body = commit? commit : @"";
    body = [_respondentUserName stringByAppendingString:body];
    
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:body attributes: @{NSFontAttributeName: [UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size: 12],NSForegroundColorAttributeName: [UIColor mgu_colorWithHex:0x333333]}];
    [string yy_setColor:[UIColor mgu_colorWithHex:0x999999] range:NSMakeRange(0, _respondentUserName.length)];
    self.textLabel.attributedText = string;
    
}

- (void)setShowMoreText {
    NSMutableAttributedString *attrCommit = [[NSMutableAttributedString alloc] initWithString:@"查看全部 >"  attributes: @{NSFontAttributeName: [UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size: 12],NSForegroundColorAttributeName: [UIColor colorWithRed:26/255.0 green:26/255.0 blue:26/255.0 alpha:1.0]}];
    self.textLabel.attributedText = attrCommit;
}

@end
