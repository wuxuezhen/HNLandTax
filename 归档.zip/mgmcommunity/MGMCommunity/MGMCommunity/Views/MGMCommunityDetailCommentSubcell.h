//
//  MGMCommunityDetailCommentSubcell.h
//  MGMCommunity
//
//  Created by apple on 2018/12/19.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMCommunityDetailCommentSubcell : UITableViewCell

- (void)setTextWithUserName:(NSString *)userName commit:(NSString *)commit respondentUserName:(NSString *)respondentUserName;
- (void)setShowMoreText;
@end

NS_ASSUME_NONNULL_END
