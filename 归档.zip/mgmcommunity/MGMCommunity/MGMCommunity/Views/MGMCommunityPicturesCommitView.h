//
//  MGMCommunityPicturesCommitView.h
//  AFNetworking
//
//  Created by Banana on 2019/8/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
extern NSString *const MGMCommunityPicturesCommitViewSelectImagEventName;/**<选择图片*/
extern NSString *const MGMCommunityPicturesCommitViewPublishEventName;/**<发布动态*/
extern NSString *const MGMCommunityPictureKey;
extern NSString *const MGMCommunityPicturesDeletePublishEventName;

typedef void (^tapActionBlock)(void);

typedef void (^tapTopicCollectionCellActionBlock)(NSInteger indexCell, BOOL isSelect);

@class MGMDynamicTopicItemInfo;

@interface MGMCommunityPicturesCommitView : UIView
//@property (nonatomic, assign, getter = isContentTextEnable) BOOL contentTextEnable;
@property (nonatomic, assign, readonly) NSInteger maxPicturesCount;
@property (nonatomic, copy) tapActionBlock bottomViewTapedAction;
@property (nonatomic, copy) tapTopicCollectionCellActionBlock collectionViewCellAction;

//底部标签的collectonView 数据源
//@property (nonatomic, strong) NSMutableArray<NSDictionary *> *topicTitleArray;

//底部标签的collectonView 数据源
@property (nonatomic, strong) NSMutableArray<MGMDynamicTopicItemInfo *> *topicTitleItemInfoArray;

//刷新底部标签的collectonView
- (void)reloadTopicCollect;
/**
 初始化

 @param pictures images
 @param bottomViewTapedAction 点击空白处
 @return instance
 */
- (instancetype)initWithFrame:(CGRect)frame pictures:(NSArray <NSDictionary *> *_Nullable)pictures bottomViewTapedAction:(_Nullable tapActionBlock)bottomViewTapedAction;

/**
 添加图片

 @param pictures images
 */
- (void)addPictures:(NSArray<NSDictionary *> *)pictures;

/**
 获取图片

 @return pictures images
 */
- (NSArray<NSDictionary *> *)getPictures;

@end

NS_ASSUME_NONNULL_END
