//
//  MGMCommunityDetailControllerBottomView.m
//  MGMCommunity
//
//  Created by apple on 2018/12/20.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityDetailPageBottomView.h"
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/MGMCategories.h>
#import <Masonry/Masonry.h>
#import <MGMDataStore/MGMDSUser.h>
#import <YYWebImage/YYWebImage.h>
#import "MGMCommunityGotoLogin.h"
#import "MGMCommunityResource.h"

@interface MGMCommunityDetailPageBottomView ()

@property (nonatomic, strong, readwrite) UIImageView *userIcon;
@property (nonatomic, strong, readwrite) UIView *buttonContainerView;
@property (nonatomic, strong, readwrite) UIButton *commitButton;
@property (nonatomic, strong, readwrite) UIView *topLine;

@end

@implementation MGMCommunityDetailPageBottomView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.topLine];
        [self addSubview:self.userIcon];
        [self addSubview:self.buttonContainerView];
        [self.buttonContainerView addSubview:self.commitButton];
        [self setPlaceholderCommentCount:0];
    }
    return self;
}

- (void)updateConstraints {
    
    [self.userIcon mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(kMGMHBL(-22));
        make.left.mas_equalTo(kMGMHBL(30));
        make.width.height.mas_equalTo(kMGMHBL(60));
    }];
    
    [self.buttonContainerView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.height.equalTo(self.userIcon);
        make.right.mas_equalTo(kMGMHBL(-30));
        make.left.equalTo(self.userIcon.mas_right).offset(kMGMHBL(30));
    }];
    
    [self.topLine mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self);
        make.top.equalTo(self.userIcon.mas_top).offset(kMGMHBL(-22));
        make.height.mas_equalTo(kMGMHBL(1));
    }];
    
    [self.commitButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(kMGMHBL(18));
        make.bottom.mas_equalTo(kMGMHBL(-18));
        make.left.mas_equalTo(kMGMHBL(30));
//        make.width.mas_greaterThanOrEqualTo(kMGMHBL(50));
        make.right.mas_equalTo(kMGMHBL(-30));
    }];
    
    [super updateConstraints];
}

- (UIImageView *)userIcon {
    if (!_userIcon) {
        _userIcon = [[UIImageView alloc] init];
        // _userIcon.frame = CGRectMake(15,626.5,30,30);
        _userIcon.backgroundColor = [UIColor mgu_colorWithHex:0xF5F5F5];
        [_userIcon setupCornerWithRadius:kMGMHBL(30)];
        [_userIcon yy_setImageWithURL:[NSURL URLWithString:[MGMDSUser user].avatar] placeholder:[UIImage miguDefaultPortraitImage]];
    }
    return _userIcon;
}

- (UIView *)buttonContainerView {
    if (!_buttonContainerView) {
        _buttonContainerView = [[UIView alloc] init];
        _buttonContainerView.layer.backgroundColor = [UIColor mgu_colorWithHex:0xF5F5F5].CGColor;
        [_buttonContainerView setupCornerWithRadius:kMGMHBL(30)];
    }
    return _buttonContainerView;
}

- (UIView *)topLine {
    if (!_topLine) {
        _topLine = [[UIView alloc] init];
        _topLine.layer.backgroundColor = [UIColor colorWithRed:226/255.0 green:226/255.0 blue:226/255.0 alpha:1.0].CGColor;
    }
    return _topLine;
}

- (UIButton *)commitButton {
    if (!_commitButton) {
        _commitButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _commitButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [_commitButton addTarget:self action:@selector(publishNewCommit:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _commitButton;
}

- (void)publishNewCommit:(id)sender {
    if ([_deleaget respondsToSelector:@selector(communityDetailPageBottomView:shuldUpdateConstaitWithIsOpen:)]) {
        [_deleaget communityDetailPageBottomView:self shuldUpdateConstaitWithIsOpen:nil];
    }
}

- (void)setPlaceholderCommentCount:(NSInteger)count {
    NSString *countString = [NSString stringWithFormat:@"已有%ld条评论，我也来插一嘴", count];
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:countString attributes: @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Regular" size: 12],NSForegroundColorAttributeName: [UIColor mgu_colorWithHex:0x999999]}];
    [self.commitButton setAttributedTitle:string forState:UIControlStateNormal];
}


@end
