//
//  MGMCommunityDetailCommentCell.m
//  MGMCommunity
//
//  Created by apple on 2018/12/19.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityDetailCommentCell.h"
#import "MGMCommunityResource.h"
#import "MGMCommunityDetailCommentSubcell.h"
#import "MGMCommunity.h"

#import <Masonry/Masonry.h>
#import <YYText/YYText.h>
#import <YYWebImage/YYWebImage.h>
#import <MGMRoute/MGMRoute.h>
#import <MGMCategories/MGMCategories.h>
#import <MGMCategories/NSString+MGMStringData.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/UIImage+MGMPlaceHolderImage.h>
#import <MGMHttpApiModel/MGMFilmReviewHotListDataModel.h>
#import "MGMFilmReviewHotData+MGMCommitHeight.h"
#import "MGMCommunityGotoLogin.h"
#import <MGMCategories/NSString+MGMValidation.h>

static NSString *MGMCommunityDetailCommentSubcellId = @"MGMCommunityDetailCommentSubcellId";

@interface MGMCommunityDetailCommentCell ()<UITableViewDelegate, UITableViewDataSource>

@property(nonatomic,strong) UIImageView *userHeaderIcon;
@property(nonatomic,strong) UILabel *userNameLabel;
@property(nonatomic,strong) UILabel *commitLabel;

@property(nonatomic,strong) UILabel *updateTimeLabel;

// 点赞相关
@property(nonatomic,strong) UIButton *popularBtn;
@property(nonatomic,strong) UILabel *popularCount;

/** 热评内容回复背景视图 */
@property(nonatomic,strong) UIView *bottomLine;

@property (nonatomic, strong, readwrite) UITableView *subCommitList;

@property (nonatomic, strong)YYAnimatedImageView *userAttestationImgV;

@end

@implementation MGMCommunityDetailCommentCell

- (void)setModel:(MGMFilmReviewHotData *)model {
    _model = model;
    NSURL *url = [NSURL URLWithString:model.userPortrait];
    UIImage *placeholder = [UIImage miguDefaultPortraitImage];
    [_userHeaderIcon yy_setImageWithURL:url placeholder:placeholder];
    _userNameLabel.text = model.userName;
    if (model.iconUrl) {
        [self.userAttestationImgV yy_setImageWithURL:[NSURL URLWithString:model.iconUrl] placeholder:nil];
    }
    self.userAttestationImgV.hidden = !model.iconUrl;
    _popularCount.text = model.likeModel.likeCount;
   
    [self setCommitLabelText:model.body];

    //NSString *updateTime = [NSString mgm_categoriesDataTotimeString:[NSString mgm_categoriesTimeStampToDataStringBiaoZhun:_model.createTime]];;
    //_updateTimeLabel.text = updateTime;
    
    
    NSString *publishTime = [NSString stringWithFormat:@"%@",_model.createTime];
    _updateTimeLabel.text = [publishTime mgm_timeStampStrToUGCTimeString];
    
    _popularBtn.selected = model.likeModel.mgm_has;
    UInt32 color = model.likeModel.mgm_has? 0xFF3E40 : 0xB2B2B2;
    _popularCount.textColor = [UIColor mgu_colorWithHex:color];
    [_subCommitList reloadData];
    [self layoutIfNeeded];
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self addSubview:self.userHeaderIcon];
        [self addSubview:self.userNameLabel];
        [self addSubview:self.userAttestationImgV];
        [self addSubview:self.commitLabel];
        [self addSubview:self.updateTimeLabel];
        [self addSubview:self.popularBtn];
        [self addSubview:self.popularCount];
        [self addSubview:self.subCommitList];
        [self addSubview:self.bottomLine];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.userHeaderIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(kMGMHBL2X(20));
        make.left.mas_equalTo(kMGMHBL2X(15));
        make.width.height.mas_equalTo(kMGMHBL2X(35));
    }];
    
    [self.userNameLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.userHeaderIcon.mas_right).offset(kMGMHBL2X(10));
        make.top.mas_equalTo(kMGMHBL2X(30));
        make.height.mas_equalTo(kMGMHBL2X(17));
        make.width.mas_greaterThanOrEqualTo(kMGMHBL2X(15));
    }];
    [self.userAttestationImgV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.userNameLabel.mas_right).mas_equalTo(kMGMHBL2X(5));
        make.centerY.equalTo(self.userHeaderIcon);
        make.size.mas_equalTo(CGSizeMake(kMGMHBL2X(14), kMGMHBL2X(14)));
    }];
    [self.commitLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.userHeaderIcon.mas_bottom).offset(kMGMHBL2X(15));
        make.left.mas_equalTo(kMGMHBL2X(15));
        make.right.mas_equalTo(kMGMHBL2X(-15));
        make.height.mas_greaterThanOrEqualTo(kMGMHBL2X(0));
    }];
    
    if (self.model.childCommentInfo.count > 0) {
        self.subCommitList.hidden = NO;
        [self.subCommitList mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.updateTimeLabel);
            make.right.equalTo(self.popularCount);
            make.top.equalTo(self.commitLabel.mas_bottom).offset(kMGMHBL2X(15));
            make.height.mas_equalTo(self.subCommitList.contentSize.height);
        }];
        [self.updateTimeLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kMGMHBL2X(15));
            make.top.equalTo(self.subCommitList.mas_bottom).offset(kMGMHBL2X(20));
            make.height.mas_equalTo(kMGMHBL2X(14));
            make.width.mas_greaterThanOrEqualTo(kMGMHBL2X(51));
        }];
    } else {
        self.subCommitList.hidden = YES;
        [self.updateTimeLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kMGMHBL2X(15));
            make.top.equalTo(self.commitLabel.mas_bottom).offset(kMGMHBL2X(15));
            make.height.mas_equalTo(kMGMHBL2X(14));
            make.width.mas_greaterThanOrEqualTo(kMGMHBL2X(51));
        }];
    }
    
    [self.popularCount mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.height.equalTo(self.updateTimeLabel);
        make.right.mas_equalTo(kMGMHBL2X(-15));
        make.width.mas_greaterThanOrEqualTo(kMGMHBL2X(10));
    }];
    
    [self.popularBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.popularCount.mas_left);//.offset(kMGMHBL2X(-6));
        make.width.height.mas_equalTo(kMGMHBL2X(14+12));
        make.centerY.equalTo(self.popularCount);
    }];
    
    [self.bottomLine mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self);
        make.right.equalTo(self).offset(kMGMHBL2X(-15));
        make.left.mas_equalTo(kMGMHBL2X(15));
        make.height.mas_equalTo(kMGMHBL2X(0.5));
    }];
}

#pragma mark - lazyLoad 懒加载
/** 用户头像 */
- (UIImageView *)userHeaderIcon{
    if (!_userHeaderIcon) {
        _userHeaderIcon = [[UIImageView alloc]init];
        _userHeaderIcon.contentMode = UIViewContentModeScaleToFill;
        _userHeaderIcon.clipsToBounds = YES;
        _userHeaderIcon.backgroundColor = [UIColor mgu_colorWithHex:0xD8D8D8];
        [_userHeaderIcon setupCornerWithRadius:kMGMHBL(35)];//半径大小
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(shouldGotoUserInfo)];
        _userHeaderIcon.userInteractionEnabled = YES;
        [_userHeaderIcon addGestureRecognizer:tap];;
    }
    return _userHeaderIcon;
}
/** 用户名称 */
- (UILabel *)userNameLabel{
    if (!_userNameLabel) {
        _userNameLabel = [[UILabel alloc]init];
        _userNameLabel.textAlignment = NSTextAlignmentLeft;
        _userNameLabel.textColor = [UIColor mgu_colorWithHex:0x1A1A1A];
        _userNameLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:15];
    }
    return _userNameLabel;
}
- (YYAnimatedImageView *)userAttestationImgV{
    if (!_userAttestationImgV) {
        _userAttestationImgV = [[YYAnimatedImageView alloc]init];
        _userAttestationImgV.contentMode = UIViewContentModeScaleToFill;
    }
    return _userAttestationImgV;
}

/** 热评内容 */
- (UILabel *)commitLabel{
    if (!_commitLabel) {
        UILabel *label = [[UILabel alloc] init];
        label.numberOfLines = 2;
        label.textAlignment = NSTextAlignmentJustified;
        _commitLabel = label;
        _commitLabel.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickComment:)];
        [_commitLabel addGestureRecognizer:tap];
    }
    return _commitLabel;
}

- (void)setCommitLabelText:(NSString *)text {
    NSString *_text = text? text : @"";
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:_text attributes: @{NSFontAttributeName: [UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size: 14],NSForegroundColorAttributeName: [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0]}];
    
    _commitLabel.attributedText = string;
}

/** 热评时间 */
- (UILabel *)updateTimeLabel{
    if (!_updateTimeLabel) {
        _updateTimeLabel = [[UILabel alloc]init];
        _updateTimeLabel.textAlignment = NSTextAlignmentLeft;
        _updateTimeLabel.textColor = [UIColor mgu_colorWithHex:0xB2B2B2];
        _updateTimeLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
    }
    return _updateTimeLabel;
}

- (UILabel *)popularCount{
    if (!_popularCount) {
        _popularCount = [[UILabel alloc]init];
        //_titleLable.contentMode = UIViewContentModeLeft;
        _popularCount.textAlignment = NSTextAlignmentLeft;
        _popularCount.textColor = [UIColor mgu_colorWithHex:0xB2B2B2];
        _popularCount.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
    }
    return _popularCount;
}

/** 热评点赞按钮 */
- (UIButton *)popularBtn{
    if (!_popularBtn) {
        _popularBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _popularBtn.contentMode = UIViewContentModeLeft;
         [_popularBtn setImage:[MGMCommunityResource originalRenderingImageNamed:@"community_like_normal"] forState:UIControlStateNormal];
        [_popularBtn setImage:[MGMCommunityResource originalRenderingImageNamed:@"community_like_selected"] forState:UIControlStateSelected];
        [_popularBtn addTarget:self action:@selector(likeComment:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _popularBtn;
}

- (void)likeComment:(id)sender {
    NSMutableDictionary *userInfo = @{}.mutableCopy;
    [userInfo setValue:self.indexPath forKey:@"indexPath"];
    [self routerEventWithName:MGMCommunityDetailLikeSubCommentRouterName userInfo:userInfo];
}

- (UITableView *)subCommitList {
    if (!_subCommitList) {
        _subCommitList = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _subCommitList.delegate = self;
        _subCommitList.dataSource = self;
        _subCommitList.estimatedRowHeight = 0;
        _subCommitList.estimatedSectionFooterHeight = 0;
        _subCommitList.estimatedSectionHeaderHeight = 0;
        _subCommitList.rowHeight = kMGMHBL(54);
        [_subCommitList registerClass:[MGMCommunityDetailCommentSubcell class] forCellReuseIdentifier:MGMCommunityDetailCommentSubcellId];
        _subCommitList.backgroundColor = [UIColor mgu_colorWithHex:0xF5F5F5];
        _subCommitList.separatorColor = [UIColor clearColor];
        _subCommitList.scrollEnabled = NO;
    }
    return _subCommitList;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger childCommentCount = self.model.childCommentInfo.count;
    NSInteger commentTotalCount = [self.model.commentedCount integerValue];
//    NSInteger cellCount = [self.model.commentedCount integerValue] != 0? [self.model.commentedCount integerValue] : self.model.childCommentInfo.count;
    NSInteger count = (childCommentCount > 1 && commentTotalCount > 2) ? 3 : childCommentCount;
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MGMCommunityDetailCommentSubcell *cell = [tableView dequeueReusableCellWithIdentifier:MGMCommunityDetailCommentSubcellId forIndexPath:indexPath];
    if (indexPath.row < 2) {
        MGMFilmReviewHotChildCommentInfo *subModel = self.model.childCommentInfo[indexPath.row];
        [cell setTextWithUserName:subModel.userName commit:subModel.childNodeUserCommentBody respondentUserName:subModel.respondentUserName];
    } else if (indexPath.row == 2) {
        [cell setShowMoreText];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [UIView new];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [UIView new];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return kMGMHBL2X(12.5-5);
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return kMGMHBL2X(12.5-5);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
 
    _clickCallback? _clickCallback() : nil;
}

- (void)clickComment:(UITapGestureRecognizer *)tap {
    _clickCallback? _clickCallback() : nil;
}

/** 热评内容回复背景视图 */
- (UIView *)bottomLine{
    if (!_bottomLine) {
        _bottomLine = [[UIView alloc]init];
        //_titleLable.contentMode = UIViewContentModeLeft;
        _bottomLine.backgroundColor = [UIColor mgu_colorWithHex:0xE2E2E2];
    }
    return _bottomLine;
}

- (void)shouldGotoUserInfo {
    [MGMCommunityGotoLogin gotoUserMainPageVC:self.model.userId];
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *view = [super hitTest:point withEvent:event];
    return view;
}

+ (CGFloat)cellHeightWithData:(MGMFilmReviewHotData *)data {
    CGFloat cellHeight = kMGMHBL2X(70.f) + data.commitTextHeight;
    if (data.childCommentInfo.count == 0) {
        cellHeight += kMGMHBL2X(50);
    } else {
        cellHeight += kMGMHBL2X(54+15);
        cellHeight += data.commitListHeigth;
        cellHeight -= 14.f; // 10+4
    }
    
    return cellHeight;
}

@end
