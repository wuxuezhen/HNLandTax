//
//  MGMParentCommentHeaderView.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/3/13.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MGMparentCommentReview, MGMParentCommentHeaderView;
NS_ASSUME_NONNULL_BEGIN

@protocol MGMParentCommentHeaderViewDelegate <NSObject>

- (void)parentCommentHeaderView:(MGMParentCommentHeaderView *)headerView didCilckLikeButton:(UIButton *)sender;

@end

@interface MGMParentCommentHeaderView : UITableViewHeaderFooterView

@property (nonatomic, strong, readwrite) MGMparentCommentReview *model;

@property (nonatomic, weak, nullable) id <MGMParentCommentHeaderViewDelegate> delegate;
@end

NS_ASSUME_NONNULL_END
