//
//  MGMDynamicTopicCollectionViewCell.m
//  Aspects
//
//  Created by 袁飞扬 on 2020/1/9.
//

#import "MGMDynamicTopicCollectionViewCell.h"
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/MGMCategories.h>

@interface MGMDynamicTopicCollectionViewCell ()

@property (nonatomic, strong)UILabel *titleLabel;

@end


@implementation MGMDynamicTopicCollectionViewCell


- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.textColor = [UIColor mgu_colorWithHex:0x63ADEF opacity:1.0];
        _titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:13];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _titleLabel;
}


- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        self.contentView.layer.cornerRadius = kMGMHBL2X(14);
        self.contentView.layer.masksToBounds = YES;
        
        [self.contentView addSubview:self.titleLabel];
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kMGMHBL2X(14));
            make.right.mas_equalTo(-kMGMHBL2X(14));
            make.centerY.mas_equalTo(self.contentView);
            make.height.mas_equalTo(kMGMHBL2X(13));
        }];
        
    }
    return self;
}


#pragma mark — 实现自适应文字宽度的关键步骤:item的layoutAttributes
- (UICollectionViewLayoutAttributes*)preferredLayoutAttributesFittingAttributes:(UICollectionViewLayoutAttributes*)layoutAttributes {
    UICollectionViewLayoutAttributes *attributes = [super preferredLayoutAttributesFittingAttributes:layoutAttributes];
    CGRect rect = [self.titleLabel.text boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, kMGMHBL2X(28)) options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:13]} context:nil];
    CGFloat itemWidth = ceilf(rect.size.width+kMGMHBL2X(30));
    rect.size.width = itemWidth;
    rect.size.height = kMGMHBL2X(28);
    attributes.frame = rect;
    return attributes;
}

- (void)dynamicTopicCellWithTitle:(NSString *)title{
    self.titleLabel.text = title;
}
- (void)settingTitleLbIsSelect:(BOOL)isSelect{
    if (!isSelect) {
        self.titleLabel.textColor = [UIColor mgu_colorWithHex:0x63ADEF opacity:1.0];
    }else{
        self.titleLabel.textColor = [UIColor mgu_colorWithHex:0xBDBDBD opacity:1.0];
    }
}
@end
