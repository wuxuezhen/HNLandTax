//
//  MGMParentCommentHeaderView.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/3/13.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMParentCommentHeaderView.h"
#import "MGMCommunityResource.h"
#import <Masonry/Masonry.h>
#import <MGMCategories/MGMCategories.h>
#import <MGMCategories/NSString+MGMStringData.h>
#import <MGMHttpApiModel/MGMFilmDetailChildReviewModel.h>
#import <YYWebImage/YYWebImage.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>

@interface MGMParentCommentHeaderView ()

@property (nonatomic, strong, readwrite) UIButton *userIcon;
@property (nonatomic, strong, readwrite) UILabel *userNameLabel;
@property (nonatomic, strong, readwrite) UILabel *commentLabel;
@property (nonatomic, strong, readwrite) UILabel *updateTimeLabel;
@property (nonatomic, strong, readwrite) UIButton *likeButton;
@property (nonatomic, strong, readwrite) UILabel *likeCountLabel;

@end

@implementation MGMParentCommentHeaderView

- (void)setModel:(MGMparentCommentReview *)model {
    _model = model;
    [self layoutIfNeeded];
}

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if (self) {
        _userIcon = [UIButton buttonWithType:UIButtonTypeCustom];
        [_userIcon setupCornerWithRadius:kMGMHBL(35)];
        _userNameLabel = [[UILabel alloc] init];
        _commentLabel = [[UILabel alloc] init];
        _updateTimeLabel = [[UILabel alloc] init];
        _updateTimeLabel.textColor = [UIColor colorWithRed:178/255.0 green:178/255.0 blue:178/255.0 alpha:1.0];
        _updateTimeLabel.font = [UIFont systemFontOfSize:14];
        _likeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_likeButton setImage:[MGMCommunityResource originalRenderingImageNamed:@"community_like_normal"] forState:UIControlStateNormal];
        [_likeButton setImage:[MGMCommunityResource originalRenderingImageNamed:@"community_like_selected"] forState:UIControlStateSelected];
        [_likeButton addTarget:self action:@selector(likeAction:) forControlEvents:UIControlEventTouchUpInside];
        _likeCountLabel = [[UILabel alloc] init];
        _likeCountLabel.textColor = [UIColor colorWithRed:178/255.0 green:178/255.0 blue:178/255.0 alpha:1.0];
        _likeCountLabel.font = [UIFont systemFontOfSize:14];
        
        [self.contentView addSubview:_userIcon];
        [self.contentView addSubview:_userNameLabel];
        [self.contentView addSubview:_commentLabel];
        [self.contentView addSubview:_updateTimeLabel];
        [self.contentView addSubview:_likeButton];
        [self.contentView addSubview:_likeCountLabel];
        [self layoutIfNeeded];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    UIImage *placeholder = [UIImage miguDefaultPortraitImage];
    [self.userIcon yy_setImageWithURL:[NSURL URLWithString:_model.userPortrait] forState:UIControlStateNormal placeholder:placeholder];
    [self.userIcon mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(kMGMHBL2X(15));
        make.top.equalTo(self.contentView).offset(kMGMHBL2X(20));
        make.width.height.mas_equalTo(kMGMHBL2X(35.f));
    }];
    
    NSString *userName = _model.userName;
    if (userName == nil) {
        userName = _model.mobile;
    }
    if (userName == nil) {
        userName = @"";
    }
    self.userNameLabel.attributedText = [[NSMutableAttributedString alloc] initWithString:userName attributes: @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Semibold" size: 15],NSForegroundColorAttributeName: [UIColor colorWithRed:26/255.0 green:26/255.0 blue:26/255.0 alpha:1.0]}];
    [self.userNameLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.userIcon).offset(kMGMHBL2X(10));
        make.bottom.equalTo(self.userIcon).offset(kMGMHBL2X(-10));
        make.left.equalTo(self.userIcon.mas_right).offset(kMGMHBL2X(10));
        make.right.equalTo(self.contentView).offset(kMGMHBL2X(-15));
    }];
    
    NSString *commentBody = _model.body? _model.body : @"";
    _commentLabel.attributedText = [[NSMutableAttributedString alloc] initWithString:commentBody attributes: @{NSFontAttributeName: [UIFont fontWithName:@"PingFangSC-Regular" size: 14],NSForegroundColorAttributeName: [UIColor colorWithRed:26/255.0 green:26/255.0 blue:26/255.0 alpha:1.0]}];
    
    [self.commentLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.userIcon.mas_bottom).offset(kMGMHBL2X(15));
        make.left.equalTo(self.contentView).offset(kMGMHBL2X(15));
        make.right.equalTo(self.contentView).offset(kMGMHBL2X(-15));
    }];
    
    // 分类内使用的是本地时间，和格林尼治时间相差八小时
    NSString *updateTime = [NSString mgm_categoriesDataTotimeString:[NSString mgm_categoriesTimeStampToDataStringBiaoZhun:_model.createTime]];
    self.updateTimeLabel.text = updateTime;
    [self.updateTimeLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.commentLabel.mas_bottom).offset(kMGMHBL2X(15));
        make.left.equalTo(self.commentLabel);
        make.bottom.equalTo(self.contentView).offset(kMGMHBL2X(-20));
        make.width.mas_greaterThanOrEqualTo(kMGMHBL2X(0));
    }];
    
    self.likeCountLabel.text = _model.likeModel.likeCount;
    [self.likeCountLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(self.updateTimeLabel);
        make.right.equalTo(self.contentView).offset(kMGMHBL2X(-15));
        make.width.mas_greaterThanOrEqualTo(0);
    }];
    
    self.likeButton.selected = _model.likeModel.mgm_has;
    [self.likeButton mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.updateTimeLabel);
        make.right.equalTo(self.likeCountLabel.mas_left).offset(kMGMHBL2X(-7));
        make.width.height.mas_equalTo(kMGMHBL2X(14));
    }];
    
}

- (void)likeAction:(UIButton *)sender {
    if ([_delegate respondsToSelector:@selector(parentCommentHeaderView:didCilckLikeButton:)]) {
        [_delegate parentCommentHeaderView:self didCilckLikeButton:sender];
    }
}

- (CGSize)sizeThatFits:(CGSize)size {
    CGFloat height = kMGMHBL2X(119);
    height += [self.commentLabel sizeThatFits:size].height;
    height -= kMGMHBL2X(6.f);
    return CGSizeMake(size.width, height);
}

@end
