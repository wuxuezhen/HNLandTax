//
//  MGMCommunityPicturesCommitView.m
//  AFNetworking
//
//  Created by Banana on 2019/8/1.
//

#import "MGMCommunityPicturesCommitView.h"
#import "MGMCommunityResource.h"
#import "MGMCommunitySelectePictureCollectionViewCell.h"

#import <Masonry/Masonry.h>
#import <MGUCategoryUtil/UIResponder+MGUExtension.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <YYCategories/YYCategories.h>
#import "MGMDynamicTopicCollectionViewCell.h"
#import <MGMCategories/MGMCategories.h>
#import "MGMDynamicTopicItemInfo.h"

NSString *const MGMCommunityPicturesCommitViewSelectImagEventName = @"MGMCommunityPicturesCommitViewSelectImagEventName";
NSString *const MGMCommunityPicturesCommitViewPublishEventName = @"MGMCommunityPicturesCommitViewPublishEventName";
NSString *const MGMCommunityPictureKey = @"png";
NSString *const MGMCommunityPicturesDeletePublishEventName = @"MGMCommunityPicturesDeletePublishEventName";

static const NSString *cell_id = @"MGMCommunitySelectePictureCollectionViewCell";
static const NSInteger kPictureMaxcount = 3;

@interface MGMCommunityPicturesCommitView ()<UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>
@property (nonatomic, strong) UICollectionView *pictureContentVeiw;/**<已选择*/
@property (nonatomic, strong) UIImageView *pickeImageView;/**<选择图片*/
@property (nonatomic, strong) UIView *bottomBGview;
//@property (nonatomic, strong) UIButton *publishBtn;/**<发布*/
@property (nonatomic, strong) UIView *topLineView;

@property (nonatomic, strong, readwrite) NSMutableArray <NSDictionary *> *pictures;
@property (nonatomic, assign, readwrite) NSInteger maxPicturesCount;
//@property (nonatomic, assign, getter = isPublishtEnable) BOOL publishtEnable;/**<可以发布*/

@property (nonatomic, strong) UICollectionView *topicCollectionView;

@end

@implementation MGMCommunityPicturesCommitView
- (instancetype)initWithFrame:(CGRect)frame pictures:(NSArray<NSDictionary *> *_Nullable)pictures bottomViewTapedAction:(tapActionBlock _Nullable)bottomViewTapedAction {
    self = [self initWithFrame:frame];
    if (self) {
        [_pictures addObjectsFromArray:pictures];
        _bottomViewTapedAction = bottomViewTapedAction;
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _pictures = [NSMutableArray array];
        [self customSetup];
    }
    return self;
}

//- (NSMutableArray *)topicTitleArray{
//    if (!_topicTitleArray) {
//        _topicTitleArray = @[@{@"title": @"#000000#",
//                               @"isSelelct" : @(1),
//                               @"topicId" :@"1"
//                               },
//                             @{@"title": @"#111111#",
//                               @"isSelelct" : @(1),
//                               @"topicId" :@"2"
//                             },
//                             @{@"title": @"#222222#",
//                               @"isSelelct" : @(1),
//                               @"topicId" :@"3"
//                             }
//                            ];
//    }
//    return _topicTitleArray;
//}

#pragma mark - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
        return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (collectionView == self.pictureContentVeiw) {
        return _pictures.count <= kPictureMaxcount ? _pictures.count : kPictureMaxcount;
    }else{
        return self.topicTitleItemInfoArray.count>4 ? 4 : self.topicTitleItemInfoArray.count;
    }
    
}

#pragma mark - UICollectionViewDelegate
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (collectionView == self.pictureContentVeiw) {
        MGMCommunitySelectePictureCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cell_id forIndexPath:indexPath];
        NSDictionary *dic = [_pictures mgu_objectOrNilAtIndex:indexPath.row];
        cell.imageDic = dic;
        @weakify(self)
        cell.deleteBlock = ^(NSDictionary * _Nonnull imageDic) {
            @strongify(self)
            [_pictures removeObject: imageDic];
            [self updatepickeImageViewHighlighted];
            [self updatePublishStatus];
            [self updateSubviewLayout];
        };
        return cell;
    }else{
        MGMDynamicTopicCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MGMDynamicTopicCollectionViewCell" forIndexPath:indexPath];
        MGMDynamicTopicItemInfo *info = self.topicTitleItemInfoArray[indexPath.row];
        if (indexPath.row<3) {
            [cell dynamicTopicCellWithTitle:[self transformationStringWithTopicName:info.name]];
            [cell settingTitleLbIsSelect:info.selected];
        }else if (indexPath.row == 3){
            [cell dynamicTopicCellWithTitle:info.name];
            [cell settingTitleLbIsSelect:NO];
        }
        
        return cell;
    }
}


- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (collectionView == self.topicCollectionView) {
        //NSDictionary *dic = self.topicTitleArray[indexPath.row];
        MGMDynamicTopicItemInfo *info = self.topicTitleItemInfoArray[indexPath.row];
        self.collectionViewCellAction(indexPath.row,info.selected);
    }
}

#pragma mark - public
- (void)addPictures:(NSArray<NSDictionary *> *)pictures {
    [_pictures addObjectsFromArray:pictures];
    [self updatepickeImageViewHighlighted];
    [self updatePublishStatus];
    [self updateSubviewLayout];
}

- (NSArray<NSDictionary *> *)getPictures {
    return [_pictures copy];
}

#pragma mark - private
- (void)updateSubviewLayout {
    if (_pictures.count > 0) {
        [self.pictureContentVeiw mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.offset(111.f);
        }];
        self.topLineView.hidden = NO;
    } else {
        [self.pictureContentVeiw mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.offset(0);
        }];
        self.topLineView.hidden = YES;
    }
    [self.pictureContentVeiw reloadData];
}

- (void)updatepickeImageViewHighlighted {
    if (_pictures.count >= kPictureMaxcount) {
        self.pickeImageView.highlighted = YES;
    } else {
        self.pickeImageView.highlighted = NO;
    }
}

- (void)updatePublishStatus {
    if (_pictures.count > 0) {
        //self.publishtEnable = YES;
    } else {
        [self routerEventWithName:MGMCommunityPicturesDeletePublishEventName userInfo:nil];
    }
}
- (void)reloadTopicCollect{
    [self.topicCollectionView reloadData];
}
//文字两边加#号
- (NSString *)transformationStringWithTopicName:(NSString *)name{
    NSString *tranStr = [NSString stringWithFormat:@"#%@#",name];
    return tranStr;
}

- (void)customSetup {
    UIView *bgview = [UIView new];
    bgview.backgroundColor = UIColorHex(#F5F5F5);
    @weakify(self)
//    UITapGestureRecognizer *bottomViewTap = [[UITapGestureRecognizer alloc] initWithActionBlock:^(id _Nonnull sender) {
//        @strongify(self)
//        if (self.bottomViewTapedAction) {
//            self.bottomViewTapedAction();
//        }
//    }];
//    [bgview addGestureRecognizer:bottomViewTap];
    self.bottomBGview = bgview;
    [self addSubview:bgview];
    [bgview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(self);
        make.height.offset(50.f);
        make.top.equalTo(self.pictureContentVeiw.mas_bottom);
    }];

    UIImageView *imageView = [[UIImageView alloc] initWithImage:[MGMCommunityResource imageNamed:@"icon_p"] highlightedImage:[MGMCommunityResource imageNamed:@"icon_p_n"]];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectImageAction)];
    [imageView addGestureRecognizer:tapGesture];
    imageView.userInteractionEnabled = YES;
    [bgview addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15.f);
        make.centerY.equalTo(bgview);
        make.size.mas_equalTo(CGSizeMake(24.f, 24.f));
    }];
    self.pickeImageView = imageView;

    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
    flowLayout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 15.f);
    flowLayout.minimumInteritemSpacing = 10.f;
    flowLayout.estimatedItemSize = CGSizeMake(10, 28);
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    UICollectionView *collectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:flowLayout];
    collectionView.backgroundColor = [UIColor clearColor];
    collectionView.delegate = self;
    collectionView.dataSource = self;
    collectionView.showsVerticalScrollIndicator = NO;
    collectionView.showsHorizontalScrollIndicator = NO;
    [collectionView registerClass:[MGMDynamicTopicCollectionViewCell class] forCellWithReuseIdentifier:@"MGMDynamicTopicCollectionViewCell"];
    [bgview addSubview:collectionView];
    [collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(imageView.mas_right).mas_equalTo(15.5f);
        make.right.top.bottom.mas_equalTo(0);
    }];
    self.topicCollectionView = collectionView;
    
    
    
//    UIButton *publicBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    [publicBtn setTitle:@"发布" forState:UIControlStateNormal];
//    [publicBtn setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
//    publicBtn.layer.backgroundColor = UIColorHex(#DBDBDB).CGColor;
//    publicBtn.layer.cornerRadius = 14.f;
//    publicBtn.layer.masksToBounds = YES;
//    publicBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:13];
//    [publicBtn addTarget:self action:@selector(commitAction:) forControlEvents:UIControlEventTouchUpInside];
//    [bgview addSubview:publicBtn];
//    [publicBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.right.offset(-15.f);
//        make.centerY.equalTo(bgview);
//        make.size.mas_equalTo(CGSizeMake(50.f, 28.f));
//    }];
//    self.publishBtn = publicBtn;
}

- (void)selectImageAction {
    if (!self.pickeImageView.highlighted) {
        [self routerEventWithName:MGMCommunityPicturesCommitViewSelectImagEventName userInfo:nil];
    }
}

//- (void)commitAction:(UIButton *)sender {
//    if (self.isPublishtEnable) {
//        [self routerEventWithName:MGMCommunityPicturesCommitViewPublishEventName userInfo:nil];
//    }
//}

#pragma mark - Setter


//- (void)setContentTextEnable:(BOOL)contentTextEnable {
//    _contentTextEnable = contentTextEnable;
//    [self updatePublishStatus];
//}

#pragma mark - Getter
- (UICollectionView *)pictureContentVeiw {
    if (!_pictureContentVeiw) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake(80.f, 80.f);
        layout.sectionInset = UIEdgeInsetsMake(15.f, 15.f, -15.f, 15.f);
        layout.minimumInteritemSpacing = 8.f;

        UICollectionView *view = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        view.delegate = self;
        view.dataSource = self;
        view.scrollEnabled = NO;
        view.showsHorizontalScrollIndicator = NO;
        view.backgroundColor = UIColor.whiteColor;
        [view registerClass:MGMCommunitySelectePictureCollectionViewCell.self forCellWithReuseIdentifier:cell_id];
        [self addSubview:view];
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.equalTo(self);
            make.width.offset(286.f);
            make.height.offset(0);
        }];

        _pictureContentVeiw = view;
    }
    return _pictureContentVeiw;
}

- (UIView *)topLineView {
    if (!_topLineView) {
        UIView *topline = [UIView new];
        topline.backgroundColor = UIColorHex(#E2E2E2);
        [self addSubview:topline];
        [topline mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.offset(0.25);
            make.top.offset(0);
            make.left.offset(15.f);
            make.right.offset(-15.f);
        }];
        _topLineView = topline;
    }
    return _topLineView;
}

- (NSInteger)maxPicturesCount {
    return kPictureMaxcount - _pictures.count;
}

@end
