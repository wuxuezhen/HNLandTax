//
//  MGMDynamicTopicItemInfo.m
//  MGMCommunity
//
//  Created by wdlzh on 2020/1/9.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicTopicItemInfo.h"

@implementation MGMDynamicTopicItemInfo

+(NSArray *)mgm_fetchTopicsWithTopicArray:(NSArray *)topicArray
{
    NSMutableArray *topics = [NSMutableArray array];
    for (MGMDynamicTopicItemModel *itemModel in topicArray)
    {
        MGMDynamicTopicItemInfo *itemInfo = [self mgm_fetchTopicItemInfoWithTopicItemModel:itemModel];
        [topics addObject:itemInfo];
    }
    
    return [topics copy];
}

//处理被选数据
+(NSArray *)mgm_fetchSelectedTopicArrayWithAllTopics:(NSArray *)topics selectedTopics:(NSArray *)selectedTopics
{
    NSMutableArray *array = [topics mutableCopy];
    
    if (selectedTopics.count >0 && topics.count > 0)
    {
        for (MGMDynamicTopicItemInfo *itemInfo in selectedTopics)
        {
            [topics indexOfObjectPassingTest:^BOOL(MGMDynamicTopicItemInfo *obj, NSUInteger idx, BOOL* stop){
                if ([obj.topicId isEqualToString:itemInfo.topicId])
                {
                    obj.selected = YES;
                    [array replaceObjectAtIndex:idx withObject:obj];
                }
                return ([obj.topicId isEqualToString:itemInfo.topicId]);
            }];
        }
    }
    
    return [array copy];
}

#pragma mark - privateMethods
+(MGMDynamicTopicItemInfo *)mgm_fetchTopicItemInfoWithTopicItemModel:(MGMDynamicTopicItemModel *)itemModel
{
    MGMDynamicTopicItemInfo *itemInfo = [[MGMDynamicTopicItemInfo alloc]init];
    itemInfo.clientType = itemModel.clientType;
    itemInfo.name = itemModel.name;
    itemInfo.dynamicCount = itemModel.dynamicCount;
    itemInfo.topicId = itemModel.topicId;
    itemInfo.createTime = itemModel.createTime;
    itemInfo.sortNum = itemModel.sortNum;
    itemInfo.status = itemModel.status;
    itemInfo.updateTime = itemModel.updateTime;
    itemInfo.viewNum = itemModel.viewNum;
    itemInfo.mIds = itemModel.mIds;
    itemInfo.selected = NO;
    
    return itemInfo;
}


@end

