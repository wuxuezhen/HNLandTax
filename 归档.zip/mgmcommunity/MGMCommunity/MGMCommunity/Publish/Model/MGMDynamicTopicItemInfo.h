//
//  MGMDynamicTopicItemInfo.h
//  MGMCommunity
//
//  Created by wdlzh on 2020/1/9.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MGMDynamicTopicItemModel.h"

NS_ASSUME_NONNULL_BEGIN

//跳转到更多话题的入口类型
typedef NS_ENUM(NSUInteger, MGMDynamicMoreTopicsPushType)
{
    MGMDynamicMoreTopicsDefault     = 0,  //常规的push类型
    MGMDynamicMoreTopicsPublishType = 1,  //从底部弹出类型 发布动态入口
};

@interface MGMDynamicTopicItemInfo : MGMDynamicTopicItemModel

@property (nonatomic, assign) BOOL  selected;

//给话题数据 添加一个selected字段 初始化数据
+(NSArray *)mgm_fetchTopicsWithTopicArray:(NSArray *)topicArray;

/*
 *  在话题数据中标记已选的h状态
 *
 *  @param topics          话题数据
 *  @param selectedTopics  已被选的话题数据
 */
+(NSArray *)mgm_fetchSelectedTopicArrayWithAllTopics:(NSArray *)topics selectedTopics:(NSArray *)selectedTopics;

@end

NS_ASSUME_NONNULL_END
