//
//  MGMPublishTimeLineVC.m
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMPublishTimeLineVC.h"
#import "MGMCommunityPicturesCommitView.h"
#import "MGMCommunityResource.h"

#import <Masonry/Masonry.h>
#import <YYCategories/YYCategories.h>
#import <YYWebImage/YYWebImage.h>
#import <MGMDataStore/MGMDSUser.h>
#import <MGMUIKit/MGMProgressHUD+Prompt.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <Photos/Photos.h>
#import <MGMCategories/UIView+MGMToast.h>
#import <MGUCategoryUtil/UIResponder+MGUExtension.h>
#import <MGMPhotoBrowser/LGPhotoPickerBrowserViewController.h>
#import <MGMSocialModule/MGMShareDynamicMicroblog.h>
#import <MGMSocialModule/MGMSocialDynamicPub.h>
#import <MGThirdKit/AFNetworking_mgs.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/UIImage+MGMPlaceHolderImage.h>
#import <MGMUIKit/MSSAutoresizeLabelFlow.h>
#import <MGMCategories/MGMCategories.h>
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGMSocialModule/MGMDynamicFetchTopicListInfo.h>
#import "MGMDynamicTopicItemInfo.h"
#import <MGMRoute/MGMRoute.h>
#import <MGMUIKit/MGMProgressHUD+MGMConfig.h>

static const NSUInteger limitTextLength = 1000;

@interface MGMPublishTimeLineVC ()<UITextViewDelegate, LGPhotoPickerViewControllerDelegate, MGMSocialDynamicPubDelegate, MGMSocialDynamicContentDelegate,MGMDynamicFetchTopicListInfoDelegate>

@property (nonatomic, strong) UITextView *contentTextView;
@property (nonatomic, strong) MGMCommunityPicturesCommitView *commitPictureView;
@property (nonatomic, strong) UIImageView *userAvaterImg;/**<头像*/
@property (nonatomic, strong) UILabel *placeholderLab;/**<placeholder*/
@property (nonatomic, strong) UILabel *textCountLab;/**<字数*/
@property (nonatomic, strong) UIImagePickerController *imgPickerController;
@property (nonatomic, strong) MGMSocialDynamicPub *publishManager;

@property (nonatomic, strong) UIView *countBGView;

@property (nonatomic, strong) MSSAutoresizeLabelFlow *topicLabelFlow;

@property (nonatomic, strong) MSSAutoresizeLabelFlow *initialFlow;

@property (nonatomic, strong) UIButton *publishBtn;/**<发布*/

@property (nonatomic, strong) NSMutableArray<MGMDynamicTopicItemInfo *> *selectDynamicTopicItemArray;

@property (nonatomic, strong) MGMDynamicFetchTopicListInfo *topicListInfoManager;

@property (nonatomic, strong) NSArray<MGMDynamicTopicItemInfo *> *topicArray;

@property (nonatomic, strong) NSMutableArray<MGMDynamicTopicItemInfo *> *dynamicTopicItemArray;

@end

@implementation MGMPublishTimeLineVC
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupNavigationbar];
    [self setupUI];
    [self.topicListInfoManager fetchTopicList];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShowNotification:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHideNotification:) name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(mgm_updateDataWithSelectedTopics:) name:@"MGMDynamicMoreTopicsVCNotification" object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.contentTextView becomeFirstResponder];
//    if (self.commitPictureView.collectionViewCellAction) {
//        self.commitPictureView.collectionViewCellAction(1,0);
//    }
    
//    mgm_updateDataWithSelectedTopics
    
//    NSNotification *notify =
    
    
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.contentTextView resignFirstResponder];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - UITextViewDelegate
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if (text.length == 0) {
        return YES;
    }
    NSUInteger textLength = [self charactertextLengthWithText:textView.text];
    NSUInteger changeTextLength = [self charactertextLengthWithText:text];
    if (changeTextLength % 2 == 1) {
        changeTextLength++;
    }
    BOOL beyondLimitRange = (textLength + changeTextLength) / 2 > limitTextLength;
    if (beyondLimitRange) {
        [self.view showAutoHideToastWithText:@"字数超过限制"];
    }
    return !beyondLimitRange;
}

- (void)textViewDidChange:(UITextView *)textView {
    self.userAvaterImg.hidden = YES;
    self.placeholderLab.hidden = YES;
    [self.contentTextView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(11.5);
    }];

    NSUInteger textLength = [self charactertextLengthWithText:textView.text] / 2;
    self.textCountLab.text = [NSString stringWithFormat:@"%lu/1000", (unsigned long)textLength];
   // self.commitPictureView.contentTextEnable = textView.text.length;
    
    [self settingPublishButtonColor];
    
}
- (void)settingPublishButtonColor{
    if (self.contentTextView.text.length>0) {
        [self.publishBtn setTitleColor:UIColorHex(#FF3E40) forState:UIControlStateNormal];
        self.publishBtn.enabled = YES;
    }else{
        
        if (self.commitPictureView.getPictures.count>0) {
            [self.publishBtn setTitleColor:UIColorHex(#FF3E40) forState:UIControlStateNormal];
            self.publishBtn.enabled = YES;
        }else{
            self.publishBtn.enabled = NO;
            [self.publishBtn setTitleColor:UIColorHex(#B2B2B2) forState:UIControlStateNormal];
        }
    }
}
#pragma mark - LGPhotoPickerViewControllerDelegate

- (void)pickerViewControllerDoneAsstes:(NSArray <LGPhotoAssets *> *)assets isOriginal:(BOOL)original {
    NSMutableArray <NSDictionary *> *pictures = @[].mutableCopy;
    for (LGPhotoAssets *asset in assets) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        ALAssetRepresentation *re = [asset.asset representationForUTI: (__bridge NSString *)kUTTypeGIF];
        
        if (asset.originImage) {
            [dic mgu_safe_setObject:asset.originImage forKey:@"png"];
        } else if (asset.compressionImage) {
            [dic mgu_safe_setObject:asset.compressionImage forKey:@"png"];
        } else if (asset.thumbImage) {
            [dic mgu_safe_setObject:asset.thumbImage forKey:@"png"];
        }
        if (re) {
        [dic mgu_safe_setObject:@"gif" forKey:@"type"];
         NSData *gifData = [self gifData:asset.asset];
         [dic mgu_safe_setObject:gifData forKey:@"gif"];
        } else {
            [dic mgu_safe_setObject:@"png" forKey:@"type"];
        }
        [pictures mgu_safe_addObject:dic];
    }
    if (pictures.count > 0) {
        [self.commitPictureView addPictures:pictures];
    }
    
     [self settingPublishButtonColor];
}

- (NSData *)gifData:(ALAsset *)asset{
    ALAssetRepresentation *re = [asset representationForUTI:(__bridge NSString *)kUTTypeGIF];;
    long long size = re.size;
    uint8_t *buffer = malloc(size);
    NSError *error;
    NSUInteger bytes = [re getBytes:buffer fromOffset:0 length:size error:&error];
    NSData *data = [NSData dataWithBytes:buffer length:bytes];
    free(buffer);
    return data;
}

#pragma mark - ImgPickerController-Delegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *, id> *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    UIImage *pickeImg = info[@"UIImagePickerControllerEditedImage"];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic mgu_safe_setObject:@"png" forKey:@"type"];
    [dic mgu_safe_setObject:pickeImg forKey:@"png"];
    [self.commitPictureView addPictures:@[dic]];
    [self settingPublishButtonColor];
}

#pragma mark - MGMSocialDynamicPubDelegate
- (void)dynamicPubStar {
    if ([self.delegate respondsToSelector:@selector(dynamicPublishStart)]) {
        [self.delegate dynamicPublishStart];
    }
}

- (void)dynamicPubEndWithError:(NSError *)error prompt:(nullable NSString *)prompt {
    if ([self.delegate respondsToSelector:@selector(dynamicPublishEndWithError:prompt:)]) {
        [self.delegate dynamicPublishEndWithError:error prompt:prompt];
    }
}

#pragma mark - action & target
- (void)mgm_updateDataWithSelectedTopics:(NSNotification *)noti{
    NSDictionary *paramDic = noti.userInfo;
    NSArray *array = [[paramDic mgu_objectOrNilForKey:@"selectTopics"] copy];
    NSArray<MGMDynamicTopicItemInfo *> *itemInfoArray = array;
    [self.selectDynamicTopicItemArray removeAllObjects];
    self.selectDynamicTopicItemArray = [[NSMutableArray alloc]initWithArray:itemInfoArray];
    NSMutableArray *showTopicArray = [[NSMutableArray alloc]init];
    for (MGMDynamicTopicItemInfo *info in self.selectDynamicTopicItemArray) {
        [showTopicArray mgu_safe_addObject:info.name];
    }
    if (self.topicLabelFlow) {
        //更新选中标签
        [self.topicLabelFlow reloadAllWithTitles:showTopicArray.mutableCopy];
    }else{
        [self.initialFlow removeFromSuperview];
        MGMWeakSelf
        MSSAutoresizeLabelFlow *labelFlow = [[MSSAutoresizeLabelFlow alloc]initWithFrame:CGRectZero titles:showTopicArray.mutableCopy type:MSSAutoresizeLabelFlowTypeDynamicTopic selectedHandler:^(NSUInteger index, NSString *title) {
            MGMStrongSelf
            //选择了已选中标签，---删除此标签，并判断底部标签栏收否有这个标签，有的话变为可选
                MGMDynamicTopicItemInfo *selectItemInfo = [self.selectDynamicTopicItemArray mgu_objectOrNilAtIndex:index];
                NSString *selectTopicId = selectItemInfo.topicId;
                for (int i = 0; i<self.commitPictureView.topicTitleItemInfoArray.count; i++) {
                    MGMDynamicTopicItemInfo *titleItemInfo = self.commitPictureView.topicTitleItemInfoArray[i];
                    NSString *titleTopicId = titleItemInfo.topicId;
                    if ([selectTopicId isEqualToString:titleTopicId]) {
                        MGMDynamicTopicItemInfo *mutItemInfo = titleItemInfo;
                        mutItemInfo.selected = NO;
                        [self.commitPictureView.topicTitleItemInfoArray replaceObjectAtIndex:i withObject:mutItemInfo];
                        [self.commitPictureView reloadTopicCollect];
                        break;
                    }
                }
            //删除选中标签并刷新
            if (index<self.selectDynamicTopicItemArray.count) {
                [self.selectDynamicTopicItemArray removeObjectAtIndex:index];
                NSMutableArray *showTopicArray = [[NSMutableArray alloc]init];
                for (MGMDynamicTopicItemInfo *itemInfo in self.selectDynamicTopicItemArray) {
                    [showTopicArray mgu_safe_addObject:itemInfo.name];
                }
                [self.topicLabelFlow reloadAllWithTitles:showTopicArray.mutableCopy];
            }
        }];
       [self.view addSubview:labelFlow];
       self.topicLabelFlow = labelFlow;
       [labelFlow mas_makeConstraints:^(MASConstraintMaker *make) {
           make.left.offset(15.0f);
           make.right.offset(-15.0f);
           make.top.mas_equalTo(self.contentTextView.mas_bottom).mas_equalTo(0);
           make.height.offset(30);
           make.bottom.mas_equalTo(self.countBGView.mas_top).mas_equalTo(kMGMHBL2X(4));
       }];
       [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(numberOfLineNotificenter:) name:numberOfLineNotificenter object:nil];
    }
    
    //判断返回回来的数组中。在底部标签栏是否有存在的  如果有责置灰
    NSMutableArray *mutItemArray = self.commitPictureView.topicTitleItemInfoArray;
    for (int i=0; i<mutItemArray.count; i++) {
        MGMDynamicTopicItemInfo *info = mutItemArray[i];
        for (MGMDynamicTopicItemInfo *selectInfo in self.selectDynamicTopicItemArray) {
            if ([info.topicId isEqualToString:selectInfo.topicId]) {
                info.selected = YES;
                [self.commitPictureView.topicTitleItemInfoArray replaceObjectAtIndex:i withObject:info];
            }
        }
    }
    [self.commitPictureView reloadTopicCollect];
}

#pragma mark - routevent

- (void)routerEventWithName:(NSString *)eventName userInfo:(NSDictionary *)userInfo {
    if ([eventName isEqualToString:MGMCommunityPicturesDeletePublishEventName]) {
       // [self dynamicPublish];
        [self settingPublishButtonColor];
    } else if ([eventName isEqualToString:MGMCommunityPicturesCommitViewSelectImagEventName]) {
        if (self.contentTextView.isFirstResponder) {
            [self.contentTextView resignFirstResponder];
        }
        [self showSelectImageAcionSheet];
    }
}

#pragma mark - private
- (void)dynamicPublish {
    if ([AFNetworkReachabilityManager_mgs sharedManager].isReachable) {
        NSMutableArray *mutArray = [[NSMutableArray alloc]init];
        for (MGMDynamicTopicItemInfo *info in self.selectDynamicTopicItemArray) {
            [mutArray mgu_safe_addObject:info.topicId];
        }
        MGMShareDynamicMicroblog *blog = [[MGMShareDynamicMicroblog alloc] initWithText:self.contentTextView.text labellds:mutArray.mutableCopy pictures:self.commitPictureView.getPictures delegate:self];
        MGMSocialDynamicPub *pub = [[MGMSocialDynamicPub alloc] initDelegate:self];
        [pub updateContent:blog];
        [pub share];
        self.publishManager = pub;

        [self dismissViewControllerAnimated:YES completion:nil];
    } else {
        [self.view showAutoHideToastWithText:@"请检查网络后重试"];
    }
}

- (NSUInteger)charactertextLengthWithText:(NSString *)text {
    NSUInteger asciiLength = 0;
    for (NSUInteger i = 0; i < text.length; i++) {
        unichar uc = [text characterAtIndex:i];
        asciiLength += isascii(uc) ? 1 : 2;
    }
    NSUInteger unicodeLength = asciiLength;
    return unicodeLength;
}

- (void)setupNavigationbar {
    self.title = @"发布动态";
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"关闭" forState:UIControlStateNormal];
    [btn setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:15.f];
    btn.size = CGSizeMake(30.f, 15.f);
    [btn sizeToFit];
    [btn addTarget:self action:@selector(closeAction) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    UIButton *publicBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [publicBtn setTitle:@"发布" forState:UIControlStateNormal];
    [publicBtn setTitleColor:UIColorHex(#B2B2B2) forState:UIControlStateNormal];
    publicBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:15];
    [publicBtn addTarget:self action:@selector(dynamicPublish) forControlEvents:UIControlEventTouchUpInside];
    publicBtn.size = CGSizeMake(30.f, 15.f);
    self.publishBtn = publicBtn;
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:publicBtn];
    self.navigationItem.rightBarButtonItem = rightItem;
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationController.navigationBar.barTintColor = UIColor.whiteColor;
}

- (void)closeAction {
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        if ([self.delegate respondsToSelector:@selector(publishPageCloseButtonDidClicked)]) {
            [self.delegate publishPageCloseButtonDidClicked];
        }
    }];
}
- (void)setupUI {
    [self.navigationController.navigationBar setShadowImage:[self imageWithColor:[UIColor colorWithRed:226 / 255.0 green:226 / 255.0 blue:226 / 255.0 alpha:1.0] size:CGSizeMake(self.view.frame.size.width, 0.5)]];

    UIImageView *imgView = [[UIImageView alloc] init];
    imgView.layer.cornerRadius = 17.5;
    imgView.layer.masksToBounds = YES;
    [imgView yy_setImageWithURL:[NSURL URLWithString:[MGMDSUser user].avatar] placeholder:[UIImage miguDefaultPortraitImage] options:YYWebImageOptionProgressive | YYWebImageOptionIgnoreDiskCache completion:nil];
    self.userAvaterImg = imgView;
    [self.view addSubview:self.userAvaterImg];
    [self.userAvaterImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(16.f);
        if (@available(iOS 11.0, *)) {
            make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop).offset(15.f);
        } else {
            make.top.offset(64.f + 15.f);
        }
        make.size.mas_equalTo(CGSizeMake(35.f, 35.f));
    }];

    UITextView *textView = [[UITextView alloc] init];
    textView.font = [UIFont systemFontOfSize:14.f];
    textView.tintColor = UIColorHex(#FF3E40);
    textView.showsVerticalScrollIndicator = NO;
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 7.f;
    paragraphStyle.lineBreakMode = NSLineBreakByCharWrapping;
    NSDictionary *attibutes = @{ NSParagraphStyleAttributeName: paragraphStyle, NSFontAttributeName: [UIFont systemFontOfSize:14] };
    textView.attributedText = [[NSAttributedString alloc] initWithString:@"test" attributes:attibutes];
    textView.attributedText = [[NSAttributedString alloc] initWithString:@"" attributes:attibutes];
    textView.delegate = self;
    textView.textAlignment = NSTextAlignmentJustified;
    textView.textContainerInset = UIEdgeInsetsMake(23.f, 0, 0, 11.5);
    self.contentTextView = textView;
    [self.view addSubview:textView];
    [textView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(0);
        make.left.equalTo(self.userAvaterImg.mas_right).offset(6.f);
        if (@available(iOS 11.0, *)) {
            make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
        } else {
            make.top.equalTo(self.mas_topLayoutGuide);
        }
    }];

    UILabel *placeholder = [[UILabel alloc] init];
    placeholder.textColor = UIColorHex(#B2B2B2);
    placeholder.text = @"来都来了，不说两句再走？";
    placeholder.font = [UIFont systemFontOfSize:14.f];
    self.placeholderLab = placeholder;
    [textView addSubview:placeholder];
    [placeholder mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(7.f);
        make.centerY.equalTo(self.userAvaterImg);
    }];

    UIView *countBGView = [UIView new];
    countBGView.backgroundColor = UIColor.whiteColor;
    [self.view addSubview:countBGView];
    [countBGView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.offset(0);
        make.height.offset(42.f);
       // make.top.equalTo(textView.mas_bottom);
    }];
    self.countBGView = countBGView;
    UILabel *countLab = [[UILabel alloc] init];
    countLab.textColor = UIColorHex(#B2B2B2);
    countLab.text = @"0/1000";
    countLab.font = [UIFont systemFontOfSize:12.f];
    self.textCountLab = countLab;
    [countBGView addSubview:countLab];
    [countLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-24.f);
        make.bottom.offset(-15.f);
        make.height.offset(12.f);
    }];

//    UIView *dynamicTopicView = [[UIView alloc]init];
//    dynamicTopicView.backgroundColor = [UIColor redColor];
//    [self.view addSubview:dynamicTopicView];
//    [dynamicTopicView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.right.offset(0);
//        make.height.mas_greaterThanOrEqualTo(39.f);
//        make.bottom.equalTo(countBGView.mas_top);
//    }];
    
    if (self.topicId) {
        MGMDynamicTopicItemInfo *itemInfo = [[MGMDynamicTopicItemInfo alloc]init];
        itemInfo.topicId = self.topicId;
        itemInfo.name = self.topicName;
        itemInfo.selected = 1;
        [self.selectDynamicTopicItemArray mgu_safe_addObject:itemInfo];
    }
    MSSAutoresizeLabelFlow *flow = [[MSSAutoresizeLabelFlow alloc]initWithFrame:CGRectZero titles:(self.topicName ? @[self.topicName] : @[]) type:MSSAutoresizeLabelFlowTypeDynamicTopic selectedHandler:^(NSUInteger index, NSString *title) {
        //删除操作
        if (self.selectDynamicTopicItemArray.count>0) {
            [self.initialFlow reloadAllWithTitles:@[]];
            [self.selectDynamicTopicItemArray removeAllObjects];
            for (MGMDynamicTopicItemInfo *itemInfo in self.commitPictureView.topicTitleItemInfoArray) {
                if ([itemInfo.topicId isEqualToString:self.topicId]) {
                    itemInfo.selected = 0;
                }
            }
            [self.commitPictureView reloadTopicCollect];
        }
    }];
     [self.view addSubview:flow];
     self.initialFlow = flow;
     [flow mas_makeConstraints:^(MASConstraintMaker *make) {
         make.left.offset(15.0f);
         make.right.offset(-15.0f);
         make.top.mas_equalTo(self.contentTextView.mas_bottom).mas_equalTo(0);
         make.height.offset(30);
         make.bottom.mas_equalTo(countBGView.mas_top).mas_equalTo(kMGMHBL2X(4));
     }];
  
    _commitPictureView = [[MGMCommunityPicturesCommitView alloc] initWithFrame:CGRectZero pictures:nil bottomViewTapedAction:^{
       // [textView resignFirstResponder];
    }];
    [self.view addSubview:self.commitPictureView];
    [self.commitPictureView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.offset(0);
        make.top.equalTo(countBGView.mas_bottom);
    }];

    UIView *bottomMaskView = [UIView new];
    bottomMaskView.backgroundColor = UIColorHex(#F5F5F5);
    [self.view addSubview:bottomMaskView];
    [bottomMaskView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(self.view);
        make.top.equalTo(self.commitPictureView.mas_bottom);
    }];
    
    //[flow reloadAllWithTitles:@[@"1111"]];
    
    MGMWeakSelf
    self.commitPictureView.collectionViewCellAction = ^(NSInteger indexCell, BOOL isSelect) {
      MGMStrongSelf
        //点击cell事件
        NSInteger index = indexCell;
        if (self.selectDynamicTopicItemArray.count<3 && !isSelect && index<3) {
            MGMDynamicTopicItemInfo *info = self.commitPictureView.topicTitleItemInfoArray[index];
            [self.selectDynamicTopicItemArray mgu_safe_addObject:info];
            NSMutableArray *showTopicArray = [[NSMutableArray alloc]init];
            for (MGMDynamicTopicItemInfo *info in self.selectDynamicTopicItemArray) {
                [showTopicArray mgu_safe_addObject:info.name];
            }
            if (self.topicLabelFlow) {
                //更新选中标签
                [self.topicLabelFlow reloadAllWithTitles:showTopicArray.mutableCopy];
            }else{
                [flow removeFromSuperview];
                MSSAutoresizeLabelFlow *labelFlow = [[MSSAutoresizeLabelFlow alloc]initWithFrame:CGRectZero titles:showTopicArray.mutableCopy type:MSSAutoresizeLabelFlowTypeDynamicTopic selectedHandler:^(NSUInteger index, NSString *title) {
                    //选择了已选中标签，---删除次标签，并判断底部标签栏收否有这个标签，有的话变为可选
                        MGMDynamicTopicItemInfo *selectItemInfo = [self.selectDynamicTopicItemArray mgu_objectOrNilAtIndex:index];
                        NSString *selectTopicId = selectItemInfo.topicId;
                        for (int i = 0; i<self.commitPictureView.topicTitleItemInfoArray.count; i++) {
                            MGMDynamicTopicItemInfo *titleItemInfo = self.commitPictureView.topicTitleItemInfoArray[i];
                            NSString *titleTopicId = titleItemInfo.topicId;
                            if ([selectTopicId isEqualToString:titleTopicId]) {
                                MGMDynamicTopicItemInfo *mutItemInfo = titleItemInfo;
                                mutItemInfo.selected = NO;
                                [self.commitPictureView.topicTitleItemInfoArray replaceObjectAtIndex:i withObject:mutItemInfo];
                                [self.commitPictureView reloadTopicCollect];
                                break;
                            }
                        }
                    //删除选中标签并刷新
                    if (index<self.selectDynamicTopicItemArray.count) {
                        [self.selectDynamicTopicItemArray removeObjectAtIndex:index];
                        NSMutableArray *showTopicArray = [[NSMutableArray alloc]init];
                        for (MGMDynamicTopicItemInfo *itemInfo in self.selectDynamicTopicItemArray) {
                            [showTopicArray mgu_safe_addObject:itemInfo.name];
                        }
                        [self.topicLabelFlow reloadAllWithTitles:showTopicArray.mutableCopy];
                    }
                }];
               [self.view addSubview:labelFlow];
               self.topicLabelFlow = labelFlow;
               [labelFlow mas_makeConstraints:^(MASConstraintMaker *make) {
                   make.left.offset(15.0f);
                   make.right.offset(-15.0f);
                   make.top.mas_equalTo(self.contentTextView.mas_bottom).mas_equalTo(0);
                   make.height.offset(30);
                   make.bottom.equalTo(countBGView.mas_top);
               }];
               [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(numberOfLineNotificenter:) name:numberOfLineNotificenter object:nil];
            }
            //刷新底部标签
            MGMDynamicTopicItemInfo *mutItemInfo = info;
            mutItemInfo.selected = YES;
            NSMutableArray *replaceTopicArray = [[NSMutableArray alloc]initWithArray:self.commitPictureView.topicTitleItemInfoArray];
            [replaceTopicArray replaceObjectAtIndex:index withObject:mutItemInfo];
            self.commitPictureView.topicTitleItemInfoArray = replaceTopicArray;
            [self.commitPictureView reloadTopicCollect];
        }else if (index == 3){
            //跳转话题列表页
            NSDictionary *param = @{@"pushType": @"1",@"selectTopics": self.selectDynamicTopicItemArray};
            [MGMRoute routePageControllerWithName:@"community_moreTopics_page" parameters:param transitionStyle:(MGURouteTransitionStylePresent)];
            //发通知 接收用户选中的话题
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(mgm_updateDataWithSelectedTopics:) name:@"MGMDynamicMoreTopicsVCNotification" object:nil];
        }else{
            if (isSelect) {
                //提示不可选
                //[MGMProgressHUD showAutoHiddeText:@"话题已存在"];
            }else{
                //提示已经超过3个标签
                [MGMProgressHUD showAutoHiddeText:@"最多可添加3个话题"];
            }
        }
    };
}

#pragma mark - MGMDynamicFetchTopicListInfoDelegate
- (void)fetchTopicList:(nullable NSArray <MGMDynamicTopicItemModel *>*)topics error:(nullable NSError *)error{
    if (!error) {
        self.topicArray = [MGMDynamicTopicItemInfo mgm_fetchTopicsWithTopicArray:topics];
        if (self.topicArray.count >3) {
            for (int i=0; i<3; i++) {
                MGMDynamicTopicItemInfo *itemInfo = [self.topicArray mgu_objectOrNilAtIndex:i];
                if ([itemInfo.topicId isEqualToString:self.topicId]) {
                    itemInfo.selected = 1;
                }
                [self.dynamicTopicItemArray mgu_safe_addObject:itemInfo];
            }
            MGMDynamicTopicItemInfo *itemInfo = [[MGMDynamicTopicItemInfo alloc]init];
            itemInfo.name = @"更多话题";
            [self.dynamicTopicItemArray mgu_safe_addObject:itemInfo];
        }else{
            self.dynamicTopicItemArray = [[NSMutableArray alloc]initWithArray:self.topicArray];
        }
        //更新底部标签栏数据
        self.commitPictureView.topicTitleItemInfoArray = self.dynamicTopicItemArray;
        [self.commitPictureView reloadTopicCollect];
    }
}



- (void)numberOfLineNotificenter:(NSNotification *)notifi{
    NSString *num = [notifi.object valueForKey:@"lineNumber"];
    NSInteger lineNum = [num integerValue];
    [self.topicLabelFlow mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.offset((lineNum>3?3:lineNum)*30);
    }];
}
- (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size {
    if (!color || size.width <= 0 || size.height <= 0) return nil;

    CGRect rect = CGRectMake(0.0f, 0.0f, size.width, size.height);

    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);

    CGContextRef context = UIGraphicsGetCurrentContext();

    CGContextSetFillColorWithColor(context, color.CGColor);

    CGContextFillRect(context, rect);

    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();

    UIGraphicsEndImageContext();

    return image;
}

- (void)keyboardWillShowNotification:(NSNotification *)noti {
    CGFloat keyboardHeight = [noti.userInfo [UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    [self.commitPictureView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.offset(-keyboardHeight);
    }];
}

- (void)keyboardWillHideNotification:(NSNotification *)noti {
    CGFloat keyboardHeight = [noti.userInfo [UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    [self.commitPictureView mas_updateConstraints:^(MASConstraintMaker *make) {
        if (@available(iOS 11.0, *)) {
            make.bottom.offset(-self.view.safeAreaInsets.bottom);
        } else {
            make.bottom.offset(0);
        }
    }];
}

- (void)showPhotoPickerVC {
    LGPhotoPickerViewController *pickerVc = [[LGPhotoPickerViewController alloc] initWithShowType:LGShowImageTypeImagePicker];
    pickerVc.modalPresentationStyle = UIModalPresentationFullScreen;
    pickerVc.status = PickerViewShowStatusCameraRoll;
    pickerVc.maxCount = self.commitPictureView.maxPicturesCount;   // 最多能选9张图片
    pickerVc.delegate = self;
//    pickerVc.allowClipImage = YES;
    pickerVc.allowMultiSelected = YES;
    pickerVc.hideCameraItem = YES;
    pickerVc.topShowPhotoPicker = NO;
    pickerVc.allowPhotoPreview = YES;
    [pickerVc showPickerVc:self];
//    [self.navigationController pushViewController:pickerVc animated:YES];
}

- (void)presentCameraPikerController {
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        NSArray *mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];
        if ([mediaTypes containsObject:(NSString *)kUTTypeImage]) {
            AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
            switch (status) {
                case AVAuthorizationStatusNotDetermined: {//未选择
                    @weakify(self)
                    [AVCaptureDevice requestAccessForMediaType: AVMediaTypeVideo completionHandler:^(BOOL granted) {
                        if (granted) {
                            @strongify(self)
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [self presentViewController:self.imgPickerController animated:YES completion:nil];
                            });
                        }
                    }];
                }
                break;
                case AVAuthorizationStatusAuthorized: {//允许
                    [self presentViewController:self.imgPickerController animated:YES completion:nil];
                }
                break;
                case AVAuthorizationStatusRestricted: {//不可更改
                }
                break;
                case AVAuthorizationStatusDenied: {//以拒绝
                    NSString *message = @"未取得您的相机使用权限，请在应用设置中打开权限";
                    [self.view showAutoToastInWindowWithText:message];
                }
                break;
            }
        }
    }
}

- (void)showSelectImageAcionSheet {
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];

    __weak typeof(self) weakSelf = self;

    UIAlertAction *cameraAction = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
        [weakSelf presentCameraPikerController];
    }];
    [cameraAction setValue:[UIColor colorWithRed:26 / 255.0 green:26 / 255.0 blue:26 / 255.0 alpha:1.0] forKey:@"titleTextColor"];
    [actionSheet addAction:cameraAction];

    UIAlertAction *albumAction = [UIAlertAction actionWithTitle:@"手机相册" style:UIAlertActionStyleDefault handler:^(UIAlertAction *_Nonnull action) {
        [weakSelf showPhotoPickerVC];
    }];
    [actionSheet addAction:albumAction];
    [albumAction setValue:[UIColor colorWithRed:26 / 255.0 green:26 / 255.0 blue:26 / 255.0 alpha:1.0] forKey:@"titleTextColor"];

    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *_Nonnull action) {
        [self.contentTextView becomeFirstResponder];
    }];
    [cancelAction setValue:[UIColor colorWithRed:247 / 255.0 green:68 / 255.0 blue:68 / 255.0 alpha:1.0] forKey:@"titleTextColor"];
    [actionSheet addAction:cancelAction];
    [self presentViewController:actionSheet animated:YES completion:nil];
}

#pragma mark - Getter
- (UIImagePickerController *)imgPickerController {
    if (!_imgPickerController) {
        _imgPickerController = [[UIImagePickerController alloc] init];
        _imgPickerController.allowsEditing = YES;
        _imgPickerController.mediaTypes = @[(NSString *)kUTTypeImage];
        _imgPickerController.delegate = self;
        _imgPickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    }
    return _imgPickerController;
}
- (MGMDynamicFetchTopicListInfo *)topicListInfoManager{
    if (!_topicListInfoManager) {
        _topicListInfoManager = [[MGMDynamicFetchTopicListInfo alloc]initWithDelegate:self];
    }
    return _topicListInfoManager;
}
- (NSMutableArray<MGMDynamicTopicItemInfo *> *)dynamicTopicItemArray{
    if (!_dynamicTopicItemArray) {
        _dynamicTopicItemArray = [[NSMutableArray alloc]init];
    }
    return _dynamicTopicItemArray;
}
- (NSMutableArray<MGMDynamicTopicItemInfo *> *)selectDynamicTopicItemArray{
    if (!_selectDynamicTopicItemArray) {
        _selectDynamicTopicItemArray = [[NSMutableArray alloc]init];
    }
    return _selectDynamicTopicItemArray;
}
@end
