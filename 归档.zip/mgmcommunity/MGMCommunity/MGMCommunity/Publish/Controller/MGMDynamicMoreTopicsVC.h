//
//  MGMDynamicMoreTopicsVC.h
//  MGMCommunity
//
//  Created by wdlzh on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <MGMDisplay/MGMPageController.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMDynamicMoreTopicsVC : MGMPageController

@end

NS_ASSUME_NONNULL_END
