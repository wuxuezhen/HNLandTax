//
//  MGMPublishTimeLineVC.h
//  MGMCommunity
//
//  Created by YL on 2019/7/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <MGMDisplay/MGMPageController.h>

NS_ASSUME_NONNULL_BEGIN
@protocol MGMPublishTimeLineVCDelegate <NSObject>

@optional

/**
开始 发布
 */
- (void)dynamicPublishStart;

/**
 发布结束

 @param error error
 */
- (void)dynamicPublishEndWithError:(NSError *)error prompt:(NSString *)prompt;

/**
 点击关闭按钮
 */
- (void)publishPageCloseButtonDidClicked;
@end

@interface MGMPublishTimeLineVC : MGMPageController
@property (nonatomic, weak) id<MGMPublishTimeLineVCDelegate> delegate;

@property (nonatomic, strong) NSString *topicId;

@property (nonatomic, strong) NSString *topicName;

@end

NS_ASSUME_NONNULL_END
