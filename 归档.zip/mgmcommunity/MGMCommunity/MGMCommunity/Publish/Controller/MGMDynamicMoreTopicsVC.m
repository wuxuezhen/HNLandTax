//
//  MGMDynamicMoreTopicsVC.m
//  MGMCommunity
//
//  Created by wdlzh on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicMoreTopicsVC.h"

#import <Masonry/Masonry.h>
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGMCategories/UIColor+MGMColorExtension.h>
#import <MGMNavigation/MGMNavigationView.h>
#import <MGMUIKit/MGMRefresh.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMUIKit/MGMProgressHUD+MGMConfig.h>
#import <MGMRoute/MGMRoute.h>

#import "MGMDynamicMoreTopicsTopView.h"
#import "MGMDynamicMoreTopicsEmptyView.h"
#import "MGMDynamicMoreTopicsCell.h"

#import "MGMDynamicTopicBody.h"
#import "MGMDynamicFetchTopicListInfo.h"
#import "MGMDynamicTopicItemInfo.h"
#import "MGMCommunity.h"

static NSString *const MGMDynamicMoreTopicsCellID = @"MGMDynamicMoreTopicsCell";

@interface MGMDynamicMoreTopicsVC ()<UITableViewDelegate, UITableViewDataSource, MGMDynamicFetchTopicListInfoDelegate, MGMNavigationViewDelegate>
//自定义导航
@property (nonatomic, strong) MGMNavigationView            *navigationView;
//分割线
@property (nonatomic, strong) UIView                       *lineView;
//当从发布页面跳过来时，话题顶部view
@property(nonatomic, strong) MGMDynamicMoreTopicsTopView   *topView;
//话题列表
@property(nonatomic, strong) UITableView                   *tableView;
//空view
@property(nonatomic, strong) MGMDynamicMoreTopicsEmptyView *emptyView;
//网络请求类
@property(nonatomic, strong) MGMDynamicFetchTopicListInfo  *topicListInfo;
//跳转到更多话题的入口类型
@property(nonatomic, assign) MGMDynamicMoreTopicsPushType  pushType; 
//话题数据
@property(nonatomic, strong) NSMutableArray               *topicArray;
//已经被选的话题数据
@property(nonatomic, strong) NSMutableArray               *selectedTopicArray;

@end

@implementation MGMDynamicMoreTopicsVC

#pragma mark - cycleLife
-(void)setupParameters:(NSDictionary *)params
{
    [super setupParameters:params];
    if(![params isKindOfClass:[NSDictionary class]])
    {
        return; //数据异常
    }
    
    NSDictionary *paramDic = [params copy];
    if (paramDic)
    {
        self.pushType = [[paramDic mgu_objectOrNilForKey:@"pushType"] integerValue];
        if ([[paramDic mgu_objectOrNilForKey:@"selectTopics"] isKindOfClass:[NSArray class]])
        {
            self.selectedTopicArray = [[paramDic mgu_objectOrNilForKey:@"selectTopics"] mutableCopy];
        }
    }
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    [self mgm_setData];
    [self mgm_setUI];
}

-(void)mgm_setData
{
    [self mgm_fetchTopicList];
}

-(void)mgm_setUI
{
    self.view.backgroundColor = [UIColor dealHexString:@"#F5F5F5"];
    
    [self.view addSubview:self.navigationView];
    [self.view addSubview:self.lineView];
    [self.view addSubview:self.emptyView];
    [self.view addSubview:self.tableView];
    
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.navigationView.mas_bottom);
        make.left.right.equalTo(self.view);
        make.height.mas_equalTo(0.25);
    }];
    
    [self.emptyView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineView.mas_bottom);
        make.left.right.equalTo(self.view);
        make.bottom.equalTo(self.view.mas_bottom).offset(MGMXSafeH);
    }];

    if (self.pushType == MGMDynamicMoreTopicsDefault)
    {
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.lineView.mas_bottom);
            make.left.right.equalTo(self.view);
            make.bottom.equalTo(self.view.mas_bottom).offset(MGMXSafeH);
        }];
    }
    else
    {
        [self.view addSubview:self.topView];
        
        [self.topView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.lineView.mas_bottom);
            make.left.right.equalTo(self.view);
            make.height.mas_equalTo(MGMScaleValue(37.f));
        }];
        
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.topView.mas_bottom);
            make.left.right.equalTo(self.view);
            make.bottom.equalTo(self.view.mas_bottom).offset(MGMXSafeH);
        }];
    }
}

#pragma mark - MGMDynamicFetchTopicListInfoDelegate
- (void)fetchTopicList:(nullable NSArray <MGMDynamicTopicItemModel *>*)topics error:(nullable NSError *)error
{
    if (error)
    {
         [self.tableView.mj_footer endRefreshing];
         [self.tableView.mj_header endRefreshing];
         
         if (error.code == MGMDMErrorCodeAPIResponseNoMoreData)
         {
             [self mgm_hideMoreFooter];
             [self mgm_reloadUIWithIsEmpty:self.topicArray.count > 0?NO:YES isError:NO];
         }
        else
        {
            [self mgm_reloadUIWithIsEmpty:YES isError:YES];
            NSLog(@"MGMDynamicMoreTopicsVC error:%@",error);
        }
    }
    else
    {
        //  下拉刷新
        if ([self.tableView.mj_header isRefreshing] || ![self.tableView.mj_footer isRefreshing])
        {
            [self.tableView.mj_header endRefreshing];
            [self.topicArray removeAllObjects];
            [self.tableView.mj_footer resetNoMoreData];
        }
        //  上拉加载
        else if ([self.tableView.mj_footer isRefreshing])
        {
            [self.tableView.mj_footer endRefreshing];
        }
        
        NSArray *topicData = [MGMDynamicTopicItemInfo mgm_fetchTopicsWithTopicArray:topics];
        NSArray *array = [MGMDynamicTopicItemInfo mgm_fetchSelectedTopicArrayWithAllTopics:topicData selectedTopics:self.selectedTopicArray];
        [self.topicArray addObjectsFromArray:array];
        [self mgm_reloadUIWithIsEmpty:self.topicArray.count > 0?NO:YES isError:NO];
    }
    
    [self.tableView reloadData];
}

-(void)mgm_reloadUIWithIsEmpty:(BOOL)isEmpty isError:(BOOL)isError
{
    if (isEmpty)
    {
        [self.emptyView mgm_reloadUIWithIsError:isError];
        self.topView.hidden = YES;
        self.tableView.hidden = YES;
        self.emptyView.hidden = NO;
    }
    else
    {
        self.topView.hidden = NO;
        self.tableView.hidden = NO;
        self.emptyView.hidden = YES;
    }
}

#pragma mark - MGMNavigationViewDelegate
- (void)navigationViewDidTapBack:(MGMNavigationView *)navView
{
    if (self.pushType == MGMDynamicMoreTopicsDefault)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    }
}

#pragma mark - UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.topicArray.count;
}

-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MGMDynamicMoreTopicsCell *cell = [tableView dequeueReusableCellWithIdentifier:MGMDynamicMoreTopicsCellID forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    MGMDynamicTopicItemInfo *topicItemInfo = [self.topicArray mgu_objectOrNilAtIndex:indexPath.row];
    [cell mgm_reupdateWithTopicItemModel:topicItemInfo row:indexPath.row pushType:self.pushType];
    return cell;
}

#pragma mark - UITableViewDelegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return MGMScaleValue(70.5f);
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *topics = [self.topicArray copy];
    MGMDynamicTopicItemInfo *itemInfo = [topics mgu_objectOrNilAtIndex:indexPath.row];
    if (self.pushType == MGMDynamicMoreTopicsDefault)
    {
        //进入话题详情页
        if([itemInfo.topicId mgu_isNotBlank])
        {
            NSMutableDictionary *param = [NSMutableDictionary dictionary];
            [param mgu_safe_setObject:itemInfo.topicId forKey:MGMCommunityRouteTopicId];
            [MGMRoute routePageControllerWithName:@"community_topicDetail_page" parameters:param transitionStyle:(MGURouteTransitionStyleNav)];
        }
    }
    else
    {
        //数据处理
        if (itemInfo.selected) return;
        
        if (self.selectedTopicArray.count < 3 && !itemInfo.selected)
        {
            itemInfo.selected = YES;
            [self.topicArray replaceObjectAtIndex:indexPath.row withObject:itemInfo];
            [self.tableView reloadData];
        }

        [self.navigationController dismissViewControllerAnimated:YES completion:^{
            if (self.selectedTopicArray.count >= 3)
            {
                [MGMProgressHUD showAutoHiddeText:@"最多可添加3个话题"];
            }
            else
            {
                //数据处理发通知
                [self.selectedTopicArray addObject:itemInfo];
                NSDictionary *param = @{@"selectTopics": self.selectedTopicArray};
                [[NSNotificationCenter defaultCenter] postNotificationName:@"MGMDynamicMoreTopicsVCNotification" object:nil userInfo:param];
            }
        }];
    }
}

#pragma mark - setter & getter
-(MGMNavigationView *)navigationView
{
    if (!_navigationView) {
        _navigationView = [MGMNavigationView backNavWithTitle:@"更多话题"];
        _navigationView.delegate = self;
        
        UIButton *backBtn = (UIButton *)[_navigationView viewWithTag:102];
        if (self.pushType == MGMDynamicMoreTopicsPublishType)
        {
            [backBtn setImage:[UIImage imageNamed:@"MGMCommunityResource.bundle/icon_close"] forState:UIControlStateNormal];
        }
    }
    return _navigationView;
}

-(UIView *)lineView
{
    if (!_lineView) {
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = [UIColor dealHexString:@"#E2E2E2"];
    }
    return _lineView;
}

-(UITableView *)tableView
{
    if (!_tableView){
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.hidden = YES;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.showsHorizontalScrollIndicator = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView registerClass:[MGMDynamicMoreTopicsCell class] forCellReuseIdentifier:MGMDynamicMoreTopicsCellID];
        
        MGMWeakSelf;
        MGMRefrshGifHeader *header = [MGMRefrshGifHeader headerWithRefreshingBlock:^{
            MGMStrongSelf;
            [self mgm_fetchTopicList];
        }];
        _tableView.mj_header = header;
        
        MJRefreshAutoNormalFooter *footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(mgm_fetchMoreTopicList)];
        [footer setTitle:@"加载中..." forState:MJRefreshStateRefreshing];
        [footer setTitle:@"" forState:MJRefreshStateIdle];
        [footer setTitle:@"—— 我也是有底线的 ——" forState:MJRefreshStateNoMoreData];
        footer.stateLabel.textColor = [UIColor dealHexString:@"#BDBDBD"];
        footer.stateLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size: MGMScaleValue(11.f)];
        _tableView.mj_footer = footer;
    }
    return _tableView;
}

-(MGMDynamicMoreTopicsTopView *)topView
{
    if (!_topView) {
        _topView = [[MGMDynamicMoreTopicsTopView alloc]init];
        _topView.hidden = YES;
    }
    return _topView;
}

-(MGMDynamicMoreTopicsEmptyView *)emptyView
{
    if (!_emptyView) {
        _emptyView = [[MGMDynamicMoreTopicsEmptyView alloc]init];
        _emptyView.hidden = YES;
        MGMWeakSelf;
        _emptyView.refreshHandler = ^{
            MGMStrongSelf;
            [self mgm_fetchTopicList];
        };
    }
    return _emptyView;
}

-(MGMDynamicFetchTopicListInfo *)topicListInfo
{
    if (!_topicListInfo) {
        _topicListInfo = [[MGMDynamicFetchTopicListInfo alloc] initWithDelegate:self];
    }
    return _topicListInfo;
}

-(NSMutableArray *)topicArray
{
    if (!_topicArray) {
        _topicArray = [NSMutableArray array];
    }
    return _topicArray;
}

-(NSMutableArray *)selectedTopicArray
{
    if (!_selectedTopicArray) {
        _selectedTopicArray = [NSMutableArray array];
    }
    return _selectedTopicArray;
}

#pragma makr - privateMethods
//刷新话题列表
-(void)mgm_fetchTopicList
{
    [self.topicListInfo fetchTopicList];
}

//获取更多话题列表
-(void)mgm_fetchMoreTopicList
{
    [self.topicListInfo fetchMoreTopicList];
}

- (void)mgm_hideMoreFooter
{
    [self.tableView.mj_footer endRefreshingWithNoMoreData];
    self.tableView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f);
}

@end
