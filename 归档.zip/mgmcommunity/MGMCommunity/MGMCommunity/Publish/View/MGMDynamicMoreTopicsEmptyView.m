//
//  MGMDynamicMoreTopicsEmptyView.m
//  MGMCommunity
//
//  Created by wdlzh on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicMoreTopicsEmptyView.h"

#import <Masonry/Masonry.h>
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGMCategories/UIColor+MGMColorExtension.h>

@interface MGMDynamicMoreTopicsEmptyView ()
//为空icon
@property (nonatomic, strong) UIImageView *emptyImageView;
//为空提示语
@property (nonatomic, strong) UILabel     *promptLable;
//刷新按钮
@property (nonatomic, strong) UIButton    *refreshBtn;

@end

@implementation MGMDynamicMoreTopicsEmptyView
#pragma mark - cycleLiffe
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self mgm_setUI];
    }
    return self;
}

-(void)mgm_setUI
{
    [self addSubview:self.emptyImageView];
    [self addSubview:self.promptLable];
    
    [self.emptyImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.mas_centerX);
        make.top.equalTo(self.mas_top).offset(MGMScaleValue(260.f));
        make.width.mas_equalTo(MGMScaleValue(123.5f));
        make.height.mas_equalTo(MGMScaleValue(95.f));
    }];
    
    [self.promptLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.emptyImageView.mas_centerX);
        make.top.equalTo(self.emptyImageView.mas_bottom).offset(MGMScaleValue(17.f));
    }];
}

-(void)mgm_reloadUIWithIsError:(BOOL)isError
{
    if (self.refreshBtn)
    {
        [self.refreshBtn removeFromSuperview];
    }
    
    if (isError)
    {
        self.emptyImageView.image = [UIImage imageNamed:@"MGMCommunityResource.bundle/icon_wwl"];
        self.promptLable.text = @"没有网络啦，快去检查下";
        [self addSubview:self.refreshBtn];
        
        [self.emptyImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.mas_centerX);
            make.top.equalTo(self.mas_top).offset(MGMScaleValue(120.f));
            make.width.height.mas_equalTo(MGMScaleValue(190.f));
        }];
        
        [self.refreshBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.emptyImageView.mas_centerX);
            make.top.equalTo(self.promptLable.mas_bottom).offset(MGMScaleValue(13.f));
            make.width.mas_offset(MGMScaleValue(100.f));
            make.height.mas_offset(MGMScaleValue(40.f));
        }];
    }
    else
    {
        self.emptyImageView.image = [UIImage imageNamed:@"MGMCommunityResource.bundle/img_ssk"];
        self.promptLable.text = @"未搜到匹配的内容";
        
        [self.emptyImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.mas_centerX);
            make.top.equalTo(self.mas_top).offset(MGMScaleValue(260.f));
            make.width.mas_equalTo(MGMScaleValue(123.5f));
            make.height.mas_equalTo(MGMScaleValue(95.f));
        }];
    }
}

#pragma mark - action & target
-(void)mgm_reload
{
    if(self.refreshHandler) {
        self.refreshHandler();
    }
}

#pragma mark - setter & getter
-(UIImageView *)emptyImageView
{
    if(!_emptyImageView){
        _emptyImageView = [[UIImageView alloc]init];
    }
    return _emptyImageView;
}

-(UILabel *)promptLable
{
    if (!_promptLable) {
        _promptLable = [[UILabel alloc]init];
        _promptLable.textColor = [UIColor dealHexString:@"#999999"];
        _promptLable.font = [UIFont fontWithName:@"PingFangSC-Regular" size:MGMScaleValue(15.f)];
    }
    return _promptLable;
}

-(UIButton *)refreshBtn{
    if (!_refreshBtn) {
        _refreshBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _refreshBtn.backgroundColor = [UIColor dealHexString:@"#FF3E40"];
        [_refreshBtn setTitleColor:[UIColor dealHexString:@"#FFFFFF"] forState:UIControlStateNormal];
        [_refreshBtn setTitle:@"刷新" forState:UIControlStateNormal];
        _refreshBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:MGMScaleValue(16.f)];
        _refreshBtn.layer.masksToBounds = YES;
        _refreshBtn.layer.cornerRadius = MGMScaleValue(20.f);
        [_refreshBtn addTarget:self action:@selector(mgm_reload) forControlEvents:UIControlEventTouchUpInside];
    }
   return _refreshBtn;
}

@end
