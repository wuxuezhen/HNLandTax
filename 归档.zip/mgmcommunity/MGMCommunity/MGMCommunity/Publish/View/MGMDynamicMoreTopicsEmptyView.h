//
//  MGMDynamicMoreTopicsEmptyView.h
//  MGMCommunity
//
//  Created by wdlzh on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMDynamicMoreTopicsEmptyView : UIView

@property (nonatomic, copy) dispatch_block_t refreshHandler;

/*
 *  刷新h更多话题列表为空和网路出错UI界面
 *
 *  @param isError 是否为网络出错界面
 */
-(void)mgm_reloadUIWithIsError:(BOOL)isError;

@end

NS_ASSUME_NONNULL_END
