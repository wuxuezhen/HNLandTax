//
//  MGMDynamicMoreTopicsCell.m
//  MGMCommunity
//
//  Created by wdlzh on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicMoreTopicsCell.h"

#import <Masonry/Masonry.h>
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGMCategories/UIColor+MGMColorExtension.h>

@interface MGMDynamicMoreTopicsCell ()

//右边icon
@property (nonatomic, strong) UIImageView *topicImageView;
//话题名字
@property (nonatomic, strong) UILabel     *topicName;
//讨论条数
@property (nonatomic, strong) UILabel     *discussNumLable;
//话题选中按钮
@property (nonatomic, strong) UIButton    *topicSelectedBtn;
//分割线
@property (nonatomic, strong) UIView      *lineView;

@end

@implementation MGMDynamicMoreTopicsCell
#pragma mark - cycleLife

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self mgm_setUI];
    }
    return self;
}

-(void)mgm_setUI
{
    
    [self.contentView addSubview:self.topicImageView];
    [self.contentView addSubview:self.topicName];
    [self.contentView addSubview:self.discussNumLable];
    [self.contentView addSubview:self.topicSelectedBtn];
    [self.contentView addSubview:self.lineView];
    
    [self.topicImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView.mas_top).offset(MGMScaleValue(15.f));
        make.left.equalTo(self.contentView.mas_left).offset(MGMScaleValue(15.f));
        make.width.height.mas_equalTo(MGMScaleValue(40.f));
    }];
    
    [self.topicName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.topicImageView.mas_right).offset(MGMScaleValue(10.f));
        make.top.equalTo(self.topicImageView.mas_top).offset(MGMScaleValue(-1.f));
        make.right.equalTo(self.contentView.mas_right).offset(MGMScaleValue(-50.f));
    }];
    
    [self.discussNumLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.topicImageView.mas_right).offset(MGMScaleValue(10.f));
        make.top.equalTo(self.topicName.mas_bottom).offset(MGMScaleValue(4.f));
    }];
    
    [self.topicSelectedBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.right.equalTo(self.contentView.mas_right).offset(MGMScaleValue(-15.f));
        make.width.height.mas_equalTo(MGMScaleValue(15.f));
    }];
    
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(MGMScaleValue(15.f));
        make.right.equalTo(self.contentView.mas_right).offset(MGMScaleValue(-15.f));
        make.height.mas_equalTo(0.5);
        make.bottom.equalTo(self.contentView.mas_bottom).offset(-0.5);
    }];
}

-(void)mgm_reupdateWithTopicItemModel:(MGMDynamicTopicItemInfo *)topicItemInfo row:(NSInteger)row pushType:(MGMDynamicMoreTopicsPushType)pushType
{
    if (row % 2 == 0)
    {
        self.topicImageView.image = [UIImage imageNamed:@"MGMCommunityResource.bundle/icon_gdht1"];
    }
    else
    {
        self.topicImageView.image = [UIImage imageNamed:@"MGMCommunityResource.bundle/icon_gdht"];
    }
    self.topicName.text = [NSString stringWithFormat:@"#%@#",topicItemInfo.name];
    self.discussNumLable.text = [NSString stringWithFormat:@"%ld条讨论",topicItemInfo.dynamicCount];
    
    if (pushType == MGMDynamicMoreTopicsPublishType)
    {
        self.topicSelectedBtn.hidden = !topicItemInfo.selected;
    }
}

#pragma makr - setter & getter
-(UIImageView *)topicImageView
{
    if (!_topicImageView) {
        _topicImageView = [[UIImageView alloc]init];
    }
    return _topicImageView;
}

-(UILabel *)topicName
{
    if (!_topicName) {
        _topicName = [[UILabel alloc]init];
        _topicName.textColor = [UIColor dealHexString:@"#1A1A1A"];
        _topicName.font = [UIFont fontWithName:@"PingFangSC-Regular" size:MGMScaleValue(15.f)];
    }
    return _topicName;
}

-(UILabel *)discussNumLable
{
    if (!_discussNumLable) {
        _discussNumLable = [[UILabel alloc]init];
        _discussNumLable.textColor = [UIColor dealHexString:@"#999999"];
        _discussNumLable.font = [UIFont fontWithName:@"PingFangSC-Regular" size:MGMScaleValue(12.f)];
    }
    return _discussNumLable;
}

-(UIButton *)topicSelectedBtn
{
    if (!_topicSelectedBtn) {
        _topicSelectedBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_topicSelectedBtn setImage:[UIImage imageNamed:@"MGMCommunityResource.bundle/icon_htyx30"] forState:UIControlStateNormal];
        _topicSelectedBtn.hidden = YES;
    }
    return _topicSelectedBtn;
}

-(UIView *)lineView
{
    if (!_lineView) {
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = [UIColor dealHexString:@"#E2E2E2"];
    }
    return _lineView;
}

@end
