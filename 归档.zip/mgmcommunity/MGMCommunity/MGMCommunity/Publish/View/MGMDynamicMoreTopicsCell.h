//
//  MGMDynamicMoreTopicsCell.h
//  MGMCommunity
//
//  Created by wdlzh on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MGMDynamicTopicItemInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMDynamicMoreTopicsCell : UITableViewCell
/*
 *  刷新数据
 *  @param topicItemInfo 话题对象
 *  @param row 第几行 为了判断最左边图片显示 除2取余 余数为0为红色icon，余数为1为蓝色icon
 */
-(void)mgm_reupdateWithTopicItemModel:(MGMDynamicTopicItemInfo *)topicItemInfo row:(NSInteger)row pushType:(MGMDynamicMoreTopicsPushType)pushType;

@end

NS_ASSUME_NONNULL_END
