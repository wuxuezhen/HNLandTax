//
//  MGMDynamicMoreTopicsTopView.m
//  MGMCommunity
//
//  Created by wdlzh on 2020/1/8.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicMoreTopicsTopView.h"

#import <Masonry/Masonry.h>
#import <MGMUIKit/MGMGlabalMacro.h>
#import <MGMCategories/UIColor+MGMColorExtension.h>

@interface MGMDynamicMoreTopicsTopView ()
//提示 '每条动态最多可添加3个话题'
@property(nonatomic, strong) UILabel *promptLable;

@end

@implementation MGMDynamicMoreTopicsTopView
#pragma mark - cycleLife

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor dealHexString:@"#FFF6EC"];
        [self mgm_setUI];
    }
    return self;
}

-(void)mgm_setUI
{
    [self addSubview:self.promptLable];
    [self.promptLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
    }];
}

#pragma mark - setter & getter
-(UILabel *)promptLable
{
    if (!_promptLable) {
        _promptLable = [[UILabel alloc]init];
        _promptLable.textColor = [UIColor dealHexString:@"#F5A623"];
        _promptLable.font = [UIFont fontWithName:@"PingFangSC-Regular" size:MGMScaleValue(13.f)];
        _promptLable.text = @"每条动态最多可添加3个话题";
    }
    return _promptLable;
}

@end
