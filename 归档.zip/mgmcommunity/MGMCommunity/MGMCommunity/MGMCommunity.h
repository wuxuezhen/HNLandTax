//
//  MGMCommunity.h
//  MGMCommunity
//
//  Created by apple on 2018/12/5.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#ifndef MGMCommunity_h
#define MGMCommunity_h
#import <UIKit/UIKit.h>
#import <MGMUIKit/MGMGlabalMacro.h>

#define MGMItemSpace 15.f
#define MGMItemInnerSpace 7.5f
#define MGMUserProfileH   75.f
#define MGMRowCount 3
#define MGMItemSizeW floorf(((MGMScreenW - (2 * MGMItemSpace) - (2 * MGMItemInnerSpace)) / MGMRowCount))

// MARK: Cell ReuseIdentifer

static NSString *const MGMStagePhotoTimeLineCellID = @"MGMStagePhotoTimeLineCell";
static NSString *const MGMImageAndTextTimeLineCellID = @"MGMImageAndTextTimeLineCell";

// MARK: - Responder Event

static NSString const *MGMCommunityRouteTopicId = @"MGMCommunityRouteTopicId";
static NSString const *MGMCommunityMainInfo = @"MGMCommunityMainInfo";
static NSString const *MGMCommunityExtraInfo = @"MGMCommunityExtraInfo";
static NSString const *MGMCommunityClickComment = @"MGMCommunityClickComment";
static NSString const *MGMCommunityShareImage = @"MGMCommunityShareImage";
static NSString const *MGMCommunityCellToolBarCommentRouterName = @"MGMCommunityCellToolBarCommentRouteName";
static NSString const *MGMCommunityLikeInfo = @"MGMCommunityLikeInfo";
static NSString const *MGMCommunityLikeEvent = @"MGMCommunityLikeEvent";
static NSString const *MGMCommunityCellToolBarShareRouterName = @"MGMCommunityCellToolBarShareRouterName";
static NSString const *MGMCommunityCellBodyTextCloseOrOpenRouterName = @"MGMCommunityCellBodyTextCloseOrOpenRouterName";
static NSString const *MGMCommunityTopicClickEvent = @"MGMCommunityTopicClickEvent";
static NSString const *MGMCommunityTopicClickIndex = @"MGMCommunityTopicClickIndex";
static NSString const *MGMCommunityPhotoClickEvent = @"MGMCommunityPhotoClickEvent";
static NSString const *MGMCommunityPhotoClickIndex = @"MGMCommunityPhotoClickIndex";
static NSString const *MGMCommunityUserAvatarEvent = @"MGMCommunityUserAvatarEvent";
static NSString const *MGMCommunityUserNameEvent = @"MGMCommunityUserNameEVent";
static NSString const *MGMCommunityFilmContentID = @"MGMCommunityFilmContentID";
static NSString const *MGMCommunityFilmKID = @"MGMCommunityFilmKID";
static NSString const *MGMCommunityFilmContentName = @"MGMCommunityFilmContentName";
static NSString const *MGMCommunityFilmEvent = @"MGMCommunityFilmEvent";
static NSString const *MGMCommunityMiniVideoType = @"MGMCommunityMiniVideoType";
static NSString const *MGMCommunityMiniVideoContentID = @"MGMCommunityMiniVideoContentID";
static NSString const *MGMCommunityMiniVideoContentName = @"MGMCommunityMiniVideoContentName";
static NSString const *MGMCommunityMiniVideoEvent = @"MGMCommunityMiniVideoEvent";
static NSString const *MGMCommunityGeKePlayEvent = @"MGMCommunityGeKePlayEvent";
static NSString const *MGMCommunityFilmCollectionID = @"MGMCommunityFilmCollectionID";
static NSString const *MGMCommunityFilmCollectionEvent = @"MGMCommunityFilmCollectionEvent";
static NSString const *MGMCommunityStagePhotoEvent = @"MGMCommunityStagePhotoEvent";
static NSString const *MGMCommunityStagePhotoClickEvent = @"MGMCommunityStagePhotoClickEvent";
static NSString const *MGMCommunityShareEvent = @"MGMCommunityShareEvent";
static NSString const *MGMCommunityTopicEvent = @"MGMCommunityTopicEvent";
static NSString const *MGMCommunityImageTextClickEvent = @"MGMCommunityImageTextClickEvent";
static NSString const *MGMCommunityImageTextMainCommentEvent = @"MGMCommunityImageTextMainCommentEvent";
static NSString const *MGMCommunityMoreEvent = @"MGMCommunityMoreEvent";
static NSString const *MGMCommunityCommentTrackEvent = @"MGMCommunityCommentTrackEvent";
static NSString const *MGMCommunityMainCommentEvent = @"MGMCommunityMainCommentEvent";
static NSString const *MGMCommunitySubCommentEvent = @"MGMCommunitySubCommentEvent";
static NSString const *MGMCommunityFollowEvent = @"MGMCommunityFollowEvent";
static NSString const *MGMCommunityReportEvent = @"MGMCommunityReportEvent";
static NSString const *MGMCommunityDeleteEvent = @"MGMCommunityDeleteEvent";
static NSString const *MGMCommunityDetailLikeSubCommentRouterName = @"MGMCommunityDetailLikeSubCommentRouterName";

#endif /* MGMCommunity_h */
