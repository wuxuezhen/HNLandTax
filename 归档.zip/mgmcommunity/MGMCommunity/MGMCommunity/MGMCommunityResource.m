//
//  MGMCommunityResource.m
//  MGMCommunity
//
//  Created by apple on 2018/12/3.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityResource.h"

@implementation MGMCommunityResource



+ (UIImage *)originalRenderingImageNamed:(NSString *)name {
    return [self originalRenderingModeImageWithName:name];
}

@end
