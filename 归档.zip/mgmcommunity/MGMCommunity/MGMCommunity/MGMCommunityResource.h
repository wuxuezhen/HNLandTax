//
//  MGMCommunityResource.h
//  MGMCommunity
//
//  Created by apple on 2018/12/3.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MGMCategories/MGMCategoryBaseResource.h>

@interface MGMCommunityResource : MGMCategoryBaseResource

+ (UIImage *)originalRenderingImageNamed:(NSString *)name;
@end
