//
//  MGMPageController+MGMDynamic.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMPageController+MGMDynamic.h"
#import "MGMCommunity.h"
#import "MGMCommunityGotoLogin.h"
#import "MGMCommunityResource.h"
#import "MGMTimeLineImageTextModel.h"
#import "MGMTimeLineStagePhotoModel.h"
#import <MGMRoute/MGMRoute.h>
#import <MGMShare/MGMShare.h>
#import <MGMLoginSDK/WXApi.h>
#import <MGMUIKit/MGMRefrshGifHeader.h>
#import <MGMUIKit/MGMUIKitResource.h>
#import <MGMCategories/UIImage+MGMUIKit.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <objc/message.h>
#import <MGMDataStore/MGMDCommonSettingConfig.h>
#import <YYWebImage/YYWebImageManager.h>
#import <MGUHttpApiCore/MGUHttpApiFactory.h>
#import <MGUCategoryUtil/UIImage+MGUExtension.h>

@implementation MGMPageController (MGMDynamic)

#pragma mark - Public

- (void)mgm_popDeleteAlertViewWithCancelHandler:(void (^)(UIAlertAction * _Nonnull))cancelHandler
                                 confirmHandler:(void (^)(UIAlertAction * _Nonnull))confirmHandler
{
    NSString *title = @"确定删除本条动态吗?";
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title
                                                                             message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    NSMutableAttributedString *attrTitle = [[NSMutableAttributedString alloc] initWithString:title];
    [attrTitle addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0]
                      range:NSMakeRange(0, title.length)];
    [attrTitle addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"PingFangSC-Regular" size:12]
                      range:NSMakeRange(0, title.length)];
    [alertController setValue:attrTitle forKey:@"attributedTitle"];
    
    NSString *actionTitleColor = @"titleTextColor";
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        !cancelHandler ?: cancelHandler(action);
    }];
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        !confirmHandler ?: confirmHandler(action);
       
    }];
    [cancelAction setValue:[UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1.0]
                    forKey:actionTitleColor];
    [confirmAction setValue:[UIColor colorWithRed:255/255.0 green:62/255.0 blue:64/255.0 alpha:1.0]
                     forKey:actionTitleColor];
    [alertController addAction:cancelAction];
    [alertController addAction:confirmAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)mgm_presentPublishPageController:(UIViewController *)publishPageController
{
    if ([MGMDSUser user].isLogin)
    {
        [self presentViewController:publishPageController animated:YES completion:nil];
    }
    else
    {
        [[MGMLoginManager shareManager] verifyLoginStateSuccess:nil failure:nil];
    }
}

- (void)mgm_resetRefreshFooterWithListView:(UITableView *)listView
{
    if (!self.hideFooter) return;
    
    self.hideFooter = NO;
    listView.mj_footer.hidden = NO;
    [listView.mj_footer resetNoMoreData];
    UIEdgeInsets edgeInsets = listView.contentInset;
    listView.contentInset = UIEdgeInsetsMake(edgeInsets.top,
                                             edgeInsets.left,
                                             edgeInsets.bottom + listView.mj_footer.mj_h,
                                             edgeInsets.right);}

- (void)mgm_hideRefreshFooterWithListView:(UITableView *)listView
                               totalCount:(NSInteger)totalCount
{
    if (listView.mj_footer.hidden) return;
      
    //  数据大于等于10条显示上拉加载控件
    NSInteger showFooterMinCount = 10;
    BOOL hide = (totalCount < showFooterMinCount);
    listView.mj_footer.hidden = hide;
    
    //  如果上拉加载控件没有隐藏,则设置内边距调整上拉加载控件位置
    if (self.isHideFooter || hide) return;
    
    self.hideFooter = YES;
    [listView.mj_footer endRefreshingWithNoMoreData];
    UIEdgeInsets edgeInsets = listView.contentInset;
    listView.contentInset = UIEdgeInsetsMake(edgeInsets.top,
                                             edgeInsets.left,
                                             edgeInsets.bottom - listView.mj_footer.mj_h,
                                             edgeInsets.right);
}

- (void)mgm_showPublishView:(UIView *)publishView
               publishCount:(NSInteger)publishCount
                     status:(MGMDyanmicPublishStatus)status
                     prompt:(NSString *)prompt
{
    NSString *title = @"正在发布动态...";
    UIImage *iconImage = nil;
    switch (status) {
        case MGMDyanmicPublishStatusSending:
        {
            if (publishCount > 1)
            {
                title = [NSString stringWithFormat:@"正在发布动态(%zd)...",publishCount];
            }
            iconImage = [MGMCommunityResource imageNamed:@"icon_fbz"];
        }
            break;
            
        case MGMDyanmicPublishStatusSuccess:
        {
            title = prompt.length > 0 ? prompt : @"发布成功，小编正在加速审核";
            iconImage = [MGMCommunityResource imageNamed:@"icon_fbcg"];
        }
            break;
            
        default:
        {
            title = prompt.length > 0 ? prompt : @"发布失败，请稍后再试";
            iconImage = [MGMCommunityResource imageNamed:@"icon_fbsb"];
            publishView.userInteractionEnabled = YES;
        }
            break;
    }
    [self.view addSubview:publishView];
    [self.mgm_publishIndicatorView setTitle:title forState:(UIControlStateNormal)];
    [self.mgm_publishIndicatorView setImage:iconImage forState:(UIControlStateNormal)];
}

- (void)mgm_dismissPublishView:(UIView *)publishView
{
    publishView.hidden = YES;
    [publishView removeFromSuperview];
}

- (void)mgm_adjustContentInset:(UIEdgeInsets)contentInset
                 contentOffset:(CGPoint)contentOffset
                   forListView:(UITableView *)listView
{
    listView.contentInset = contentInset;
    [listView setContentOffset:contentOffset animated:YES];
}

- (void)mgm_resetListView:(UITableView *)listView
{
    listView.contentInset = UIEdgeInsetsZero;
    [listView setContentOffset:CGPointZero animated:YES];
}

- (BOOL)mgm_shouldHandleEventName:(NSString *)eventName
                         userInfo:(NSDictionary *)userInfo
                         position:(NSInteger)position
                         location:(NSString *)location
{
    if (!eventName.length || !userInfo) return NO;
    
    BOOL handle = YES;
    MGMDynamicModel *extraInfo = userInfo[MGMCommunityExtraInfo];
    //  图文图片事件
    if ([eventName isEqualToString:MGMCommunityPhotoClickEvent])
    {
        MGMTimeLineImageTextModel *imageTextModel = (MGMTimeLineImageTextModel *)extraInfo;
        NSInteger picIndex = [[userInfo mgu_objectOrNilForKey:MGMCommunityPhotoClickIndex] integerValue];
        [self.nextResponder routerEventWithName:eventName userInfo:userInfo];
        [self mgm_presentPhotoBrowsePageControllerWithPicIndex:picIndex
                                                       picUrls:imageTextModel.picUrls
                                                        feedId:imageTextModel.feedId];
    }
    //  剧照图片事件
    else if ([eventName isEqualToString:MGMCommunityStagePhotoClickEvent])
    {
        MGMTimeLineStagePhotoModel *stagePhotoModel = (MGMTimeLineStagePhotoModel *)extraInfo;
        NSInteger picIndex = [[userInfo mgu_objectOrNilForKey:MGMCommunityPhotoClickIndex] integerValue];
        NSString *picUrl = stagePhotoModel.stagePhotoCoverUrl;
        [self mgm_presentPhotoBrowsePageControllerWithPicIndex:picIndex
                                                       picUrls:picUrl ? @[picUrl] : nil
                                                        feedId:stagePhotoModel.feedId];
    }
    else if ([eventName isEqualToString:MGMCommunityShareEvent])
    {        
        UIImage *shareImage = userInfo[MGMCommunityShareImage];
        NSString *dynamicId = extraInfo.feedId;
        NSString *text = @"";
        if ([extraInfo isMemberOfClass:[MGMTimeLineImageTextModel class]]) {
            MGMTimeLineImageTextModel *imageModel = (MGMTimeLineImageTextModel *)extraInfo;
            text = imageModel.textContent;
        }
        [self shareDynamicWithImage:shareImage dynamicId:dynamicId contentText:text];
    }
    //  头像、用户名事件
    else if ([eventName isEqualToString:MGMCommunityUserAvatarEvent] ||
             [eventName isEqualToString:MGMCommunityUserNameEvent])
    {
        if ([eventName isEqualToString:MGMCommunityUserAvatarEvent] && location.length && position != NSNotFound)
        {
            //  上报点击头像埋点
            [self uploadDynamicEventTrackingWithType:@"JUMP_INNER_NEW_PAGE"
                                            location:location
                                            position:position
                                           programId:nil
                                              pageId:@"MV_PERSONAL_INFORMATION"
                                           dynamicId:extraInfo.feedId];
        }
        
        if (extraInfo && extraInfo.userId)
        {
            //  跳转个人主页
            if (![MGMCommunityGotoLogin shouldGotoLoginWithType:2 backButton:NO inController:nil])
            {
                [MGMRoute routePageControllerWithName:@"interaction_userprofile_main"
                                           parameters:@{@"userId": extraInfo.userId ?: @""}
                                      transitionStyle:(MGURouteTransitionStyleNav)];
            }
        }
    }
    //  正片事件
    else if ([eventName isEqualToString:MGMCommunityFilmEvent])
    {
        if (location.length && position != NSNotFound)
        {
            //  上报点击剧照影片埋点
            [self uploadDynamicEventTrackingWithType:@"JUMP_INNER_NEW_PAGE"
                                            location:location
                                            position:position
                                           programId:nil
                                              pageId:@"MV_DETAIL_COMMENT_PAGE"
                                           dynamicId:extraInfo.feedId];
        }
        
        [self mgm_pushFilmDetailPageControllerWithContentId:[userInfo mgu_objectOrNilForKey:MGMCommunityFilmContentID]
                                                        kId:[userInfo mgu_objectOrNilForKey:MGMCommunityFilmKID]
                                                contentName:[userInfo mgu_objectOrNilForKey:MGMCommunityFilmContentName]];
    }
    //  话题标签点击事件
    else if ([eventName isEqualToString:MGMCommunityTopicClickEvent])
    {
        NSInteger clickIndex = [userInfo[MGMCommunityTopicClickIndex] integerValue];
        MGMFeedItemLabel *feedItemLabel = [extraInfo.topicLabels mgu_objectOrNilAtIndex:clickIndex];
        if (feedItemLabel) {
            if(feedItemLabel.isCurrentTopic && !extraInfo.isClickAllTopic) return handle;
                
            if([[MGMDCommonSettingConfig shareConfig].dynamicIdArray containsObject:feedItemLabel.topicId] && self.navigationController.viewControllers.count == 1) {
                NSInteger scrollIndex = [[MGMDCommonSettingConfig shareConfig].dynamicIdArray indexOfObject:feedItemLabel.topicId];
                 [MGMRoute routePageControllerWithTabIndex:3 subTabIndex:scrollIndex];
            }
            else {
                NSString *topicId = feedItemLabel.topicId;
                NSMutableDictionary *paramM = [NSMutableDictionary dictionary];
                [paramM mgu_safe_setObject:topicId forKey:MGMCommunityRouteTopicId];
                [MGMRoute routePageControllerWithName:@"community_topicDetail_page"
                                           parameters:paramM
                                      transitionStyle:(MGURouteTransitionStyleNav)];
            }
        }
    }
    else
    {
        handle = NO;
    }
    return handle;
}

#pragma mark - Private

- (void)shareDynamicWithImage:(UIImage *)image
                    dynamicId:(NSString *)dynamicId contentText:(NSString *)content
{
    if (!dynamicId.length) return;
    MGMWeakSelf;
    //灰度 http://117.131.17.174:40443/mgyy/share/details/prd/dynamicDetail.html?dynamicId=
    //@L_m 动态分享H5测试地址 http://117.131.17.174:8084/mgyy/share/details/prd/dynamicDetail.html?dynamicId=  小程序地址 /pages/webview/index?src=编码后的H5地址
    NSString *url = [[NSUserDefaults standardUserDefaults] objectForKey:@"MGM_UGC_PAGE_SHARE"];
    if (!url) {
        return;
    }
    NSString *webUrl = [url stringByAppendingString:dynamicId.length > 0 ? dynamicId : @""];
    [MGMShareView showShareViewDidClickItemCallback:^(MGMUshareObject *model) {
        MGMStrongSelf;
        NSString *title = @"我在“咪咕影院”分享了一条动态，快来看看吧";
        if (MGMSocialPlatformType_Sina == model.platform)
        {
            [model shareToSinaWithStyle:(MGMShareSinaStyleNormal)
                                  title:title
                                  image:image
                                 webUrl:webUrl];
        }
        else if (MGMSocialPlatformType_WechatSession == model.platform)
        {
            NSString *userName = @"gh_04715ce2795f";
            NSString *path = [NSString stringWithFormat:@"/pages/webview/index?src=%@",[webUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            
            WXMiniProgramObject *object = [WXMiniProgramObject object];
            object.webpageUrl = webUrl;
            object.userName = userName;
            object.path = path;
            object.hdImageData = [image fetchImageDataOnSizeLimit:128.f / 1024.f];
            object.miniProgramType = WXMiniProgramTypeRelease;
            
            WXMediaMessage *message = [WXMediaMessage message];
            message.title = title;
            message.mediaObject = object;
            SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
            req.bText = NO;
            req.message = message;
            //  目前只支持会话
            req.scene = WXSceneSession;
            [WXApi sendReq:req completion:^(BOOL success) {
                
            }];
        }
        else
        {
            NSString *subtitle = @"《咪咕影院》动态频道，一个电影爱好者的互动社区，来这里说说你和电影的事吧";
            [model shareWithWebLink:webUrl
                              title:title
                              descr:content.length > 0 ? content : subtitle
                           thumbURL:image
                         webpageUrl:webUrl];
        }
        
    } callback:^(id data, NSError *error) {
        NSLog(@"share error = %@",error.localizedDescription);
    } supportTimeLine:NO];
}

/**
    跳转图片浏览器
 
 @param picIndex 图片索引
 @param picUrl 图片url集合
 @param feedId feedID
 */
- (void)mgm_presentPhotoBrowsePageControllerWithPicIndex:(NSInteger)picIndex
                                                 picUrls:(NSArray *)picUrls
                                                  feedId:(NSString *)feedId
{
    NSMutableDictionary *paramM = [NSMutableDictionary dictionary];
    /// 展示相关数据
    [paramM setValue:picUrls ?: @"" forKey:@"images"];
    [paramM setValue:@"1" forKey:@"animationType"];
    [paramM setValue:@(picIndex) forKey:@"currentIndex"];
    
    /// 埋点相关数据
    [paramM setValue:@"4" forKey:@"type"];
    [paramM setValue:feedId forKey:@"source_id"];
    [paramM setValue:@"99" forKey:@"source_type"];
    
    [MGMRoute routePageControllerWithName:@"film_detail_movieStills"
                               parameters:paramM
                          transitionStyle:(MGURouteTransitionStylePresent)];
}

/**
    跳转影片详情页
 
 @param contentId   节目ID
 @param contentName 节目名字
 */
- (void)mgm_pushFilmDetailPageControllerWithContentId:(NSString *)contentId
                                                  kId:(NSString *)kId
                                          contentName:(NSString *)contentName {
    
    if(![contentId mgu_isNotBlank] && ![kId mgu_isNotBlank]) {
        return;
    }
    MGMRouteFilmParams *params = [[MGMRouteFilmParams alloc] init];
    params.filmContentId = contentId;
    params.assertShellId  = kId;
    [MGMRoute routePageControllerWithName:@"film_detail"
                               parameters:params
                          transitionStyle:MGURouteTransitionStyleNav];
}

- (void)uploadDynamicEventTrackingWithType:(NSString *)type
                                  location:(NSString *)location
                                  position:(NSInteger)position
                                 programId:(NSString *)programId
                                    pageId:(NSString *)pageId
                                 dynamicId:(NSString *)dynamicId
{
    NSMutableDictionary *keshengEvent = [NSMutableDictionary dictionary];
    [keshengEvent mgu_safe_setObject:type forKey:@"type"];
    NSMutableDictionary *params = @{}.mutableCopy;
    [params mgu_safe_setObject:location forKey:@"location"];
    [params mgu_safe_setObject:@(position+1) forKey:@"index"];
    if (programId.length)
    {
        [params mgu_safe_setObject:programId forKey:@"targetProgramId"];
    }
    
    if (pageId.length)
    {
        [params mgu_safe_setObject:pageId forKey:@"pageId"];
    }
    [keshengEvent mgu_safe_setObject:params forKey:@"params"];
    NSDictionary *extraInfo = @{@"dynamicId": dynamicId ?: @""};
    [keshengEvent mgu_safe_setObject:extraInfo forKey:@"extra"];
    MGMEventTransferHandler *handler = [[MGMEventTransferHandler alloc] init];
    [handler logKeshengCustomEvent:keshengEvent];
}

#pragma mark - Setter

- (void)setHideFooter:(BOOL)hideFooter
{
    objc_setAssociatedObject(self, @selector(isHideFooter), @(hideFooter), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)setMgm_publishIndicatorView:(UIButton *)mgm_publishIndicatorView
{
    objc_setAssociatedObject(self, @selector(mgm_publishIndicatorView), mgm_publishIndicatorView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

#pragma mark - Getter

- (BOOL)isHideFooter
{
    NSNumber *hide = objc_getAssociatedObject(self, _cmd);
    return hide.boolValue;
}

- (UIButton *)mgm_publishIndicatorView
{
    return objc_getAssociatedObject(self, _cmd);
}

@end
