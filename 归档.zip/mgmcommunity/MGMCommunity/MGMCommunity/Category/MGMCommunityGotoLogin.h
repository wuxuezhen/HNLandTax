//
//  MGMCommunityGotoLogin.h
//  MGMCommunity
//  职责：验证用户是否登录、跳转到指定用户主页
//  Created by apple on 2018/12/21.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MGMDataStore/MGMDSUser.h>
#import <MGMLoginManager.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMCommunityGotoLogin : UIViewController

/*
    MGMLoginShowTypePush        = 1,
    MGMLoginShowTypePresent     = 2,
 */
+ (BOOL)shouldGotoLoginWithType:(NSInteger)showType backButton:(BOOL)isHidden inController:(id)controller;

+ (void)gotoUserMainPageVC:(NSString *)userId;
@end

NS_ASSUME_NONNULL_END
