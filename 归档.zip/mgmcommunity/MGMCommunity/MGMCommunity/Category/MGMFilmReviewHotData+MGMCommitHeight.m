//
//  MGMFilmReviewHotData+MGMCommitHeight.m
//  MGMCommunity
//
//  Created by apple on 2018/12/19.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFilmReviewHotData+MGMCommitHeight.h"
#import <objc/runtime.h>
#import <MGMCategories/MGMScreenAdapter+MGMAdapterUse.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>

const char *kCommitListHeigth= "commitListHeigth";
const char *kcommitTextHeight = "commitTextHeight";

@implementation MGMFilmReviewHotData (MGMCommitHeight)

- (CGFloat)commitListHeigth {
    
    NSInteger childCommentCount = self.childCommentInfo.count;
    NSInteger commentTotalCount = [[self commentedCount] integerValue];
    NSInteger count = (childCommentCount > 1 && commentTotalCount > 2) ? 3 : childCommentCount;

//    if (count > 3) count = 3;
    if (count == 0) {
        return 0.f;
    } else if (count == 1){
        return kMGMHBL2X(57);// 15+15+27
    } else if (count == 2) {
        return kMGMHBL2X(84);// 15 + 15  + 27 * 2
    } else {
        return kMGMHBL2X(111); // 15 + 15 + 27 * 3
    }
}

- (CGFloat)commitTextHeight {
    
    NSDictionary *attri = @{NSFontAttributeName: [UIFont mgu_safeFontWithName:@"PingFangSC-Regular" size: 14],NSForegroundColorAttributeName: [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0]};
    CGFloat height = [self.body boundingRectWithSize:CGSizeMake(kMGMHBL(690), 45) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:attri context:nil].size.height;
    return height;
}



@end
