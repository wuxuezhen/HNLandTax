//
//  MGMCommunityGotoLogin.m
//  MGMCommunity
//
//  Created by apple on 2018/12/21.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityGotoLogin.h"

#import <MGMLogin/MGMLoginManager.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMRoute/MGMRoute.h>

@implementation MGMCommunityGotoLogin

+ (BOOL)shouldGotoLoginWithType:(NSInteger)showType backButton:(BOOL)isHidden inController:(id)controller{
    MGMDSUser *user = [MGMDSUser user];
    if (user.isLogin) return NO;
    [MGMLoginManager shareManager];
    [[MGMLoginManager shareManager] loginFromViewController:nil
                                                   showType:MGMLoginShowTypePresent
                                           isBackButtonHide:isHidden
                                                    success:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
                                                        
                                                    } fail:^(NSDictionary * _Nullable info, NSError * _Nullable error) {
                                                        
                                                    }];
    
    
    return YES;
}


+ (void)gotoUserMainPageVC:(NSString *)userId {
    if(![userId mgu_isNotBlank]) {
        return;
    }
    [[MGMLoginManager shareManager] verifyLoginStateSuccess:^{
        [MGMRoute routePageControllerWithName:@"interaction_userprofile_main" parameters:@{@"userId":userId} transitionStyle:(MGURouteTransitionStyleNav)];
    } failure:^{
        
    }];
}

@end
