//
//  MGMPageController+MGMDynamic.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/8/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <MGMDisplay/MGMPageController.h>
#import <MGMStatistics/MGMEventTransferHandler.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, MGMDyanmicPublishStatus)
{
    MGMDyanmicPublishStatusSending,
    MGMDyanmicPublishStatusSuccess,
    MGMDyanmicPublishStatusFailure
};

@interface MGMPageController (MGMDynamic)

@property (nonatomic, assign, getter=isHideFooter) BOOL hideFooter;
@property (nonatomic, strong) UIButton *mgm_publishIndicatorView;;

/**
    是否处理响应链自定义事件

 @param eventName 事件名
 @param userInfo  数据信息
 @return 是否处理事件
 */
- (BOOL)mgm_shouldHandleEventName:(NSString *)eventName
                         userInfo:(NSDictionary *)userInfo
                         position:(NSInteger)position
                         location:(nullable NSString *)location;

/**
    弹出删除框
 
 @param cancelAction 取消回调
 @param confirmAction 确定回调
 */
- (void)mgm_popDeleteAlertViewWithCancelHandler:(void(^)(UIAlertAction *cancelAction))cancelHandler
                                 confirmHandler:(void(^)(UIAlertAction *confirmAction))confirmHandler;

/// 上报动态埋点
/// @param type      类型
/// @param location  位置
/// @param position  索引
/// @param programId 节目ID
/// @param dynamicId 动态ID
- (void)uploadDynamicEventTrackingWithType:(NSString *)type
                                  location:(nullable NSString *)location
                                  position:(NSInteger)position
                                 programId:(nullable NSString *)programId
                                    pageId:(nullable NSString *)pageId
                                 dynamicId:(NSString *)dynamicId;


/**
    呈现发布页

 @param publishPageController 发布页面
*/
- (void)mgm_presentPublishPageController:(UIViewController *)publishPageController;

/**
    重置列表视图上拉加载视图

 @param listView   列表视图
*/
- (void)mgm_resetRefreshFooterWithListView:(UITableView *)listView;

/**
    根据数据总数隐藏列表视图上拉加载视图

 @param totalCount 总数量
 @param listView   列表视图
*/
- (void)mgm_hideRefreshFooterWithListView:(UITableView *)listView
                               totalCount:(NSInteger)totalCount;

/**
    显示发布指示器

 @param publishView  发布视图
 @param publishCount 发布数量
 @param status       发布状态
 @param prompt       指示文案
*/
- (void)mgm_showPublishView:(UIView *)publishView
               publishCount:(NSInteger)publishCount
                     status:(MGMDyanmicPublishStatus)status
                     prompt:(NSString *)prompt;

/**
    移除发布指示器

 @param publishView  发布视图
*/
- (void)mgm_dismissPublishView:(UIView *)publishView;

/**
    调整列表视图边距,偏移量

 @param contentInsets 内边距
 @param contentOffset 偏移量
 @param listView      列表视图
*/
- (void)mgm_adjustContentInset:(UIEdgeInsets)contentInsets
                 contentOffset:(CGPoint)contentOffset
                   forListView:(UITableView *)listView;

/**
    重置列表视图边距,偏移量

 @param listView  列表视图
*/
- (void)mgm_resetListView:(UITableView *)listView;

@end

NS_ASSUME_NONNULL_END
