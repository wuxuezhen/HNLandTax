//
//  MGMCommunityReportManager.m
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/3/2.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommunityReportManager.h"
#import <MGUCategoryUtil/MGUCategoryUtil.h>
#import <MGMCategories/MGMCategories.h>
#import <MGMUIKit/MGMProgressHUD+MGMConfig.h>
#import <MGMUIKit/MGMProgressHUD+Prompt.h>
#import <MGThirdKit/AFNetworking_mgs.h>

@interface MGMCommunityReportManager ()<MGMSheetViewDelegate>

@end

@implementation MGMCommunityReportManager
static MGMCommunityReportManager *_MGMCommunityReportManager = nil;
+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _MGMCommunityReportManager = [[MGMCommunityReportManager alloc] init];
    });
}

+ (void)resportUGCWithObjectOnVC:(__kindof UIViewController *)vc handler:(void(^)(NSString *actionTitle))handler{
    if (![AFNetworkReachabilityManager_mgs sharedManager].isReachable) {
        [MGMProgressHUD showAutoHiddeText:@"网络连接异常，请稍后重试"];
        return;
    }
    
    [MGMSheetView showSheetWithTitles:@[@"广告推销", @"暴力血腥", @"色情低俗", @"赌博欺诈"] withDelegate:_MGMCommunityReportManager];
}
- (void)didClickItem:(NSString *)item inSheetView:(MGMSheetView *)sheetView {
    NSString *promt = ![AFNetworkReachabilityManager_mgs sharedManager].isReachable? @"网络连接异常，请稍后重试" : @"举报成功";
    [MGMProgressHUD showAutoHiddeText:promt];
}

@end
