//
//  MGMCommunityReportManager.h
//  MGMCommunity
//
//  Created by WangDa Mac on 2019/3/2.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 动态主页和详情用户举报事件
 */
@interface MGMCommunityReportManager : NSObject
+ (void)resportUGCWithObjectOnVC:(__kindof UIViewController *)vc handler:(void(^)(NSString *actionTitle))handler;
@end

NS_ASSUME_NONNULL_END
