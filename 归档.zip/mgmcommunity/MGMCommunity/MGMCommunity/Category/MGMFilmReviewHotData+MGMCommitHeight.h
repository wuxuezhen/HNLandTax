//
//  MGMFilmReviewHotData+MGMCommitHeight.h
//  MGMCommunity
//
//  Created by apple on 2018/12/19.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MGMFilmReviewHotListDataModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFilmReviewHotData (MGMCommitHeight)

@property (nonatomic, readonly) CGFloat commitListHeigth;

@property (nonatomic, readonly) CGFloat commitTextHeight;

@end

NS_ASSUME_NONNULL_END
