//
//  ViewController.m
//  MGMCommunity
//
//  Created by apple on 2018/12/1.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController pushViewController:[NSClassFromString(@"MGMCommunityController") new] animated:NO];
}

@end
