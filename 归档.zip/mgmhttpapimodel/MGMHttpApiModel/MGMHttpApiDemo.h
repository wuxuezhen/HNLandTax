//
//  MGMHttpApiDemo.h
//  MGMHttpApiModel
//
//  Created by RenYi on 2018/12/19.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MGUDisplayCore/MGUBasePageDataManager.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMHttpApiDemo : MGUBasePageDataManager

#pragma mark - 获取城市信息

/**
 获取城市信息
 
 @param cityName 城市名称，例如：上海
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchCityInfoWithName:(NSString *)cityName tag:(NSUInteger)tag;

#pragma mark - 获取城市列表接口

/**
 获取城市列表接口
 
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchCitieslistWithTag:(NSUInteger)tag;

#pragma mark - 获取城市区域列表

/**
 获取城市区域列表
 
 @param cityId 城市id
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchDistrictInCity:(NSUInteger)cityId tag:(NSUInteger)tag;

#pragma mark - 获取可订票影院列表

/**
 根据条件获取可订票的影院;更多说明：http://confluence.cmvideo.cn/confluence/pages/viewpage.action?pageId=18658459
 @param cityId 城市ID
 @param regionId 区域ID,
 @param showDate 场次放映日期 格式：yyyy-MM-dd（查询场次放映日期在showDate当天及其之后时间的影院）
 @param filmId 电影ID -1表示默认不传
 @param orderType 排序类型:1.按与当前位置的距离排序
 @param longitude 用户当前位置经度
 @param latitude 用户当前位置纬度
 @param cinemaCompany 所属院线 1-万达;2-SFC;3-横店;4-中影
 @param searchDate 根据具体放映日查询影片该日有场次的影院 格式：yyyy-MM-dd（当filmId不为空时，searchDate参数才有效。且查询的是searchDate当天有场次的影院）
 @param feature 影院特色信息；影院特色信息数据从“07 查询影院特色标签列表”接口获取
 glasses3D - 3D眼镜
 childrenDiscount - 儿童优惠
 parkingInfo - 可停车
 wifi - 免费WiFi
 specialHall_4D厅 - 特色影厅中的4D厅（其他的特色影厅也是这种格式）
 @param businessAreaName 商圈名称 例如：五角场  商圈数据从 “09 查询商圈列表”接口获取
 @param investmentName 影投名称 例如：博纳国际影城  影投数据从 “08 查询品牌（影投）列表”接口获取
 @param pageNum 当前查询页数 -1表示默认不传
 @param pageSize 每页记录数 -1表示默认不传
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchValidCinemasInCity:(NSString *)cityId
                       regionId:(nullable NSString *)regionId
                       showDate:(nullable NSString *)showDate
                        filmeId:(nullable NSString *)filmId
                      orderType:(nullable NSString *)orderType
                      longitude:(nullable NSString *)longitude
                       latitude:(nullable NSString *)latitude
                  cinemaCompany:(nullable NSString *)cinemaCompany
                     searchDate:(nullable NSString *)searchDate
                        feature:(nullable NSString *)feature
               businessAreaName:(nullable NSString *)businessAreaName
                 investmentName:(nullable NSString *)investmentName
                        pageNum:(NSInteger)pageNum
                       pageSize:(NSInteger)pageSize
                            tag:(NSUInteger)tag;

#pragma mark - 获取影院详情

/**
 获取影院详情
 
 @param cinemaId 影院id
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchCinemaInfo:(NSString *)cinemaId tag:(NSUInteger)tag;

#pragma mark - 根据多个影院id获取多个影院信息

/**
 根据多个影院id获取多个影院信息
 
 @param cinemaIds 影院编号（多个id用”,”隔开
 @param longitude 经度
 @param latitude 纬度
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)batchFetchCinemasInfo:(NSString *)cinemaIds
                    longitude:(nullable NSString *)longitude
                     latitude:(nullable NSString *)latitude
                          tag:(NSUInteger)tag;

#pragma mark - 查询影院特色标签列表

/**
 根据城市ID查询该城市下特色影院标签列表
 
 @param cityId 城市ID
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchSpecialListForCity:(NSString *)cityId tag:(NSUInteger)tag;

#pragma mark - 查询品牌（影投）列表

/**
 查询品牌（影投）列表
 
 @param cityId 城市id
 @param tag api标识
 @return  NO表示请求发送失败，YES表示请求发送成功
 */
-(BOOL)fetchInvestmentListInCity:(NSUInteger)cityId tag:(NSUInteger)tag;

#pragma mark -  获取商圈列表

/**
 获取商圈列表
 
 @param cityId 城市id
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchBusinessAreaInCity:(NSUInteger)cityId tag:(NSUInteger)tag;

#pragma mark - 正在上映

/**
 根据城市id获取正在上映影片信息
 
 @param cityId 城市id
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchShowingMoviesWithCityId:(NSString *)cityId tag:(NSUInteger)tag;

#pragma mark - 即将上映

/**
 根据城市id获取z即将上映影片信息
 
 @param cityId 城市id
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchUpcomingMoviesWithCityId:(NSString *)cityId pageNo:(NSInteger)pageNo pageSize:(NSInteger)pageSize tag:(NSUInteger)tag;

#pragma mark - 场次微服务接口 -

#pragma mark - 影院上映列表

/**
 根据影院ID和查询类型 查询影院下有场次排片的影片列表
 
 @param cinemaId 影片ID 例如：62827
 @param type 查询类型 0:所有 1:已经上映 2:即将上映
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchFilmsForCinema:(NSString *)cinemaId type:(NSString *)type tag:(NSUInteger)tag;

#pragma mark - 影院影片获取场次排片

/**
 根据影片id和影院id，拉取对应的场次排片
 
 @param filmId 影片ID 例如：62827
 @param cinemaId 影院ID 例如：14323
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchScheduleForCinemaId:(NSString *)cinemaId WithFilmId:(NSString *)filmId tag:(NSUInteger)tag;

#pragma mark - 获取座位信息

/**
 获取场次座位信息
 
 @param cinemaId 影院ID
 @param hallId 影厅ID
 @param showId 场次ID
 @param accessorid 接入方ID
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchSeatsInfoForCinemaId:(NSString *)cinemaId
                           hallId:(NSString *)hallId
                           showId:(NSString *)showId
                       accessorId:(NSString *)accessorid
                              tag:(NSUInteger)tag;

#pragma mrak - 影片区域获取场次排片

/**
 根据影片ID、区域ID、场次放映日期 查询影院-场次信息
 
 @param filmId 影片ID 例如：62827
 @param regionId 区域id
 @param showDate 场次放映日期（yyyy-mm-dd）
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchScheduleForFilm:(NSString *)filmId inArea:(NSString *)regionId onDate:(NSString *)showDate tag:(NSUInteger)tag;

#pragma mark - 查询场次id

/**
 根据特定条件 查询场次id
 
 @param cinemaId 影院编号
 @param filmId 影片id
 @param showDate 场次日期(2017-03-19)
 @param showTime 场次时间16:15为例，(1615),
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchShowIdForCinemaId:(NSString *)cinemaId
                        filmId:(NSString *)filmId
                      showDate:(NSString *)showDate
                      showTime:(NSString *)showTime
                           tag:(NSUInteger)tag;

#pragma mark - 查询影片排片信息

/**
 根据特定条件查询影片排片日期列表
 
 @param filmId 影片id
 @param cityId 城市id
 @param regionId 区域代码
 @param tag api标识
 @return NO表示请求发送失败，YES表示请求发送成功
 */
- (BOOL)fetchShowDatesForFilm:(NSString *)filmId
                       cityId:(NSString *)cityId
                     regionId:(nullable NSString *)regionId
                          tag:(NSUInteger)tag;


@end

//- (BOOL)fetchMyOrderAndMyWatchFilm:(NSString *)startTime
//                           endTime:(NSString *)endTtime
//                              sort:(NSString *)sort
//                          pageSize:(NSString *)pageSize
//                           pageNum:(NSString *)pageNum serviceCodes:(NSString *)serviceCodes

NS_ASSUME_NONNULL_END
