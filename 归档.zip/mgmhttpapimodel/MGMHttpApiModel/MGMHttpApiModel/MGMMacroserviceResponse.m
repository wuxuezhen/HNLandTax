//
//  MGMCommunityMacroResponse.m
//  AFNetworking
//
//  Created by WangDa Mac on 2019/6/12.
//

#import "MGMMacroserviceResponse.h"

@implementation MGMMacroserviceResponse

- (BOOL)isSuccess {
    if ([self.resultCode isEqualToString:@"SUCCESS"] || [self.resultCode isEqualToString:@"0000"])
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

+ (NSError *)macroserviceErrorWithCode:(NSUInteger)code customerDesc:(NSString *)desc
{
    NSDictionary *userInfoDic;
    if (desc.length > 0)
    {
        userInfoDic = @{NSLocalizedDescriptionKey:desc};
    }
    NSError *error = [NSError errorWithDomain:@"com.migumovie.macroservice.error"
                                         code:code
                                     userInfo:userInfoDic];
    
    return error;
}

@end
