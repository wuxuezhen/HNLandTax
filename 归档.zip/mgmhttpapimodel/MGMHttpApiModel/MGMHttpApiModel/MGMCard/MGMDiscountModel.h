//
//  MGMDiscountModel.h
//  MGMHttpApiModel
//
//  Created by MyMac on 2018/12/24.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MGMDiscountModel : NSObject

/**
    满减优惠要求的订单最低价
 */
@property (nonatomic, copy) NSString *orderAmount;

/**
    满减优惠订单减少价
 */
@property (nonatomic, copy) NSString *orderDiscountAmount;

/**
    规则优惠类型1:每订单减少(满x赠y)；4:按比例打折 85折
 */
@property (nonatomic, copy) NSString *discountType;

/**
    是否限制支付方式  false 不限制 true 限制
 */
@property (nonatomic, assign) BOOL isLimitPay;

@property (nonatomic,copy) NSString *payType;

@end
