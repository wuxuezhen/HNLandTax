//
//  MGMCardModel.h
//  MGMHttpApiModel
//
//  Created by MyMac on 2018/12/24.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

//  个人卡券模型

NS_ASSUME_NONNULL_BEGIN

@class MGMDiscountModel;

@interface MGMCardModel : NSObject

/**
    卡适用类型：
    卡类型|说明
    MOVIE|电影
    PERFORM|演出票
 */
@property (nonatomic, copy) NSArray <NSString *>*cardRange;

@property (nonatomic, copy) NSString *scope;

@property (nonatomic, copy) NSString *desc;

/**
    卡名称
 */
@property (nonatomic, copy) NSString *cardName;

/**
    限制的城市列表（不支持演出票)
 */
@property (nonatomic, assign) BOOL isLimitCityId;

//限制城市ID
@property (nonatomic, copy) NSArray<NSString *> *limitCityId;

/**
    是否使用万达电子券 （true为限制  false为不限制）（不支持演出票）
 */
@property (nonatomic, assign) BOOL isUseWDCard;

//万达使用码类型
@property (nonatomic, copy) NSArray<NSString *> *wDCardDime;

//万达电子码票使用类型
@property (nonatomic, copy) NSArray<NSString *> *wanDaVoucherPriceCodeList;

/**
    是否限制特定影片（true为限制  false为不限制）（不支持演出票）
 */
@property (nonatomic, assign) BOOL isLimitFilm;

//限制影片列表
@property (nonatomic, copy) NSArray<NSString *> *limitFilm;

/**
    是否限价 （true为限制  false为不限制）（不支持演出票）
 */
@property (nonatomic, assign) BOOL isLimitPrice;

//限制价格上限
@property (nonatomic, copy) NSString *limitPrice;

/**
  （不支持演出票）
 */
@property (nonatomic, assign) BOOL isLimitShowDime;

@property (nonatomic, copy) NSArray<NSString *> *showDime;

/**
    是否限制接入方 (true为限制  false为不限制）(不支持演出票)
 */
@property (nonatomic, assign) BOOL isLimitAccessor;

//限制接入方列表
@property (nonatomic, copy) NSArray<NSString *> *limitAccessor;

/**
    是否绑定活动（不支持演出票）
 */
@property (nonatomic, assign) BOOL isBingActivityId;
//活动ID
@property (nonatomic, copy) NSString  *activityId;

/**
    是否限制省份 （true为限制  false为不限制）（不支持演出票）
 */
@property (nonatomic, assign) BOOL isLimitProvinceName;

//限制省份列表
@property (nonatomic, copy) NSArray<NSString *> *provinceName;

//是否限制产品类型（true为限制  false为不限制）
@property (nonatomic, assign) BOOL     isLimitProductType;

//产品类型  ios android h5 miniProgram other
@property (nonatomic, copy) NSArray<NSString *> *productType;

/**
    是否使用规则（true为使用 false为不使用）
 */
@property (nonatomic, assign) BOOL isUseDiscountCoupon;

@property (nonatomic, strong) MGMDiscountModel *discountCouponMap;

//是否限制节假日 （仅当场次接入方为4且isUseWDCard=true 才对该限制进行判断）
@property (nonatomic, assign) BOOL  isLimitHoliday;

//节假日列表 格式:yyyy-mm-dd
@property (nonatomic, copy) NSArray<NSString *> *holidayList;

//自定义字段，卡券是否可用  NO  可用   YES  不可用
@property (nonatomic, assign) BOOL              limitUseCard;
///卡号
@property (nonatomic, copy) NSString  *cardNum;
///卡批次号
@property (nonatomic, copy) NSString  *cardBatchId;
///是否限制影院白名单
@property (nonatomic, assign) BOOL         ifLimitWhiteListOfCinema;
///影院白名单ID列表
@property (nonatomic, copy) NSArray<NSString *> *whiteListOfCinema;
///是否限制影院黑名单
@property (nonatomic, assign) BOOL         ifLimitBlackListOfCinema;
///影院黑名单ID列表
@property (nonatomic, copy) NSArray<NSString *> *blackListOfCinema;
///是否限制购票城市数量
@property (nonatomic, assign) BOOL         ifLimitCityNum;
///限制城市数量
@property (nonatomic, assign) NSInteger         limitCityNum;
///当日已经购买订单该批次城市数量
@property (nonatomic, assign) NSInteger         ticketCityNum;
///是否限制该批次卡日激活上限
@property (nonatomic, assign) BOOL         ifLimitUsingTimes;
///日激活上限
@property (nonatomic, assign) NSInteger         limitUsingTimes;
///当日该批次已经激活数量
@property (nonatomic, assign) NSInteger         usedTimes;
///是否限制该批次卡日购票订单数量
@property (nonatomic, assign) BOOL         ifLimitTicketTimes;
///日购票订单数量
@property (nonatomic, assign) NSInteger         limitTicketTimes;
///当日该批次卡购票数量
@property (nonatomic, assign) NSInteger         ticketTimes;

@end

NS_ASSUME_NONNULL_END

