//
//  MGMCardModel.m
//  MGMHttpApiModel
//
//  Created by MyMac on 2018/12/24.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCardModel.h"

@implementation MGMCardModel

@end
