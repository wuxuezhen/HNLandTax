//
//  MGMConcertTicketsTypePerformModel.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMConcertTicketsTypePerformModel : MGMBaseModel

@property (nonatomic, copy) NSString *playTypeId;
@property (nonatomic, copy) NSString *playTypeName;

@end

NS_ASSUME_NONNULL_END
