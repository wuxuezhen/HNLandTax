//
//  MGMConcertTicketsListModel.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMConcertTicketsListModel : MGMBaseModel

@property (nonatomic, copy) NSString *playName;
@property (nonatomic, copy) NSString *playVenueName;
@property (nonatomic, copy) NSString *priceGroup;
@property (nonatomic, copy) NSString *productEndTime;
@property (nonatomic, copy) NSString *productId;
@property (nonatomic, copy) NSString *productPictureSmall;
@property (nonatomic, copy) NSString *productStartTime;
@property (nonatomic, copy) NSString *status;

@end

NS_ASSUME_NONNULL_END
