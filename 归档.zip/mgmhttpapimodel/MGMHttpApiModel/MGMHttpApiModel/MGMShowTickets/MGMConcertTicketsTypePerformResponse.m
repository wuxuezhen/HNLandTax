//
//  MGMConcertTicketsTypePerformResponse.m
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMConcertTicketsTypePerformResponse.h"

@implementation MGMConcertTicketsTypePerformResponse

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"playType" : [MGMConcertTicketsTypePerformModel class]};
}

-(NSDictionary *)dataWithTypePerformData:(NSDictionary *)data{
    
    NSMutableArray *resultsArray = nil;
    NSDictionary *dic = nil;
    if (data) {
        resultsArray = data[@"results"];
    }
    if (resultsArray.count>0){
        NSDictionary *DataDic = resultsArray[0];
        NSMutableArray *playTypeArray = [NSMutableArray array];
        NSDictionary *typeDic = @{@"playTypeId": @"",
                                  @"playTypeName": @"全部"};
        [playTypeArray addObject:typeDic];
        NSArray *array = DataDic[@"playType"];
        [playTypeArray addObjectsFromArray:array];
        NSString *resultCode = DataDic[@"resultCode"];
        NSString *resultDesc = DataDic[@"resultDesc"];
        dic = @{@"playType": playTypeArray,
                @"resultCode": resultCode,
                @"resultDesc": resultDesc};
    }
    
    return dic;
}

@end
