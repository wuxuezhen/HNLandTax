//
//  MGMConcertTicketsTypePerformResponse.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"
#import "MGMConcertTicketsTypePerformModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMConcertTicketsTypePerformResponse : MGMBaseModel

@property (nonatomic, strong) NSArray <MGMConcertTicketsTypePerformModel *> *playType;

-(NSDictionary *)dataWithTypePerformData:(NSDictionary *)data;

@end

NS_ASSUME_NONNULL_END
