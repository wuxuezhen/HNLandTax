//
//  MGMConcertTicketsCitiesPerformModel.m
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/9.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMConcertTicketsCitiesPerformModel.h"

@implementation MGMConcertTicketsCitiesPerformModel

@end
