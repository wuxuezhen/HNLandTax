//
//  MGMConcertTicketsCitiesPerformResponse.m
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/9.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMConcertTicketsCitiesPerformResponse.h"

@implementation MGMConcertTicketsCitiesPerformResponse

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"cities" : [MGMConcertTicketsCitiesPerformModel class]};
}

-(NSDictionary *)dataWithCityPerformData:(NSDictionary *)data{
    
    NSMutableArray *resultsArray = nil;
    if (data) {
        resultsArray = data[@"results"];
    }
    NSDictionary *dic = (resultsArray.count>0)?dic = resultsArray[0]:nil;
    return dic;
}

@end
