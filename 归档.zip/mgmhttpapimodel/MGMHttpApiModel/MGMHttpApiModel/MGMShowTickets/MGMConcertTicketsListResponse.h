//
//  MGMConcertTicketsListResponse.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"
#import "MGMConcertTicketsListModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMConcertTicketsListResponse : MGMBaseModel

@property (nonatomic, copy) NSString *resultCode;
@property (nonatomic, copy) NSString *resultDesc;
@property (nonatomic, assign) NSInteger resultcount;
@property (nonatomic, strong) NSArray<MGMConcertTicketsListModel*> *products;

-(NSDictionary *)dataWithCityPerformData:(NSDictionary *)data;

@end

NS_ASSUME_NONNULL_END
