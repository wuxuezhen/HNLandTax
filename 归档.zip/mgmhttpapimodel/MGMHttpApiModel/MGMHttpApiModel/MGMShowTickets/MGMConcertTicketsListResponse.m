//
//  MGMConcertTicketsListResponse.m
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMConcertTicketsListResponse.h"

@implementation MGMConcertTicketsListResponse

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    self.resultcount = [dic[@"resultcount"] integerValue];
    return YES;
}

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"products" : [MGMConcertTicketsListModel class]};
}

-(NSDictionary *)dataWithCityPerformData:(NSDictionary *)data{
    NSMutableArray *resultsArray = nil;
    if (data) {
        resultsArray = data[@"results"];
    }
    NSDictionary *dic = (resultsArray.count>0)?resultsArray[0]:nil;
    return dic;
}

@end
