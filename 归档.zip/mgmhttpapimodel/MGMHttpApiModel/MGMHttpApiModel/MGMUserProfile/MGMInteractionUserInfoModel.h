//
//  MGMInteractionUserInfoModel.h
//  MGMHttpApiModel
//
//  Created by YL on 2019/4/11.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

//互动 用户信息model
#import "MGMBaseModel.h"

//用户类型
typedef NS_ENUM(NSInteger, MGMUserType)
{
    MGMUserNormalType = 0, //普通用户
    MGMUserGkeType,    //G客用户
    MGMUserOfficeType, //官方用户
};

NS_ASSUME_NONNULL_BEGIN

@interface MGMInteractionUserInfoModel : MGMBaseModel

@property (nonatomic, copy) NSString *userId;
@property (nonatomic, copy) NSString *userInfoId;
@property (nonatomic, copy) NSString *mobile; //手机号
@property (nonatomic, copy) NSString *sname;   //昵称
@property (nonatomic, copy) NSString *picture; //头像
@property (nonatomic, copy) NSString *registTime; //注册时间
@property (nonatomic, assign)NSInteger   sex;  //性别：0男，1女
@property (nonatomic, copy) NSString *age;   //年龄
@property (nonatomic, copy) NSString *birth;  //生日格式：yyyy-MM-dd
@property (nonatomic, copy) NSString *area;   //地区
@property (nonatomic, copy) NSString *hobbies;  //兴趣爱好
@property (nonatomic, copy) NSString *sign;  //个性签名
@property (nonatomic, copy) NSString *address; //现居地
@property (nonatomic, copy) NSString *email;  //电子邮箱
@property (nonatomic, copy) NSString *album;  //相册
@property (nonatomic, copy) NSString *starSign; //星座
@property (nonatomic, copy) NSString *height;   //身高
@property (nonatomic, copy) NSString *profession; //职业
@property (nonatomic, copy) NSString *education; //学历
@property (nonatomic, copy) NSString *snameStatus; //昵称审核状态, 0-审核中; 1-审核通过; 2-审核失败
@property (nonatomic, copy) NSString *signStatus;  //个性签名审核状态, 0-审核中; 1-审核通过; 2-审核失败
@property (nonatomic, copy) NSString *provice;  //城市

@property (nonatomic, copy)NSString *collection;
@property (nonatomic, copy)NSString  *footprint;
@property (nonatomic, copy)NSString  *memberLevel;
@property (nonatomic, copy) NSArray *miguvideopictures;
    
@property (nonatomic, copy)NSString  *personalNotice;   //个人公告
@property (nonatomic, copy)NSString  *jumpLink; //公告跳转链接
@property (nonatomic, copy)NSString  *relevanceProgram;//相关节目

//自定义字段
@property (nonatomic, assign) NSInteger  followNum; //关注数目
@property (nonatomic, assign) NSInteger  fanNum;    //粉丝数目
@property (nonatomic, copy)   NSString   *relationType ; //用户关注关系  NORELATION 没有关系  MYFOLLOW 我的关注 MYFANS 我的粉丝 FUNSEACHOTHER 互粉
@property (nonatomic, assign) MGMUserType userType; //用户类型
@property (nonatomic, copy) NSArray      *dynamicTypes; //动态类型
/**
 用户认证新增字段
 */
@property (nonatomic , strong) NSArray<NSDictionary *> *certificationTags;
//用户认证icon
@property (nonatomic , strong) NSString *iconUrl;

@end

@interface MGMUserInfoBaseModel : MGMBaseModel

@property (nonatomic, strong) NSArray<MGMInteractionUserInfoModel *> *dataMap;

@end

NS_ASSUME_NONNULL_END
