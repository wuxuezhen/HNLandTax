//
//  MGMUserInfoModel.h
//  MGMMeModule
//
//  Created by MyMac on 2019/4/18.
//  Copyright © 2019年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMUserInfoModel : MGMBase

/**
    年龄
 */
@property (nonatomic, assign) NSInteger age;

/**
    现居地
 */
@property (nonatomic, strong) NSString *address;

/**
    几几后（00后）
 */
@property (nonatomic, strong) NSString *ageAfter;

/**
    相册
 */
@property (nonatomic, strong) NSString *album;

/**
    地区
 */
@property (nonatomic, strong) NSString *area;

/**
    生日格式：yyyy-MM-dd
 */
@property (nonatomic, strong) NSString *birth;

/**
    收藏  0--关闭 1--打开
 */
@property (nonatomic, strong) NSString *collection;

/**
    学历
 */
@property (nonatomic, strong) NSString *education;

/**
    电子邮箱
 */
@property (nonatomic, strong) NSString *email;

/**
    足迹  0--关闭 1--打开
 */
@property (nonatomic, strong) NSString *footprint;

/**
    身高
 */
@property (nonatomic, strong) NSString *height;

/**
    兴趣爱好
 */
@property (nonatomic, strong) NSString *hobbies;

/**
    咪咕视频相册
 */
@property (nonatomic, strong) NSString *miguvideopictures;

/**
    手机号
 */
@property (nonatomic, strong) NSString *mobile;

/**
    头像
 */
@property (nonatomic, strong) NSString *picture;

/**
    相册照片是否设置为头像 1是 2否
 */
@property (nonatomic, strong) NSString *pictureType;

/**
    职业
 */
@property (nonatomic, strong) NSString *profession;

/**
    注册时间
 */
@property (nonatomic, strong) NSString *registTime;

/**
    性别：0男，1女
 */
@property (nonatomic, assign) NSInteger sex;

/**
    个性签名
 */
@property (nonatomic, strong) NSString *sign;

/**
    个性签名审核状态, 0-审核中; 1-审核通过; 2-审核失败
 */
@property (nonatomic, strong) NSString *signStatus;

/**
    昵称
 */
@property (nonatomic, strong) NSString *sname;

/**
    昵称审核状态, 0-审核中; 1-审核通过; 2-审核失败
 */
@property (nonatomic, strong) NSString *snameStatus;

/**
    星座
 */
@property (nonatomic, strong) NSString *starSign;

/**
    用户Id
 */
@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *memberLevel;
@property (nonatomic, assign) NSInteger userInfoId;

@end

NS_ASSUME_NONNULL_END
