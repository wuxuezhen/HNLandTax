//
//  MGMInteractionUserInfoModel.m
//  MGMHttpApiModel
//
//  Created by YL on 2019/4/11.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMInteractionUserInfoModel.h"
#import <MGMUserCertification/MGMUserCertification.h>

@implementation MGMInteractionUserInfoModel


- (void)setCertificationTags:(NSArray<NSDictionary *> *)certificationTags{
    _certificationTags = certificationTags;
    NSArray *array = _certificationTags;
    NSDictionary *tagDic = array.firstObject;
    if (tagDic) {
        NSMutableArray *cerTypes = [NSMutableArray array];
        NSArray *keys = tagDic.allKeys;
        for (NSString *aKey in keys) {
            NSString *value = [tagDic objectForKey:aKey];
            if ((value.length > 0) && (![value isEqualToString:@"null"]) && (![value isEqualToString:@"NULL"])) {
                [cerTypes addObject:aKey];
            }
        }
        if (cerTypes.count > 0) {
            for (NSString *cerInfoString in cerTypes) {
                MGMUserCerInfo *cerInfo = [[MGMUserCertification sharedUserCertification] cerInfoForType:cerInfoString];
                if (cerInfo) {
                    _iconUrl = cerInfo.iconUrl;
                    return ;
                }
            }
        }
    }
}




@end

@implementation MGMUserInfoBaseModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"dataMap" : [MGMInteractionUserInfoModel class]
             };
}



@end
