//
//Created by ESJsonFormatForMac on 18/12/24.
//

#import <Foundation/Foundation.h>

@class MGMReciveAddressBody,MGMReciveAddressResults,MGMReciveAddressAddresss;
@interface MGMReciveAddressModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMReciveAddressBody *body;

@end
@interface MGMReciveAddressBody : NSObject

@property (nonatomic, strong) NSArray *results;

@end

@interface MGMReciveAddressResults : NSObject

@property (nonatomic, copy) NSString *resultDesc;

@property (nonatomic, copy) NSString *resultCode;

@property (nonatomic, strong) NSArray *addresss;

@end

@interface MGMReciveAddressAddresss : NSObject

@property (nonatomic, copy) NSString *address;

@property (nonatomic, copy) NSString *phone;

@property (nonatomic, copy) NSString *expressPrice;

@property (nonatomic, copy) NSString *userName;

@property (nonatomic, copy) NSString *region;

@property (nonatomic, copy) NSString *userId;

@property (nonatomic, copy) NSString *addressId;

@property (nonatomic, copy) NSString *defaultFlag;

@property (nonatomic, copy) NSString *zipCode;

@end

