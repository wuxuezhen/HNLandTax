//
//Created by ESJsonFormatForMac on 18/12/24.
//

#import "MGMReciveAddressModel.h"
@implementation MGMReciveAddressModel


@end

@implementation MGMReciveAddressBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"results" : [MGMReciveAddressResults class]};
}


@end


@implementation MGMReciveAddressResults

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"addresss" : [MGMReciveAddressAddresss class]};
}


@end


@implementation MGMReciveAddressAddresss


@end


