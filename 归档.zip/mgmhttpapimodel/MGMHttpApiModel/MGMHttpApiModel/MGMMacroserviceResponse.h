//
//  MGMCommunityMacroResponse.h
//  AFNetworking
//
//  Created by WangDa Mac on 2019/6/12.
//

#import "MGMLegoAction.h"
NS_ASSUME_NONNULL_BEGIN

/**
 该类和影单模块 MGMMicroserviceResponse 一模一样，如果 MGMMicroserviceResponse 抽离到单独模块可以将直接替换该类
 */
@interface MGMMacroserviceResponse : MGMBase

@property (nonatomic, strong, readwrite, nullable) id data;
@property (nonatomic, copy, readwrite) NSString *resultCode;
@property (nonatomic, copy, readwrite) NSString *resultDesc;
@property (nonatomic, assign, readonly, getter=isSuccess) BOOL success;


/**
 微服务错误

 @param code 自定义code，建议使用 resultCode 与微服务保持一致
 @param desc 自定义错误描述
 @return NSError
 */
+ (NSError *)macroserviceErrorWithCode:(NSUInteger)code customerDesc:(nullable NSString *)desc;

@end

NS_ASSUME_NONNULL_END
