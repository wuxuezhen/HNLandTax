//
//  MGMCashRegisterOptionBody.h
//  AFNetworking
//
//  Created by WangDa Mac on 2019/4/8.
//
//http://confluence.cmvideo.cn/confluence/pages/viewpage.action?pageId=24094195
#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMCashRegisterOption : MGMBase
@property (nonatomic, copy) NSString *bankCode;
@property (nonatomic, copy, readwrite, nullable) NSString *payType;
@property (nonatomic, copy, readwrite, nullable) NSString *label;
@property (nonatomic, copy, readwrite, nullable) NSString *desc;
@property (nonatomic, copy, readwrite, nullable) NSString *dailog;
@property (nonatomic, copy, readwrite, nullable) NSString *switch_;
@property (nonatomic, copy, readwrite, nullable) NSString *starttime;
@property (nonatomic, copy, readwrite, nullable) NSString *endtime;
@property (nonatomic, assign, readwrite) BOOL switch2_;
@property (nonatomic, copy, readwrite, nullable) NSDate *starttime_;
@property (nonatomic, copy, readwrite, nullable) NSDate *endtime_;
@property (nonatomic, copy, readwrite, nullable) NSString *range;

@end

@interface MGMCashRegisterOptionBody : MGMBase

@property (nonatomic, copy) NSString *active;
@property (nonatomic, copy) NSString *desc;
@property (nonatomic, copy) NSString *paramKey;
@property (nonatomic, copy) NSString *paramValue;
@property (nonatomic, strong) NSArray <MGMCashRegisterOption *>*paramValue_;
@end

NS_ASSUME_NONNULL_END
