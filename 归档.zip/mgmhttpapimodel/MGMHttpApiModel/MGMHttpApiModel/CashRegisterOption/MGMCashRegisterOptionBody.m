//
//  MGMCashRegisterOptionBody.m
//  AFNetworking
//
//  Created by WangDa Mac on 2019/4/8.
//

#import "MGMCashRegisterOptionBody.h"
#import <YYModel/NSObject+YYModel.h>



@implementation MGMCashRegisterOption
+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"switch_"  : @"switch"};
}

- (NSDate *)starttime_ {
    if (!_starttime_) {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMdd HH:mm";
        _starttime_ = [formatter dateFromString:_starttime];
    }
    return _starttime_;
}

- (NSDate *)endtime_ {
    if (!_endtime_) {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMdd HH:mm";
        _endtime_ = [formatter dateFromString:_endtime];
    }
    return _endtime_;
}
- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    if (self.starttime_ && self.endtime_) {
        self.starttime_;
        self.endtime_;
        self.switch2_;
        NSDate *date = [NSDate date];
        
        _switch2_ =  [self.starttime_ compare:date] == NSOrderedAscending && [self.endtime_ compare:date] == NSOrderedDescending && [_switch_ isEqualToString:@"on"];
        
    }
    return YES;
}

@end

@implementation MGMCashRegisterOptionBody
- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    NSString *paramValue = _paramValue? _paramValue : @"";
    NSData *data = [paramValue dataUsingEncoding:NSUTF8StringEncoding];
    NSArray *opts = [NSJSONSerialization JSONObjectWithData:data options:(NSJSONReadingMutableLeaves) error:nil];
    _paramValue_ = [NSArray yy_modelArrayWithClass:[MGMCashRegisterOption class] json:opts];
    return YES;
}
@end
