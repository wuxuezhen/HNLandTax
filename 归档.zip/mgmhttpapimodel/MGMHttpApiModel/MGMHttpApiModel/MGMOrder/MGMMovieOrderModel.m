//
//  MGMMovieOrderModel.m
//  MGMHttpApiModel
//
//  Created by YL on 2018/12/24.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMMovieOrderModel.h"

@implementation MGMMovieOrderModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"order" : [MovieOrder class]
             };
}
    
@end

@implementation ExtData

@end

@implementation SubPaymentInfo
    
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"extData" : [ExtData class]
             };
}


@end

@implementation CurrentPaymentInfo
    
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"subPaymentInfoList" : [SubPaymentInfo class]
             };
}


@end

@implementation MovieOrder
    
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"currentPaymentInfo" : [CurrentPaymentInfo class]
             };
}
    
@end
