//
//  MGMMovieOrderModel.h
//  MGMHttpApiModel
//
//  Created by YL on 2018/12/24.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

//影片订单
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ExtData :NSObject
//支付SDK需要的订单ID
@property (nonatomic, copy) NSString *transactionCode;
//苹果商品ID
@property (nonatomic, copy) NSString *serviceId;
@property (nonatomic, strong) NSString *orderInfo;

@end

@interface SubPaymentInfo : NSObject
//金额 分
@property (nonatomic, assign) long     amount;
@property (nonatomic, copy) NSString *paymentCode;
@property (nonatomic, copy) NSString *status;
@property (nonatomic, strong)ExtData    *extData;
    
@end

@interface CurrentPaymentInfo :NSObject
//交易流水号
@property (nonatomic, copy) NSString *    paymentId;
//订单支付状态
@property (nonatomic, copy) NSString *    status;
@property (nonatomic, copy) NSArray <SubPaymentInfo *>*subPaymentInfoList;

@end

@interface MovieOrder : NSObject
    
//订单号
@property (nonatomic, copy) NSString *orderId;
//订单支付状态
@property (nonatomic, copy) NSString *status;

@property (nonatomic, strong) CurrentPaymentInfo *currentPaymentInfo;

@end

@interface MGMMovieOrderModel : NSObject

@property (nonatomic, copy) NSString  *externalOrderId;
    
@property (nonatomic, strong) MovieOrder *order;

@property (nonatomic, copy) NSString  *bizCode;

@property (nonatomic, copy) NSString  *bizMsg;

@end

NS_ASSUME_NONNULL_END
