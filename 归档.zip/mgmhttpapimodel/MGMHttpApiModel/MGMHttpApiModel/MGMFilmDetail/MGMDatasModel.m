//
//  MGMDatasModel.m
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/10/14.
//

#import "MGMDatasModel.h"

@implementation MGMDatasModel

@end
@implementation MGMDatasTip

@end

