//
//  MGMDataManagerResponse.h
//  AFNetworking
//
//  Created by apple on 2018/12/12.
//

#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN

extern NSString * const MGMDataManagerResponseErrorDomain;

@interface MGMDataManagerResponse : MGMBase

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) id body;

@property (nonatomic, assign) int64_t timeStamp;

@property (nonatomic, strong, readwrite) NSError *error;

@property (nonatomic, strong, readwrite) id otherInfo; ///< 保存其他信息

@end

NS_ASSUME_NONNULL_END
