//
//  MGMStarModel.m
//  MGMHttpApiModel
//
//  Created by 刘勇 on 2018/12/11.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMStarModel.h"

@implementation MGMStarModel

@end
