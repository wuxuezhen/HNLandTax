//
//  MGMPosterPics.h
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/10/14.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMPosterPics : MGMBaseModel
/**
 海报高清横图 4：3横图--  1080*810
 */
@property (nonatomic, copy) NSString * highResolutionH_43;

/**
 海报高清竖图 4：3竖图-- 1440*1080
 */
@property (nonatomic, copy) NSString * highResolutionV_43;

/**
 海报高清横图 16：9横图-- 1080*608
 */
@property (nonatomic, copy) NSString * highResolutionH_169;

/**
 海报高清竖图 16：9竖图-- 1920*1080
 */
@property (nonatomic, copy) NSString *highResolutionV_169;
@end

NS_ASSUME_NONNULL_END
