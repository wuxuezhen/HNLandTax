//
//  MGMFilmDetailHotReviewCountBody.h
//  MGMHttpApiModel
//
//  Created by 袁飞扬 on 2018/12/12.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"

@class MGMFilmDetailHotReviewCountBody;

NS_ASSUME_NONNULL_BEGIN

@interface MGMFilmDetailHotReviewCountModel : MGMBase

@property (nonatomic,copy)NSString *code;

@property (nonatomic,copy)NSString *message;
@property (nonatomic,copy)NSString *timeStamp;
@property (nonatomic,copy)MGMFilmDetailHotReviewCountBody *body;

@end



@interface MGMFilmDetailHotReviewCountBody : MGMBase

@property (nonatomic,copy)NSString *commentCount;

@end

@interface MGMFilmDetailLikeAndCountModel : MGMBase

@property (nonatomic,copy)NSString *code;

@property (nonatomic,copy)NSString *message;
@property (nonatomic,copy)NSString *timeStamp;
@property (nonatomic,strong)id body;

@end




@interface MGMFilmDetailLikeAndCountBody : MGMBase

@property (nonatomic,copy)NSString *hasLike;

@property (nonatomic,copy)NSString *likeCount;

@property (nonatomic,copy)NSString *commentCount;

@end



NS_ASSUME_NONNULL_END
