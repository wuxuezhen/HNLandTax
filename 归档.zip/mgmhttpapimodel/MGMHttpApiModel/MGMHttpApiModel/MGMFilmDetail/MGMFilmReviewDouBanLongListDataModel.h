//
//  MGMFilmReviewDouBanLongListDataModel.h
//  MGMLegoModule
//
//  Created by 袁飞扬 on 2018/12/8.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMThumbData.h"
@class MGMFilmReviewDouBanLong;
NS_ASSUME_NONNULL_BEGIN

@interface MGMFilmReviewDouBanLongListDataModel : NSObject

@property (nonatomic , strong) NSArray<MGMFilmReviewDouBanLong *> *commentInfos;
@property (nonatomic , strong) NSString *count;

@end

@interface MGMFilmReviewDouBanLong : NSObject

@property (nonatomic , strong) NSString *author;
@property (nonatomic , strong) NSString *body;

@property (nonatomic , strong) NSString *children;
@property (nonatomic , strong) NSString *cinemaId;
@property (nonatomic , strong) NSString *cinemaName;
@property (nonatomic , strong) NSString *cityName;
@property (nonatomic , strong) NSString *clientType;
@property (nonatomic , strong) NSString *commentCreator;
@property (nonatomic , strong) NSString *commentId;
@property (nonatomic , strong) NSString *commentSource;
@property (nonatomic , strong) NSString *commentType;



@property (nonatomic , strong) NSString *commentedCount;
@property (nonatomic , strong) NSString *commentedName;
@property (nonatomic , strong) NSString *contentId;
@property (nonatomic , strong) NSString *contentName;
@property (nonatomic , strong) NSString *contentType;
@property (nonatomic , strong) NSString *createTime;
@property (nonatomic , strong) NSString *doubanCommentId;
@property (nonatomic , strong) NSString *doubanContentId;
@property (nonatomic , strong) NSString *filmId;



@property (nonatomic , strong) NSString *headline;
@property (nonatomic , strong) NSString *latitude;
@property (nonatomic , strong) NSString *likeCount;
@property (nonatomic , strong) NSString *longComment;
@property (nonatomic , strong) NSString *longCommentSource;
@property (nonatomic , strong) NSString *longitude;
@property (nonatomic , strong) NSString *mId;
@property (nonatomic , strong) NSString *mobile;
@property (nonatomic , strong) NSString *parentId;


@property (nonatomic , strong) NSString *pictureLength;
@property (nonatomic , strong) NSString *pictureURL;
@property (nonatomic , strong) NSString *pictureWide;
@property (nonatomic , strong) NSString *score;
@property (nonatomic , strong) NSString *sdkVersion;
@property (nonatomic , strong) NSString *status;
@property (nonatomic , strong) NSString *summary;
@property (nonatomic , strong) NSString *system;
@property (nonatomic , strong) NSString *terminalType;


@property (nonatomic , strong) NSString *text;
@property (nonatomic , strong) NSString *title;
@property (nonatomic , strong) NSString *top;
@property (nonatomic , strong) NSString *topTime;
@property (nonatomic , strong) NSString *ua;
@property (nonatomic , strong) NSString *updateTime;
@property (nonatomic , strong) NSString *userHasLike;
@property (nonatomic , strong) NSString *userId;
@property (nonatomic , strong) NSString *userName;
@property (nonatomic , strong) MGMThumbData *likeModel;
@end




NS_ASSUME_NONNULL_END
