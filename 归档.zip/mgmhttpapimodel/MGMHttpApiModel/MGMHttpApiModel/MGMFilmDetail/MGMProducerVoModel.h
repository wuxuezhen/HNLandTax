//
//  MGMProducerVoModel.h
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/10/14.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMProducerVoModel : MGMBaseModel

/**
 出品方（多个值空格分隔）
 */
@property (nonatomic, copy) NSString * producers;

/**
 发行机构（多个值空格分隔）
 */
@property (nonatomic, copy) NSString * issuers;

/**
 制作机构（多个值空格分隔）
 */
@property (nonatomic, copy) NSString * productOrganizations;

/**
 引进机构（多个值空格分隔）
 */
@property (nonatomic, copy) NSString *importingOrganizations;
/**
 译作机构（多个值空格分隔）
 */
@property (nonatomic, strong) NSString *translationOrganizations;

@end

NS_ASSUME_NONNULL_END
