//
//  MGMFilmReviewHotListDataModel.m
//  MGMLegoModule
//
//  Created by 袁飞扬 on 2018/12/8.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFilmReviewHotListDataModel.h"
#import <YYModel/YYModel.h>
#import <MGMUserCertification/MGMUserCertification.h>

@implementation MGMFilmReviewHotListDataModel

@end

@implementation MGMFilmReviewHotListBody
///以字典的方式返回.key是咱们写的模型中的属性名,value是我们想要映射的后台给的字段名.
+ (nullable NSDictionary<NSString *, id> *)modelCustomPropertyMapper {
    return @{
             @"commentInfoList" : @[@"commentList",@"commentInfoList"],
             };
}

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"commentInfoList" : [MGMFilmReviewHotData class],
             };
}

@end
@implementation MGMFilmReviewHotData
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"childCommentInfo"      :     [MGMFilmReviewHotChildCommentInfo class],
             };
}
- (NSString *)userName{
    return _userName ? _userName : @"咪咕用户";
}


- (void)setCertificationTags:(NSArray<NSDictionary *> *)certificationTags{
    _certificationTags = certificationTags;
    NSArray *array = _certificationTags;
    NSDictionary *tagDic = array.firstObject;
    if (tagDic) {
        NSMutableArray *cerTypes = [NSMutableArray array];
        NSArray *keys = tagDic.allKeys;
        for (NSString *aKey in keys) {
            NSString *value = [tagDic objectForKey:aKey];
            if ((value.length > 0) && (![value isEqualToString:@"null"]) && (![value isEqualToString:@"NULL"])) {
                [cerTypes addObject:aKey];
            }
        }
        if (cerTypes.count > 0) {
            for (NSString *cerInfoString in cerTypes) {
                MGMUserCerInfo *cerInfo = [[MGMUserCertification sharedUserCertification] cerInfoForType:cerInfoString];
                if (cerInfo) {
                    _iconUrl = cerInfo.iconUrl;
                    return ;
                }
            }
        }
    }
}


@end
@implementation MGMFilmReviewHotChildCommentInfo

@end

@implementation MGMcommentPicsInfo

@end

@implementation MGMCommentPicDetail


@end
