//
//  MGMFilmDetailHotReviewCountBody.m
//  MGMHttpApiModel
//
//  Created by 袁飞扬 on 2018/12/12.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFilmDetailHotReviewCountModel.h"

@implementation MGMFilmDetailHotReviewCountModel
@end

@implementation MGMFilmDetailHotReviewCountBody
@end
@implementation MGMFilmDetailLikeAndCountModel
@end
@implementation MGMFilmDetailLikeAndCountBody
@end
