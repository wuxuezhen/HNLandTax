//
//  MGMRecommendcinemaModel.m
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/4/15.
//

#import "MGMRecommendcinemaModel.h"

@implementation MGMRecommendcinemaModel

@end
