//
//  MGMAwardDetailModel.h
//  MGMHttpApiModel
//  奖项详情model
//  Created by YL on 2019/10/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@class MGMActorInfoModel,MGMFilmDetailContentInfo;

@interface MGMAwardMainModel : MGMBaseModel
//奖项ID
@property (nonatomic, copy)  NSString   *awardId;
//奖项中文名
@property (nonatomic, copy)  NSString   *name;
//奖项英文名
@property (nonatomic, copy)  NSString   *nameEn;
//奖项简称
@property (nonatomic, copy)  NSString   *shortName;
//奖项类型 中间用‘|’隔开
@property (nonatomic, copy)  NSString   *category;
//主办单位
@property (nonatomic, copy)  NSString   *belong;
//举办地区
@property (nonatomic, copy)  NSString   *awardArea;
//举办日期
@property (nonatomic, copy)  NSString   *awardDate;
//官网地址
@property (nonatomic, copy)  NSString   *govUrl;
//奖项简介
@property (nonatomic, copy)  NSString   *detail;
//奖项图片名称
@property (nonatomic, copy)  NSString   *imageName;
//奖项图片地址
@property (nonatomic, copy)  NSString   *imagePath;

@end

//奖项人物和作品信息
@interface MGMAwardStarAssets : MGMBaseModel
//作品id，媒资id
@property (nonatomic, copy)  NSString   *assetId;
//节目ID
@property (nonatomic, copy)  NSString   *contId;
//作品名称，媒资名称
@property (nonatomic, copy)  NSString   *assetName;
//人物id
@property (nonatomic, copy)  NSString   *starId;
//人物名称
@property (nonatomic, copy)  NSString   *starName;
//一级分类类型
@property (nonatomic, copy)  NSString   *displayType;
//一级分类名称，如：电影
@property (nonatomic, copy)  NSString   *displayName;
//获奖类型，0：提名 1：获奖
@property (nonatomic, copy)  NSString   *awardType;

@property (nonatomic, strong) MGMActorInfoModel     *actorInfoModel;

@property (nonatomic, strong) MGMFilmDetailContentInfo *filmInfoModel;

@end

@interface MGMAwardStarAssetsList : MGMBaseModel

@property (nonatomic, strong)  NSMutableArray <MGMAwardStarAssets*>*starAsset;

@end

//子奖项
@interface MGMAwardChild : MGMBaseModel
//子奖项id
@property (nonatomic, copy)  NSString   *awardChildId;
//子奖项名称
@property (nonatomic, copy)  NSString   *childname;
//奖项年代
@property (nonatomic, copy)  NSString   *dates;
//奖项届别
@property (nonatomic, copy)  NSString   *period;
//该届举办地区
@property (nonatomic, copy)  NSString   *area;
//该届举办日期
@property (nonatomic, copy)  NSString   *sponsorDate;

@property (nonatomic, strong) MGMAwardStarAssetsList *awardStarAssets;
//自定义字段，判断这个子奖项是颁发给影人的
@property (nonatomic, assign) BOOL     isActorAward;

@end

@interface MGMAwardDetailModel : MGMBaseModel

@property (nonatomic, strong) MGMAwardMainModel   *award;

@property (nonatomic, copy)  NSArray <MGMAwardChild*>*awardChilds;
//奖项届别
@property (nonatomic, copy)  NSString   *period;
//奖项年代
@property (nonatomic, copy)  NSString   *year;
//该届举办地区
@property (nonatomic, copy)  NSString   *area;
//该届举办日期
@property (nonatomic, copy)  NSString   *sponsorDate;
//提名总数
@property (nonatomic, copy)  NSString   *nominateCount;
//获奖总数
@property (nonatomic, copy)  NSString   *prizeCount;

@end



NS_ASSUME_NONNULL_END
