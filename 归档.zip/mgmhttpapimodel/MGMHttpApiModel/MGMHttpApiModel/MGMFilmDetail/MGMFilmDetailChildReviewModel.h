//
//  MGMFilmDetailChildReviewModel.h
//  MGMHttpApiModel
//
//  Created by 袁飞扬 on 2018/12/20.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"
#import "MGMThumbData.h"
@class MGMChildCommentListModel,MGMparentCommentReview,MGMFilmDetailChildReviewModel;


NS_ASSUME_NONNULL_BEGIN

//@interface MGMFilmDetailChildResponse : MGMBase
//@property (nonatomic,strong)NSString *timeStamp;
//@property (nonatomic,strong)NSString *code;
//@property (nonatomic,strong)MGMFilmDetailChildReviewModel *body;
//@property (nonatomic,strong)NSString *message;
//
//@end


@interface MGMFilmDetailChildReviewModel : MGMBase

@property (nonatomic,strong)NSString *next;

@property (nonatomic,strong)NSArray<MGMChildCommentListModel *> *commentList;
@property (nonatomic,strong)NSString *success;
@property (nonatomic,strong)NSString *pageNo;

@property (nonatomic,strong)MGMparentCommentReview *parentComment;
@property (nonatomic,strong)NSString *pageSize;

@end


@interface MGMChildCommentListModel : MGMBase

@property (nonatomic,strong)NSString *commentId;

@property (nonatomic,strong)NSString *rootNodeId;
@property (nonatomic,strong)NSString *parentId;
@property (nonatomic,strong)NSString *userId;

@property (nonatomic,strong)NSString *userName;
@property (nonatomic,strong)NSString *userPortrait;

@property (nonatomic,strong)NSString *mobile;

@property (nonatomic,strong)NSString *body;
@property (nonatomic,strong)NSString *pictureType;
@property (nonatomic,strong)NSString *pictureURL;

@property (nonatomic,strong)NSString *contentId;
@property (nonatomic,strong)NSString *contentName;

@property (nonatomic, strong) NSString *respondentUserId;
@property (nonatomic, strong) NSString *respondentUserName;

@property (nonatomic,strong)NSString *contentType;

@property (nonatomic,strong)NSString *status;
@property (nonatomic,strong)NSString *clientType;
@property (nonatomic,strong)NSString *createTime;

@property (nonatomic,strong)NSString *updateTime;
@property (nonatomic,strong)NSString *mId;

@property (nonatomic,strong)NSString *likeCount;
@property (nonatomic,strong)NSString *userHasLike;

@property (nonatomic, strong) MGMThumbData *likeModel;
@property (nonatomic, assign, readonly) NSInteger commentId_;
/**
 用户认证新增字段
 */
@property (nonatomic , strong) NSArray<NSDictionary *> *certificationTags;
//用户认证icon
@property (nonatomic , strong) NSString *iconUrl;

@end



@interface MGMparentCommentReview : MGMBase


@property (nonatomic,strong)NSString *commentId;

@property (nonatomic,strong)NSString *userId;
@property (nonatomic,strong)NSString *userName;
@property (nonatomic,strong)NSString *userPortrait;

@property (nonatomic,strong)NSString *mobile;
@property (nonatomic,strong)NSString *body;



@property (nonatomic,strong)NSString *bodyMd5;

@property (nonatomic,strong)NSString *contentId;
@property (nonatomic,strong)NSString *contentName;
@property (nonatomic,strong)NSString *contentType;

@property (nonatomic,strong)NSString *status;
@property (nonatomic,strong)NSString *clientType;



@property (nonatomic,strong)NSString *commentType;

@property (nonatomic,strong)NSString *system;
@property (nonatomic,strong)NSString *top;
@property (nonatomic,strong)NSString *topTime;

@property (nonatomic,strong)NSString *createTime;
@property (nonatomic,strong)NSString *updateTime;



@property (nonatomic,strong)NSString *pictureType;

@property (nonatomic,strong)NSString *pictureURL;
@property (nonatomic,strong)NSString *commentSource;
@property (nonatomic,strong)NSString *commentCreator;

@property (nonatomic,strong)NSString *mId;
@property (nonatomic,strong)NSString *commentedCount;



@property (nonatomic,strong)NSString *likeCount;

@property (nonatomic,strong)NSString *childCommentInfo;
@property (nonatomic,strong)NSString *ua;
@property (nonatomic,strong)NSString *sdkVersion;

@property (nonatomic,strong)NSString *channelId;
@property (nonatomic,strong)NSString *userHasLike;


@property (nonatomic, strong) MGMThumbData *likeModel;

//certificationTags
/**
 用户认证新增字段
 */
@property (nonatomic , strong) NSArray<NSDictionary *> *certificationTags;
//用户认证icon
@property (nonatomic , strong) NSString *iconUrl;

@end









NS_ASSUME_NONNULL_END
