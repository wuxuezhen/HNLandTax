//
//  MGMFilmDetailTopic.m
//  MGMHttpApiModel
//
//  Created by apple on 2018/12/12.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFilmDetailTopic.h"

@implementation MGMFilmDetailTopicContentModel

@end

@implementation MGMFilmDetailTopicResponseBody

+ (nullable NSDictionary<NSString *, id> *)modelContainerPropertyGenericClass {
    return @{@"content": MGMFilmDetailTopicContentModel.class};
}

@end

@implementation MGMFilmDetailTopicResponse

@end


