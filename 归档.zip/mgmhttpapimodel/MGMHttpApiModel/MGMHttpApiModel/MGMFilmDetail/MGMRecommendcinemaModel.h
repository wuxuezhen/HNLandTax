//
//  MGMRecommendcinemaModel.h
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/4/15.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMRecommendcinemaModel : MGMBaseModel


@property (nonatomic, copy) NSString * msg;


@property (nonatomic, copy) NSString * status;


@property (nonatomic, copy) NSArray * data;


@end

NS_ASSUME_NONNULL_END
