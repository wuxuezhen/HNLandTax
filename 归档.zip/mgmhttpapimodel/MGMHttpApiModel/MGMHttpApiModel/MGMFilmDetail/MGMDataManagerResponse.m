//
//  MGMDataManagerResponse.m
//  AFNetworking
//
//  Created by apple on 2018/12/12.
//

#import "MGMDataManagerResponse.h"

NSString * const MGMDataManagerResponseErrorDomain = @"MGMDataManagerResponseErrorDomain";

@implementation MGMDataManagerResponse

@end
