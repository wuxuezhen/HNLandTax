//
//  MGMFilmDetailContentInfo.m
//  MGMHttpApiModel
//
//  Created by zhaohao on 2018/12/11.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFilmDetailContentInfo.h"
#import <YYModel/YYModel.h>

@implementation MGMFilmDetailContentInfo

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"contentID"  : @"contId"};
}
    
+ (nullable NSDictionary<NSString *, id> *)modelContainerPropertyGenericClass {
    return @{@"star": MGMStarModel.class,
             @"directorInfo":MGMStarModel.class,
             @"movieStills": NSString.class,
             @"awardInfo" : MGMAwardDetailModel.class
             };
}

@end
