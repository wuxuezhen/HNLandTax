//
//  MGMAwardDetailModel.m
//  MGMHttpApiModel
//
//  Created by YL on 2019/10/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMAwardDetailModel.h"

@implementation MGMAwardMainModel

@end

@implementation MGMAwardStarAssets

@end

@implementation MGMAwardStarAssetsList

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"starAsset" : [MGMAwardStarAssets class],
             };
}

@end

@implementation MGMAwardChild

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"awardStarAssets" : [MGMAwardStarAssetsList class]
             };
}

@end

@implementation MGMAwardDetailModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"award" : [MGMAwardMainModel class],
             @"awardChilds" : [MGMAwardChild class]
             };
}

@end
