//
//  MGMActorDetailModel.h
//  MGMHttpApiModel
//  影人详情
//  Created by YL on 2019/10/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMActorInfoModel:MGMBaseModel
//影人类型
@property (nonatomic, copy)  NSString   *starVocation;
//影人头像
@property (nonatomic, copy)  NSString   *starImg;
//影人姓名
@property (nonatomic, copy)  NSString   *starName;
//影人ID
@property (nonatomic, copy)  NSString   *starId;
//影人生日
@property (nonatomic, copy)  NSString   *starBirthday;
//影人简介
@property (nonatomic, copy)  NSString   *brief;
//影人国籍
@property (nonatomic, copy)  NSString   *birthplace;

@end

@interface MGMActorDetailModel : MGMBaseModel

@property (nonatomic, copy) NSArray    <MGMActorInfoModel *>*body;

@end

NS_ASSUME_NONNULL_END
