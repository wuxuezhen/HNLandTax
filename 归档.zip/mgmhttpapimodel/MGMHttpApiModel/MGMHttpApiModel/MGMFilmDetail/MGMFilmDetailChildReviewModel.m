//
//  MGMFilmDetailChildReviewModel.m
//  MGMHttpApiModel
//
//  Created by 袁飞扬 on 2018/12/20.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFilmDetailChildReviewModel.h"
#import <MGMUserCertification/MGMUserCertification.h>


//@implementation MGMFilmDetailChildResponse
//
//
//@end


@implementation MGMFilmDetailChildReviewModel

+ (NSDictionary *)modelContainerPropertyGenericClass {
    
    return @{@"commentList" : [MGMChildCommentListModel class],
             };
}

+ (nullable NSDictionary<NSString *, id> *)modelCustomPropertyMapper {
    return @{
             @"commentList" : @[@"commentList" ,@"commentInfoList"],
             };
}
@end

@implementation MGMChildCommentListModel

- (NSInteger)commentId_ {
    return self.commentId.integerValue;
}
- (NSString *)userName {
    return _userName? _userName : @"咪咕用户";
}
//- (NSString *)respondentUserName{
//    return _respondentUserName ? _respondentUserName : @"咪咕用户";
//}

- (void)setCertificationTags:(NSArray<NSDictionary *> *)certificationTags{
    _certificationTags = certificationTags;
    NSArray *array = _certificationTags;
    NSDictionary *tagDic = array.firstObject;
    if (tagDic) {
        NSMutableArray *cerTypes = [NSMutableArray array];
        NSArray *keys = tagDic.allKeys;
        for (NSString *aKey in keys) {
            NSString *value = [tagDic objectForKey:aKey];
            if ((value.length > 0) && (![value isEqualToString:@"null"]) && (![value isEqualToString:@"NULL"])) {
                [cerTypes addObject:aKey];
            }
        }
        if (cerTypes.count > 0) {
            for (NSString *cerInfoString in cerTypes) {
                MGMUserCerInfo *cerInfo = [[MGMUserCertification sharedUserCertification] cerInfoForType:cerInfoString];
                if (cerInfo) {
                    _iconUrl = cerInfo.iconUrl;
                    return ;
                }
            }
        }
    }
}

@end

@implementation MGMparentCommentReview
- (NSString *)userName {
    return _userName? _userName : @"咪咕用户";
}
- (void)setCertificationTags:(NSArray<NSDictionary *> *)certificationTags{
    _certificationTags = certificationTags;
    NSArray *array = _certificationTags;
    NSDictionary *tagDic = array.firstObject;
    if (tagDic) {
        NSMutableArray *cerTypes = [NSMutableArray array];
        NSArray *keys = tagDic.allKeys;
        for (NSString *aKey in keys) {
            NSString *value = [tagDic objectForKey:aKey];
            if ((value.length > 0) && (![value isEqualToString:@"null"])  && (![value isEqualToString:@"NULL"])) {
                [cerTypes addObject:aKey];
            }
        }
        if (cerTypes.count > 0) {
            for (NSString *cerInfoString in cerTypes) {
                MGMUserCerInfo *cerInfo = [[MGMUserCertification sharedUserCertification] cerInfoForType:cerInfoString];
                if (cerInfo) {
                    _iconUrl = cerInfo.iconUrl;
                    return ;
                }
            }
        }
    }
}

@end
