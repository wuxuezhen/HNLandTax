//
//  MGMFilmDetailTopic.h
//  MGMHttpApiModel
//
//  Created by apple on 2018/12/12.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@interface MGMFilmDetailTopicContentModel : MGMBase

@property (nonatomic, strong) NSString * author;
@property (nonatomic, strong) NSString * cinemaName;
@property (nonatomic, strong) NSString * cityName;
@property (nonatomic, assign) NSInteger commentedCount;
@property (nonatomic, strong) NSString * content;
@property (nonatomic, strong) NSString * cornerMark;
@property (nonatomic, strong) NSDate * createTime;
@property (nonatomic, assign) NSInteger id;
@property (nonatomic, assign) NSInteger likeCount;
@property (nonatomic, strong) NSString * mobile;
@property (nonatomic, assign) NSInteger objectId;
@property (nonatomic, strong) NSString * objectName;
@property (nonatomic, strong) NSString * objectType;
@property (nonatomic, assign) NSInteger readCount;
@property (nonatomic, strong) NSDate * recoveryTime;
@property (nonatomic, strong) NSString * sdkVersion;
@property (nonatomic, assign) NSInteger status;
@property (nonatomic, strong) NSString * summary;
@property (nonatomic, strong) NSURL * summaryImages;
@property (nonatomic, strong) NSString * system;
@property (nonatomic, strong) NSString * terminalType;
@property (nonatomic, strong) NSString * title;
@property (nonatomic, strong) NSString * top;
@property (nonatomic, strong) NSString * topEndTime;
@property (nonatomic, strong) NSString * topStartTime;
@property (nonatomic, strong) NSString * topTags;
@property (nonatomic, strong) NSString * topicSource;
@property (nonatomic, strong) NSString * topicTags;
@property (nonatomic, strong) NSString * topicType;
@property (nonatomic, strong) NSString * ua;
@property (nonatomic, strong) NSDate * updateTime;
@property (nonatomic, assign) BOOL userHasLike;
@property (nonatomic, strong) NSString * userId;

@end

@interface MGMFilmDetailTopicResponseBody : MGMBase
@property (nonatomic, assign) NSInteger count;
@property (nonatomic, assign) NSInteger nextStart;
@property (nonatomic, strong) NSArray <MGMFilmDetailTopicContentModel *>*content;

@end

@interface MGMFilmDetailTopicResponse : MGMBase

@property (nonatomic, assign) NSInteger code;
@property (nonatomic, strong) NSString * message;
@property (nonatomic, assign) double timeStamp;
@property (nonatomic, strong) MGMFilmDetailTopicResponseBody *body;

@end

NS_ASSUME_NONNULL_END
