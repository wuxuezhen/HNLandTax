//
//  MGMFilmReviewDouBanLongListDataModel.m
//  MGMLegoModule
//
//  Created by 袁飞扬 on 2018/12/8.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFilmReviewDouBanLongListDataModel.h"
#import <YYModel/YYModel.h>

@implementation MGMFilmReviewDouBanLongListDataModel

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"commentInfos" : [MGMFilmReviewDouBanLong class],
             };
}
// 直接添加以下代码即可自动完成
- (void)encodeWithCoder:(NSCoder *)aCoder { [self yy_modelEncodeWithCoder:aCoder]; }
- (id)initWithCoder:(NSCoder *)aDecoder { self = [super init]; return [self yy_modelInitWithCoder:aDecoder]; }
- (id)copyWithZone:(NSZone *)zone { return [self yy_modelCopy]; }
- (NSUInteger)hash { return [self yy_modelHash]; }
- (BOOL)isEqual:(id)object { return [self yy_modelIsEqual:object]; }
- (NSString *)description { return [self yy_modelDescription]; }

@end

@implementation MGMFilmReviewDouBanLong

- (NSString *)userName{
    return _userName ? _userName : @"咪咕用户";
}

// 直接添加以下代码即可自动完成
- (void)encodeWithCoder:(NSCoder *)aCoder { [self yy_modelEncodeWithCoder:aCoder]; }
- (id)initWithCoder:(NSCoder *)aDecoder { self = [super init]; return [self yy_modelInitWithCoder:aDecoder]; }
- (id)copyWithZone:(NSZone *)zone { return [self yy_modelCopy]; }
- (NSUInteger)hash { return [self yy_modelHash]; }
- (BOOL)isEqual:(id)object { return [self yy_modelIsEqual:object]; }
- (NSString *)description { return [self yy_modelDescription]; }
@end
