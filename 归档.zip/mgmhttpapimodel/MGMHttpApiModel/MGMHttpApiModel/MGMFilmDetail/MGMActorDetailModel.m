//
//  MGMActorDetailModel.m
//  MGMHttpApiModel
//
//  Created by YL on 2019/10/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMActorDetailModel.h"

@implementation MGMActorInfoModel

@end

@implementation MGMActorDetailModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"body" : [MGMActorInfoModel class],
             };
}

@end
