//
//  MGMPlayingModel.h
//  MGMHttpApiModel
//
//  Created by 刘勇 on 2018/12/11.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMPlayingModel : MGMBaseModel

/**
 节目ID,当前播放的节目信息，如果为剧集壳取第一集的信息
 */
@property (nonatomic, copy) NSString *pID;

/**
 节目名称
 */
@property (nonatomic, copy) NSString *name;

/**
 节目时长
 */
@property (nonatomic, copy) NSString *duration;


@end

NS_ASSUME_NONNULL_END
