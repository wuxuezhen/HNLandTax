//
//  MGMProducerVoModel.m
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/10/14.
//

#import "MGMProducerVoModel.h"

@implementation MGMProducerVoModel

@end
