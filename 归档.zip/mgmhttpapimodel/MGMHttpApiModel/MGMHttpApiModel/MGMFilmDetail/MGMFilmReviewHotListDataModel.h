//
//  MGMFilmReviewHotListDataModel.h
//  MGMLegoModule
//
//  Created by 袁飞扬 on 2018/12/8.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMThumbData.h"
#import <MGMUserCertification/MGMUserCertification.h>

@class MGMFilmReviewHotData, MGMFilmReviewHotListBody;
@class MGMFilmReviewHotChildCommentInfo,MGMcommentPicsInfo,MGMCommentPicDetail;


NS_ASSUME_NONNULL_BEGIN

@interface MGMFilmReviewHotListDataModel : MGMBase

@property (nonatomic , strong) MGMFilmReviewHotListBody *body;

@property (nonatomic , strong) NSString *timeStamp;
@property (nonatomic , strong) NSString *code;


@end


@interface MGMFilmReviewHotListBody : MGMBase

@property (nonatomic , strong) NSString *next;
@property (nonatomic , strong) NSString *pageNo;
@property (nonatomic , strong) NSString *pageSize;
@property (nonatomic , strong) NSString *success;
@property (nonatomic , strong) NSArray<MGMFilmReviewHotData *> *commentInfoList;
@property (nonatomic, strong) NSString *commentCount;
@end



@interface MGMFilmReviewHotData : MGMBase

@property (nonatomic , strong) NSString *body;
@property (nonatomic , strong) NSString *clientType;
@property (nonatomic , strong) NSString *commentId;
@property (nonatomic , strong) NSString *commentType;
@property (nonatomic , strong) NSString *commentedCount;

@property (nonatomic , strong) NSString *contentId;
@property (nonatomic , strong) NSString *contentName;
@property (nonatomic , strong) NSString *contentType;
@property (nonatomic , strong) NSString *createTime;
@property (nonatomic , strong) NSString *likeCount;

@property (nonatomic , strong) NSString *mId;
@property (nonatomic , strong) NSString *mobile;
@property (nonatomic , strong) NSString *pictureType;
@property (nonatomic , strong) NSString *pictureURL;
@property (nonatomic , strong) NSString *status;

@property (nonatomic , strong) NSString *top;
@property (nonatomic , strong) NSString *topTime;
@property (nonatomic , strong) NSString *updateTime;
@property (nonatomic , strong) NSString *userHasLike;
@property (nonatomic , strong) NSString *userId;
@property (nonatomic , strong) NSString *userName;
@property (nonatomic , strong) NSString *userPortrait;
@property (nonatomic , strong) NSArray<MGMFilmReviewHotChildCommentInfo *> *childCommentInfo;
@property (nonatomic , strong) MGMThumbData *likeModel;

/**
 用户认证新增字段
 */
@property (nonatomic , strong) NSArray<NSDictionary *> *certificationTags;
//用户认证icon
@property (nonatomic , strong) NSString *iconUrl;



/**
评论定位新增字段
*/

@property (nonatomic , strong) NSString *hasVip;

//@property (nonatomic , strong) NSString *sendDynamic;
//
//@property (nonatomic , strong) NSArray<NSString *> *commentQuestionAnswer;

@property (nonatomic , assign) BOOL questionAnswerComment;

//@property (nonatomic , strong) NSArray<MGMcommentPicsInfo *> *commentPics;


@end


@interface MGMFilmReviewHotChildCommentInfo : MGMBase
@property (nonatomic , strong) NSString *childNodeId;
@property (nonatomic , strong) NSString *childNodeUserCommentBody;
@property (nonatomic , strong) NSString *status;
@property (nonatomic , strong) NSString *userId;
@property (nonatomic , strong) NSString *userName;
@property (nonatomic , strong) NSString *userPortrait;

@property (nonatomic, copy) NSString *respondentUserId;
@property (nonatomic, copy) NSString *respondentUserName;
@property (nonatomic, copy) NSString *respondentCommentId;

@end


/**
 评论定位新增字段
 */
@interface MGMcommentPicsInfo : MGMBase

@property (nonatomic , strong) MGMCommentPicDetail *heightPic;

@property (nonatomic , strong) MGMCommentPicDetail *lowPic;

@end


@interface MGMCommentPicDetail : NSObject

@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *width;
@property (nonatomic, copy) NSString *height;

@end

NS_ASSUME_NONNULL_END
