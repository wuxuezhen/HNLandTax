//
//  MGMFilmDetailContentInfo.h
//  MGMHttpApiModel
//
//  Created by zhaohao on 2018/12/11.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMStarModel.h"
#import "MGMLegoModel.h"
#import "MGMDatasModel.h"
#import "MGMProducerVoModel.h"
#import "MGMPosterPics.h"
#import "MGMAwardInfo.h"
#import "MGMAwardDetailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFilmDetailContentInfo : NSObject

@property (nonatomic, copy) NSString * actor;

@property (nonatomic, copy) NSString * area;
// 媒资ID
@property (nonatomic, copy) NSString * assetID;

@property (nonatomic, copy) NSString * year;

@property (nonatomic, copy) NSString * contentStyle;

//值为MOVIE 代表正片  节目类型  获取节目类型 TV_PLAY：电视剧 MOVIE：电影 VARIETY_SHOW：综艺 OTHER：其他
//此字段接口出问题，已废弃，建议其他接口的programType字段不要用
@property (nonatomic, copy) NSString * programType;

// 版权方
@property (nonatomic, copy) NSString * cpName;

// 导演
@property (nonatomic, copy) NSString * director;

// 简介
@property (nonatomic, copy) NSString * detail;

@property (nonatomic, copy) NSString * name;

// 评分
@property (nonatomic, copy) NSString *score;

// 影人
@property (nonatomic, copy) NSArray<MGMStarModel *> *star;

@property (nonatomic, strong) MGMPic *pics;

@property (nonatomic, copy) NSString *starIds;

// 预览图片
@property (nonatomic, copy) NSString * previewPicture;

@property (nonatomic, copy) NSString * author;

// 版权使用方式限制 1-仅播放；2-仅下载；3-不限播放和下载
@property (nonatomic, copy) NSString * way;

@property (nonatomic, strong) MGMPic *h5pics;

@property (nonatomic, copy) NSString *filmId;

// 上映时间
@property (nonatomic, copy) NSString *showTime;

@property (nonatomic, copy) NSString *showTimeName;

@property (nonatomic, copy) NSString *showTimeDesc;

// 发布时间
@property (nonatomic, copy) NSString *publishTime;

@property (nonatomic, copy) NSArray <NSString *> *movieStills;

@property (nonatomic, copy) NSString *playing;

// 产品包ID
@property (nonatomic, copy) NSString * prdPackId;

// 是否是pp产品包(1:是，2:不是)
@property (nonatomic, copy) NSString * pricing_stage;

// 时长
@property (nonatomic, copy) NSString * duration;

/// 关键字
@property (nonatomic, strong) NSString * KEYWORDS;
/// 判断影片是否是全片
@property (nonatomic, strong) NSString  *contForm;

/// 分享副标题
@property (nonatomic, strong) NSString  *twDetail;

/// 是否可以播放
@property (nonatomic, copy) NSString *playType;
/// 彩蛋信息
@property (nonatomic, copy) NSString *filmEnd;
/// 视频剧照小视频搜索需要字段
@property (nonatomic, copy) NSString *mpid;
/// 电影时长
@property (nonatomic, copy) NSString *showLength;


// 10月改版新增字段
//节目信息
@property (nonatomic, copy) MGMDatasModel *datas;
//数据总条数
@property (nonatomic, copy) NSString *totalCount;
//为兼容老版本，新增programType
@property (nonatomic, copy) NSString *programTypeV2;

//首周票房，单位为万
@property (nonatomic, copy) NSString *weeklyBoxOffice;
//累计票房，单位为万
@property (nonatomic, copy) NSString *totalBoxOffice;

//出版信息
@property (nonatomic, strong) MGMProducerVoModel *producerVo;

//海报高清图
@property (nonatomic, strong) MGMPosterPics *posterPics;
//海报高清图
@property (nonatomic, strong) MGMPosterPics *posterHttpsPics;
//获奖信息
@property (nonatomic, strong) NSArray <MGMAwardDetailModel *> *awardInfo;
//导演信息
@property (nonatomic, copy)  NSArray<MGMStarModel *> *directorInfo;

//自定义字段
@property (nonatomic, assign) BOOL isOpen;

@property (nonatomic, copy) NSString    *contentID;
@property (nonatomic, copy) NSString    *assetShellId; //媒资壳ID

@end


NS_ASSUME_NONNULL_END
