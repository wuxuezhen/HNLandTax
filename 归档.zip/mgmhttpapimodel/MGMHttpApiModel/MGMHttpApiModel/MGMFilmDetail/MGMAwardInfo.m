//
//  MGMAwardInfo.m
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/10/14.
//

#import "MGMAwardInfo.h"

@implementation MGMAwardInfo

@end

@implementation MGMAwardModel

@end

@implementation MGMAwardStarAssetsModel
+ (nullable NSDictionary<NSString *, id> *)modelContainerPropertyGenericClass {
    return @{@"starAsset": MGMStarAssetModel.class,
             };
}
@end

@implementation MGMStarAssetModel

@end
