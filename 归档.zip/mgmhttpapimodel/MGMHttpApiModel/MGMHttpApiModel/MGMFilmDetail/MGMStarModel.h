//
//  MGMStarModel.h
//  MGMHttpApiModel
//
//  Created by 刘勇 on 2018/12/11.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMStarModel : MGMBaseModel

/**
 影人类型
 */
@property (nonatomic, copy) NSString * career;

/**
 影人头像
 */
@property (nonatomic, copy) NSString * img;

/**
 影人姓名
 */
@property (nonatomic, copy) NSString * name;

/**
 影人ID
 */
@property (nonatomic, copy) NSString * starId;

@end

NS_ASSUME_NONNULL_END
