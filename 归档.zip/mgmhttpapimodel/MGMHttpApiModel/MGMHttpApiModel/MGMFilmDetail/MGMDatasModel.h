//
//  MGMDatasModel.h
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/10/14.
//

#import <Foundation/Foundation.h>
#import "MGMBaseModel.h"
#import "MGMLegoModel.h"

@class MGMDatasTip;

NS_ASSUME_NONNULL_BEGIN



@interface MGMDatasModel : MGMBaseModel
/**
 时长
 */
@property (nonatomic, copy) NSString * duration;

/**
 节目名称
 */
@property (nonatomic, copy) NSString * name;

/**
 节目ID
 */
@property (nonatomic, copy) NSString * pID;

/**
 海报图片
 */
@property (nonatomic, strong) MGMPic *pics;
/**
 角标
 */
@property (nonatomic, strong) MGMDatasTip *tip;



@end

@interface MGMDatasTip : MGMBaseModel

/**
 角标代码
 */
@property (nonatomic, copy) NSString * code;

/**
 角标名称
 */
@property (nonatomic, copy) NSString * msg;

@end




NS_ASSUME_NONNULL_END
