//
//  MGMHttpResponse.h
//  MGMHttpApiModel
//
//  Created by zhaohao on 2018/12/11.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMHttpResponse : NSObject

@property (nonatomic, copy) NSString *code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) id body;

@property (nonatomic, assign) int64_t timeStamp;

@end

NS_ASSUME_NONNULL_END
