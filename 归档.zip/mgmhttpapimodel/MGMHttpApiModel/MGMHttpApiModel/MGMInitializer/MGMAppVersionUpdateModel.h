//
//  MGMAppVersionUpdateModel.h
//  MGMHttpApiModel
//
//  Created by 袁飞扬 on 2019/1/31.
//  Copyright © 2019年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"
#import <YYModel/YYModel.h>

NS_ASSUME_NONNULL_BEGIN

@class MGMAppVersionUpdateBody;

@interface MGMAppVersionUpdateModel : MGMBase

@property (nonatomic, copy)NSString *timeStamp;

@property (nonatomic, copy)NSString *code;

@property (nonatomic, copy)NSString *message;

@property (nonatomic, copy)MGMAppVersionUpdateBody *body;

@end


@interface MGMAppVersionUpdateBody : MGMBase

//版本号
@property (nonatomic, copy)NSString  *version;
//版本id
@property (nonatomic, assign)NSInteger  versionCode;
//强升版本id（低于此版本号仅允许发送白名单请求需要APP端验证）
@property (nonatomic, assign)NSInteger  updateVersionCode;
//终端类型 IOS Android
@property (nonatomic, copy)NSString  *ua;
//是否强制升级  true 是  false 否
@property (nonatomic, assign)BOOL renew;

//是否清除缓存   true 是   false 否
@property (nonatomic, assign)BOOL delCache;
//当前版本是否为最新版本  true 是  false 否
@property (nonatomic, assign)BOOL latestVersion;
//更新提示
@property (nonatomic, copy)NSString  *tips;
//升级内容
@property (nonatomic, copy)NSString  *message;
//更新页地址
@property (nonatomic, copy)NSString  *pageUrl;
//下载地址
@property (nonatomic, copy)NSString  *downloadUrl;
//升级包大小
@property (nonatomic, copy)NSString  *packageSize;
@end



NS_ASSUME_NONNULL_END
