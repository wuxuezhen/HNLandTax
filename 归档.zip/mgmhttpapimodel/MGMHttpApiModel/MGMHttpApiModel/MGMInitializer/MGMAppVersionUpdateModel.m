//
//  MGMAppVersionUpdateModel.m
//  MGMHttpApiModel
//
//  Created by 袁飞扬 on 2019/1/31.
//  Copyright © 2019年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMAppVersionUpdateModel.h"

@implementation MGMAppVersionUpdateModel

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"body" : [MGMAppVersionUpdateBody class],
             };
}

@end

@implementation MGMAppVersionUpdateBody

@end
