//
//Created by ESJsonFormatForMac on 19/03/21.
//

#import "MGMSignStaticImgModel.h"
@implementation MGMSignStaticImgModel


@end

@implementation MGMSignStaticImgBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [MGMSignStaticImgData class]};
}


+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"ID":@"id"};
}

@end


@implementation MGMSignStaticImgData


@end


@implementation MGMSignStaticImgPics


@end


@implementation MGMSignStaticImgH5Pics


@end


@implementation MGMSignStaticImgExtradata


@end


