//
//Created by ESJsonFormatForMac on 19/03/25.
//

#import "MGMSignCardOrderResultModel.h"
@implementation MGMSignCardOrderResultModel


@end

@implementation MGMSignCardOrderResultBody


@end


@implementation MGMSignCardOrder


@end


@implementation MGMSignCardOrderResultExtinfo


@end


@implementation MGMSignCardOrderResultCurrentpaymentinfo

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"subPaymentInfoList" : [MGMSignCardOrderResultSubpaymentinfolist class]};
}


@end


@implementation MGMSignCardOrderResultSubpaymentinfolist


@end


