//
//Created by ESJsonFormatForMac on 19/09/11.
//

#import <Foundation/Foundation.h>

@class MGMUserDiscreteSignDetailInfoBody,MGMDiscretesigndetailinfos;
@interface MGMUserDiscreteSignDetailInfoModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMUserDiscreteSignDetailInfoBody *body;

@property (nonatomic, assign) BOOL success;

@end
@interface MGMUserDiscreteSignDetailInfoBody : NSObject

@property (nonatomic, assign) NSInteger day;

@property (nonatomic, assign) BOOL isSigned;

@property (nonatomic, strong) NSArray *discreteSignDetailInfos;

@end

@interface MGMDiscretesigndetailinfos : NSObject

@property (nonatomic, assign) NSInteger state;

@property (nonatomic, copy) NSString *wareId;

@property (nonatomic, assign) NSInteger day;

@property (nonatomic, copy) NSString *wareName;

@property (nonatomic, copy) NSString *intfId;

@end

