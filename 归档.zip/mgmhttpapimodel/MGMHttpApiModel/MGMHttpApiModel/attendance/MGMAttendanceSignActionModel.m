//
//Created by ESJsonFormatForMac on 19/03/04.
//

#import "MGMAttendanceSignActionModel.h"
@implementation MGMAttendanceSignActionModel


@end

@implementation MGMAttendanceSignActionBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"wareList" : [MGMAttendanceSignActionWarelist class]};
}


@end


@implementation MGMAttendanceSignActionWarelist


@end


