//
//Created by ESJsonFormatForMac on 19/03/11.
//

#import "MGMAttendanceAcountBillModel.h"
@implementation MGMAttendanceAcountBillModel


@end

@implementation MGMAttendanceAcountBillBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"bills" : [MGMAttendanceAcountBill class]};
}


@end


@implementation MGMAttendanceAcountBill


@end


@implementation MGMAttendanceAcountBillExtinfo


@end


