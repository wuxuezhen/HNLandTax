//
//Created by ESJsonFormatForMac on 19/03/05.
//

#import <Foundation/Foundation.h>

@class MGMAttendanceUserWaresModelBody,MGMAttendanceUserWaresModelWarelist;
@interface MGMAttendanceUserWaresModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMAttendanceUserWaresModelBody *body;

@property (nonatomic, assign) BOOL success;

@end
@interface MGMAttendanceUserWaresModelBody : NSObject

@property (nonatomic, copy) NSString *userId;

@property (nonatomic, strong) NSArray *wareList;

@end

@interface MGMAttendanceUserWaresModelWarelist : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, assign) long long createTime;

@property (nonatomic, copy) NSString *wareName;

@property (nonatomic, copy) NSString *wareId;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *tag;

@end

