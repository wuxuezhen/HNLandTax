//
//Created by ESJsonFormatForMac on 19/10/11.
//

#import <Foundation/Foundation.h>

@class MGMRechargeInfoBody,MGMRechargeinfolist,MGMRechargeInfoExtinfo;
@interface MGMRechargeInfoModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMRechargeInfoBody *body;

@end
@interface MGMRechargeInfoBody : NSObject

@property (nonatomic, copy) NSString *bizCode;

@property (nonatomic, strong) NSArray *rechargeInfoList;

@property (nonatomic, copy) NSString *bizMsg;

@end

@interface MGMRechargeinfolist : NSObject

@property (nonatomic, copy) NSString *isDefer;

@property (nonatomic, strong) NSDictionary *extInfo;

@property (nonatomic, assign) NSInteger amount;

@property (nonatomic, copy) NSString *managementId;

@property (nonatomic, copy) NSString *scope;

@property (nonatomic, copy) NSString *rechargeNum;

@property (nonatomic, copy) NSString *accountType;

@property (nonatomic, copy) NSString *cardNum;

@property (nonatomic, copy) NSString *batchId;

@property (nonatomic, copy) NSString *expiryDate;

@property (nonatomic, copy) NSString *createTime;

@property (nonatomic, strong) NSDictionary *currencyMetaInfo;

@property (nonatomic, copy) NSString *effectiveDate;

@property (nonatomic, copy) NSString *beginExpiryDate;

@property (nonatomic, copy) NSString *currency;

@end

