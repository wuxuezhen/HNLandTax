//
//Created by ESJsonFormatForMac on 19/03/11.
//

#import <Foundation/Foundation.h>

@class MGMAttendanceCardPriceBody,MGMAttendanceCardPricing,MGMAttendanceCardPriceInfo,MGMAttendanceCardPriceMaindeliveryitem,MGMAttendanceCardPriceData,MGMAttendanceCardPriceServiceinfo,MGMAttendanceCardPricePayments,MGMAttendanceCardPriceRate;
@interface MGMAttendanceCardPriceModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMAttendanceCardPriceBody *body;

@end
@interface MGMAttendanceCardPriceBody : NSObject

@property (nonatomic, copy) NSString *bizCode;

@property (nonatomic, strong) MGMAttendanceCardPricing *pricing;

@property (nonatomic, copy) NSString *bizMsg;

@end

@interface MGMAttendanceCardPricing : NSObject

@property (nonatomic, strong) NSArray *priceInfo;

@end

@interface MGMAttendanceCardPriceInfo : NSObject

@property (nonatomic, strong) MGMAttendanceCardPriceServiceinfo *serviceInfo;

@property (nonatomic, copy) NSString *resultDesc;

@property (nonatomic, assign) NSInteger lastPrice;

@property (nonatomic, strong) MGMAttendanceCardPriceMaindeliveryitem *mainDeliveryItem;

@property (nonatomic, strong) NSArray *securities;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, copy) NSString *resultCode;

@property (nonatomic, strong) NSArray *payments;

@property (nonatomic, strong) NSArray *promotions;

@property (nonatomic, strong) NSArray *extDeliveryItems;

@property (nonatomic, copy) NSString *errorCode;

@end

@interface MGMAttendanceCardPriceMaindeliveryitem : NSObject

@property (nonatomic, copy) NSString *handler;

@property (nonatomic, assign) BOOL revokeScheduleSupport;

@property (nonatomic, strong) MGMAttendanceCardPriceData *data;

@property (nonatomic, assign) BOOL beforehandSupport;

@property (nonatomic, copy) NSString *scheduling;

@property (nonatomic, assign) BOOL revokeDeliverySupport;

@property (nonatomic, copy) NSString *authorization;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *desc;

@end

@interface MGMAttendanceCardPriceData : NSObject

@property (nonatomic, copy) NSString *sendSmsStatus;

@property (nonatomic, copy) NSString *mobile;

@property (nonatomic, copy) NSString *cardCount;

@property (nonatomic, copy) NSString *cardAmount;

@property (nonatomic, copy) NSString *deliverySalt;

@property (nonatomic, copy) NSString *partnerNoOrderId;

@property (nonatomic, copy) NSString *partnerNo;

@property (nonatomic, copy) NSString *deliverStatus;

@property (nonatomic, copy) NSString *traceId;

@property (nonatomic, copy) NSString *expireDate;

@property (nonatomic, copy) NSString *effectiveDate;

@property (nonatomic, copy) NSString *goodsId;

@property (nonatomic, copy) NSString *syncStatus;

@end

@interface MGMAttendanceCardPriceServiceinfo : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) BOOL repeatSubscriptionSupport;

@property (nonatomic, assign) BOOL autoSubscriptionSupport;

@property (nonatomic, copy) NSString *code;

@property (nonatomic, assign) NSInteger price;

@property (nonatomic, assign) BOOL supportRefund;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, assign) BOOL supportProlongAuth;

@property (nonatomic, copy) NSString *name;

@end

@interface MGMAttendanceCardPricePayments : NSObject

@property (nonatomic, copy) NSString *limited;

@property (nonatomic, assign) NSInteger amount;

@property (nonatomic, assign) BOOL mixable;

@property (nonatomic, copy) NSString *charge;

@property (nonatomic, copy) NSString *accountType;

@property (nonatomic, copy) NSString *code;

@property (nonatomic, strong) NSArray *carrierSupport;

@property (nonatomic, strong) NSArray *terminalSupport;

@property (nonatomic, strong) MGMAttendanceCardPriceRate *rate;

@property (nonatomic, assign) BOOL autoSubscriptionSupport;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) NSArray *payDeliveryItems;

@end

@interface MGMAttendanceCardPriceRate : NSObject

@property (nonatomic, assign) NSInteger numerator;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger denominator;

@end

