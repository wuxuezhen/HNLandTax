//
//Created by ESJsonFormatForMac on 19/04/22.
//

#import <Foundation/Foundation.h>

@class MGMAttendanceBalanceBody,MGMAttendanceBalances;
@interface MGMAttendanceBalanceModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMAttendanceBalanceBody *body;

@end
@interface MGMAttendanceBalanceBody : NSObject

@property (nonatomic, copy) NSString *bizMsg;

@property (nonatomic, strong) NSArray *balances;

@property (nonatomic, copy) NSString *extInfo;

@property (nonatomic, copy) NSString *bizCode;

@end

@interface MGMAttendanceBalances : NSObject

@property (nonatomic, copy) NSString *expiryDate;

@property (nonatomic, assign) NSInteger amount;

@property (nonatomic, copy) NSString *currency;

@property (nonatomic, copy) NSString *accountType;

@end

