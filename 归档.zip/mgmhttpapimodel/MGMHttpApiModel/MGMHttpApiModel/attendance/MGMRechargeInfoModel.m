//
//Created by ESJsonFormatForMac on 19/10/11.
//

#import "MGMRechargeInfoModel.h"
@implementation MGMRechargeInfoModel


@end

@implementation MGMRechargeInfoBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"rechargeInfoList" : [MGMRechargeinfolist class]};
}


@end


@implementation MGMRechargeinfolist
+ (NSDictionary *)modelCustomPropertyMapper
{
    return @{@"beginExpiryDate": @"initExpiryDate"};
}

@end




