//
//Created by ESJsonFormatForMac on 19/03/20.
//

#import "MGMSignFilmCardModel.h"
@implementation MGMSignFilmCardModel


@end

@implementation MGMSignFilmCardBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [MGMSignFilmCardData class]};
}


+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"ID":@"id"};
}

@end


@implementation MGMSignFilmCardData


@end


@implementation MGMSignFilmCardPics


@end


@implementation MGMSignFilmCardH5Pics


@end


@implementation MGMSignFilmCardExtradata


@end


