//
//Created by ESJsonFormatForMac on 19/03/11.
//

#import "MGMAttendanceCardPriceModel.h"
@implementation MGMAttendanceCardPriceModel


@end

@implementation MGMAttendanceCardPriceBody


@end


@implementation MGMAttendanceCardPricing

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"10010127" : [MGMAttendanceCardPriceInfo class]};
}


@end


@implementation MGMAttendanceCardPriceInfo

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"payments" : [MGMAttendanceCardPricePayments class]};
}


@end


@implementation MGMAttendanceCardPriceMaindeliveryitem


@end


@implementation MGMAttendanceCardPriceData


@end


@implementation MGMAttendanceCardPriceServiceinfo


@end


@implementation MGMAttendanceCardPricePayments


@end


@implementation MGMAttendanceCardPriceRate


@end


