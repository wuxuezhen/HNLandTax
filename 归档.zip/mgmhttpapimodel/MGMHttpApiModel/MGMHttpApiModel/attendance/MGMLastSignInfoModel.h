//
//Created by ESJsonFormatForMac on 19/08/22.
//

#import <Foundation/Foundation.h>

@class MGMLastSignInfoBody,MGMLastSignInfoSeriescheckindetailinfos;
@interface MGMLastSignInfoModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMLastSignInfoBody *body;

@property (nonatomic, assign) BOOL success;

@end
@interface MGMLastSignInfoBody : NSObject

@property (nonatomic, strong) NSArray *seriesCheckInDetailInfos;

@property (nonatomic, assign) BOOL isSigned;

@property (nonatomic, copy) NSString *seriesDays;

@end

@interface MGMLastSignInfoSeriescheckindetailinfos : NSObject

@property (nonatomic, copy) NSString *wareId;

@property (nonatomic, copy) NSString *lotteryIntfId;

@property (nonatomic, assign) NSInteger lotteryStatus;

@property (nonatomic, copy) NSString *wareName;

@property (nonatomic, copy) NSString *day;

@property (nonatomic, copy) NSString *warePicture;

@property (nonatomic, assign) NSInteger checkInStatus;

@end

