//
//Created by ESJsonFormatForMac on 19/04/22.
//

#import "MGMAttendanceBalanceModel.h"
@implementation MGMAttendanceBalanceModel


@end

@implementation MGMAttendanceBalanceBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"balances" : [MGMAttendanceBalances class]};
}


@end


@implementation MGMAttendanceBalances


@end


