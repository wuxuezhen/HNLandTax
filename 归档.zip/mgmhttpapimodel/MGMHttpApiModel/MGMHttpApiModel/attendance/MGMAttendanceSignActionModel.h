//
//Created by ESJsonFormatForMac on 19/03/04.
//

#import <Foundation/Foundation.h>

@class MGMAttendanceSignActionBody,MGMAttendanceSignActionWarelist;
@interface MGMAttendanceSignActionModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMAttendanceSignActionBody *body;

@property (nonatomic, assign) BOOL success;

@end
@interface MGMAttendanceSignActionBody : NSObject

@property (nonatomic, copy) NSString *requestId;

@property (nonatomic, assign) NSInteger day;

@property (nonatomic, strong) NSArray *wareList;

@property (nonatomic, copy) NSString *wareResultCode;

@end

@interface MGMAttendanceSignActionWarelist : NSObject

@property (nonatomic, copy) NSString *parentName;

@property (nonatomic, copy) NSString *subScript;

@property (nonatomic, copy) NSString *wareName;

@property (nonatomic, copy) NSString *wareId;

@property (nonatomic, copy) NSString *pictureUrl;

@property (nonatomic, copy) NSString *parentId;

@end

