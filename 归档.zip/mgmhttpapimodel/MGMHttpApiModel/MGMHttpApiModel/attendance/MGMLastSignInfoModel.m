//
//Created by ESJsonFormatForMac on 19/08/22.
//

#import "MGMLastSignInfoModel.h"
@implementation MGMLastSignInfoModel


@end

@implementation MGMLastSignInfoBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"seriesCheckInDetailInfos" : [MGMLastSignInfoSeriescheckindetailinfos class]};
}

+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"isSigned":@"signed"};
}


@end


@implementation MGMLastSignInfoSeriescheckindetailinfos


@end


