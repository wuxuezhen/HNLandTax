//
//Created by ESJsonFormatForMac on 19/09/11.
//

#import "MGMUserDiscreteSignDetailInfoModel.h"
@implementation MGMUserDiscreteSignDetailInfoModel


@end

@implementation MGMUserDiscreteSignDetailInfoBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"discreteSignDetailInfos" : [MGMDiscretesigndetailinfos class]};
}

+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"isSigned":@"signed"};
}
@end


@implementation MGMDiscretesigndetailinfos


@end


