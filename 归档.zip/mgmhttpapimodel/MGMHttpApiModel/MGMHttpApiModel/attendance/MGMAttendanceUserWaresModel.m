//
//Created by ESJsonFormatForMac on 19/03/05.
//

#import "MGMAttendanceUserWaresModel.h"
@implementation MGMAttendanceUserWaresModel


@end

@implementation MGMAttendanceUserWaresModelBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"wareList" : [MGMAttendanceUserWaresModelWarelist class]};
}


@end


@implementation MGMAttendanceUserWaresModelWarelist


+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"ID":@"id"};
}

@end


