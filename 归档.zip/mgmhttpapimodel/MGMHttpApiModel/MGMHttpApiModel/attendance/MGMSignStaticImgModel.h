//
//Created by ESJsonFormatForMac on 19/03/21.
//

#import <Foundation/Foundation.h>

@class MGMSignStaticImgBody,MGMSignStaticImgData,MGMSignStaticImgPics,MGMSignStaticImgH5Pics,MGMSignStaticImgExtradata;
@interface MGMSignStaticImgModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) MGMSignStaticImgBody *body;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, assign) long long timestamp;

@end
@interface MGMSignStaticImgBody : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, strong) NSArray *data;

@property (nonatomic, copy) NSString *refreshTime;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *totalPage;

@property (nonatomic, copy) NSString *totalCount;

@end

@interface MGMSignStaticImgData : NSObject

@property (nonatomic, strong) MGMSignStaticImgPics *pics;

@property (nonatomic, strong) MGMSignStaticImgH5Pics *h5pics;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) MGMSignStaticImgExtradata *extraData;

@end

@interface MGMSignStaticImgPics : NSObject

@property (nonatomic, copy) NSString *lowResolutionH;

@end

@interface MGMSignStaticImgH5Pics : NSObject

@property (nonatomic, copy) NSString *lowResolutionH;

@end

@interface MGMSignStaticImgExtradata : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *starttime;

@property (nonatomic, copy) NSString *endime;

@property (nonatomic, copy) NSString *mission_Day;

@property (nonatomic, copy) NSString *reward;

@end

