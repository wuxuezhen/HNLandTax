//
//Created by ESJsonFormatForMac on 19/03/11.
//

#import <Foundation/Foundation.h>

@class MGMAttendanceAcountBillBody,MGMAttendanceAcountBill,MGMAttendanceAcountBillExtinfo;
@interface MGMAttendanceAcountBillModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMAttendanceAcountBillBody *body;

@end
@interface MGMAttendanceAcountBillBody : NSObject

@property (nonatomic, copy) NSString *resultCode;

@property (nonatomic, assign) NSInteger totalCount;

@property (nonatomic, strong) NSArray *bills;

@property (nonatomic, copy) NSString *resultDesc;

@end

@interface MGMAttendanceAcountBill : NSObject

@property (nonatomic, copy) NSString *externalId;

@property (nonatomic, copy) NSString *messageId;

@property (nonatomic, strong) MGMAttendanceAcountBillExtinfo *extInfo;

@property (nonatomic, assign) NSInteger amount;

@property (nonatomic, assign) NSInteger balance;

@property (nonatomic, copy) NSString *rechargeNum;

@property (nonatomic, copy) NSString *rechargeStatus;

@property (nonatomic, copy) NSString *scope;

@property (nonatomic, copy) NSString *operResultCode;

@property (nonatomic, copy) NSDictionary *currencyMetaInfo;

@property (nonatomic, copy) NSString *accountType;

@property (nonatomic, copy) NSString *billType;

@property (nonatomic, copy) NSString *userId;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *billSeqNum;

@property (nonatomic, copy) NSString *billTime;

@property (nonatomic, copy) NSString *currency;

@end

@interface MGMAttendanceAcountBillExtinfo : NSObject

@property (nonatomic, copy) NSString *expiryDate;

@property (nonatomic, copy) NSString *rechargeObjectID;

@property (nonatomic, copy) NSString *reserved9;

@property (nonatomic, copy) NSString *rechargeNum;

@end

