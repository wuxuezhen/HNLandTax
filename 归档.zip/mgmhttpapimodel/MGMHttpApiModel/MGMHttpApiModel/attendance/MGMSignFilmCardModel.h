//
//Created by ESJsonFormatForMac on 19/03/20.
//

#import <Foundation/Foundation.h>

@class MGMSignFilmCardBody,MGMSignFilmCardData,MGMSignFilmCardPics,MGMSignFilmCardH5Pics,MGMSignFilmCardExtradata;
@interface MGMSignFilmCardModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) MGMSignFilmCardBody *body;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, assign) long long timestamp;

@end
@interface MGMSignFilmCardBody : NSObject

@property (nonatomic, copy) NSString *totalCount;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, strong) NSArray *data;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *refreshTime;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *totalPage;

@end

@interface MGMSignFilmCardData : NSObject

@property (nonatomic, strong) MGMSignFilmCardPics *pics;

@property (nonatomic, strong) MGMSignFilmCardH5Pics *h5pics;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) MGMSignFilmCardExtradata *extraData;

@end

@interface MGMSignFilmCardPics : NSObject

@property (nonatomic, copy) NSString *lowResolutionH;

@end

@interface MGMSignFilmCardH5Pics : NSObject

@property (nonatomic, copy) NSString *lowResolutionH;

@end

@interface MGMSignFilmCardExtradata : NSObject

@property (nonatomic, copy) NSString *goodsID;

@property (nonatomic, copy) NSString *resourceId;
@end

