//
//  MGMProgressItemModel.h
//  MGMAttendanceModule
//
//  Created by Banana on 2019/4/28.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMProgressItemModel : UIView
@property (nonatomic, assign) NSInteger dayCount;
@property (nonatomic, assign) NSInteger signDay;
@property (nonatomic, assign) BOOL didSign;
@end

NS_ASSUME_NONNULL_END
