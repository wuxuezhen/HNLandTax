//
//Created by ESJsonFormatForMac on 19/03/25.
//

#import <Foundation/Foundation.h>

@class MGMSignCardOrderResultBody,MGMSignCardOrder,MGMSignCardOrderResultExtinfo,MGMSignCardOrderResultCurrentpaymentinfo,MGMSignCardOrderResultSubpaymentinfolist;
@interface MGMSignCardOrderResultModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMSignCardOrderResultBody *body;

@end
@interface MGMSignCardOrderResultBody : NSObject

@property (nonatomic, copy) NSString *externalOrderId;

@property (nonatomic, copy) NSString *bizMsg;

@property (nonatomic, copy) NSString *clientId;

@property (nonatomic, strong) MGMSignCardOrder *order;

@property (nonatomic, copy) NSString *bizCode;

@end

@interface MGMSignCardOrder : NSObject

@property (nonatomic, strong) MGMSignCardOrderResultCurrentpaymentinfo *currentPaymentInfo;

@property (nonatomic, copy) NSString *orderId;

@property (nonatomic, assign) NSInteger rawPrice;

@property (nonatomic, copy) NSString *createTimeFormat;

@property (nonatomic, strong) MGMSignCardOrderResultExtinfo *extInfo;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, copy) NSString *status;

@property (nonatomic, assign) BOOL reverseSubscription;

@property (nonatomic, assign) NSInteger salesPrice;

@property (nonatomic, assign) NSInteger createTime;

@property (nonatomic, assign) BOOL autoSubscription;

@end

@interface MGMSignCardOrderResultExtinfo : NSObject

@property (nonatomic, copy) NSString *appName;

@end

@interface MGMSignCardOrderResultCurrentpaymentinfo : NSObject

@property (nonatomic, copy) NSString *status;

@property (nonatomic, strong) NSArray *subPaymentInfoList;

@property (nonatomic, copy) NSString *paymentId;

@end

@interface MGMSignCardOrderResultSubpaymentinfolist : NSObject

@property (nonatomic, assign) NSInteger amount;

@property (nonatomic, copy) NSString *status;

@property (nonatomic, copy) NSString *paymentCode;

@end

