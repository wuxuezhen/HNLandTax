//
//  MGMCommonSettingModel.h
//  MGMHttpApiModel
//
//  Created by YL on 2020/1/6.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMCommonSettingModel : NSObject

@property (nonatomic, copy) NSString   *paramKey;
@property (nonatomic, copy) NSString   *paramValue;
@property (nonatomic, copy) NSString   *desc;
@property (nonatomic, assign) BOOL     active;

@end

NS_ASSUME_NONNULL_END
