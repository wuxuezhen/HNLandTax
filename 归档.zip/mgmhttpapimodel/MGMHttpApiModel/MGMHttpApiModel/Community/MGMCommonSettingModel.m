//
//  MGMCommonSettingModel.m
//  MGMHttpApiModel
//
//  Created by YL on 2020/1/6.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommonSettingModel.h"

@implementation MGMCommonSettingModel

@end
