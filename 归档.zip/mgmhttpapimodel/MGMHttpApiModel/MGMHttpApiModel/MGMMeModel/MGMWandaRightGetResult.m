//
//  MGMWandaRightGetResult.m
//  MGMMembership
//
//  Created by WangDa Mac on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMWandaRightGetResult.h"

@implementation MGMWandaDeliverInfo

@end
@implementation MGMWandaDeliverInfoBody

@end
