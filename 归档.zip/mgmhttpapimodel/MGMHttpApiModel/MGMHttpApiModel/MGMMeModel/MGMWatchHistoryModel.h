//
//Created by ESJsonFormatForMac on 18/12/20.
//

#import <Foundation/Foundation.h>

@class MGMWatchHistoryBody,MGMWatchHistoryPhlist;

@interface MGMWatchHistoryModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMWatchHistoryBody *body;

@end

@interface MGMWatchHistoryBody : NSObject

@property (nonatomic, copy) NSString *resultCode;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, strong) NSArray <MGMWatchHistoryPhlist *> *PHList;

@property (nonatomic, copy) NSString *resultDesc;

@end

@interface MGMWatchHistoryPhlist : NSObject

@property (nonatomic, copy) NSString *lastUpdate;

@property (nonatomic, copy) NSString *pictureUrl;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *platform;

@property (nonatomic, assign) NSInteger subPart;

@property (nonatomic, assign) NSInteger currTime;

@property (nonatomic, assign) NSInteger part;

@property (nonatomic, copy) NSString *hwId;

@property (nonatomic, copy) NSString *childContId;

@property (nonatomic, copy) NSString *cMId;

@property (nonatomic, copy) NSString *highResolutionH;

@property (nonatomic, copy) NSString *imageHUrl;

@property (nonatomic, copy) NSString *videoType;

@property (nonatomic, copy) NSString *director;

@property (nonatomic, assign) long long mId;

@property (nonatomic, copy) NSString *lowResolutionV;

@property (nonatomic, copy) NSString *path;

@property (nonatomic, copy) NSString *area;

@property (nonatomic, copy) NSString *lowResolutionH;

@property (nonatomic, copy) NSString *updateTime;

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *playType;

@property (nonatomic, copy) NSString *contId;

@property (nonatomic, copy) NSString *kId;

@property (nonatomic, copy) NSString *imageSUrl;

@property (nonatomic, copy) NSString *contentStyle;

@property (nonatomic, copy) NSString *introduction;

@property (nonatomic, assign) NSInteger totalTime;

@property (nonatomic, copy) NSString *mobile;

@property (nonatomic, copy) NSString *highResolutionV;

@property (nonatomic, copy) NSString *episode;

@property (nonatomic, copy) NSString *programType;

@property (nonatomic, copy) NSString *nodeId;

@property (nonatomic, copy) NSString *createTime;

@property (nonatomic, copy) NSString *contName;

@property (nonatomic, copy) NSString *stbcontId;

@property (nonatomic, copy) NSString *ip;

@property (nonatomic, assign) NSInteger isLive;

@property (nonatomic, copy) NSString *udid;

@property (nonatomic, assign) NSInteger userId;

@property (nonatomic, assign, getter=isSelecte) BOOL selecte;/**<选中*/

@end

