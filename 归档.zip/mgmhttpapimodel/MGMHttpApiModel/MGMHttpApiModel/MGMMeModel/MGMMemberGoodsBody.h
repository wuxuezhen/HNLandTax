//
//  MGMMemberGoodsBody.h
//  MGMMembership
//  备注：以下获取商品详情
//  Created by WangDa Mac on 2019/1/15.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMMemberGoods : MGMBase
@property (nonatomic, strong) NSString * goodsType;
@property (nonatomic, strong) NSString * id;
@property (nonatomic, strong) NSString * name;
@property (nonatomic, assign) NSInteger originalPrice;
@property (nonatomic, assign) NSInteger showPrice;
@end

@interface MGMMemberGoodsBody : MGMBase
@property (nonatomic, assign) NSInteger bizCode;
@property (nonatomic, strong) NSString * bizFlag;
@property (nonatomic, strong) NSString * bizMsg;
@property (nonatomic, strong) NSArray <MGMMemberGoods *>* data;
@end

@interface MGMMemberGoodsPriceInfoDetail : NSObject

@property (nonatomic, strong) NSString * duration;
@property (nonatomic, strong) NSString * goodsName;
@property (nonatomic, strong) NSString * goodsStatus;
@property (nonatomic, strong) NSString * goodsType;
@property (nonatomic, strong) NSString * idField;
@property (nonatomic, strong) NSString * memberId;
@property (nonatomic, strong) NSObject * memo;
@property (nonatomic, strong) NSString * showPrice;
@property (nonatomic, strong) NSString * summary;
@end

@interface MGMMemberGoodsPriceInfo : MGMBase
@property (nonatomic, strong) NSString * id;
@property (nonatomic, strong) MGMMemberGoodsPriceInfoDetail * memberGoods;
@property (nonatomic, strong) NSString * memo;
@property (nonatomic, strong) NSString * payChannel;
@property (nonatomic, strong) NSString * price;
@property (nonatomic, strong) NSString *showPrice;
@end

@interface MGMMemberGoodsPriceInfoBody : MGMBase
@property (nonatomic, assign) NSInteger bizCode;
@property (nonatomic, strong) NSString * bizMsg;
@property (nonatomic, strong) NSArray <MGMMemberGoodsPriceInfo *>* priceInfo;
@end

NS_ASSUME_NONNULL_END
