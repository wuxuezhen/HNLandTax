//
//  MGMUserMemberInfo.m
//  MGMMembership
//
//  Created by WangDa Mac on 2019/1/8.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMWandaMemberInfo.h"
#import <NSObject+YYModel.h>
#import <MGMCategories/MGMCategories.h>

@implementation MGMWandaMemberInfo

@end

@implementation MGMWandaMemberInfoBody

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    for (MGMWandaMemberInfo *info in self.memberInfo) {
        NSDate *date = [NSDate date];
        if ([info.deliverId isEqualToString:@"a"]) {
            _wandaRight_A = info;
            continue;
        }
        NSDate *expiredDate = info.expiredDate;
        if (expiredDate == nil) {
            expiredDate = [NSDate dateWithTimeIntervalSince1970:0];
        }
        if ([date compare:info.expiredDate] != NSOrderedDescending) {
            _wandaRight_B = info;
            continue;
        }
    }
    return YES;
}

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"memberInfo" : [MGMWandaMemberInfo class]};
}

@end
