//
//Created by ESJsonFormatForMac on 19/03/14.
//

#import <Foundation/Foundation.h>

@class MGMMeMovieCommentBody,MGMMeMovieCommentData,MGMMeMovieCommentContentinfo,MGMMeMovieCommentPics,MGMMeMovieCommentH5Pics;
@interface MGMMeMovieCommentModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMMeMovieCommentBody *body;

@end
@interface MGMMeMovieCommentBody : NSObject

@property (nonatomic, strong) NSArray *data;

@end

@interface MGMMeMovieCommentData : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *contentName;

@property (nonatomic, assign) NSInteger clientType;

@property (nonatomic, assign) NSInteger mid;

@property (nonatomic, assign) BOOL top;

@property (nonatomic, assign) long long updateTime;

@property (nonatomic, assign) NSInteger topTime;

@property (nonatomic, copy) NSString *pictureURL;

@property (nonatomic, assign) NSInteger pictureType;

@property (nonatomic, copy) NSString *commentId;

@property (nonatomic, copy) NSString *body;

@property (nonatomic, copy) NSString *mobile;

@property (nonatomic, strong) MGMMeMovieCommentContentinfo *contentInfo;

@property (nonatomic, assign) NSInteger commentedCount;

@property (nonatomic, copy) NSString *userPortrait;

@property (nonatomic, copy) NSString *contentId;

@property (nonatomic, assign) NSInteger commentType;

@property (nonatomic, assign) NSInteger contentType;

@property (nonatomic, copy) NSString *userName;

@property (nonatomic, assign) NSInteger likeCount;

@property (nonatomic, assign) long long createTime;

@property (nonatomic, copy) NSString *userId;

//个人主页动态使用
@property (nonatomic, assign) float commentHeight;
@property (nonatomic, copy)   NSString *publishTimeStr;

@end

@interface MGMMeMovieCommentContentinfo : NSObject

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) MGMMeMovieCommentPics *pics;

@property (nonatomic, copy) NSString *director;

@property (nonatomic, copy) NSString *contForm;

@property (nonatomic, copy) NSString *contentStyle;

@property (nonatomic, copy) NSString *way;

@property (nonatomic, copy) NSString *area;

@property (nonatomic, copy) NSString *programType;

@property (nonatomic, copy) NSString *contId;

@property (nonatomic, copy) NSString *playType;

@property (nonatomic, copy) NSString *showTimeDesc;

@property (nonatomic, copy) NSString *actor;

@property (nonatomic, copy) NSString *cpName;

@property (nonatomic, copy) NSString *duration;

@property (nonatomic, copy) NSString *showTimeName;

@property (nonatomic, copy) NSString *score;

@property (nonatomic, strong) MGMMeMovieCommentH5Pics *h5pics;

@property (nonatomic, copy) NSString *showTime;

@end

@interface MGMMeMovieCommentPics : NSObject

@property (nonatomic, copy) NSString *lowResolutionV;

@property (nonatomic, copy) NSString *highResolutionV;

@property (nonatomic, copy) NSString *highResolutionH;

@property (nonatomic, copy) NSString *lowResolutionH;

@end

@interface MGMMeMovieCommentH5Pics : NSObject

@property (nonatomic, copy) NSString *lowResolutionV;

@property (nonatomic, copy) NSString *highResolutionV;

@property (nonatomic, copy) NSString *highResolutionH;

@property (nonatomic, copy) NSString *lowResolutionH;

@end

