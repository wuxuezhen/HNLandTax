//
//  MGMUserMemberInfo.h
//  MGMMembership
//
//  Created by WangDa Mac on 2019/1/8.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN


/**
 联合会员权益模型
 */
@interface MGMWandaMemberInfo : MGMBase

@property (nonatomic, strong) NSDate * activeDate;
@property (nonatomic, strong) NSString * deliverId;
@property (nonatomic, strong) NSDate * expiredDate;
@property (nonatomic, strong) NSObject * generateMemo;
@property (nonatomic, strong) NSString * generateType;
@property (nonatomic, strong) NSString * id;
@property (nonatomic, strong) NSString * memberId;
@property (nonatomic, strong) NSString * memo;
@property (nonatomic, strong) NSString * rightCode;
@property (nonatomic, strong) NSString * rightCount;
@property (nonatomic, strong) NSString * rightPrice;
@property (nonatomic, strong) NSString * rightType;
/// 前端）状态（"1":待领取,"2":已领取,"3":已过期,"4":已失效,"5":领取中）
@property (nonatomic, assign) NSInteger status;
@property (nonatomic, strong) NSString * summary;

//自定义字段 权益标题 ，权益简介
@property (nonatomic, copy) NSString *diy_rightTitle;
@property (nonatomic, copy) NSString *diy_rightDesc;

@end

@interface MGMWandaMemberInfoBody : MGMBase

@property (nonatomic, strong) NSString * bizCode;
@property (nonatomic, strong) NSString * bizMsg;
@property (nonatomic, strong) NSArray <MGMWandaMemberInfo *>* memberInfo;

@property (nonatomic, strong, readwrite) MGMWandaMemberInfo *wandaRight_A;
@property (nonatomic, strong, readwrite) MGMWandaMemberInfo *wandaRight_B;


@end

NS_ASSUME_NONNULL_END
