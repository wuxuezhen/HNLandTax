//
//  MGMMemberMicros.h
//  MGMMembership
//
//  Created by WangDa Mac on 2019/1/23.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#ifndef MGMMemberMicros_h
#define MGMMemberMicros_h

#import <Foundation/Foundation.h>
typedef NS_ENUM(NSInteger, MGMWandaCardPackageType) {
    //话费单月
    MGMWandaCardPackage_Call_Charge_Month,
    //话费连续包月
    MGMWandaCardPackage_Call_Charge_Monthly,
    //话费季卡
    MGMWandaCardPackage_Call_Charge_Quarter,
    //支付宝单月
    MGMWandaCardPackage_AliPay_Month,
    //支付宝季卡
    MGMWandaCardPackage_AliPay_Quarter,
    //支付宝连续包月
    MGMWandaCardPackage_AliPay_Monthly,
    //微信连续包月
    MGMWandaCardPackaage_WeChat_Monthly,
    //微信单月
    MGMWandaCardPackage_Weixin_Month,
    //未知
    MGMWandaCardPackage_Platform_Time_Unkwon
};

#endif /* MGMMemberMicros_h */
