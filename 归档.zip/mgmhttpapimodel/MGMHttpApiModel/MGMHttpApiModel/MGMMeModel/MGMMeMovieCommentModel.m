//
//Created by ESJsonFormatForMac on 19/03/14.
//

#import "MGMMeMovieCommentModel.h"
@implementation MGMMeMovieCommentModel


@end

@implementation MGMMeMovieCommentBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [MGMMeMovieCommentData class]};
}


@end


@implementation MGMMeMovieCommentData


@end


@implementation MGMMeMovieCommentContentinfo


@end


@implementation MGMMeMovieCommentPics


@end


@implementation MGMMeMovieCommentH5Pics


@end


