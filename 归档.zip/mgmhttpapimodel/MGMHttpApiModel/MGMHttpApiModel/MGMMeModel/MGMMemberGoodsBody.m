//
//  MGMMemberGoodsBody.m
//  MGMMembership
//
//  Created by WangDa Mac on 2019/1/15.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMMemberGoodsBody.h"
@implementation MGMMemberGoods

@end

@implementation MGMMemberGoodsBody
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"data" : [MGMMemberGoods class]};
}
@end

@implementation MGMMemberGoodsPriceInfoDetail
@end
@implementation MGMMemberGoodsPriceInfo
- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    _showPrice = _memberGoods.showPrice;
    return YES;
}

@end
@implementation MGMMemberGoodsPriceInfoBody

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"priceInfo":@"MGMMemberGoodsPriceInfo"};
}

@end
