//
//  MGMMemberCardContracts.h
//  MGMMembership
//  注释：以下模型支付宝合约查询接口返回数据
//  Created by WangDa Mac on 2019/1/14.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"
@class MGMMemberCardContract;

NS_ASSUME_NONNULL_BEGIN

@interface MGMMemberCardContractBody : MGMBase
@property (nonatomic, strong) NSArray  <MGMMemberCardContract *>* contracts;
@property (nonatomic, strong) NSString * resultCode;
@end

@interface MGMMemberCardContract : MGMBase


@property (nonatomic, strong) NSString * contractStatus;
@property (nonatomic, strong) NSString * cpId;
@property (nonatomic, assign) NSInteger createTime;
@property (nonatomic, strong) NSString * deliveryId;
@property (nonatomic, assign) NSInteger effectTime;
@property (nonatomic, assign) NSInteger endTime;
@property (nonatomic, strong) NSString * id;
@property (nonatomic, assign) BOOL isTimes;
@property (nonatomic, assign) NSInteger lastResumeTime;
@property (nonatomic, assign) NSInteger lastSuspendTime;
@property (nonatomic, assign) NSInteger lastUpdateTime;
@property (nonatomic, strong) NSString * msisdn;
@property (nonatomic, strong) NSString * operCode;
@property (nonatomic, strong) NSString * operateStatus;
@property (nonatomic, strong) NSString * orderId;
@property (nonatomic, strong) NSString * productId;
@property (nonatomic, strong) NSString * provinceId;
@property (nonatomic, assign) NSInteger signTime;
@property (nonatomic, strong) NSString * type;
@property (nonatomic, strong) NSString * userId;
@property (nonatomic, copy) NSString *serviceName;
@property (nonatomic, copy) NSString *price;
@property (nonatomic, copy) NSString *nextPaidTime;


@end

@interface MGMMemberCardStopAutoSubscriptionResult : MGMBase

@property (nonatomic, strong) NSString * resultCode;
@property (nonatomic, assign) BOOL isSucccess;

@end
NS_ASSUME_NONNULL_END
