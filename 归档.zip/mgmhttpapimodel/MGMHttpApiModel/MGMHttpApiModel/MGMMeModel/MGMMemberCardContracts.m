//
//  MGMMemberCardContracts.m
//  MGMMembership
//
//  Created by WangDa Mac on 2019/1/14.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMMemberCardContracts.h"

@implementation MGMMemberCardContractBody
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"contracts" : [MGMMemberCardContract class]};
}
@end

@implementation MGMMemberCardContract

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    NSString *payNextTime = [dic[@"nextPaidTime"] stringValue];
    NSInteger yearLength = 4;
    NSInteger monthLength = 2;
    NSInteger dayLength = 2;
    NSString *year = nil;
    NSString *month = nil;
    NSString *day = nil;
    if (payNextTime.length)
    {
        year = [payNextTime substringWithRange:NSMakeRange(0, yearLength)];
        month = [payNextTime substringWithRange:NSMakeRange(yearLength, monthLength)];
        day = [payNextTime substringWithRange:NSMakeRange(yearLength + monthLength, dayLength)];
        _nextPaidTime = [NSString stringWithFormat:@"%@.%@.%@",year,month,day];
    }
    return YES;
}

@end


@implementation MGMMemberCardStopAutoSubscriptionResult
- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    _isSucccess = [self.resultCode isEqualToString:@"SUCCESS"];
    return YES;
}

@end
