//
//  MGMWandaRightGetResult.h
//  MGMMembership
//
//  Created by WangDa Mac on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN


/**
 联合会员权益获取回调数据模型
 */
@interface MGMWandaDeliverInfo : MGMBase

@property (nonatomic, strong) NSString * deliverMemo;
@property (nonatomic, strong) NSString * deliverNo;
@property (nonatomic, strong) NSDate * deliverTime;
@property (nonatomic, strong) NSDate * generateMemo;
/// 领取状态：0:领取成功,1:领取失败，2:领取中,3:已领取
@property (nonatomic, assign) NSInteger status;
@end

@interface MGMWandaDeliverInfoBody : MGMBase

@property (nonatomic, strong) NSString * bizCode;
@property (nonatomic, strong) NSString * bizMsg;
@property (nonatomic, strong) MGMWandaDeliverInfo * deliverInfo;
@end

NS_ASSUME_NONNULL_END
