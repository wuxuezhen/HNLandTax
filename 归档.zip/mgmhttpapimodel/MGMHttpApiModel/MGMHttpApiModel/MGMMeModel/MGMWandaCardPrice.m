//
//  MGMWandaCardPrice.m
//  MGMMembership
//
//  Created by WangDa Mac on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMWandaCardPrice.h"
#import <YYModel/NSObject+YYModel.h>


@implementation MGMWandaCardPriceInfo

+ (NSDictionary *)modelCustomPropertyMapper {
    /*
     return @{@"name"  : @"n",
     @"page"  : @"p",
     @"desc"  : @"ext.desc",
     @"bookID": @[@"id", @"ID", @"book_id"]};
     */
    return @{@"mgm_2028600513" : @"2028600513"};
}

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"mgm_2028600513" : [MGMWandaCardPrice class] };
}



@end

@implementation MGMWandaCardCharge //
@end

@implementation MGMWandaCardRate //
@end

@implementation MGMWandaCardPayment //
@end

@implementation MGMWandaCardServiceInfo //
- (NSDictionary *)toDictionary {
    return [self yy_modelToJSONObject];
}
@end

@implementation MGMWandaCardAuthorization //
@end

@implementation MGMWandaCardMainDeliveryItemData //
@end

@implementation MGMWandaCardMainDeliveryItem //
@end

@implementation MGMWandaCardExtDeliveryItemData //
@end

@implementation MGMWandaCardExtDeliveryItem //
@end


@implementation MGMWandaCardPrice

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"extDeliveryItems" : [MGMWandaCardExtDeliveryItem class],
             @"payments" : MGMWandaCardPayment.class };
}

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    double lastPrice = self.lastPrice.doubleValue;
    for (MGMWandaCardPayment *payment in self.payments) {
        NSString *payType = payment.code;
        NSLog(@"payType = %@ --- packageType = %@", payType, payment.charge.operType);
        
        if (![self checkPayType:payType]) {
            continue;
        }
        double price = payment.amount;
        NSString *pakageType = payment.charge.operType;
        [self dealWith:payType price:price lastPrice:lastPrice pakageType:pakageType];
    }
    return YES;
}

- (void)dealWith:(NSString *)payType price:(double)price lastPrice:(double)lastPrice pakageType:(NSString *)pakageType {
   
    self.price = price >= 0? price : lastPrice;
    self.serviceInfo.price = self.price;
    if ([payType isEqualToString:@"ALI_CONTRACT_PAY"])
    { //
        self.packageType = MGMWandaCardPackage_AliPay_Monthly;
    }
    else if ([payType isEqualToString:@"SUNNY_V6_MOBILE_BOSS"])
    {
        if ([pakageType isEqualToString:@"BOSS_PERIOD"]) {
            self.packageType = MGMWandaCardPackage_Call_Charge_Quarter;
        } else if ([pakageType isEqualToString:@"BOSS_MONTH"]) {
            self.packageType = MGMWandaCardPackage_Call_Charge_Monthly;
        } else {
            self.packageType = MGMWandaCardPackage_Platform_Time_Unkwon;
        }
    } else
    {
        self.packageType = MGMWandaCardPackage_Platform_Time_Unkwon;
    }
    
    if (self.payments.firstObject.charge.productId.length > 0) {
        self.productId = self.payments.firstObject.charge.productId;
    } else if (self.mainDeliveryItem.data.productId.length > 0) {
        self.productId = self.mainDeliveryItem.data.productId;
    } else if (self.extDeliveryItems.firstObject.data.productId.length > 0){
        self.productId = self.extDeliveryItems.firstObject.data.productId;
    } else {
        self.productId = @"";
    }
}

- (BOOL)checkPayType:(NSString *)payType {
    return [payType isEqualToString:@"ALI_CONTRACT_PAY"] ||
           [payType isEqualToString:@"SUNNY_V6_MOBILE_BOSS"];
}

@end

@implementation MGMWandaCardPriceBody
@end
