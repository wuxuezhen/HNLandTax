//
//  MGMWandaCardPrice.h
//  MGMMembership
//  职责：该数据为联合会员询价接口返回数据
//  Created by WangDa Mac on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"
#import "MGMMemberMicros.h"

NS_ASSUME_NONNULL_BEGIN



@interface MGMWandaCardCharge : MGMBase

@property (nonatomic, strong) NSString * cpCode;
@property (nonatomic, strong) NSString * operCode;
@property (nonatomic, strong) NSString * operType;
@property (nonatomic, strong) NSString * productId;
@end

@interface MGMWandaCardRate : MGMBase

@property (nonatomic, assign) NSInteger denominator;
@property (nonatomic, strong) NSString * desc;
@property (nonatomic, assign) NSInteger numerator;
@end

@interface MGMWandaCardPayment : MGMBase


@property (nonatomic, strong) NSString * accountType;
@property (nonatomic, assign) NSInteger amount;
@property (nonatomic, assign) BOOL autoSubscriptionSupport;
@property (nonatomic, strong) NSArray <NSString *>* carrierSupport;
@property (nonatomic, strong) MGMWandaCardCharge * charge;
@property (nonatomic, strong) NSString * code;
@property (nonatomic, strong) NSString * limited;
@property (nonatomic, assign) BOOL mixable;
@property (nonatomic, strong) NSString * name;
@property (nonatomic, strong) NSArray * payDeliveryItems;
@property (nonatomic, strong) MGMWandaCardRate * rate;
@property (nonatomic, strong) NSArray <NSString *>* terminalSupport;
@end


@interface MGMWandaCardServiceInfo : MGMBase
@property (nonatomic, assign) BOOL autoSubscriptionSupport;
@property (nonatomic, strong) NSString * code;
@property (nonatomic, strong) NSString * desc;
@property (nonatomic, strong) NSString * name;
@property (nonatomic, assign) NSInteger price;
@property (nonatomic, assign) BOOL repeatSubscriptionSupport;
@property (nonatomic, assign) BOOL supportProlongAuth;
@property (nonatomic, assign) BOOL supportRefund;
@property (nonatomic, strong) NSString * type;
- (NSDictionary *)toDictionary;
@end

@interface MGMWandaCardAuthorization : MGMBase

@property (nonatomic, assign) NSInteger amount;
@property (nonatomic, strong) NSString * authType;
@property (nonatomic, assign) NSInteger effectOn;
@property (nonatomic, assign) NSInteger expireOn;
@property (nonatomic, strong) NSString * periodUnit;
@property (nonatomic, assign) NSInteger validTimeSecond;
@end

@interface MGMWandaCardMainDeliveryItemData : MGMBase

@property (nonatomic, strong) NSString * mobileNo;
@property (nonatomic, strong) NSString * orderNo;
@property (nonatomic, strong) NSString * productId;
@property (nonatomic, strong) NSString * traceId;
@property (nonatomic, strong) NSString * type;
@property (nonatomic, strong) NSString * channelId;

@end

@interface MGMWandaCardMainDeliveryItem : MGMBase


@property (nonatomic, strong) MGMWandaCardAuthorization * authorization;
@property (nonatomic, assign) BOOL beforehandSupport;
@property (nonatomic, strong) MGMWandaCardMainDeliveryItemData * data;
@property (nonatomic, strong) NSString * desc;
@property (nonatomic, strong) NSString * handler;
@property (nonatomic, strong) NSString * name;
@property (nonatomic, assign) BOOL revokeDeliverySupport;
@property (nonatomic, assign) BOOL revokeScheduleSupport;
@property (nonatomic, strong) NSString * scheduling;

@end

@interface MGMWandaCardExtDeliveryItemData : MGMBase

@property (nonatomic, strong) NSString * contractType;
@property (nonatomic, strong) NSString * cpId;
@property (nonatomic, strong) NSString * msisdn;
@property (nonatomic, strong) NSString * operCode;
@property (nonatomic, strong) NSString * orderId;
@property (nonatomic, strong) NSString * productId;
@property (nonatomic, strong) NSString * traceId;
@end

@interface MGMWandaCardExtDeliveryItem : MGMBase

@property (nonatomic, strong) id authorization;
@property (nonatomic, assign) BOOL beforehandSupport;
@property (nonatomic, strong) MGMWandaCardExtDeliveryItemData * data;
@property (nonatomic, strong) NSString * desc;
@property (nonatomic, strong) NSString * handler;
@property (nonatomic, strong) NSString * name;
@property (nonatomic, assign) BOOL revokeDeliverySupport;
@property (nonatomic, assign) BOOL revokeScheduleSupport;
@property (nonatomic, strong) NSString * scheduling;

@end

// MARK: - main
@interface MGMWandaCardPrice : MGMBase

@property (nonatomic, assign) NSInteger count;
@property (nonatomic, strong) NSString * errorCode;
@property (nonatomic, strong) NSArray <MGMWandaCardExtDeliveryItem *> * extDeliveryItems;
@property (nonatomic, copy) NSString *lastPrice;
@property (nonatomic, strong) MGMWandaCardMainDeliveryItem * mainDeliveryItem;
@property (nonatomic, strong) NSArray  <MGMWandaCardPayment *>* payments;
@property (nonatomic, strong) NSArray * promotions;
@property (nonatomic, strong) NSString * resultCode;
@property (nonatomic, strong) NSString * resultDesc;
@property (nonatomic, strong) NSArray * securities;
@property (nonatomic, strong) MGMWandaCardServiceInfo * serviceInfo;


@property (nonatomic, assign, readwrite) MGMWandaCardPackageType packageType;
@property (nonatomic, assign, readwrite) double price;
@property (nonatomic, copy, readwrite) NSString *productId;

@end


@interface MGMWandaCardPriceInfo : MGMBase

@property (nonatomic, strong) NSArray <MGMWandaCardPrice *>* mgm_2028600513;

@end

@interface MGMWandaCardPriceBody : MGMBase
@property (nonatomic, strong) NSString * bizCode;
@property (nonatomic, strong) NSString * bizMsg;
@property (nonatomic, strong) MGMWandaCardPriceInfo * pricing;

@end

NS_ASSUME_NONNULL_END
