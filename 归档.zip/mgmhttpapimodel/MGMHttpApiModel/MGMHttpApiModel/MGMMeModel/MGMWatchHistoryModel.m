//
//Created by ESJsonFormatForMac on 18/12/20.
//

#import "MGMWatchHistoryModel.h"
@implementation MGMWatchHistoryModel


@end

@implementation MGMWatchHistoryBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"PHList" : [MGMWatchHistoryPhlist class]};
}


@end


@implementation MGMWatchHistoryPhlist


+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"ID":@"id"};
}

@end


