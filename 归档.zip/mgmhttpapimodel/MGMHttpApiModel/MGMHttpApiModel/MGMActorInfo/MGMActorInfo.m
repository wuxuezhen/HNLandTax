//
//  MGMActorInfo.m
//  AFNetworking
//
//  Created by WangDa Mac on 2019/4/11.
//

#import "MGMActorInfo.h"

@implementation MGMActorWork
@end
@implementation MGMActorInfo
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"allOpus" : [MGMActorWork class],
             @"magnumOpus" : [MGMActorWork class]};
}
@end

@implementation MGMActorInfos
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"star" : [MGMActorInfo class]};
}
@end

@implementation MGMActorInfoBody
@end

@implementation MGMWorkDetail
- (NSInteger)publishYear {
    if (_showTime.length >= 4) {
        _publishYear = [[_showTime substringToIndex:4] integerValue];
    } else {
        _publishYear = 0;
    }
    return _publishYear;
}
- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    [self publishYear];
    return YES;
}
@end
