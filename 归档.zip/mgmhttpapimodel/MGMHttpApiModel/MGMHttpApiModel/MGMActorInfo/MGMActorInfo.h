//
//  MGMActorInfo.h
//  AFNetworking
//
//  Created by WangDa Mac on 2019/4/11.
//

#import "MGMLegoAction.h"
@class MGMPic;
NS_ASSUME_NONNULL_BEGIN

@interface MGMActorWork : MGMBase
@property (nonatomic, strong) NSString * contName;
@property (nonatomic, strong) NSString * programId;
@end


@interface MGMActorInfo : MGMBase
@property (nonatomic, strong) NSArray <MGMActorWork *>* allOpus;
@property (nonatomic, strong) NSString * birthPlace;
@property (nonatomic, strong) NSString * brief;
@property (nonatomic, strong) NSArray <MGMActorWork *>* magnumOpus;
@property (nonatomic, strong) NSString * starBirthday;
@property (nonatomic, strong) NSString * starId;
@property (nonatomic, strong) NSString * starImg;
@property (nonatomic, strong) NSString * starName;
@property (nonatomic, strong) NSString * starNameEn;
@property (nonatomic, strong) NSString * starVocation;
@end

@interface MGMActorInfos : MGMBase
@property (nonatomic, strong) NSArray<MGMActorInfo *> * star;
@property (nonatomic, assign) NSInteger starNum;
@end

@interface MGMActorInfoBody : MGMBase
@property (nonatomic, assign) NSInteger costTime;
@property (nonatomic, strong) NSArray <NSString *>* highLightList;
@property (nonatomic, assign) NSInteger isRecommend;
@property (nonatomic, strong) NSString * responseCode;
@property (nonatomic, strong) NSString * responseMessage;
@property (nonatomic, assign) NSInteger resultNum;
@property (nonatomic, strong) MGMActorInfos * starInfo;
@property (nonatomic, assign) BOOL success;
@end


@interface MGMWorkDetail : MGMBase
@property (nonatomic, strong) NSString * actor;
@property (nonatomic, strong) NSString * area;
@property (nonatomic, strong) NSString * contForm;
@property (nonatomic, strong) NSString * contId;
@property (nonatomic, strong) NSString * contentStyle;
@property (nonatomic, strong) NSString * cpName;
@property (nonatomic, strong) NSString * director;
@property (nonatomic, strong) NSString * duration;
@property (nonatomic, strong) MGMPic * h5pics;
@property (nonatomic, strong) NSString * mpid;
@property (nonatomic, strong) NSString * name;
@property (nonatomic, strong) MGMPic * pics;
@property (nonatomic, strong) NSString * playType;
@property (nonatomic, strong) NSString * programType;
@property (nonatomic, strong) NSString * score;
@property (nonatomic, strong) NSString * showTime;
@property (nonatomic, strong) NSString * showTimeDesc;
@property (nonatomic, strong) NSString * showTimeName;
@property (nonatomic, strong) NSString * way;
/// 发布年代
@property (nonatomic, assign) NSInteger publishYear;
@end

NS_ASSUME_NONNULL_END
