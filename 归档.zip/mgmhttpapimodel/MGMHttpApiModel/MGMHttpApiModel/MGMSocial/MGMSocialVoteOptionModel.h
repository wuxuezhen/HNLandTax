//
//  MGMSocialVoteOptionModel.h
//  MGMSocialModule
//
//  Created by WangDa Mac on 2020/2/11.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <MGMDataModel/MGMDataObject.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMSocialVoteOptionModel : MGMDataObject

@property (nonatomic, copy) NSString *optionId;
@property (nonatomic, copy) NSString *optionContent;
@property (nonatomic, assign) NSInteger supportCount;
@property (nonatomic, assign, getter=isHasSupport) BOOL hasSupport;

@end

NS_ASSUME_NONNULL_END
