//
//  MGMSocialVoteContentModel.m
//  MGMSocialModule
//
//  Created by WangDa Mac on 2020/2/11.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMSocialVoteContentModel.h"
#import <YYModel/YYModel.h>

@implementation MGMSocialVoteContentModel

+ (nullable NSDictionary<NSString *, id> *)modelContainerPropertyGenericClass
{
    return @{
            @"voteOptions": NSClassFromString(@"MGMSocialVoteOptionModel")
            };
}

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic
{
    //  投票状态  END：已结束  NORMAL：未结束 
    NSString *status = dic[@"voteStatus"];
    _voteEnd = [status isEqualToString:@"END"];
    return YES;
}

@end
