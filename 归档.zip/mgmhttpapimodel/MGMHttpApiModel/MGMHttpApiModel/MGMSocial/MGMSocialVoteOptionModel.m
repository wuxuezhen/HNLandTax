//
//  MGMSocialVoteOptionModel.m
//  MGMSocialModule
//
//  Created by WangDa Mac on 2020/2/11.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMSocialVoteOptionModel.h"

@implementation MGMSocialVoteOptionModel

@end
