//
//  MGMSocialVoteContentModel.h
//  MGMSocialModule
//
//  Created by WangDa Mac on 2020/2/11.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <MGMDataModel/MGMDataObject.h>

@class MGMSocialVoteOptionModel;

NS_ASSUME_NONNULL_BEGIN

@interface MGMSocialVoteContentModel : MGMDataObject

/**
    投票配置ID
 */
@property (nonatomic, copy) NSString *voteId;

/**
    投票是否结束
 */
@property (nonatomic, assign, getter=isVoteEnd) BOOL voteEnd;

/**
    投票内容
 */
@property (nonatomic, copy) NSString *voteContent;

/**
    可选数量
 */
@property (nonatomic, assign) NSInteger optionCounts;

/**
    总投票人数
 */
@property (nonatomic, assign) NSInteger totalVoteUserCount;

/**
    投票结束时间. 单位 毫秒，如果要用秒需转换
 */
@property (nonatomic, assign) NSTimeInterval voteEndTime;

/**
    投票选项
 */
@property (nonatomic, copy) NSArray <MGMSocialVoteOptionModel *>*voteOptions;

@end

NS_ASSUME_NONNULL_END
