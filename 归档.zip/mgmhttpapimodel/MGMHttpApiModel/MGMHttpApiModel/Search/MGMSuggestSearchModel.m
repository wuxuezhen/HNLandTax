//
//Created by ESJsonFormatForMac on 18/12/18.
//

#import "MGMSuggestSearchModel.h"
@implementation MGMSuggestSearchModel


@end

@implementation MGMSuggestSearchBody


@end


