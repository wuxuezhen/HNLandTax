//
//Created by ESJsonFormatForMac on 18/12/18.
//

#import "MGMCommonSearchModel.h"
@implementation MGMCommonSearchModel


@end

@implementation MGMCommonSearchBody

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"resultList" : [MGMCommonSearchResultlist class]};
}


@end


@implementation MGMCommonSearchFacets

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"contDisplayType" : [MGMCommonSearchContdisplaytype class]};
}


@end


@implementation MGMCommonSearchPublishtime


@end


@implementation MGMCommonSearchContdisplaytype


@end


@implementation MGMCommonSearchResultlist


@end


