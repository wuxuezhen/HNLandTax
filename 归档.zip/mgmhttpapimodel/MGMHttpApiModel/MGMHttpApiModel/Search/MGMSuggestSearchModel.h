//
//Created by ESJsonFormatForMac on 18/12/18.
//

#import <Foundation/Foundation.h>

@class MGMSuggestSearchBody;
@interface MGMSuggestSearchModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMSuggestSearchBody *body;

@end
@interface MGMSuggestSearchBody : NSObject

@property (nonatomic, assign) BOOL success;

@property (nonatomic, strong) NSArray *suggestList;

@property (nonatomic, copy) NSString *responseCode;

@property (nonatomic, copy) NSString *sid;

@property (nonatomic, assign) NSInteger costTime;

@property (nonatomic, copy) NSString *responseMessage;

@end

