//
//Created by ESJsonFormatForMac on 18/12/18.
//

#import <Foundation/Foundation.h>

@class MGMBatchMovieDetailBody,MGMBatchMovieDetailPics;
@interface MGMBatchMovieDetailModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) NSArray *body;

@property (nonatomic, assign) long long timeStamp;

@end
@interface MGMBatchMovieDetailBody : NSObject

@property (nonatomic, copy) NSString *contId;

@property (nonatomic, copy) NSString *score;

@property (nonatomic, copy) NSString *actor;

@property (nonatomic, copy) NSString *director;

@property (nonatomic, copy) NSString *area;

@property (nonatomic, copy) NSString *contentStyle;

@property (nonatomic, copy) NSString *duration;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) MGMBatchMovieDetailPics *pics;

@end

@interface MGMBatchMovieDetailPics : NSObject

@property (nonatomic, copy) NSString *lowResolutionV;

@property (nonatomic, copy) NSString *highResolutionH;

@property (nonatomic, copy) NSString *highResolutionV;

@property (nonatomic, copy) NSString *lowResolutionH;

@end

