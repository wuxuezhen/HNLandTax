//
//  MovieLibrarySearchModel.m
//  MGMLegoModule
//
//  Created by apple on 2018/12/6.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCommonSearchConditionModel.h"
#import <YYModel/YYModel.h>

@implementation MGMCommonSearchConditionModel

+ (instancetype)defaultSearchConditionModelWithJSON:(NSDictionary *)json {
    return [[self class] yy_modelWithJSON:json];
}

+ (instancetype)defaultSearchConditionModel {
    
    NSDictionary *defaultJSON = @{@"keyword":  @"《海王》",
                                  @"isTonkenSearch": @"1",
                                  @"mediaShape": @"预告,精编,片段,花絮,资讯",
                                  @"type": @"0",
                                  @"perPageSize":  @"5",
                                  @"appId": @"cinema",
                                  @"userId": @"admin",
                                  @"pageNum": @1,
                                  @"msisdn": @"13855667788",
                                  @"ct": @"502",
                                  @"ua": @"UA",
                                  @"ctVer": @"5.0.0",
                                  @"coreName": @"program",
                                  @"fields": @"",
                                  @"packId": @"1001961,1002821,1001561",
                                  @"contDisplayType": @"1000",
                                  @"sortRule": @"heatValue#desc"};
    
    MGMCommonSearchConditionModel *model = [[self class] yy_modelWithJSON:defaultJSON];
    return model;
}

+ (instancetype)defaultSatrInfoSearchConditionModel {
    NSDictionary *defaultJSON = @{
        @"appId": @"cinema",
        @"pageNum":@"1",
        @"perPageSize":@"10",
        @"sortRule":@"",
        @"msisdn":@"13855667788",
        @"ct":@"101", /// **
        @"ctVer":@"1.0.0",
        @"ua":@"UA",
        @"type":@"2", /// **
        @"isTonkenSearch":@"1",
        @"keyword":@"丁志诚", /// **
        @"fields":@"801,803,804",
        @"packId":@"1001961,1002821,1001561",
        @"starId": @"117970"
        };
    MGMCommonSearchConditionModel *model = [[self class] yy_modelWithJSON:defaultJSON];
    return model;
}

//
+ (instancetype)defaultSatrWorksSearchConditionModel {
    NSDictionary *defaultJSON = @{
                                  @"appId": @"cinema",
                                  @"ct": @"501",
                                  @"isTonkenSearch": @"0",
                                  @"userId": @"VedioUsr",
                                  @"pageNum": @"1",
                                  @"perPageSize": @"10",
                                  @"msisdn": @"",
                                  @"type": @"2",
                                  @"ctVer": @"1.0.1",
                                  @"mediaShape":@"全片",
                                  @"packId": @"1001961,1002821,1001561",
                                  @"starId": @"5281" /// **
                                  };
    MGMCommonSearchConditionModel *model = [[self class] yy_modelWithJSON:defaultJSON];
    return model;
}
- (NSDictionary *)modelToJSONObject {
    return [self yy_modelToJSONObject];
}

- (void)encodeWithCoder:(NSCoder *)aCoder { [self yy_modelEncodeWithCoder:aCoder]; }
- (id)initWithCoder:(NSCoder *)aDecoder { self = [super init]; return [self yy_modelInitWithCoder:aDecoder]; }
- (id)copyWithZone:(NSZone *)zone { return [self yy_modelCopy]; }
- (NSUInteger)hash { return [self yy_modelHash]; }
- (BOOL)isEqual:(id)object { return [self yy_modelIsEqual:object]; }
- (NSString *)description { return [self yy_modelDescription]; }

@end
