//
//Created by ESJsonFormatForMac on 18/12/18.
//

#import <Foundation/Foundation.h>

@class MGMCommonSearchBody,MGMCommonSearchFacets,MGMCommonSearchPublishtime,MGMCommonSearchContdisplaytype,MGMCommonSearchResultlist;

/**
 /// MGM_Film_Common_Search_Api
 /// search4mv/v1/search/searchCommon
 */
@interface MGMCommonSearchModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) long long timeStamp;

@property (nonatomic, strong) MGMCommonSearchBody *body;

@end
@interface MGMCommonSearchBody : NSObject

@property (nonatomic, strong) MGMCommonSearchFacets *facets;

@property (nonatomic, strong) NSArray *highLightList;

@property (nonatomic, assign) NSInteger isRecommend;

@property (nonatomic, assign) BOOL success;

@property (nonatomic, assign) NSInteger resultNum;

@property (nonatomic, assign) NSInteger costTime;

@property (nonatomic, copy) NSString *responseMessage;

@property (nonatomic, copy) NSString *responseCode;

@property (nonatomic, strong) NSArray *resultList;

@end

@interface MGMCommonSearchFacets : NSObject

@property (nonatomic, strong) MGMCommonSearchPublishtime *publishTime;

@property (nonatomic, strong) NSArray *contDisplayType;

@end

@interface MGMCommonSearchPublishtime : NSObject

@property (nonatomic, assign) NSInteger publishTime1;

@property (nonatomic, assign) NSInteger publishTime2;

@property (nonatomic, assign) NSInteger publishTime3;

@end

@interface MGMCommonSearchContdisplaytype : NSObject

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *value;

@end

@interface MGMCommonSearchResultlist : NSObject

@property (nonatomic, copy) NSString *contId;

@property (nonatomic, copy) NSString *mediaActor;

@property (nonatomic, copy) NSString *mediaType;

@property (nonatomic, copy) NSString *programId;

@property (nonatomic, copy) NSString *mediaDirector;

@property (nonatomic, copy) NSString *contName;

@property (nonatomic, copy) NSString *recordIndex;

@property (nonatomic, copy) NSString *pageNum;

@end

