//
//Created by ESJsonFormatForMac on 19/03/15.
//

#import "MGMSearchMovieDetailModel.h"
@implementation MGMSearchMovieDetailModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"body" : [MGMSearchMovieDetailBody class]};
}


@end

@implementation MGMSearchMovieDetailBody


@end


@implementation MGMSearchMovieDetailH5Pics


@end


@implementation MGMSearchMovieDetailPics


@end


