//
//  MovieLibrarySearchModel.h
//  MGMLegoModule
//
//  Created by apple on 2018/12/6.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

// 具体参数解释见
// http://confluence.cmvideo.cn/confluence/pages/viewpage.action?pageId=18664993


/// 针对普通搜索创建的模型
///
/// URL: search4mv/v1/search/searchCommon
@interface MGMCommonSearchConditionModel : NSObject

//MARK: - 此处为获取电影详情片花添加的字段
@property (nonatomic, strong) NSString * appId;
@property (nonatomic, strong) NSString * contDisplayType;
/// 未见文档注释，待补充
@property (nonatomic, strong) NSString * coreName;
/// 接入类型 www ipad h5
@property (nonatomic, strong) NSString * ct;
/// 客户端版本号， 当ct为手机客户端时，必须填写
@property (nonatomic, strong) NSString * ctVer;
/// 搜索范围
@property (nonatomic, strong) NSString * fields;
/// 是否做分词搜索
@property (nonatomic, strong) NSString * isTonkenSearch;
@property (nonatomic, strong) NSString * keyword;
/// 全片、预告、精编、改编、花絮、资讯、专题、连载
@property (nonatomic, strong) NSString * mediaShape;
/// 手机号码  or null
@property (nonatomic, strong) NSString * msisdn;
/// 是否收费 http://confluence.cmvideo.cn/confluence/pages/viewpage.action?pageId=18656700
@property (nonatomic, strong) NSString * packId;
/// 页码
@property (nonatomic, assign) NSInteger pageNum;
/// 默认 15
@property (nonatomic, strong) NSString * perPageSize;
/// 排序方式
@property (nonatomic, strong) NSString * sortRule;
/// 搜索类型
@property (nonatomic, strong) NSString * type;
/// 终端UA或浏览器UA
@property (nonatomic, strong) NSString * ua;
/// 如果用户没有登陆用空字符串代替
@property (nonatomic, strong) NSString * userId;

//MARK: - 此处为片库筛选添加的字段
/// 可国家及地区,
@property (nonatomic, strong) NSString * mediaArea;
/// 发行年份/播出年代，可用“,”组合，分层枚举值
@property (nonatomic, strong, readwrite) NSString *mediaTime;
/// 上映时间
@property (nonatomic, strong) NSString * mediaYear;
/// 剧情， 喜剧、爱情
@property (nonatomic, strong) NSString * mediaType;


//MARK: - 以下为备选字段
/// 限免
@property (nonatomic, strong) NSString * limitDate;
/// 当前页码
@property (nonatomic, strong) NSString * currentPage;
/// 出品方
@property (nonatomic, strong) NSString * mediaChu;
/// 名栏
@property (nonatomic, strong) NSString * mediaMing;
/// 电影形式, 区分微电影和长片
@property (nonatomic, strong) NSString * mediaMovieForm;
/// 播出平台,区分不同播放平台的节目，例如：网络
@property (nonatomic, strong) NSString * mediaPlat;
/// 项目,区分各种类型的体育节目，如篮球、足球等
@property (nonatomic, strong) NSString * mediaProj;
///
@property (nonatomic, strong) NSString * pageSize;


/// 用于影人相关搜索
@property (nonatomic, strong, readwrite) NSString *starId;

//FIXME: - 若果需要新增 参数请注明出处
+ (instancetype)defaultSearchConditionModelWithJSON:(NSDictionary *)json;
+ (instancetype)defaultSearchConditionModel;
/// type=2 keyword starId
+ (instancetype)defaultSatrInfoSearchConditionModel;
/// starId type=2
+ (instancetype)defaultSatrWorksSearchConditionModel;

- (NSDictionary *)modelToJSONObject;
@end
