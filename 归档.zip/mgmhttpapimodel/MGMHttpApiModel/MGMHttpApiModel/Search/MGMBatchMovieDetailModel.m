//
//Created by ESJsonFormatForMac on 18/12/18.
//

#import "MGMBatchMovieDetailModel.h"
@implementation MGMBatchMovieDetailModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"body" : [MGMBatchMovieDetailBody class]};
}


@end

@implementation MGMBatchMovieDetailBody


@end


@implementation MGMBatchMovieDetailPics


@end


