//
//Created by ESJsonFormatForMac on 19/03/15.
//

#import <Foundation/Foundation.h>

@class MGMSearchMovieDetailBody,MGMSearchMovieDetailH5Pics,MGMSearchMovieDetailPics;
@interface MGMSearchMovieDetailModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) NSArray *body;

@property (nonatomic, assign) long long timeStamp;

@end
@interface MGMSearchMovieDetailBody : NSObject

@property (nonatomic, strong) MGMSearchMovieDetailH5Pics *h5pics;

@property (nonatomic, copy) NSString *showTime;

@property (nonatomic, copy) NSString *director;

@property (nonatomic, copy) NSString *contForm;

@property (nonatomic, copy) NSString *contentStyle;

@property (nonatomic, copy) NSString *way;

@property (nonatomic, copy) NSString *area;

@property (nonatomic, copy) NSString *contId;

@property (nonatomic, copy) NSString *playType;

@property (nonatomic, copy) NSString *programType;

@property (nonatomic, copy) NSString *showTimeDesc;

@property (nonatomic, copy) NSString *actor;

@property (nonatomic, copy) NSString *cpName;

@property (nonatomic, copy) NSString *duration;

@property (nonatomic, copy) NSString *showTimeName;

@property (nonatomic, copy) NSString *score;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) MGMSearchMovieDetailPics *pics;

@end

@interface MGMSearchMovieDetailH5Pics : NSObject

@property (nonatomic, copy) NSString *lowResolutionV;

@property (nonatomic, copy) NSString *highResolutionH;

@property (nonatomic, copy) NSString *highResolutionV;

@property (nonatomic, copy) NSString *lowResolutionH;

@end

@interface MGMSearchMovieDetailPics : NSObject

@property (nonatomic, copy) NSString *lowResolutionV;

@property (nonatomic, copy) NSString *highResolutionH;

@property (nonatomic, copy) NSString *highResolutionV;

@property (nonatomic, copy) NSString *lowResolutionH;

@end

