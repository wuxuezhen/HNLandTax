//
//  MGMTicketCinemaTagListItem.h
//  MGMTicket
//
//  Created by 刘勇 on 2018/12/8.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketCinemaTagListItem : MGMBaseModel

@property (nonatomic, copy) NSString *specialHall;

@property (nonatomic, copy) NSString *glasses3D;

@property (nonatomic, copy) NSString *childrenDiscount;

@property (nonatomic, copy) NSString *parkingInfo;

@property (nonatomic, copy) NSString *wifi;

@end

NS_ASSUME_NONNULL_END
