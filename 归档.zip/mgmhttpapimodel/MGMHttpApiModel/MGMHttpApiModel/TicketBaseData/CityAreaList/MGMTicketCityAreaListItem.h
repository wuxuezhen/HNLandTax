//
//  MGMTicketCityAreaListItem.h
//  MGMTicket
//
//  Created by 刘勇 on 2018/12/10.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketCityAreaListItem : MGMBaseModel

@property (nonatomic, copy) NSString *regionId;

@property (nonatomic, copy) NSString *regionName;

@end

NS_ASSUME_NONNULL_END
