//
//  MGMTicketTopicIconInfo.h
//  MGMTicket
//
//  Created by RenYi on 2018/12/4.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMLegoModel.h"
#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketTopicIconInfo : MGMBaseModel

@property (nonatomic, copy)   NSString * type;
@property (nonatomic, copy)   NSString * redirectType;
@property (nonatomic, copy)   NSString * topicName;
@property (nonatomic, strong) MGMAction* redirectAction;
@property (nonatomic, strong, readonly) MGMData *data;


@end

NS_ASSUME_NONNULL_END
