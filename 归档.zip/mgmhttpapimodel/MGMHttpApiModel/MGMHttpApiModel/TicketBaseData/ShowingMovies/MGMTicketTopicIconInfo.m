//
//  MGMTicketTopicIconInfo.m
//  MGMTicket
//
//  Created by RenYi on 2018/12/4.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTicketTopicIconInfo.h"
#import <YYModel/NSObject+YYModel.h>

@implementation MGMTicketTopicIconInfo

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic
{
    _data = [[MGMData alloc] init];
    _data.action = _redirectAction;
    return YES;
}

@end
