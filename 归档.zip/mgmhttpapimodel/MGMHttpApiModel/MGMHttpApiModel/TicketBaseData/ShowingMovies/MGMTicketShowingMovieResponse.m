//
//  MGMTicketShowingMovieResponse.m
//  MGMTicket
//
//  Created by RenYi on 2018/12/6.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTicketShowingMovieResponse.h"
#import <YYModel/NSObject+YYModel.h>
#import <MGMCategories/NSDate+MGMConversion.h>

@implementation MGMTicketShowingMovieResponse

+ (NSDictionary *)modelContainerPropertyGenericClass
{
    return @{@"movieList" : [MGMTicketShowingMovieItem class]};
}

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic
{
    NSString *stamp = @([dic[@"timeStamp"] doubleValue] / 1000).stringValue;
    NSDate *nowDate = [NSDate mgm_dateWithTimestamp:stamp];
    NSString *nowDateStr = [nowDate mgm_stringValueWithFormat:@"yyyy-MM-dd"];
    [self.movieList makeObjectsPerformSelector:@selector(setNowDate:) withObject:nowDateStr];
    return YES;
}

@end
