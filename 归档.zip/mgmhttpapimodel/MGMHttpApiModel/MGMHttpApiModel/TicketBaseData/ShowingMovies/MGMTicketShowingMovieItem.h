//
//  MGMTicketShowingMovieItem.h
//  MGMTicket
//
//  Created by RenYi on 2018/12/4.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMTicketMoviePics.h"
#import "MGMTicketTopicIconInfo.h"
#import "MGMBaseModel.h"


NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketShowingMovieItem: MGMBaseModel

/**
    服务器返回时间戳转化后的时间
 */
@property (nonatomic, copy) NSString *nowDate;

@property (nonatomic, copy)   NSString * filmId;

@property (nonatomic, copy)   NSString * filmName;

@property (nonatomic, copy)   NSString * openingDate;   //上映日期 格式：yyyy-MM-dd

@property (nonatomic, copy)   NSString * pomsContId;    //票务平台影片id

@property (nonatomic, copy)   NSString * filmSeq;       //列表排序

@property (nonatomic, copy)   NSString * director;      //导演

@property (nonatomic, copy)   NSString * score;         //评分

@property (nonatomic, copy)   NSString * actor;         //主演

/**
    媒资的ID
 */
@property (nonatomic, copy) NSString *assetID;

/**
    想看人数
 */
@property (nonatomic, strong) NSNumber *favoriteCount;

@property (nonatomic, strong) MGMTicketMoviePics* pics;

@property (nonatomic, strong) MGMTicketTopicIconInfo* topicIconVo;

@end

NS_ASSUME_NONNULL_END
