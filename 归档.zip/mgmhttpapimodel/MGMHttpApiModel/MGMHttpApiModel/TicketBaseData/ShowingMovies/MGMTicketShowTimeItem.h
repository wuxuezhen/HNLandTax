//
//  MGMTicketShowTimeItem.h
//  MGMTicket
//
//  Created by RenYi on 2018/12/6.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketShowTimeItem : MGMBaseModel

@property (nonatomic, assign) NSUInteger  hour;
@property (nonatomic, assign) NSUInteger  minute;

@end

NS_ASSUME_NONNULL_END
