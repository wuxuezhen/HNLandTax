//
//  MGMTicketShowTimeItem.m
//  MGMTicket
//
//  Created by RenYi on 2018/12/6.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTicketShowTimeItem.h"

@implementation MGMTicketShowTimeItem

@end
