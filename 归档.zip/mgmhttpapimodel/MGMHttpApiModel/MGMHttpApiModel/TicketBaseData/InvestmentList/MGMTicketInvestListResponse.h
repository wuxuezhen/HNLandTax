//
//  MGMTicketInvestListResponse.h
//  MGMTicket
//
//  Created by 刘勇 on 2018/12/10.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"
#import "MGMTicketInvestListItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketInvestListResponse : MGMBaseModel

@property (nonatomic, strong) NSArray <MGMTicketInvestListItem *> *investmentList;

@end

NS_ASSUME_NONNULL_END
