//
//  MGMTicketInvestListItem.m
//  MGMTicket
//
//  Created by 刘勇 on 2018/12/10.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTicketInvestListItem.h"

@implementation MGMTicketInvestListItem

@end
