//
//  MGMTicketInvestListItem.h
//  MGMTicket
//
//  Created by 刘勇 on 2018/12/10.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketInvestListItem : MGMBaseModel

@property (nonatomic, copy) NSString *investmentId;

@property (nonatomic, copy) NSString *investmentName;

@end

NS_ASSUME_NONNULL_END
