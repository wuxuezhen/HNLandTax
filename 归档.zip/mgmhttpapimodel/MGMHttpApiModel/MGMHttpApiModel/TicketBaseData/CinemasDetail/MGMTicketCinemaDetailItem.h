//
//  MGMTicketCinemaDetailItem.h
//  MGMTicket
//
//  Created by 刘勇 on 2018/12/7.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketCinemaDetailItem : MGMBaseModel

@property (nonatomic, copy) NSString *cinemaName;

/**
 影院地址
 */
@property (nonatomic, copy) NSString *cinemaAdd;

/**
 经度
 */
@property (nonatomic, copy) NSString *longitude;

/**
 维度
 */
@property (nonatomic, copy) NSString *latitude;

/**
 电话
 */
@property (nonatomic, copy) NSString *cinemaTel;

@property (nonatomic, copy) NSString *openTime;

/**
 公交信息
 */
@property (nonatomic, copy) NSString *bus;

/**
 地铁
 */
@property (nonatomic, copy) NSString *metro;

/**
 特色影厅
 */
@property (nonatomic, copy) NSString *specialHall;

/**
 卖品
 */
@property (nonatomic, copy) NSString *sale;

/**
 3D眼睛
 */
@property (nonatomic, copy) NSString *glasses3D;

/**
 儿童优惠
 */
@property (nonatomic, copy) NSString *childrenDiscount;

@property (nonatomic, copy) NSString *parkingInfo;

/**
 情侣座
 */
@property (nonatomic, copy) NSString *loversSeat;

@property (nonatomic, copy) NSString *wifi;

@property (nonatomic, copy) NSString *otherInfo;
///影院通知
@property (nonatomic, copy) NSString *notice;

@end

NS_ASSUME_NONNULL_END
