//
//  MGMTicketUpcomingMovieItem.m
//  MGMTicket
//
//  Created by RenYi on 2018/12/4.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTicketUpcomingMovieItem.h"

@implementation MGMTicketUpcomingMovieItem

@end
