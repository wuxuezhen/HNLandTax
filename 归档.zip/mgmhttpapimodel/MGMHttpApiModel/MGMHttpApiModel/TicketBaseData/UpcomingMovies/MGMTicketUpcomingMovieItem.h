//
//  MGMTicketUpcomingMovieItem.h
//  MGMTicket
//
//  Created by RenYi on 2018/12/4.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTicketShowingMovieItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketUpcomingMovieItem : MGMTicketShowingMovieItem

/**
    上映时间标识位（0-国内首映时间；1-待映日期）
 */
@property (nonatomic, copy)   NSString * playDateType;

/**
    按城市:即将上映，场次数
 */
@property (nonatomic, copy)   NSString * num;

/**
    按城市:即将上映，是否预售（0-想看，1-预售）
 */
@property (nonatomic, copy)   NSString * isPreSale;

/**
    想看状态(YES-已想看， NO-想看)
 */
@property (nonatomic, assign) BOOL favorite;

@end

NS_ASSUME_NONNULL_END
