//
//  MGMTicketUpcomingMoviesResponse.h
//  MGMTicket
//
//  Created by RenYi on 2018/12/6.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMBaseModel.h"
#import "MGMTicketUpcomingMovieItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketUpcomingMoviesResponse : MGMBaseModel

/**
    片源总数
 */
@property (nonatomic, assign) NSUInteger  count;

/**
    当前页数（从0开始）
 */
@property (nonatomic, assign) NSUInteger  pageNo;

/**
    每页的个数
 */
@property (nonatomic, assign) NSUInteger  pageSize;

@property (nonatomic, strong) NSArray <MGMTicketUpcomingMovieItem *>* movieList;

- (BOOL)hasMore;

@end

NS_ASSUME_NONNULL_END
