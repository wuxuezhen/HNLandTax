//
//  MGMTicketCinemaItem.m
//  MGMTicket
//
//  Created by RenYi on 2018/12/6.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTicketCinemaItem.h"

@implementation MGMTicketCinemaItem

+ (NSDictionary *)modelCustomPropertyMapper
{
    return @{
             @"address"  : @"cinemaAdd",
             @"telephone"  : @"cinemaTel",
             @"score" : @"cinemaScore",
             @"investmentName" : @"cinemaInvestmentName"
             };
}
+ (NSDictionary *)modelContainerPropertyGenericClass
{
    return @{@"showTimeList" : [MGMTicketShowTimeModel class] };
}

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic
{
    NSString * saleStr = dic[@"sale"];
    NSString * glasses3DStr = dic[@"glasses3D"];
    NSString * childrenDiscountStr = dic[@"childrenDiscount"];
    NSString * parkingInfoStr = dic[@"parkingInfo"];
    NSString * wifiStr = dic[@"wifi"];
    
    self.sale = [saleStr isEqualToString:@"0"] ? NO : YES;
    self.glasses3D = [glasses3DStr isEqualToString:@"0"] ? NO : YES;
    self.childrenDiscount = [childrenDiscountStr isEqualToString:@"0"] ? NO : YES;
    self.parkingInfo = [parkingInfoStr isEqualToString:@"0"] ? NO : YES;
    self.wifi = [wifiStr isEqualToString:@"0"] ? NO : YES;
    
    return YES;
}

@end
