//
//  MGMTicketValidCinemasResponse.m
//  MGMTicket
//
//  Created by RenYi on 2018/12/6.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTicketValidCinemasResponse.h"

@implementation MGMTicketValidCinemasResponse

+ (NSDictionary *)modelContainerPropertyGenericClass
{
    return @{@"cinemaList" : [MGMTicketCinemaItem class] };
}

+ (NSDictionary *)modelCustomPropertyMapper
{
    return @{
             @"cinemaList"  : @"cinemaes"
             };
}

@end
