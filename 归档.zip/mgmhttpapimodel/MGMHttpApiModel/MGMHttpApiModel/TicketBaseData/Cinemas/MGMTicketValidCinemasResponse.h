//
//  MGMTicketValidCinemasResponse.h
//  MGMTicket
//
//  Created by RenYi on 2018/12/6.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"
#import "MGMTicketCinemaItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketValidCinemasResponse : MGMBaseModel

@property (nonatomic, strong) NSArray <MGMTicketCinemaItem *>* cinemaes;

@end

NS_ASSUME_NONNULL_END
