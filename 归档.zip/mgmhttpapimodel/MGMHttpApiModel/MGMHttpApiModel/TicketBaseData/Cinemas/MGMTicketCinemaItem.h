//
//  MGMTicketCinemaItem.h
//  MGMTicket
//
//  Created by RenYi on 2018/12/6.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMBaseModel.h"
#import "MGMTicketShowTimeItem.h"
#import "MGMTicketShowTimeModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMTicketCinemaItem : MGMBaseModel

@property (nonatomic, assign) NSInteger  cinemaId;
@property (nonatomic, copy)   NSString * cinemaName;
@property (nonatomic, copy)   NSString * accessorId;
@property (nonatomic, copy)   NSString * address;
@property (nonatomic, copy)   NSString * telephone;

/**
 与当前位置的距离(公里)
 */
@property (nonatomic, copy)   NSString * distance;
@property (nonatomic, copy)   NSString * longitude;
@property (nonatomic, copy)   NSString * latitude;
@property (nonatomic, copy)   NSString * provinceName;
///影院评分
@property (nonatomic,copy) NSString *cinemaScore;
/**
 该影院是否为收藏影院 true:是 ，false：不是 ;默认为false
 */
@property (nonatomic,assign) BOOL collection;
/**
 所属院线: 1-万达,2-SFD,3-横店,4-中影
 */
@property (nonatomic, copy)   NSString * cinemaCompany;

/**
 系统提供商
 */
@property (nonatomic, copy)   NSString * systemProviders;

/**
 影院评分
 */
@property (nonatomic, copy)   NSString * score;

/**
 区域id
 */
@property (nonatomic, copy)   NSString * regionId;

/**
 特色影厅（多个特色影厅用“/”分隔） 例如：IMAX厅/4D厅/杜比厅
 */
@property (nonatomic, copy)   NSString * specialHall;


/**
 卖品 ( 0为空  1不为空)
 */
@property (nonatomic, assign, getter=isSale)  BOOL  sale;

/**
 3D眼镜( 0为空  1不为空)
 */
@property (nonatomic, assign, getter=isGlasses3D)   BOOL  glasses3D;

/**
 儿童优惠( 0为空  1不为空)
 */
@property (nonatomic, getter=isChildrenDiscount)   BOOL  childrenDiscount;

/**
 停车信息( 0为空  1不为空)
 */
@property (nonatomic, assign, getter=isParkingInfo)   BOOL  parkingInfo;

/**
 WIFI ( 0为空  1不为空)
 */
@property (nonatomic, assign, getter=isWifi)   BOOL  wifi;

/**
 影院最低票价，单位为元 例如：50.9
 */
@property (nonatomic, copy)   NSString * lowestTicketPrice;
@property (nonatomic, copy)   NSString * businessCenter;
@property (nonatomic, copy)   NSString * investmentName;
@property (nonatomic, copy)   NSString * allowCard;

/**
 场次放映时间列表，当查询影片在某天内有场次放映的影院时，该字段有值。
 场次放映时间 格式: hhmm
 */
@property (nonatomic, strong) NSArray <MGMTicketShowTimeModel *>* showTimeList;



@property (nonatomic,copy) NSString *showTime;
















@end

NS_ASSUME_NONNULL_END
