//
//  MGMTicketShowTimeModel.m
//  MGMHttpApiModel
//
//  Created by ww on 2018/12/18.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMTicketShowTimeModel.h"

@implementation MGMTicketShowTimeModel

@end
