//
//  MGMThumbUpCountDataModel.h
//  MGMLegoModule
//
//  Created by 袁飞扬 on 2018/12/6.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MGMLegoAction.h"
#import "MGMThumbData.h"


NS_ASSUME_NONNULL_BEGIN

@interface MGMFilmDetailThumbUpCountDataModel : MGMBase

@property (nonatomic, strong)NSArray <MGMThumbData *> *data;

@end


NS_ASSUME_NONNULL_END
