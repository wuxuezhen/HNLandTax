//
//  MGMThumbUpCountDataModel.m
//  MGMLegoModule
//
//  Created by 袁飞扬 on 2018/12/6.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMThumbUpCountDataModel.h"
#import "MGMThumbData.h"
#import <YYModel/YYModel.h>

@implementation MGMThumbUpCountDataModel
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"data" : [MGMThumbData class],
             };
}

@end
