//
//  MGMThumbData.h
//  MGMHttpApiModel
//
//  Created by zhaohao on 2018/12/11.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMThumbData : MGMBase

@property (nonatomic , strong) NSString *has;
@property (nonatomic , strong) NSString *likeCount;
@property (nonatomic , strong) NSString *objectId;

@end

@interface MGMThumbData () 

@property (nonatomic , assign) BOOL mgm_has;
@property (nonatomic , assign) NSInteger mgm_likeCount;
@property (nonatomic, assign, readonly) NSInteger objectId_;

@end


NS_ASSUME_NONNULL_END
