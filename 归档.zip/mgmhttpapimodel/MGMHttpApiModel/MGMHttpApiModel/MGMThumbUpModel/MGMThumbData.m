//
//  MGMThumbData.m
//  MGMHttpApiModel
//
//  Created by zhaohao on 2018/12/11.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMThumbData.h"

@implementation MGMThumbData


- (BOOL)mgm_has {
    return self.has.boolValue;
}

- (void)setMgm_has:(BOOL)mgm_has {
    self.has = [@(mgm_has) stringValue];
}

- (NSInteger)mgm_likeCount {
    return self.likeCount.integerValue;
}

- (void)setMgm_likeCount:(NSInteger)mgm_likeCount {
    self.likeCount = [@(mgm_likeCount) stringValue];
}

- (NSInteger)objectId_ {
    return self.objectId.integerValue;
}

@end
