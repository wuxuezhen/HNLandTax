//
//  MGMBalanceModel.h
//  MGMHttpApiModel
//
//  Created by YL on 2018/12/24.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MGMCardModel;

NS_ASSUME_NONNULL_BEGIN

@interface MGMBalanceModel : NSObject
    
@property (nonatomic, copy) NSString *accountType;
//分价格
@property (nonatomic, assign)long     amount;
//过期时间
@property (nonatomic, copy) NSString   *expiryDate;
@property (nonatomic, copy) NSString   *currency;
@property (nonatomic, copy) NSString   *scope;
//自定义字段，电影卡支付方式
@property (nonatomic, copy) NSString   *movieCardPayCode;

@property (nonatomic, strong) MGMCardModel *cardModel;
    
@end

NS_ASSUME_NONNULL_END
