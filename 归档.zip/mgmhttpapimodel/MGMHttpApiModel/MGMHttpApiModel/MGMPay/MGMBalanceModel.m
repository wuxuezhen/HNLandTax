//
//  MGMBalanceModel.m
//  MGMHttpApiModel
//
//  Created by YL on 2018/12/24.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBalanceModel.h"

@implementation MGMBalanceModel

- (NSString *)scope {
    if(_scope == nil) {
        return @"";
    }
    return _scope;
}

//电影卡的支付方式
- (NSString *)movieCardPayCode {
    NSString *payCode = nil;
    if([self.scope isEqualToString:@""] ) {
        return @"MIGU_MOVIE_CARD_PAY";
    }
    switch (self.scope.integerValue) {
        case 2000: {
            payCode = @"MIGU_MOVIE_CARD01_PAY";
            break;
        }
        case 2100: {
            payCode = @"MIGU_MOVIE_CARD02_PAY";
            break;
        }
        case 2101: {
            payCode = @"MIGU_MOVIE_CARD03_PAY";
            break;
        }
        case 2001: {
            payCode = @"MIGU_MOVIE_CARD05_PAY";
            break;
        }
        case 2002: {
            payCode = @"MIGU_MOVIE_CARD06_PAY";
            break;
        }
        case 2102: {
            payCode = @"MIGU_MOVIE_CARD07_PAY";
            break;
        }
        case 2103: {
            payCode = @"MIGU_MOVIE_CARD08_PAY";
            break;
        }
        case 2104: {
            payCode = @"MIGU_MOVIE_CARD09_PAY";
            break;
        }
        case 2105: {
            payCode = @"MIGU_MOVIE_CARD10_PAY";
            break;
        }
        case 2003: {
            payCode = @"MIGU_MOVIE_CARD11_PAY";
            break;
        }
        case 2004: {
            payCode = @"MIGU_MOVIE_CARD13_PAY";
            break;
        }
        case 2005: {
            payCode = @"MIGU_MOVIE_CARD14_PAY";
            break;
        }
        
        default:
        break;
    }
    return payCode;
}
    
@end
