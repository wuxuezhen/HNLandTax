//
//  MGMPayQueryPriceModel.m
//  MGMHttpApiModel
//
//  Created by YL on 2018/12/19.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMPayQueryPriceModel.h"

@implementation MGMPayQueryPriceModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"payments" : [MGMPayWayModel class]
             };
}

@end
