//
//  MGMCashRegisterOptionModel.m
//  MGMHttpApiModel
//
//  Created by Banana on 2019/4/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCashRegisterOptionModel.h"
#import <YYModel/NSObject+YYModel.h>

@implementation MGMCashRegisterOptionModel
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"switch_":@"switch"};
}

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    if (self.starttime_ && self.endtime_) {
        self.starttime_;
        self.endtime_;
        self.switch2_;
        NSDate *date = [NSDate date];
        
        _switch2_ =  [self.starttime_ compare:date] == NSOrderedAscending && [self.endtime_ compare:date] == NSOrderedDescending && [_switch_ isEqualToString:@"on"];
        
    }
    return YES;
}

- (NSDate *)starttime_ {
    if (!_starttime_) {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMdd HH:mm";
        _starttime_ = [formatter dateFromString:_starttime];
    }
    return _starttime_;
}

- (NSDate *)endtime_ {
    if (!_endtime_) {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMdd HH:mm";
        _endtime_ = [formatter dateFromString:_endtime];
    }
    return _endtime_;
}

@end
