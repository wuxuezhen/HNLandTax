//
//  MGMPayWayModel.m
//  MGMHttpApiModel
//
//  Created by YL on 2018/12/19.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMPayWayModel.h"

@implementation MGMChargeModel

@end

@implementation MGMPayWayModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"charge" : [MGMChargeModel class]
             };
}

@end
