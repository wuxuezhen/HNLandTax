//
//  MGMPayWayModel.h
//  MGMHttpApiModel
//
//  Created by YL on 2018/12/19.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

//支付方式
#import <Foundation/Foundation.h>
#import "MGMCashRegisterOptionModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMChargeModel : NSObject

@property (nonatomic, copy) NSString *cpCode;
@property (nonatomic, copy) NSString *productId;
@property (nonatomic, copy) NSString *operCode;  //计费点
@property (nonatomic, copy) NSString *operType;

@end

@interface MGMPayWayModel : NSObject
//价格
@property (nonatomic, assign) NSInteger    amount;
//支付code
@property (nonatomic, copy)  NSString      *code;
//支付name
@property (nonatomic, copy)  NSString      *name;

@property (nonatomic, copy)  NSString      *accountType;

@property (nonatomic, assign)BOOL          mixable;

@property (nonatomic, copy) NSArray *payDeliveryItems;
@property (nonatomic, strong) MGMCashRegisterOptionModel *activeModel;

@property (nonatomic, strong) MGMChargeModel    *charge;

@property (nonatomic, assign)BOOL          hiddenLine;

@property (nonatomic, assign)BOOL          forbidClick;

@end


NS_ASSUME_NONNULL_END
