//
//  MGMCashRegisterOptionModel.h
//  MGMHttpApiModel
//
//  Created by Banana on 2019/4/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMCashRegisterOptionModel : NSObject
@property (nonatomic, copy) NSString *bankCode;
@property (nonatomic, assign, readwrite) BOOL switch2_;

@property (nonatomic, copy) NSString *dailog;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *endtime;

@property (nonatomic, copy) NSString *label;

@property (nonatomic, copy) NSString *payType;

@property (nonatomic, copy) NSString *range;
@property (nonatomic, copy, readwrite, nullable) NSString *switch_;

@property (nonatomic, copy) NSString *starttime;
@property (nonatomic, copy, readwrite, nullable) NSDate *starttime_;
@property (nonatomic, copy, readwrite, nullable) NSDate *endtime_;
@property (nonatomic, copy) NSString *switc;

@end

NS_ASSUME_NONNULL_END
