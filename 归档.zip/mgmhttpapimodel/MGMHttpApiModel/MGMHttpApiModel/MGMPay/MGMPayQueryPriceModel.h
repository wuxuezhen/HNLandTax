//
//  MGMPayQueryPriceModel.h
//  MGMHttpApiModel
//
//  Created by YL on 2018/12/19.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMPayWayModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMPayQueryPriceModel : NSObject
//最终价格（分）
@property (nonatomic, assign) NSInteger    lastPrice;
//业务信息,生成订单使用
@property (nonatomic, strong) NSDictionary *serviceInfo;
//支付方式
@property (nonatomic, copy)   NSArray    <MGMPayWayModel*>*payments;
@property (nonatomic, copy)   NSArray    *extDeliveryItems;
@property (nonatomic, strong) NSDictionary *mainDeliveryItem;

@end

NS_ASSUME_NONNULL_END
