//
//  MGMFetchShowOrderInfoResponse.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/21.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

#import "MGMFetchShowOrderInfoItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchShowOrderInfoResponse : MGMBaseModel

/**
 返回状态码：0，-1
 */
@property (nonatomic,   copy) NSString *resultCode;

/**
 描述：success，异常，userId is null
 */
@property (nonatomic,   copy) NSString *resultDesc;

@property (nonatomic, strong) NSArray<MGMFetchShowOrderInfoItem*> *orderPerforms;

@end

NS_ASSUME_NONNULL_END
