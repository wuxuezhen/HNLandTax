//
//  MGMFetchTicketYPOrderNumResponse.h
//  MGMHttpApiModel
//
//  Created by 刘勇 on 2018/12/29.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"
#import "MGMFetchTicketOrderInfoItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchTicketYPOrderNumResponse : MGMBaseModel

@property (nonatomic, strong) NSArray<MGMFetchTicketOrderInfoItem *> *ypOrderInfoList;

@end

NS_ASSUME_NONNULL_END
