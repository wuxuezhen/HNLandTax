//
//  MGMFetchTicketOrderInfoItem.h
//  MGMHttpApiModel
//
//  Created by 刘勇 on 2018/12/29.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MGMBaseModel.h"
#import "MGMFetchTicketOrderSeatSectionInfoItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchTicketOrderInfoItem : MGMBaseModel
/**
 电影类型
 */
@property (nonatomic, copy) NSString *dimensional;

@property (nonatomic, copy) NSString *orderStatusDesc;
/**
 订单系统id
 */
@property (nonatomic, copy) NSString *tradeOrderId;

@property (nonatomic, copy) NSString *createdate;

@property (nonatomic, copy) NSString *language;

@property (nonatomic, copy) NSString *showDate;

@property (nonatomic, copy) NSString *orderTime;
/**
 取票二维码
 */
@property (nonatomic, copy) NSString *qrCode;

@property (nonatomic, copy) NSString *cinemaId;

@property (nonatomic, copy) NSString *cinemaName;

@property (nonatomic, copy) NSString *contact;
/**
 订购流水号
 */
@property (nonatomic, copy) NSString *thirdOrderId;

@property (nonatomic, copy) NSString *exchangeAddr;
/**
 取票码
 */
@property (nonatomic, copy) NSString *confirmationId;

@property (nonatomic, copy) NSString *longitude;
/**
 咪咕订单号
 */
@property (nonatomic, copy) NSString *orderNo;

@property (nonatomic, copy) NSString *showTime;
/**
 展厅Id
 */
@property (nonatomic, copy) NSString *hallId;

@property (nonatomic, copy) NSString *cinemaAdd;

@property (nonatomic, copy) NSString *filmId;

@property (nonatomic, copy) NSString *accessorId;

@property (nonatomic, copy) NSString *filmName;

@property (nonatomic, copy) NSString *latitude;
/**
 订单状态：0:未生成第三方订单;1:出票成功;2:未生成华为订单;3未支付订单;4已经支付的订单(未出票)；5：（取消华为订单成功）退款中;6华为创建订单失败 7：已退款（取消华为订单成功） 8: 未支付订单取消成功，不展示 9：支付订单取消订单失败 10:支付订单取消订单异常 ；11：未支付订单取消失败13:不支持退款
 */
@property (nonatomic, assign) NSInteger orderStatus;
/**
 *  退款状态  0 不需要退款  1 已经退款  2退款中  3 退款失败  (有可能此状态为空值)
 *  目前只处理(前端显示) 0  1 空值 等状态， 2 3状态不处理（前端不显示）
 *  判断订单状态 首先 判断 refundOrderStatus字段 ，当为 0 或 空值时，再判断 orderStatus字段，根据它的状态去做处理，当refundOrderStatus字段为 1 时，直接判断为 已退款 状态。
 *
 */
@property (nonatomic, copy) NSString *refundOrderStatus;

/**
 咪咕影片 id
 */
@property (nonatomic, copy) NSString *miguMovieId;
/**
 电影场次号
 */
@property (nonatomic, copy) NSString *showId;

@property (nonatomic, copy) NSString *seatInfo;
/**
 票的价格（分)
 */
@property (nonatomic, assign) unsigned long long amount;
/**
 系统验证码
 */
@property (nonatomic, copy) NSString *verifyCode;

@property (nonatomic, copy) NSString *mobile;

@property (nonatomic, copy) NSString *userId;
/**
 柜台取票码
 */
@property (nonatomic, copy) NSString *bookingId;
/**
 行编号
 */
@property (nonatomic, copy) NSString *rowId;

@property (nonatomic, assign) NSInteger paystatus;
/**
 展厅名称
 */
@property (nonatomic, copy) NSString *hallName;

//当前系统时间(时间戳)
@property (nonatomic, copy) NSString *timeStamp;
//影片时长(分)
@property (nonatomic, copy) NSString *duration;
//场次分区信息
@property (nonatomic, strong) NSArray<MGMFetchTicketOrderSeatSectionInfoItem *> *seatSectionInfo;

@end

NS_ASSUME_NONNULL_END

