//
//  MGMFetchTicketOrderSeatSectionInfoItem.m
//  MGMHttpApiModel
//
//  Created by 刘志辉 on 2019/12/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFetchTicketOrderSeatSectionInfoItem.h"

@implementation MGMFetchTicketOrderSeatSectionInfoItem

@end
