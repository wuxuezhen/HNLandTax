//
//  MGMFetchMallOrderDetailLogisticsInfo.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/2/19.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchMallOrderDetailLogisticsInfo : MGMBaseModel

@property (nonatomic,   copy) NSString *express;
@property (nonatomic,   copy) NSString *numbers;

@end

NS_ASSUME_NONNULL_END
