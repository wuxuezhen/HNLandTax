//
//  MGMFetchMallOrderItemGoodsInfo.m
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFetchMallOrderItemGoodsInfo.h"

@implementation MGMFetchMallOrderItemGoodsInfo

@end
