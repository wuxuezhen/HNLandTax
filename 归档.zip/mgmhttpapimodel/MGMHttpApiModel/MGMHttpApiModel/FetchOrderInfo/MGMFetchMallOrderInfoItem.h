//
//  MGMFetchMallOrderInfoItem.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

#import "MGMFetchMallOrderItemGoodsInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchMallOrderInfoItem : MGMBaseModel

@property (nonatomic,   copy) NSString *createtime;
@property (nonatomic,   copy) NSString *orderid;
@property (nonatomic,   copy) NSString *ordernumber;
@property (nonatomic,   copy) NSString *totalprice;
@property (nonatomic,   copy) NSString *status;

@property (nonatomic, strong) NSArray<MGMFetchMallOrderItemGoodsInfo*> *item;

@end

NS_ASSUME_NONNULL_END
