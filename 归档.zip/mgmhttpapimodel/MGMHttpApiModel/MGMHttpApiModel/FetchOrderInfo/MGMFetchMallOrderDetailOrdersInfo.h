//
//  MGMFetchMallOrderDetailOrdersInfo.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/2/19.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchMallOrderDetailOrdersInfo : MGMBaseModel

@property (nonatomic, copy) NSString *address;
@property (nonatomic, copy) NSString *contact;
@property (nonatomic, copy) NSString *coupon;
@property (nonatomic, copy) NSString *createtime;
@property (nonatomic, copy) NSString *ordernumber;
@property (nonatomic, copy) NSString *phone;
@property (nonatomic, copy) NSString *postprice;
@property (nonatomic, copy) NSString *remarks;
@property (nonatomic, copy) NSString *status;
@property (nonatomic, copy) NSString *totalprice;

@end

NS_ASSUME_NONNULL_END
