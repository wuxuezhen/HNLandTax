//
//  MGMFetchMallOrderDetailInfoResponse.m
//  MGMTicketPay
//
//  Created by wdlzh on 2019/2/19.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFetchMallOrderDetailInfoResponse.h"

@implementation MGMFetchMallOrderDetailInfoResponse

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"goods" : [MGMFetchMallOrderItemGoodsInfo class]};
}

@end
