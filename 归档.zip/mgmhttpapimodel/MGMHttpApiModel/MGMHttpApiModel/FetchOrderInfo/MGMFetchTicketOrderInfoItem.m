//
//  MGMFetchTicketOrderInfoItem.m
//  MGMHttpApiModel
//
//  Created by 刘勇 on 2018/12/29.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFetchTicketOrderInfoItem.h"

@implementation MGMFetchTicketOrderInfoItem

+ (NSDictionary *)modelContainerPropertyGenericClass
{
    return @{@"seatSectionInfo" : [MGMFetchTicketOrderSeatSectionInfoItem class]};
}

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic
{
    self.orderStatus = [dic[@"orderStatus"] integerValue];
    self.amount = [dic[@"amount"] longLongValue];
    self.paystatus = [dic[@"paystatus"] integerValue];
    return YES;
}

@end
