//
//  MGMFetchMallOrderItemGoodsInfo.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchMallOrderItemGoodsInfo : MGMBaseModel

@property (nonatomic,   copy) NSString *img;
@property (nonatomic,   copy) NSString *name;
@property (nonatomic,   copy) NSString *price;
@property (nonatomic,   copy) NSString *sku;
@property (nonatomic,   copy) NSString *total;
@property (nonatomic,   copy) NSString *url;

@end

NS_ASSUME_NONNULL_END
