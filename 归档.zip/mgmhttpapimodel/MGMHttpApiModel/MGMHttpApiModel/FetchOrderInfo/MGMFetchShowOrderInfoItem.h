//
//  MGMFetchShowOrderInfoItem.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/21.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchShowOrderInfoItem : MGMBaseModel

/**
 第三方支付金额（单位：分）
 */
@property (nonatomic,   copy) NSString *balance;
/**
 证件人名称（trueBuy=1时，必传，多个用,隔开）
 */
@property (nonatomic,   copy) NSString *cardName;
/**
 证件号码（trueBuy=1时，必传,多个用,隔开）
 */
@property (nonatomic,   copy) NSString *cardNo;
/**
 订单配送方式（1.快递配送；2.上门自取；3.货到付款；4.电子票）
 */
@property (nonatomic,   copy) NSString *dispatchWay;
/**
 电子码
 */
@property (nonatomic,   copy) NSString *dzmEpc;
/**
 电子票信息（dispatchWay为4时必传）
 */
@property (nonatomic,   copy) NSString *dzpMessage;
/**
 快递公司名
 */
@property (nonatomic,   copy) NSString *expressName;
/**
 快递单号
 */
@property (nonatomic,   copy) NSString *expressNo;
/**
 华为交易订单编号
 */
@property (nonatomic,   copy) NSString *huaWeiOrderId;
/**
 发票收货人姓名（获取发票方式为10、快递到付必传）
 */
@property (nonatomic,   copy) NSString *invoiceConsignee;
/**
 获取发票邮箱（获取发票方式为30、电子发票必传）
 */
@property (nonatomic,   copy) NSString *invoiceEmail;
/**
 发票快递地址（获取发票方式为10、快递到付必传）
 */
@property (nonatomic,   copy) NSString *invoiceExpressAddress;
/**
 获取发票方式：10、快递到付 20、上门自取 30、电子发票
 */
@property (nonatomic,   copy) NSString *invoiceObtainMode;
/**
 获取发票手机号（获取发票方式为10、快递到付20、上门自取必传）
 */
@property (nonatomic,   copy) NSString *invoicePhone;
/**
 发票抬头内容:发票抬头类型为0.个人时内容不能为 “个人”两个字
 */
@property (nonatomic,   copy) NSString *invoiceTitle;
/**
 发票抬头类型 ：0.个人、1.公司
 */
@property (nonatomic,   copy) NSString *invoiceTitleType;
/**
 用户是否开发票：0、不开发票 1、开发票
 */
@property (nonatomic,   copy) NSString *invoiceUnseal;
/**
 配送提示（dispatchWay为1时必传）
 */
@property (nonatomic,   copy) NSString *kdpsMessage;
/**
 咪咕订单编号
 */
@property (nonatomic,   copy) NSString *miGuOrderId;
/**
 有效证件类型 10 身份证、20 护照(trueBuy=1时，必传，多个用,隔开)
 */
@property (nonatomic,   copy) NSString *paperworkType;
/**
 收票人手机
 */
@property (nonatomic,   copy) NSString *phone;
/**
 票品名称
 */
@property (nonatomic,   copy) NSString *playName;
/**
 支付方式：ALI_PAY 支付宝 ALI_WEB_PAY 支付宝WEB MIGU_GROUP_PAY 一级SDK支付 MIGU_GROUP_WEB_PAY 一级WEB支付 SPDB_PAY  浦发支付 SUM_PAY 复星钱包支付 MOVIE_NO_ORIENT_AMOUNT_TICKET_PAY 电影储值卡 WEIXIN_PAY 微信支付
 */
@property (nonatomic,   copy) NSString *payType;
/**
 场馆名称
 */
@property (nonatomic,   copy) NSString *playAddress;
/**
 场馆Id
 */
@property (nonatomic,   copy) NSString *playAddressId;
/**
 演出场次日期
 */
@property (nonatomic,   copy) NSString *ticketTime;
/**
 购票时间
 */
@property (nonatomic,   copy) NSString *orderTime;
/**
 配送地址
 */
@property (nonatomic,   copy) NSString *orderAddress;
/**
 订单状态  0: 生成咪咕订单;1: 出票成 功;2: 未生成华为订单; 3：未支付订单(创建华为订单，等待支付);4:已经支付的订单(未出票)；5:（取消华为订单成功）退款中;6: 华为创建订单失败;7:华为退款成功;8:未支付订单取消成功;9：支付订单取消订单失败;10:支付取消订单异常11：未支付订单取消失败;13: 不支持退款
 */
@property (nonatomic,   copy) NSString *orderStatus;
/**
 *  退款状态  0 不需要退款  1 已经退款  2退款中  3 退款失败  (有可能此状态为空值)
 *  目前只处理(前端显示) 0  1 空值 等状态， 2 3状态不处理（前端不显示）
 *  判断订单状态 首先 判断 refundStatus 字段 ，当为 0 或 空值时，再判断 orderStatus字段，根据它的状态去做处理，当 refundStatus 字段为 1 时，直接判断为 已退款 状态。
 *
 */
@property (nonatomic,   copy) NSString *refundStatus;
/**
 订单总金额（单位：分）
 */
@property (nonatomic,   copy) NSString *totalFee;
/**
 票品单价（单位：元）
 */
@property (nonatomic,   copy) NSString *price;
/**
 购票数量
 */
@property (nonatomic,   copy) NSString *priceNum;
/**
 票品ID唯一标识
 */
@property (nonatomic,   copy) NSString *productId;
/**
 票品缩略图片(尺寸：90 * 120)
 */
@property (nonatomic,   copy) NSString *productPictureSmall;
/**
 上门取货地址（dispatchWay为2时必传）
 */
@property (nonatomic,   copy) NSString *smzqAddress;
/**
 上门自取取货码（dispatchWay为2时必传)
 */
@property (nonatomic,   copy) NSString *smzqCode;
/**
 上门自取信息（dispatchWay为2时必传）
 */
@property (nonatomic,   copy) NSString *smzqMessage;
/**
 上门取货时间（dispatchWay为2时必传）
 */
@property (nonatomic,   copy) NSString *smzqTime;
/**
 纳税人识别号
 */
@property (nonatomic,   copy) NSString *taxpayerNum;
/**
 是否实名制商品购票：0.否、1.是
 */
@property (nonatomic,   copy) NSString *trueBuy;

/**
 该证件购买数量（trueBuy=1时，必传，多个用,隔开）
 */
@property (nonatomic,   copy) NSString *trueBuyNum;
/**
 收票人姓名
 */
@property (nonatomic,   copy) NSString *userName;

@end

NS_ASSUME_NONNULL_END
