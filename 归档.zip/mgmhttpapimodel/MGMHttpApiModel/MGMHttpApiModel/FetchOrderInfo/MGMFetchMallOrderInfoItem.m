//
//  MGMFetchMallOrderInfoItem.m
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFetchMallOrderInfoItem.h"

@implementation MGMFetchMallOrderInfoItem

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"item" : [MGMFetchMallOrderItemGoodsInfo class]};
}

@end
