//
//  MGMFetchTicketOrderSeatSectionInfoItem.h
//  MGMHttpApiModel
//
//  Created by 刘志辉 on 2019/12/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchTicketOrderSeatSectionInfoItem : MGMBaseModel
//场区ID
@property (nonatomic, copy) NSString *fieldAreaId;
//场区名字
@property (nonatomic, copy) NSString *fieldAreaName;
//分区ID
@property (nonatomic, copy) NSString *sectionId;
//分区名字
@property (nonatomic, copy) NSString *sectionName;
//座位实际排号
@property (nonatomic, copy) NSString *rowId;
//座位实际列号
@property (nonatomic, copy) NSString *columnId;
//第三方座位标识
@property (nonatomic, copy) NSString *seatNo;
//座位逻辑排号
@property (nonatomic, copy) NSString *rowNum;
//座位逻辑列号
@property (nonatomic, copy) NSString *columnNum;

@end

NS_ASSUME_NONNULL_END
