//
//  MGMFetchMallOrderDetailLogisticsInfo.m
//  MGMTicketPay
//
//  Created by wdlzh on 2019/2/19.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFetchMallOrderDetailLogisticsInfo.h"

@implementation MGMFetchMallOrderDetailLogisticsInfo

@end
