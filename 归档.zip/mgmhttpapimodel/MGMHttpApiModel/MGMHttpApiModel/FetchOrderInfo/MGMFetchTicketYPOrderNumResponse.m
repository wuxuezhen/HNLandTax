//
//  MGMFetchTicketYPOrderNumResponse.m
//  MGMHttpApiModel
//
//  Created by 刘勇 on 2018/12/29.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFetchTicketYPOrderNumResponse.h"

@implementation MGMFetchTicketYPOrderNumResponse

@end
