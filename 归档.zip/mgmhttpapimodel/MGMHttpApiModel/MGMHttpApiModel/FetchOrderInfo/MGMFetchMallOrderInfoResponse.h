//
//  MGMFetchMallOrderInfoResponse.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/31.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MGMBaseModel.h"

#import "MGMFetchMallOrderInfoItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchMallOrderInfoResponse : MGMBaseModel

@property(nonatomic, strong) NSArray<MGMFetchMallOrderInfoItem*> *data;

@end

NS_ASSUME_NONNULL_END
