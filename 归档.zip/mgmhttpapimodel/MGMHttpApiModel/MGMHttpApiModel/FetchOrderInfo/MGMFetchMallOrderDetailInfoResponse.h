//
//  MGMFetchMallOrderDetailInfoResponse.h
//  MGMTicketPay
//
//  Created by wdlzh on 2019/2/19.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"

#import "MGMFetchMallOrderItemGoodsInfo.h"
#import "MGMFetchMallOrderDetailLogisticsInfo.h"
#import "MGMFetchMallOrderDetailOrderPreInfo.h"
#import "MGMFetchMallOrderDetailOrdersInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchMallOrderDetailInfoResponse : MGMBaseModel

@property (nonatomic, strong) NSArray<MGMFetchMallOrderItemGoodsInfo*>  *goods;

@property (nonatomic, strong) MGMFetchMallOrderDetailLogisticsInfo      *logistics;

@property (nonatomic, strong) MGMFetchMallOrderDetailOrderPreInfo       *orderpre;

@property (nonatomic, strong) MGMFetchMallOrderDetailOrdersInfo         *orders;

@property (nonatomic, copy) NSString *rescode;

@property (nonatomic, copy) NSString *resmes;

@end

NS_ASSUME_NONNULL_END
