//
//  MGMFetchTicketOrderInfoResponse.h
//  MGMHttpApiModel
//
//  Created by 刘勇 on 2018/12/29.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMBaseModel.h"
#import "MGMFetchTicketOrderInfoItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMFetchTicketOrderInfoResponse : MGMBaseModel

@property (nonatomic, strong) NSArray<MGMFetchTicketOrderInfoItem *> *orders;

@end

NS_ASSUME_NONNULL_END
