//
//  MGMFetchShowOrderInfoItem.m
//  MGMTicketPay
//
//  Created by wdlzh on 2019/1/21.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFetchShowOrderInfoItem.h"

@implementation MGMFetchShowOrderInfoItem



@end
