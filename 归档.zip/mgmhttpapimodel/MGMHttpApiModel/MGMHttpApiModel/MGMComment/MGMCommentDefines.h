//
//  MGMCommentDefines.h
//  MGMFilmCollection
//
//  Created by RenYi on 2019/5/24.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#ifndef MGMCommentDefines_h
#define MGMCommentDefines_h

typedef NS_ENUM(NSUInteger, MGMForumType)
{
    MGMForumTypeInvalid,
    MGMForumTypeFilmDetail = 1, //内容（影片详情页长评、短评）
    MGMForumTypeMainComment = 2,    //评论(若是评论的父评论contentType传2)
    MGMForumTypeFilm = 3,       //电影
    MGMForumTypeActivity = 5,   //活动
    MGMForumTypeSubject = 6,    //专题
    MGMForumTypeColumn = 7,     //7栏目(旧数据导入)
    MGMForumTypeShow = 8,       //演出票
    MGMForumTypeActor = 9,      //影人
    MGMForumTypeTopic = 10,     //话题(对白, ugc)
    MGMForumTypeNews = 11,      //咨询
    MGMForumTypeList = 12,      //榜单（影单、专题）
    MGMForumTypeVideo = 13,     //预告片（小视频）
    MGMForumTypeDating = 20,    //约影
    MGMForumTypeClientTopic = 30,   //用户端话题
    MGMForumTypeWorldCup = 40,  //世界杯
    MGMForumTypeFilmCollection = 41,  //影单
    MGMForumTypeLiveWidget = 50, //直播挂件
    
    MGMForumTypeMax
};

typedef NS_ENUM(NSUInteger, MGMCommentType)
{
    MGMCommentTypeWord = 0, //文字评论
    MGMCommentTypePic = 1   //图片评论
};


typedef NS_ENUM(NSUInteger, MGMCommentPreviewStatus)
{
    MGMCommentPreviewStatusInvalid = 0,
    MGMCommentPreviewStatusPass = 1,    //审核通过
    MGMCommentPreviewStatusReject = 2,  //审核不通过
    MGMCommentPreviewStatusUserDelete = 3,  //用户删除
    MGMCommentPreviewStatusMainDeleted = 4, //父评论删除
    MGMCommentPreviewStatusOperateDelete = 5,   //运营删除
    MGMCommentPreviewStatusFirstPass = 11,    //一审通过
    MGMCommentPreviewStatusSecondReject = 20,   //二审不通过
    MGMCommentPreviewStatusSecondPass = 21,   //二审通过
    MGMCommentPreviewStatusThirdReject = 30,   //三审不通过
    MGMCommentPreviewStatusThirdPass = 31   //三审通过
};

typedef NS_ENUM(NSUInteger, MGMCommentClientType)
{
    MGMCommentClientTypeInvalid = 0,
    MGMCommentClientTypeMiguVideoClient = 1,  //咪咕视频客户端
    MGMCommentClientTypeMiguMovie = 2,  //咪咕影院客户端
    MGMCommentClientTypePeaceWorld = 3, //和世界www
    MGMCommentClientTypeMiguVideoWap = 4,   //咪咕视频wap
    MGMCommentClientTypeMiguLive = 5,   //咪咕直播
    MGMCommentClientTypeH5 = 6,         //h5
    MGMCommentClientTypeMiguCartoon = 7,    //咪咕动漫
    
    MGMCommentClientTypeMax
    
};

typedef NS_ENUM(NSUInteger, MGMCommentAuthorType)
{
    MGMCommentAuthorTypeUser = 0,   //用户
    MGMCommentAuthorTypeCustomerService = 1,     //客服
    
    MGMCommentAuthorTypeInvalid = INT_MAX
};


//1: 父评论(一级) 2: 子评论 3: G客 4: (对该视频点赞),专题，新闻资讯等都合并到此类型

/**
 点赞和取消点赞类型(type)

 - MGMLikeMainCommentType: 主评论点赞相关
 - MGMLikeSubCommentType: 子评论点赞相关
 - MGMLikeGKeType: G客 点赞相关
 - MGMLikeOtherType: (对该视频点赞),专题，新闻资讯等都合并到此类型
 */
typedef NS_ENUM(NSInteger, MGMLikeType)
{
    MGMLikeMainCommentType = 1,
    MGMLikeSubCommentType = 2,
    MGMLikeGKeType = 3,
    MGMLikeOtherType = 4,
    MGMLikeInvalidType = NSIntegerMax
};

#endif /* MGMCommentDefines_h */
