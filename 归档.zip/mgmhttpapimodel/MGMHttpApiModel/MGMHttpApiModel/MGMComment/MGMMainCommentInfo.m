//
//  MGMMainCommentInfo.m
//  MGMFilmCollection
//
//  Created by RenYi on 2019/5/24.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMMainCommentInfo.h"
#import <MGMCategories/NSDate+MGMConversion.h>
#import <MGMCategories/NSDictionary+MGMDictionaryExtension.h>
#import <MGUCategoryUtil/MGUCategoryUtil.h>

@implementation MGMSubCommentSimpleInfo

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"userAvatar" : @"userPortrait",
             @"contentWord" : @"childNodeUserCommentBody",
             @"previewStatus" : @"status"};
}

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    NSInteger previewStatus = [[dic stringForKey:@"status"] integerValue];
    switch (previewStatus) {
        case 0:self.previewStatus = MGMCommentPreviewStatusInvalid;break;
        case 1:self.previewStatus = MGMCommentPreviewStatusPass;break;
        case 2:self.previewStatus = MGMCommentPreviewStatusReject;break;
        case 3:self.previewStatus = MGMCommentPreviewStatusUserDelete;break;
        case 4:self.previewStatus = MGMCommentPreviewStatusMainDeleted;break;
        case 5:self.previewStatus = MGMCommentPreviewStatusOperateDelete;break;
        case 11:self.previewStatus = MGMCommentPreviewStatusFirstPass;break;
        case 20:self.previewStatus = MGMCommentPreviewStatusSecondReject;break;
        case 21:self.previewStatus = MGMCommentPreviewStatusSecondPass;break;
        case 30:self.previewStatus = MGMCommentPreviewStatusThirdReject;break;
        case 31:self.previewStatus = MGMCommentPreviewStatusThirdPass;break;
        default:
            self.previewStatus = MGMCommentPreviewStatusInvalid;
            break;
    }
    return YES;
}

@end


@implementation MGMMainCommentInfo

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"userAvatar" : @"userPortrait",
             @"userMobile" : @"mobile",
             @"commentWord" : @"body",
             @"commentPicture" : @"pictureURL",
             @"commentType" : @"pictureType",
             @"forumType" : @"contentType",
             @"previewStatus" : @"status",
             @"authorCommentType" : @"commentType",
             @"subCommentCount" : @"commentedCount",
             @"subComments" : @"childCommentInfo"
             };
}

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"subComments" : [MGMSubCommentSimpleInfo class]};
}


- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    
    [self commentTypeWithValue:dic];
    self.forumType = [self forumTypeWithvalue:dic];
    self.previewStatus = [self previewStatusWithvalue:dic];
    self.clientType = [self clientTypeWithvalue:dic];
    [self authorCommentTypeWithvalue:dic];

//    self.createTime = [self getDateFrom:[dic stringForKey:@"createTime"]];
    self.createTime = [dic stringForKey:@"createTime"];
    self.updateTime = [self getDateFrom:[dic stringForKey:@"updateTime"]];
    
    NSArray *tags = [dic mgu_objectOrNilForKey:@"certificationTags"];
    NSDictionary *tagDict = tags.firstObject;
    if (tagDict)
    {
        NSMutableArray *cerTypeM = [NSMutableArray array];
        NSArray *keys = tagDict.allKeys;
        for (NSString *aKey in keys) {
            
            NSString *value = [tagDict objectForKey:aKey];
            if ((value.length > 0) &&
                (![value isEqualToString:@"null"]) &&
                (![value isEqualToString:@"Null"]) &&
                (![value isEqualToString:@"NULL"]))
            {
                [cerTypeM addObject:aKey];
            }
        }
        self.certificationTypes = cerTypeM;
    }
    return YES;
}

- (NSString *)getDateFrom:(NSString *) value {

    if (value)
    {
        NSTimeInterval createTime = [value doubleValue];
        NSDate *createDate = [NSDate dateWithTimeIntervalSince1970:createTime / 1000];
        return [NSDate mgm_stringFromDate:createDate format:@"yyyy-MM-dd HH:mm:ss"];
    }
    return nil;
}

- (void)commentTypeWithValue:(NSDictionary *) dic {
    NSInteger commentType = [dic integerValueForKey:@"pictureType"];
    if (commentType == 0) {
        self.commentType = MGMCommentTypeWord;
    } else {
        self.commentType = MGMCommentTypePic;
    }
}


- (MGMForumType)forumTypeWithvalue:(NSDictionary *) dic {
    NSInteger forumType = [dic integerValueForKey:@"contentType"];
    switch (forumType) {
        case 0:return MGMForumTypeInvalid;break;
        case 1:return MGMForumTypeFilmDetail;break;
        case 2:return MGMForumTypeMainComment;break;
        case 3:return MGMForumTypeFilm;break;
        case 5:return MGMForumTypeActivity;break;
        case 6:return MGMForumTypeSubject;break;
        case 7:return MGMForumTypeColumn;break;
        case 8:return MGMForumTypeShow;break;
        case 9:return MGMForumTypeActor;break;
        case 10:return MGMForumTypeTopic;break;
        case 11:return MGMForumTypeNews;break;
        case 12:return MGMForumTypeList;break;
        case 13:return MGMForumTypeVideo;break;
        case 20:return MGMForumTypeDating;break;
        case 31:return MGMForumTypeClientTopic;break;
        case 40:return MGMForumTypeWorldCup;break;
        case 41:return MGMForumTypeFilmCollection;break;
        case 50:return MGMForumTypeLiveWidget;break;
        default:
            return MGMForumTypeInvalid;
    }
}

- (MGMCommentPreviewStatus)previewStatusWithvalue:(NSDictionary *) dic {
    NSInteger previewStatus = [dic integerValueForKey:@"status"];
    switch (previewStatus) {
        case 0:return MGMCommentPreviewStatusInvalid;break;
        case 1:return MGMCommentPreviewStatusPass;break;
        case 2:return MGMCommentPreviewStatusReject;break;
        case 3:return MGMCommentPreviewStatusUserDelete;break;
        case 4:return MGMCommentPreviewStatusMainDeleted;break;
        case 5:return MGMCommentPreviewStatusOperateDelete;break;
        case 11:return MGMCommentPreviewStatusFirstPass;break;
        case 20:return MGMCommentPreviewStatusSecondReject;break;
        case 21:return MGMCommentPreviewStatusSecondPass;break;
        case 30:return MGMCommentPreviewStatusThirdReject;break;
        case 31:return MGMCommentPreviewStatusThirdPass;break;
        default:
            return MGMCommentPreviewStatusInvalid;
    }
}

- (MGMCommentClientType)clientTypeWithvalue:(NSDictionary *) dic {
    NSInteger clientType = [dic integerValueForKey:@"clientType"];
    if (clientType == 0) {
        return MGMCommentClientTypeInvalid;
    } else if (clientType == 1) {
        return MGMCommentClientTypeMiguVideoClient;
    } else if (clientType == 2) {
        return MGMCommentClientTypeMiguMovie;
    } else if (clientType == 3) {
        return MGMCommentClientTypePeaceWorld;
    } else if (clientType == 4) {
        return MGMCommentClientTypeMiguVideoWap;
    } else if (clientType == 5) {
        return MGMCommentClientTypeMiguLive;
    } else {
        return MGMCommentClientTypeInvalid;
    }
}

- (void)authorCommentTypeWithvalue:(NSDictionary *) dic {
    NSInteger authorCommentType = [dic integerValueForKey:@"commentType"];
    if (authorCommentType == 0) {
        self.authorCommentType = MGMCommentAuthorTypeUser;
    } else if (authorCommentType == 1) {
        self.authorCommentType = MGMCommentAuthorTypeCustomerService;
    }
    else
    {
        self.authorCommentType = MGMCommentAuthorTypeInvalid;
    }
}



@end
