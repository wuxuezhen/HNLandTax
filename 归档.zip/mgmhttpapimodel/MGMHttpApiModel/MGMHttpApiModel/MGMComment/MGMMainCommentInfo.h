//
//  MGMMainCaommentInfo.h
//  MGMFilmCollection
//
//  Created by RenYi on 2019/5/24.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMCommentDefines.h"
#import <MGMDataModel/MGMDataObject.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMSubCommentSimpleInfo : MGMDataObject <MGMDataObject>

@property (nonatomic, copy)   NSString * userId;

@property (nonatomic, copy)   NSString * userName;

/**
 用户头像
 */
@property (nonatomic, copy)   NSString * userAvatar;

/**
 子节点id
 */
@property (nonatomic, copy)   NSString * childNodeId;

/**
 子节点评论内容
 */
@property (nonatomic, copy)   NSString * contentWord;

@property (nonatomic, assign) MGMCommentPreviewStatus  previewStatus;

@end

@interface MGMMainCommentInfo : MGMDataObject <MGMDataObject>

@property (nonatomic, copy)   NSString * commentId;
@property (nonatomic, copy)   NSString * userId;
@property (nonatomic, copy)   NSString * userName;

/**
 用户头像
 */
@property (nonatomic, copy)   NSString * userAvatar;

/**
    用户标识集合
*/
@property (nonatomic, copy) NSArray *certificationTypes;

@property (nonatomic, copy)   NSString * userMobile;

/**
 评论内容
 */
@property (nonatomic, copy)   NSString * commentWord;

/**
 评论中的图片url
 */
@property (nonatomic, copy)   NSString * commentPicture;

/**
 评论的类型
 */
@property (nonatomic, assign) MGMCommentType commentType;

/**
 节目ID
 */
@property (nonatomic, copy)   NSString * contentId;

/**
 节目内容
 */
@property (nonatomic, copy)   NSString * contentName;

/**
 评论的节目类型
 */
@property (nonatomic, assign) MGMForumType  forumType;

@property (nonatomic, assign) MGMCommentPreviewStatus  previewStatus;

/**
 客户端类型
 */
@property (nonatomic, assign) MGMCommentClientType  clientType;

/**
 评论发表者类型
 */
@property (nonatomic, assign) MGMCommentAuthorType authorCommentType;

@property (nonatomic, assign) BOOL  top;
@property (nonatomic, strong) NSString * topTime;

/**
 创建时间
 */
@property (nonatomic, strong) NSString * createTime;

/**
 修改时间
 */
@property (nonatomic, strong) NSDate * updateTime;

/**
 媒咨id
 */
@property (nonatomic, copy)   NSString * mId;

/**
 子评论数
 */
@property (nonatomic, assign) NSInteger  subCommentCount;

/**
 点赞数
 */
@property (nonatomic, assign) NSInteger  likeCount;

/**
 用户是否点赞
 */
@property (nonatomic, assign) BOOL  userHasLike;    

/**
 存放子评论的数组
 */
@property (nonatomic, strong) NSArray <MGMSubCommentSimpleInfo *> * subComments;
 
@end

NS_ASSUME_NONNULL_END
