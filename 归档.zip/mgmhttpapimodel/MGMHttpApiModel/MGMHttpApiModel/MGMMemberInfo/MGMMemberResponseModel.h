//
//  MGMMemberResponseModel.h
//  MGMMeModule
//
//  Created by MyMac on 2018/12/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString  *MGMUnionWanDaMember = @"WAN_DA";  //万达联合会员
static NSString  *MGMPlatinumWanDaMember = @"WAN_DA_BJ";  //万达铂金会员
static NSString  *MGMDiamondWanDaMember = @"WAN_DA_ZS";  //万达钻石会员

@interface MGMUserMemberInfoModel : NSObject

@property (nonatomic, copy) NSString *memberShipId;

/**
    咪咕万达联合会员卡编号
 */
@property (nonatomic, copy) NSString *memberId;

/**
  WAN_DA 联合会员  WAN_DA_BJ 铂金会员  WAN_DA_BJ 钻石会员
 */
@property (nonatomic, copy) NSString *memberCode;

@property (nonatomic, copy) NSString *memberName;

/**
    用户标识
 */
@property (nonatomic, copy) NSString *userId;

/**
    用户姓名
 */
@property (nonatomic, copy) NSString *userName;

/**
    0:三方订购，1：话费订购
 */
@property (nonatomic, copy) NSString *summary;

/**
    用户电话号码
 */
@property (nonatomic, copy) NSString *phoneNumber;

/**
    会员状态0:启用，1:禁用，2:开通中
 */
@property (nonatomic, copy) NSString *status;

/**
    注册日期 格式yyyy-MM-dd
 */
@property (nonatomic, copy) NSString *registerDate;

/**
    生效日期 格式yyyy-MM-dd
 */
@property (nonatomic, copy) NSString *activateTime;

/**
    有效期至 格式yyyy-MM-dd
 */
@property (nonatomic, copy) NSString *expiredTime;

//会员卡类型：0：月卡，1：季卡，2：年卡
@property (nonatomic, copy) NSString *goodsType;

@end

@interface MGMMemberResponseModel : NSObject

@property (nonatomic, copy) NSString *bizCode;

@property (nonatomic, copy) NSString *bizMsg;

@property (nonatomic, copy) NSArray *userMemberInfo;

@end
