//
//  MGMMemberResponseModel.m
//  MGMMeModule
//
//  Created by MyMac on 2018/12/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMMemberResponseModel.h"

@implementation MGMUserMemberInfoModel

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"memberShipId"  : @"id"};
}

@end

@implementation MGMMemberResponseModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass
{
    return @{@"userMemberInfo" : [MGMUserMemberInfoModel class]};
}


@end
