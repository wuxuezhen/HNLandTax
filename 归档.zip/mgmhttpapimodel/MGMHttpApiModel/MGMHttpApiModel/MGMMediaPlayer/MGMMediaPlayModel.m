//
//  MGMMediaPlayModel.m
//  MGMPlayerModule
//
//  Created by YL on 2018/12/5.
//  Copyright © 2018 MIGU VIDEO CO.,LTD. All rights reserved.
//

#import "MGMMediaPlayModel.h"
#import <MGUKeyValueStore/MGUKeyValueStore.h>

@implementation MGMMediaPlayModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"urlInfo" : [UrlInfo class],
             @"content" : [Content class],
             @"playBill" : [MGMPlayBill class],
             @"auth" : [Auth class],
             @"mediaFiles" : [MediaFiles class],
             @"urlInfos" : [UrlInfo class],
             };
}

- (void)mgm_processMovieUrlType {
    self.isIntactMedia = (self.urlInfo.urlType.length > 0) && ![self.urlInfo.urlType isEqualToString:@"trial"];
}

- (BOOL)downloadSuccess {
    NSString *downloadKey = self.content.contId;
    MGMMediaPlayModel *localModel =  [[MGUKeyValueStore defaultStore] getObjectForKey:downloadKey];
    return (localModel.downloadMediaPath.length > 0 && [localModel.downloadMediaPath hasSuffix:@"mp4"]);
}

@end

@implementation Content
    
+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"mgm_copyRightObjectID":@"copyRightObjectID" };
}
    
@end

@implementation Auth

@end

@implementation UrlInfo

- (NSString *)formatQualityStr {
    switch (self.rateType) {
        case MGMPlayQualityLow: return @"标清";
        case MGMPlayQualityNormal : return @"高清";
        case MGMPlayQualityHigh: return @"720P";
        case MGMPlayQualityMaxHigh: return @"1080P";
        case MGMPlayQuality2KHigh: return @"2K";
        case MGMPlayQuality4KHigh: return @"4K";
        
    }
    return @"1080P";
}

@end

@implementation MediaFiles

@end

@implementation MGMPlayBill

@end

@implementation MGMMovieDetailModel

@end
