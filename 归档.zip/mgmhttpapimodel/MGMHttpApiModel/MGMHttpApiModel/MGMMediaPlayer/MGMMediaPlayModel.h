//
//  MGMMediaPlayModel.h
//  MGMPlayerModule
//
//  Created by YL on 2018/12/5.
//  Copyright © 2018 MIGU VIDEO CO.,LTD. All rights reserved.
//

//播放媒体信息
#import <Foundation/Foundation.h>

#define  MGMWeakVersionCode    @"1000948"

typedef NS_ENUM(NSUInteger, MGMPlayQuality) {
    MGMPlayQualityLow = 1,  //标清
    MGMPlayQualityNormal,   //高清
    MGMPlayQualityHigh,    //720P
    MGMPlayQualityMaxHigh, //1080P
    MGMPlayQuality2KHigh,   //2K
    MGMPlayQuality4KHigh,   //4K
};

typedef NS_ENUM(NSUInteger, MGMPlayErrorCode) {
    MGMPlayErrorCodeParamInvalid = 410,  //参数错误
    MGMPlayErrorCodeOffLine = 400,   //节目已下线
    MGMPlayErrorCodeCPLimit = 401,   //版权限制，不能提供播放地址
    MGMPlayErrorCodeNoFounded = 404, //节目无可用的媒体文件
    MGMPlayErrorCodeNoLogin = 409,//登录限制，该节目需要登录后才能播放
    MGMPlayErrorCodeOnlyMobile = 411 ,//特定用户才能访问，如只有移动用户才能播放
    MGMPlayErrorCodeNoMember = 412 ,//需会员权益才能播放，提示开通会员
    MGMPlayErrorCodeLowVersion = 413, //当前版本不支持此节目播放，请更新新版本
};

typedef NS_ENUM(NSUInteger, MGMDownloadState) {
    MGMDownloadWait=1,
    MGMDownloading,
    MGMDownloadPaused,
    MGMDownloadFailed,
    MGMDownloadFinished,
};


NS_ASSUME_NONNULL_BEGIN

@class UrlInfo,Content,MediaFiles,Auth,MGMPlayBill,MGMMovieDetailModel;

@interface MGMMediaPlayModel : NSObject

@property (nonatomic, assign) MGMPlayErrorCode   errorCode;

@property (nonatomic, strong) UrlInfo  *urlInfo;

@property (nonatomic, strong) Content  *content;

@property (nonatomic, strong) MGMPlayBill  *playBill;

@property (nonatomic, strong) Auth      *auth;

@property (nonatomic, copy) NSArray<MediaFiles*> *mediaFiles;

@property (nonatomic, copy) NSArray<UrlInfo*> *urlInfos;

/****************************自定义字段*********************************/
@property (nonatomic, copy) NSArray<UrlInfo*> *downloadUrlInfos;
//是否是完整视频，免费或者已购买过
@property (nonatomic, assign) BOOL               isIntactMedia;

@property (nonatomic, strong) MGMMovieDetailModel *moviceDetailModel;
//将要切换的分辨率
@property (nonatomic, strong) UrlInfo             *changeQualityInfo;
//是否选中
@property (nonatomic, assign) BOOL                 isSelected;
//播放开始时间
@property (nonatomic, assign) NSTimeInterval       seekStartTime;

@property (nonatomic, strong) UrlInfo              *downloadUrlInfo; //下载信息
@property (nonatomic, assign) NSTimeInterval        downloadTime;  //下载视频时间,起始时间
@property (nonatomic, assign) float                 downloadProgress;  //下载进度
@property (nonatomic, assign) MGMDownloadState      downloadState;  //下载状态
@property (nonatomic, assign) float                 downloadSpeed;  //下载速度

@property (nonatomic, copy)  NSString               *downloadSession;  //节目id+下载时间戳 MD5加密，32位字符串。
@property (nonatomic, copy)  NSString                *downloadErrorMsg; //下载失败描述信息
@property (nonatomic, assign) BOOL                  pauseByCellularNetwork; //网络切换4G暂停

//兼容老版本字段，覆盖安装情况
@property (nonatomic, copy)  NSString              *downloadMediaPath;   //本地缓存地址
@property (nonatomic, assign) BOOL                 downloadSuccess;


//判断movie是否是试播
- (void)mgm_processMovieUrlType;

@end

//节目信息
@interface  Content: NSObject
//节目ID
@property (nonatomic, copy)  NSString *contId;
//节目名称
@property (nonatomic, copy)  NSString *contName;
//节目级别
@property (nonatomic, copy)  NSString *contentLevel;
//vid
@property (nonatomic, copy)  NSString *vid;
//产品ID
@property (nonatomic, copy)  NSString *productIds;
//时长 秒
@property (nonatomic, assign)NSTimeInterval duration;
//产品包ID
@property (nonatomic, copy)  NSString *prdPackageId;
//是否需要鉴权 true： 需要 false： 不需要（即免费节目）
@property (nonatomic, assign) BOOL    needAuth;
//打点-片头
@property (nonatomic, copy)  NSString *titleValue;
//打点-片尾
@property (nonatomic, copy)  NSString *endValue;
//版权对象编号，为100948 时，过滤正片介质，不播放
@property (nonatomic, copy)  NSString *mgm_copyRightObjectID;

@end

//直播界面单信息
@interface MGMPlayBill : NSObject
//开始时间
@property (nonatomic, assign) NSTimeInterval sTime;
//结束时间
@property (nonatomic, assign) NSTimeInterval eTime;
//节目单名称
@property (nonatomic, copy)  NSString *playName;

@end

//鉴权结果
@interface Auth : NSObject
//是否已登录
@property (nonatomic, assign) BOOL      logined;
//鉴权结果 SUCCESS： 成功 FAIL： 失败
@property (nonatomic, copy)  NSString  *authResult;
//会员类型 trial： 7天试用会员 diamond： 钻石会员 gold： 黄金会员
@property (nonatomic, copy)  NSString  *member;
//用户权益
@property (nonatomic, copy)  NSString  *benefites;

@end

//播放地址数据
@interface UrlInfo : NSObject

@property (nonatomic, copy)  NSString  *contId;
//normal： 正式地址 trial： 试播地址 tourist： 游客地址
@property (nonatomic, copy)  NSString  *urlType;
//是否需要穿衣戴帽
@property (nonatomic, assign) BOOL     needClothHat;
//单个码率的鉴权结果 200: 成功 403：无权试播 409：需登录 412：需会员
@property (nonatomic, copy)  NSString  *resultCode;
//播放地址
@property (nonatomic, copy)  NSString  *url;
//媒体文件字节大小
@property (nonatomic, assign) long    mediaSize;
//媒体文件类型
@property (nonatomic, copy)  NSString  *mediaType;
//码率描述
@property (nonatomic, copy)  NSString  *rateDesc;
//媒体文件编码
@property (nonatomic, copy)  NSString  *usageCode;
//媒体文件编码码率
@property (nonatomic, copy)  NSString  *codeRate;

@property (nonatomic, assign)MGMPlayQuality  rateType;
//清晰度的UI显示字符串
@property (nonatomic, copy)  NSString  *formatQualityStr;

//报错提示
@property (nonatomic, copy)  NSString  *desc;
//错误码
@property (nonatomic, copy)  NSString  *code;
//视频编码
@property (nonatomic, copy)  NSString  *videoCoding;

@end

//媒体文件列表
@interface MediaFiles : NSObject
//编码类别
@property (nonatomic, copy)  NSString  *usageCode;
//媒体文件类型
@property (nonatomic, copy)  NSString  *mediaType;

@property (nonatomic, copy)  NSString  *codeRate;

@property (nonatomic, copy)  NSString  *rateDesc;

@property (nonatomic, assign)MGMPlayQuality  rateType;
// 鉴权结果
@property (nonatomic, copy)  NSString  *authResult;
//文件大小
@property (nonatomic, copy)  NSString  *fileSize;
//是否需要鉴权
@property (nonatomic, assign) BOOL     needAuth;
//跳过片尾
@property (nonatomic, assign) int      endValue;
//跳过片头
@property (nonatomic, assign) int      titleValue;

@end

@interface MGMMovieDetailModel : NSObject
//影片名称
@property (nonatomic, copy)  NSString   *movieName;
//影片详情
@property (nonatomic, copy) NSString    *movieDetail;
//影片类型
@property (nonatomic, copy)  NSString   *movieType;
//影片图片
@property (nonatomic, copy)  NSString   *movieIconUrl;
//影片大图
@property (nonatomic, copy)  NSString   *movieBigIconUrl;
//分享链接
@property (nonatomic, copy)  NSString   *movieShareUrl;
//媒资ID
@property (nonatomic, copy) NSString    *mediaId;
//1-仅播放；2-仅下载；3-不限播放和下载
@property (nonatomic, assign) NSInteger  way;
//判断影片是否是全片 MOVIE代表全片
@property (nonatomic, assign) BOOL      isMOVIE;
//版权所属
@property (nonatomic, copy) NSString    *cpName;

@end

NS_ASSUME_NONNULL_END
