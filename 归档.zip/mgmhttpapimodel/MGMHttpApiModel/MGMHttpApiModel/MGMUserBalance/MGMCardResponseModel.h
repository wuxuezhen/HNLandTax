//
//  MGMCardResponseModel.h
//  MGMMeModule
//
//  Created by MyMac on 2018/12/25.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MGMCardModel;

@interface MGMCardResponseModel : NSObject

@property (nonatomic, copy) NSString *message;

@property (nonatomic, copy) NSArray <MGMCardModel *>*data;

@property (nonatomic, copy) NSString *resultCode;

@end
