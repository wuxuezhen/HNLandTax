//
//  MGMBalanceResponseModel.h
//  MGMMeModule
//
//  Created by MyMac on 2018/12/24.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MGMBalanceModel;

@interface MGMBalanceResponseModel : NSObject

@property (nonatomic, copy) NSString *bizMsg;

@property (nonatomic, copy) NSArray <MGMBalanceModel *>*balances;

@property (nonatomic, copy) NSString *extInfo;

@property (nonatomic, copy) NSString *bizCode;

@end
