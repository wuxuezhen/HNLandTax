//
//  MGMCardResponseModel.m
//  MGMMeModule
//
//  Created by MyMac on 2018/12/25.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCardResponseModel.h"
#import <YYModel/NSObject+YYModel.h>
#import "MGMCardModel.h"

@implementation MGMCardResponseModel

+ (NSDictionary *)modelContainerPropertyGenericClass
{
    return @{@"data" : [MGMCardModel class]};
}

@end
