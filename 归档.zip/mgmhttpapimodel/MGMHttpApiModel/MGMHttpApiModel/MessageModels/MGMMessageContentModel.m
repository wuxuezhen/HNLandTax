//
//  MGMMessageContentModel.m
//  MGMMeModule
//
//  Created by apple on 2018/12/25.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMMessageContentModel.h"
#import <YYModel/NSObject+YYModel.h>
#import "MGMLegoAction.h"

@implementation MGMMSGModel
- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    // 可以在这里处理一些数据逻辑，如NSDate格式的转换
    _urlV5_ = [MGMAction yy_modelWithJSON:dic[@"urlV5"]];
    _action_ = [MGMAction yy_modelWithJSON:dic[@"action"]];
    return YES;
}

//+ (nullable NSDictionary<NSString *, id> *)modelCustomPropertyMapper {
//    return @{
//             @"msg" : @[@"msg" ,@"sonMsg"],
//             };
//}



@end

@implementation MGMMessageContentModel

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic {
    // 可以在这里处理一些数据逻辑，如NSDate格式的转换
    _msg_ = [MGMMSGModel yy_modelWithJSON:dic[@"msg"]];
    return YES;
}
@end

@implementation MGMMessageContentBody
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"msgs" : [MGMMessageContentModel class] };
}
@end

