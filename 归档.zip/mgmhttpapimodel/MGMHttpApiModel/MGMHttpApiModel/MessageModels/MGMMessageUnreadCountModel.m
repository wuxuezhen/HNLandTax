//
//  MGMMessageUnreadCountModel.m
//  MGMMeModule
//
//  Created by apple on 2018/12/25.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMMessageUnreadCountModel.h"

@implementation MGMMessageUnreadCountBody

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"nums" : [MGMMessageUnreadCountModel class]};
}
@end

@implementation MGMMessageUnreadCountModel

@end
