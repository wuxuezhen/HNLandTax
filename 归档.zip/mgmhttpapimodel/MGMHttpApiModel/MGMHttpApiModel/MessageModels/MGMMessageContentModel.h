//
//  MGMMessageContentModel.h
//  MGMMeModule
//
//  Created by apple on 2018/12/25.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMLegoModel.h"
#import "MGMLegoAction.h"
NS_ASSUME_NONNULL_BEGIN

@class MGMMessageParam;

@interface MGMMSGModel : MGMBase

@property (nonatomic, strong) NSString * aStatus;
@property (nonatomic, strong) NSString * channelCode;
@property (nonatomic, assign) NSInteger createTime;
@property (nonatomic, strong) NSString * deadline;
@property (nonatomic, strong) NSString * id;
@property (nonatomic, strong) NSString * mainTitle;
@property (nonatomic, strong) NSString * name;
@property (nonatomic, assign) NSInteger publishTime;
@property (nonatomic, strong) NSString * status;
@property (nonatomic, strong) NSString * subTitle;
@property (nonatomic, assign) NSInteger updateTime;
@property (nonatomic, strong) NSString * url;
@property (nonatomic, strong) NSString * userTag;


@property (nonatomic, strong) NSString * assetID;
@property (nonatomic, strong) NSString * authorUid;
@property (nonatomic, strong) NSString * authorUname;
@property (nonatomic, strong) NSString * commentId;
//hasLike = false;  // true点赞, false取消点赞
@property (nonatomic, assign) BOOL hasLike;
@property (nonatomic, assign) NSInteger index;
@property (nonatomic, strong) NSString * msg;
@property (nonatomic, assign) NSInteger msgTimes;
@property (nonatomic, strong) NSString * originalAuthorUid;
@property (nonatomic, strong) NSString * originalAuthorUname;
@property (nonatomic, strong) NSString * pID;
@property (nonatomic, strong) NSString * pName;
@property (nonatomic, strong) NSString * parentId;
@property (nonatomic, strong) NSString * type;
@property (nonatomic, copy, readwrite) NSString *extension;


//@property (nonatomic, strong) MGMMessageAction *action;
@property (nonatomic, copy) NSString *commentHasPic;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, assign) BOOL hasVip;
@property (nonatomic, copy, readwrite) NSString *sonMsg;

@property (nonatomic, copy) NSString *parentUserId;
@property (nonatomic, copy) NSString *parentUserName;
@property (nonatomic, copy) NSString *parentBody;
@property (nonatomic, strong) NSArray <NSString *> *pictureUrl;
@property (nonatomic, copy) NSString *userOperationTime;
@property (nonatomic, copy) NSString *commentType;
@property (nonatomic, copy) NSString *commentContentType;
@property (nonatomic, copy) NSString *likeType;



// 通知是否可以跳转H5
@property (nonatomic, strong) NSString * idField;
@property (nonatomic, strong) NSString * urlV5;
@property (nonatomic, strong) MGMAction *urlV5_;
// 预留设置
@property (nonatomic, strong) NSString *action;
@property (nonatomic, strong) MGMAction *action_;

@end

@interface MGMMessageContentModel : MGMBase

@property (nonatomic, copy, readwrite) MGMMSGModel *msg_;
@property (nonatomic, copy, readwrite) NSString *msg;
@property (nonatomic, copy, readwrite) NSString *sonMsg;
@property (nonatomic, copy, readwrite) NSString *msgId;
@property (nonatomic, copy, readwrite) NSString *msgStatus;
@property (nonatomic, copy, readwrite) NSString *msgTimeMilis;

@end

@interface MGMMessageContentBody : MGMBase

@property (nonatomic, assign, readwrite) NSInteger index;
@property (nonatomic, strong, readwrite) NSArray <MGMMessageContentModel *> *msgs;
@property (nonatomic, copy, readwrite) NSString *resultCode;
@property (nonatomic, assign, readwrite) NSInteger size;

@end


NS_ASSUME_NONNULL_END
