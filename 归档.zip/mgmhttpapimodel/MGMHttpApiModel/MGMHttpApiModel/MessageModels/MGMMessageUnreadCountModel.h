//
//  MGMMessageUnreadCountModel.h
//  MGMMeModule
//
//  Created by apple on 2018/12/25.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMLegoModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MGMMessageUnreadCountModel : MGMBase

@property (nonatomic, assign, readwrite) NSInteger index;
@property (nonatomic, assign, readwrite) NSInteger num;

@end

@interface MGMMessageUnreadCountBody : MGMBase

@property (nonatomic, strong, readwrite) NSArray <MGMMessageUnreadCountModel *> *nums;
@property (nonatomic, copy, readwrite) NSString *resultCode;

@end

NS_ASSUME_NONNULL_END
