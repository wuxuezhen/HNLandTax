//
//  MGMHttpResponse.m
//  MGMHttpApiModel
//
//  Created by zhaohao on 2018/12/11.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMHttpResponse.h"

@implementation MGMHttpResponse

- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic
{
    id code = dic[@"code"];
    if ([code isKindOfClass:[NSString class]])
    {
        self.code = code;
    }
    else
    {
        self.code = [NSString stringWithFormat:@"%@", code];
    }
    
    return YES;
}


@end
