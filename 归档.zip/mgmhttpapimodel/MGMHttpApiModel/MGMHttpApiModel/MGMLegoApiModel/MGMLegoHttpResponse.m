//
//  MGMLegoHttpResponse.m
//  MGMHttpApi
//
//  Created by zhaohao on 2018/11/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoHttpResponse.h"
#import "MGMLegoPage.h"

@implementation MGMLegoHttpResponse

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"desc" : @"description",
             };
}

@end

@implementation MGMBody

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"desc" : @"description",
             };
}

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"groups" : [MGMGroup class],
             @"data" : [MGMData class],
             @"components" : [MGMComponent class],
             @"titleBar" : [MGMTitleBar class]
             };
}

@end
