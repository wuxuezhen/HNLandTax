//
//  MGMLegoPage.m
//  MGMHttpApi
//
//  Created by zhaohao on 2018/11/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoPage.h"
#import "MGMFrameInfo.h"
#import <YYModel/NSObject+YYModel.h>

@implementation MGMGroup

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"desc" : @"description",
             };
}

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"components" : [MGMComponent class],
             @"buttons" : [MGMLegoButton class],
             @"extraData":[MGMExtradata class],
             @"adInfo": [MGMAdinfo class]
             };
}

@end


@implementation MGMComponent

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"desc" : @"description",
             };
}

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{
             @"data" : [MGMData class],
             };
}

@end

@implementation MGMCompVersion


@end

@implementation MGMExtradata

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"desc" : @"description"};
}

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"menus" : [MGMMenu class],
             @"labels" : [MGMLabel class],
             @"buttons" : [MGMLegoButton class],
             @"matches" : [MGMMatches class],
             @"pics" : [MGMPic class],
             @"notices": [MGMNotices class],
             @"stations": [MGMStations class],
             @"memberInfos":[MGMMemberInfos class],
             @"memberInfo":[MGMMemberInfo class],
             @"eitherInfo":[MGMEitherInfo class],
             };
}

@end


@implementation MGMMenu

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"desc" : @"description",
             };
}

@end


@implementation MGMData

+ (instancetype)modelWithJsonString:(NSString *)jsonString
{
    NSData *jsonData = [jsonString dataUsingEncoding:(NSUTF8StringEncoding)];
    NSDictionary *params = [NSJSONSerialization JSONObjectWithData:jsonData
                                                           options:(NSJSONReadingAllowFragments)
                                                             error:nil];
    MGMAction *action = [MGMAction yy_modelWithDictionary:params];
    MGMData *data = [[self alloc] init];
    data.action = action;
    return data;
}

@end

@implementation MGMNotices

@end


@implementation MGMTip

@end


@implementation MGMPic

@end

@implementation MGMLabel

@end

@implementation MGMAdinfo
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{
             @"flowList": [MGMFlowList class],
             };
}

@end

@implementation MGMTeams

@end

@implementation MGMMatches

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"teams" : [MGMTeams class]};
}

@end

@implementation MGMSearchCondition

@end

@implementation MGMPlayTimes

@end

@implementation MGMStations

@end

@implementation MGMFlowList

@end

@implementation MGMMemberInfos

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"serviceInfo" : [MGMServiceInfo class],
             @"iosServiceInfo":[MGMServiceInfo class]
             };
}


@end

@implementation MGMMemberInfo

@end

@implementation MGMServiceInfo

@end

@implementation MGMTitleBar

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"bars" : [MGMBar class]};
}

@end

@implementation MGMBar

@end

@implementation MGMEitherInfo

@end
