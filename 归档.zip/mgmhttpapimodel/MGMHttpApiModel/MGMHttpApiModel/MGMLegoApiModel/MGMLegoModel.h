//
//  MGMLegoModel.h
//  MGMHttpApi
//
//  Created by zhaohao on 2018/11/30.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#if __has_include(<MGMHttpApiModel/MGMLegoModel.h>)

#import <MGMHttpApiModel/MGMLegoAction.h>
#import <MGMHttpApiModel/MGMLegoHttpResponse.h>
#import <MGMHttpApiModel/MGMLegoPage.h>
#import <MGMHttpApiModel/MGMFrameInfo.h>

#else

#import "MGMLegoAction.h"
#import "MGMLegoHttpResponse.h"
#import "MGMLegoPage.h"
#import "MGMFrameInfo.h"

#endif /* MGMLegoModel_h */
