//
//  MGMLegoAction.m
//  MGMHttpApi
//
//  Created by zhaohao on 2018/11/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLegoAction.h"
#import <YYModel/NSObject+YYModel.h>

@interface MGMBase() <YYModel, NSCopying, NSCoding>
@end

@implementation MGMBase
- (void)encodeWithCoder:(NSCoder *)aCoder { [self yy_modelEncodeWithCoder:aCoder]; }
- (id)initWithCoder:(NSCoder *)aDecoder { self = [super init]; return [self yy_modelInitWithCoder:aDecoder]; }
- (id)copyWithZone:(NSZone *)zone { return [self yy_modelCopy]; }
- (NSUInteger)hash { return [self yy_modelHash]; }
- (BOOL)isEqual:(id)object { return [self yy_modelIsEqual:object]; }
- (NSString *)description {return [self yy_modelDescription];}
@end

@implementation MGMAction

- (instancetype)init
{
    self = [super init];
    if (self) {
        _params = [MGMParams new];
        _params.extra = [MGMExtra new];
    }
    return self;
}

@end

@implementation MGMParams

@end

@implementation MGMExtra

@end
