//
//  MGMLegoHttpResponse.h
//  MGMHttpApi
//
//  Created by zhaohao on 2018/11/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class MGMBody,MGMGroup,MGMFrame,MGMMedia,MGMComponent,MGMData,MGMTitleBar;

@interface MGMLegoHttpResponse: NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) MGMBody *body;

@property (nonatomic, assign) long long timeStamp;

@end

@interface MGMBody: NSObject

@property (nonatomic, copy) NSString *id;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, strong) NSArray<MGMGroup *> *groups;

//@property (nonatomic, strong) NSArray<Frame *> *frames;

@property (nonatomic, strong) NSArray<MGMComponent *> *components;

@property (nonatomic, strong) NSArray<MGMData *> *data;

@property (nonatomic, copy) NSString *totalPage;

@property (nonatomic, copy) NSString *totalCount;

@property (nonatomic, copy) NSString *fitArea;

@property (nonatomic, copy) NSString *isEmbedPopupPage;

@property (nonatomic, assign) BOOL isShared;

@property (nonatomic, copy) NSString *shareMainTitle;

@property (nonatomic, copy) NSString *shareSubTitle;

@property (nonatomic, copy) NSString *shareUrl;

@property (nonatomic, copy) NSString *shareIcon;

@property (nonatomic, copy) NSDictionary *result;

@property (nonatomic, strong) MGMTitleBar *titleBar;

@property (nonatomic, strong) NSDictionary *filterCondition;

@end

@interface MGMBody () // down/downurl

@property (nonatomic, strong) NSString * code;
@property (nonatomic, strong) NSString * codeRate;
@property (nonatomic, strong) NSString * contId;
//@property (nonatomic, strong) NSString * desc;
@property (nonatomic, assign) long long mediaSize;
@property (nonatomic, strong) NSString * mediaType;
@property (nonatomic, strong) NSObject * rateDesc;
@property (nonatomic, strong) NSString * url;
@property (nonatomic, strong) NSObject * urlType;
@property (nonatomic, strong) NSString * usageCode;

@end

NS_ASSUME_NONNULL_END
