//
//  MGMLegoAction.h
//  MGMHttpApi
//
//  Created by zhaohao on 2018/11/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class MGMParams,MGMExtra,MGMComponent;

@interface MGMBase: NSObject
@end

@interface MGMAction: MGMBase

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) MGMParams *params;

@property (nonatomic, copy) NSString *index;

@property (nonatomic, copy) NSString *timeStamp;

@end

@interface MGMParams: MGMBase

@property (nonatomic, copy) NSString *path;

@property (nonatomic, copy) NSString *contentID;

@property (nonatomic, copy) NSString *frameID;

@property (nonatomic, copy) NSString *pageID;

@property (nonatomic, copy) NSString *groupId;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *imgUrl;

@property (nonatomic, copy) NSString *location;

@property (nonatomic, strong) MGMExtra *extra;

@property (nonatomic, assign) long currentProgress;

@property (nonatomic, copy) NSString *index;

@property (nonatomic, strong) NSArray<NSString *> *fitArea;

@property (nonatomic, copy) NSString *assetShellID; //媒资壳ID

@end

@interface MGMExtra: MGMBase

/**
    分享图片地址(JS传值)
 */
@property (nonatomic, copy) NSString *descImg;

/**
    分享内容(JS传值)
 */
@property (nonatomic, copy) NSString *descContent;

@property (nonatomic, copy) NSString *imgUrl;

@property (nonatomic, copy) NSString *contentId;

@property (nonatomic, copy) NSString *shareSubTitle;

@property (nonatomic, copy) NSString *shareUrl;

@property (nonatomic, copy) NSString *contentType;

@property (nonatomic, copy) NSString *shareTitle;

@property (nonatomic, assign) BOOL isRedrain;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *detail;

@property (nonatomic, copy) NSString *subtitle;

@property (nonatomic, copy) NSString *pageTitle;

@property (nonatomic, copy) NSString *goodsType;

@property (nonatomic, copy) NSString *goodsId;

@property (nonatomic, copy) NSString *mediaYear;

@property (nonatomic, copy) NSString *mediaType;

@property (nonatomic, copy) NSString *mediaArea;

@property (nonatomic, copy) NSString *mgdbID;

@property (nonatomic, copy) NSString *playerId;

@property (nonatomic, copy) NSString *playerName;

@property (nonatomic, copy) NSString *teamId;

@property (nonatomic, copy) NSString *teamName;

@property (nonatomic, assign) BOOL isCast; // 自动投屏

@property (nonatomic, assign) BOOL isH5Page; // 自动投屏

@property (nonatomic, assign) BOOL isRemote; // 自动进入遥控器

@property (nonatomic, copy) NSString *competitionID; // 赛程筛选ID

@property (nonatomic, copy) NSString *topic;    //话题

@property (nonatomic, copy) NSString *area;     //赛区

@property (nonatomic, copy) NSString *station;  //站点

@property (nonatomic, copy) NSString *jid;

@property (nonatomic, assign) NSInteger gktype; //0是原来G客上传页面，1是G客大赛上传页面

@property (nonatomic, copy) NSString *eventId;
@property (nonatomic, assign) NSInteger xAxis; //G客封面宽比例值
@property (nonatomic, assign) NSInteger yAxis; //G客封面高比例值
@property (nonatomic, copy) NSString *minCoverWidth;//G客封面最小宽度
@property (nonatomic, copy) NSString *maxCoverWidth;//G客封面最大宽度
@property (nonatomic, copy) NSString *returnUrl;
@property (nonatomic, copy) NSString *index;

@property (nonatomic, copy) NSString *channelID;
@property (nonatomic, copy) NSString *pageName;
@property (nonatomic, copy) NSString *positionName;
@property (nonatomic, copy) NSString *targetPageName;

@property (nonatomic, copy) NSString *refProgramID; // 详情跳转详情时增加当前播放详情页的节目id

@property (nonatomic, copy) NSString *starID; //明星ID
@property (nonatomic, copy) NSString *name; //明星名字
@property (nonatomic, copy) NSString *fitArea;
@property (nonatomic, copy) NSString *miguToken;
@property (nonatomic, copy) NSString *status;      //挂件预览状态 P:预约 L:直播 R:回看

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *reason;

@property (nonatomic, copy) NSString *pID;
@property (nonatomic, copy) NSString *pName;
@property (nonatomic, copy) NSString *userid;
@property (nonatomic, copy) NSString *UDID;

@property (nonatomic, copy) NSString *originalActionType;

// 影院 extra
@property (nonatomic, copy) NSString *filmId;
@property (nonatomic, copy) NSString *belongToName;
@property (nonatomic, copy) NSString *isPlayable;  //影片是否可播放  1：可以播放   0不可播放
@property (nonatomic, copy) NSString *topicTagName;//话题标签详情页
@property (nonatomic, assign) BOOL isNeedLogin; // 跳转前是否弹出登录界面
@property (nonatomic, copy) NSString *filmEngagementId;


//我的消息
@property (nonatomic, copy) NSString *contentID; // 节目id
@property (nonatomic, copy) NSString *mID; //媒资id
@property (nonatomic, copy) NSString *commentID;//子评论id
@property (nonatomic, copy) NSString *parentCommentID;//父评论id

//排片页
@property (nonatomic, copy) NSString *cinemaID;
@property (nonatomic, copy) NSString *cinemaAdd;
@property (nonatomic, copy) NSString *cinemaName;
@property (nonatomic, copy) NSString *cinemaCompany;
@property (nonatomic, copy) NSString *cityID;
@property (nonatomic, copy) NSString *position;
@property (nonatomic, copy) NSString *cinemaTel;
@property (nonatomic, copy) NSString *allowCard;

//  约票
@property (nonatomic, copy) NSString *cinema;
@property (nonatomic, copy) NSString *dateTime;
@property (nonatomic, assign) BOOL isFilmEngagement;
@property (nonatomic, copy) NSString *movieName;

@end

NS_ASSUME_NONNULL_END
