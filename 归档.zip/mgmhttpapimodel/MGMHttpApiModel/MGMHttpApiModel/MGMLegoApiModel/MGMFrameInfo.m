//
//  MGMFrameInfo.m
//  MGMHttpApi
//
//  Created by zhaohao on 2018/11/27.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMFrameInfo.h"

@implementation MGMInitInfo

@end

@implementation MGMFrame

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"topBars" : [MGMTopbar class]};
}

@end


@implementation MGMBottombar

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"buttons" : [MGMLegoButton class]};
}

@end


@implementation MGMLegoButton

@end


@implementation MGMTopbar

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"buttons" : [MGMLegoButton class]};
}

@end


@implementation MGMLogo

@end
