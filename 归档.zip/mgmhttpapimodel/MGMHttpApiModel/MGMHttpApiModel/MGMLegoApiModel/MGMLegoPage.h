//
//  MGMLegoPage.h
//  MGMHttpApi
//
//  Created by zhaohao on 2018/11/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN

@class MGMGroup,MGMComponent,MGMExtradata,MGMMenu,MGMData,MGMTip,MGMPic,MGMLabel,MGMLegoButton,MGMAdinfo,MGMMatches,MGMSearchCondition,MGMNotices,MGMStations,MGMFlowList,MGMServiceInfo,MGMMemberInfos,MGMMemberInfo,MGMBar,MGMEitherInfo,MGMCompVersion;

@interface MGMGroup: NSObject

@property (nonatomic, strong) MGMComponent *headerComp;

@property (nonatomic, strong) NSArray<MGMComponent *> *components;

@property (nonatomic, copy) NSString *id;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, strong) NSArray<NSString *> *fitArea;
@property (nonatomic, strong) NSArray<NSString *> *fitProgramType;

@property (nonatomic, copy) NSString *isSegmentLine; // 分割线

@property (nonatomic, strong) MGMExtradata *extraData;

@property (nonatomic, strong) MGMAdinfo *adInfo;

@end

@interface MGMComponent: MGMBase

@property (nonatomic, strong) MGMAction *action;

@property (nonatomic, copy) NSString *id;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *dataCount;

@property (nonatomic, strong) MGMExtradata *extraData;

@property (nonatomic, copy) NSString *status;

@property (nonatomic, copy) NSString *fetchDataType;

@property (nonatomic, strong) MGMSearchCondition *searchCondition;

@property (nonatomic, copy) NSString *dataSource;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *compType;

@property (nonatomic, copy) NSString *isWaterfallFlow;

@property (nonatomic, copy) NSString *sortValue;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString *vomsNodeID;

@property (nonatomic, copy) NSString *isDisplay;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *compStyle;

@property (nonatomic, copy) NSString *location;

@property (nonatomic, strong) NSArray<NSString *> *fitArea;

@property (nonatomic, strong) NSArray<NSString *> *fitProgramType;

@property (nonatomic, copy) NSString *totalCount;

@property (nonatomic, strong) NSArray<MGMData *> *data;

@property (nonatomic, copy) NSString *totalPage;

@property (nonatomic, copy) NSString *displayCount;

@property (nonatomic, copy) NSString *isContainAD;

@property (nonatomic, strong) MGMAdinfo *adInfo;

@property (nonatomic, copy) NSString *score;

@property (nonatomic, copy) NSString *contentStyle;

@property (nonatomic, copy) NSString *playTimes;

@property (nonatomic, copy) NSString *focusStatus;

@property (nonatomic, copy) NSArray<NSString *> *userType;    //会员标识

@property (nonatomic, weak) UIView *tempView;

@property (nonatomic, assign)CGPoint downPoint;

@property (nonatomic, strong) MGMCompVersion *iosVersion;

@end

@interface MGMCompVersion : MGMBase

@property (nonatomic, copy) NSString *min;
@property (nonatomic, copy) NSString *max;
@property (nonatomic, assign) BOOL isAllVersion;
@property (nonatomic, strong) NSArray <NSString *> *exclude;

@end

@interface MGMExtradata: MGMBase

@property (nonatomic, strong) NSArray<MGMMenu *> *menus;

@property (nonatomic, strong) NSArray<MGMLabel *> *labels;

@property (nonatomic, strong) NSArray<MGMLegoButton *> *buttons;

@property (nonatomic, strong) NSArray<MGMNotices *> *notices;

@property (nonatomic, strong) NSArray<MGMStations *> *stations;

@property (nonatomic, copy) NSString *backgroundColor;

@property (nonatomic, copy) NSString *backgroundImg;

@property (nonatomic, strong) NSArray<NSString *> *mediaArea;

@property (nonatomic, strong) NSArray<NSString *> *mediaYear;

@property (nonatomic, strong) NSArray<NSString *> *mediaType;

@property (nonatomic, copy) NSString *actionId;

@property (nonatomic, strong) MGMAction *action;

@property (nonatomic, strong) NSArray<MGMMatches *> *matches;

@property (nonatomic, strong) MGMPic *pics;

@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *displayText;

@property (nonatomic, copy) NSString *displayDesc;

@property (nonatomic, copy) NSString *displayImg;

@property (nonatomic, copy) NSString *displayColor;

@property (nonatomic, strong) NSArray<MGMMemberInfos *> *memberInfos;

@property (nonatomic, strong) NSArray<MGMMemberInfo *> *memberInfo;

@property (nonatomic, copy) NSString *slideTime;

@property (nonatomic, assign) BOOL isNeedLogin;

@property (nonatomic, copy) NSString *Addyuepiao;

@property (nonatomic, copy) NSString *more_yuepiao;

@property (nonatomic, assign) BOOL autoPlay;

@property (nonatomic, assign) BOOL isFullPage;

@property (nonatomic, copy) NSString *position;

@property (nonatomic, copy) NSString *pageURL;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString *mute;

@property (nonatomic, copy) NSString *replay;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *channel;

@property (nonatomic, copy) NSString *privacy; //on 展示

@property (nonatomic, copy) NSString *VersionCode_IOS; //IOS 版本号
@property (nonatomic, copy) NSString *viptype;  //万达会员VIP类型   PLATINUM_WANDA:铂金 DIAMOND_WANDA 钻石

@property (nonatomic, copy) NSString *Validity; //有效期，针对万达会员卡   month 月卡 season季卡  year 年卡  ali_month 支付宝包月 mobie_month 话费包月 mobie_season 话费季卡

@property (nonatomic, copy) NSArray <MGMEitherInfo *> *eitherInfo;  //万达会员权益信息

// 影院添加
@property (nonatomic, copy) NSArray <NSString *> *tujiResolutions;

@property (nonatomic, copy) NSString *isPlayable;
//会员卡详情 会员卡特权 关于判断乐高配置右边按钮显示字段 为空按钮不显示 , 为"videoticket"时按钮为"领取" , 为"buyticket"时按钮为例如"9.9元购"
@property (nonatomic, copy) NSString *type;
//会员卡详情 为"buyticket"时按钮为例如"9.9元购" goodsId
@property (nonatomic, copy) NSString *goodsId;
//批价到的价格
@property (nonatomic, assign) NSInteger goodsPrice;

//签到
@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *starttime;

@property (nonatomic, copy) NSString *endime;

@property (nonatomic, copy) NSString *mission_Day;

@property (nonatomic, copy) NSString *reward;

@property (nonatomic, copy) NSString *goodsID;

@property (nonatomic, copy) NSString *resourceId;

@property (nonatomic, copy) NSString *goodstype;

@property (nonatomic, copy) NSString *lotteryID;

@property (nonatomic, copy) NSString *lotterykey;

@property (nonatomic, copy) NSString *background;

@property (nonatomic, copy) NSString *button;

@property (nonatomic, copy) NSString *card;

//k11展会
@property (nonatomic, copy) NSString *checkaddress;
/**
 用户详情跳转Action
 */
@property (nonatomic, copy) MGMAction *userAction;

/**
 电影跳转Action
 */
@property (nonatomic, copy) MGMAction *movieAction;


@end


@interface MGMNotices: MGMBase

@property (nonatomic, strong) MGMAction *action;

@property (nonatomic, copy) NSString *actionId;

@property (nonatomic, copy) NSString *activatedTextColor;

@property (nonatomic, copy) NSString *defaultTextColor;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString *id;

@property (nonatomic, copy) NSString *title;

@end

@interface MGMMenu: MGMBase

@property (nonatomic, strong) MGMAction *action;

@property (nonatomic, copy) NSString *displayColor;

@property (nonatomic, copy) NSString *displayText;

@property (nonatomic, copy) NSString *defaultTextColor;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *actionId;

@property (nonatomic, copy) NSString *activatedTextColor;

@end

@interface MGMData: MGMBase

@property (nonatomic, copy) NSString *detail;

@property (nonatomic, copy) NSString *updateEP;

@property (nonatomic, copy) NSString *pID;

@property (nonatomic, copy) NSString *vomsID;

@property (nonatomic, copy) NSString *assetID;

@property (nonatomic, copy) NSString *videoType;

@property (nonatomic, copy) NSString *auth;

@property (nonatomic, copy) NSString *programType;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) MGMAction *action;

@property (nonatomic, strong) MGMTip *tip;

@property (nonatomic, copy) NSString *updateV;

@property (nonatomic, copy) NSString *publishTime;

@property (nonatomic, copy) NSString *duration;

@property (nonatomic, copy) NSString *score;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) MGMPic *pics;

@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *updateTimeDesc;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *gkeUserid;

@property (nonatomic, copy) NSString *sign;

@property (nonatomic, copy) NSString *mediaSize;

@property (nonatomic, copy) NSString *avator;

@property (nonatomic, copy) NSString *author;

@property (nonatomic, copy) NSArray<NSString *> *previewPicture;

@property (nonatomic, copy) NSString *contentType;

@property (nonatomic, copy) NSString *career;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *starId;

@property (nonatomic, copy) NSString *year;

@property (nonatomic, copy) NSString *contentStyle;

@property (nonatomic, copy) NSString *actor;

@property (nonatomic, copy) NSString *playTimes;

@property (nonatomic, strong) NSArray<NSString *> *fitArea;

@property (nonatomic, assign) BOOL isSelected;

@property (nonatomic, copy) NSString *comments;

@property (nonatomic, copy) NSString *searchOptions;

@property (nonatomic, copy) NSString *releaseTime;


//G客大赛
@property (nonatomic, copy) NSString *lables;
@property (nonatomic, copy) NSString *periodHeat;
@property (nonatomic, copy) NSString *period;
@property (nonatomic, copy) NSString *raceAreaName;
@property (nonatomic, copy) NSString *showHeat;
@property (nonatomic, copy) NSString *stationAreaName;
@property (nonatomic, copy) NSString *status;
@property (nonatomic, copy) NSString *topic;
@property (nonatomic, copy) NSString *totalHeat;
@property (nonatomic, copy) NSString *userId;
@property (nonatomic, copy) NSString *vid;

//影院专用
@property (nonatomic, copy) NSString *showStyle;
@property (nonatomic, strong) MGMExtradata *extraData;
@property (nonatomic, copy) NSString *isPresell;
@property (nonatomic, strong) id adData;
@property (nonatomic, copy) NSString *playTime;


//对白列表跳转到详情页需要移除获取列表按钮，乐高并未配置该字段此处暂做修改，添加某个字段以作判断
@property (nonatomic, copy) NSString *shouldShowMoreDuibaiButton;

+ (instancetype)modelWithJsonString:(NSString *)jsonString;

@end

@interface MGMTip: MGMBase

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, copy) NSString *code;

@end

@interface MGMPic: MGMBase

@property (nonatomic, copy) NSString *lowResolutionV;

@property (nonatomic, copy) NSString *highResolutionH;

@property (nonatomic, copy) NSString *highResolutionV;

@property (nonatomic, copy) NSString *lowResolutionH;

@property (nonatomic, copy) NSString *gkResolution1;

@property (nonatomic, copy) NSString *gkResolution2;

@end

@interface MGMLabel: MGMBase

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *actionId;

@property (nonatomic, copy) NSString *defaultTextColor;

@property (nonatomic, strong) MGMAction *action;

@end

@interface MGMAdinfo: MGMBase

@property (nonatomic, strong) NSArray<NSString *> *adPosition;

@property (nonatomic, strong) NSArray<NSString *> *adID;

@property (nonatomic, strong) NSArray<NSString *> *materialStyle;

@property (nonatomic, copy) NSString *displayStride;

@property (nonatomic, copy) NSString *startPosition;

@property (nonatomic,strong) NSArray<MGMFlowList*> *flowList;

@property (nonatomic,copy) NSString *adImg;

@property (nonatomic ,strong) MGMAction *action;

@property (nonatomic,copy) NSString *adTitle;

@property (nonatomic,copy) NSString *actionId;

@end

@interface MGMTeams: MGMBase

@property (nonatomic, copy) NSString *teamLogo;

@property (nonatomic, copy) NSString *score;

@property (nonatomic, copy) NSString *teamName;

@end

@interface MGMMatches: MGMBase

@property (nonatomic, copy) NSString *startTime;

@property (nonatomic, copy) NSString *startTimeStr;

@property (nonatomic, copy) NSString *endTime;

@property (nonatomic, copy) NSString *round;

@property (nonatomic, strong) NSArray<MGMTeams *> *teams;

@property (nonatomic, copy) NSString *actionId;

@property (nonatomic, strong) MGMAction *action;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *logo;

@property (nonatomic, copy) NSString *title;

@end

@interface MGMSearchCondition: MGMBase

@property (nonatomic, copy) NSString *contDisplayType;
@property (nonatomic, copy) NSString *packId;
@property (nonatomic, copy) NSString *mediaShape;
@property (nonatomic, copy) NSString *mediaChu;
@property (nonatomic, copy) NSString *rankingType;
@property (nonatomic, copy) NSString *channel;

@end

@interface MGMPlayTimes: MGMBase

@property (nonatomic, strong) NSDictionary * body;
@property (nonatomic, assign) NSInteger code;
@property (nonatomic, copy) NSString * message;
@property (nonatomic, assign) NSInteger timeStamp;
@end

@interface MGMStations: MGMBase

@property (nonatomic, copy) NSString * id;
@property (nonatomic, copy) NSString * stationID;

@end

@interface MGMFlowList: MGMBase

@property (nonatomic, copy) NSString * code;
@property (nonatomic, copy) NSString * price;
@property (nonatomic, copy) NSString * subtitle;
@property (nonatomic, copy) NSString * icon;
@property (nonatomic, strong) MGMAction *action;
@property (nonatomic, copy) NSString * startTime;
@property (nonatomic, copy) NSString * endTime;
@property (nonatomic, copy) NSString * title;
@property (nonatomic, copy) NSString * type;

@end

@interface MGMServiceInfo: MGMBase

@property (nonatomic, copy) NSString * subTitle;
@property (nonatomic, copy) NSString * price;
@property (nonatomic, copy) NSString * originalPrice;
@property (nonatomic, copy) NSString * serviceCode;
@property (nonatomic, copy) NSString * icon;
@property (nonatomic, copy) NSString * title;
@property (nonatomic, assign) BOOL isSelected;
@property (nonatomic, strong) MGMAction *action;


@end

@interface MGMMemberInfos: MGMBase

@property (nonatomic, copy) NSString * memberInfos;
@property (nonatomic, copy) NSString * subTitle ;
@property (nonatomic, copy) NSString * goodsID;
@property (nonatomic, copy) NSString * name;
@property (nonatomic, strong) NSArray<MGMServiceInfo *> *serviceInfo;
@property (nonatomic, strong) NSArray<MGMServiceInfo *> *iosServiceInfo;


@end

@interface MGMMemberInfo: MGMBase

@property (nonatomic, copy) NSString *key;
@property (nonatomic, copy) NSString *value;
@property (nonatomic, copy) NSString *priority;

@end

@interface MGMTitleBar: MGMBase

@property (nonatomic, strong) NSArray<MGMBar *> *bars;

@end

@interface MGMBar: MGMBase

@property (nonatomic, copy) NSString *icon;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *actionId;
@property (nonatomic, strong) MGMAction *action;

@end

//会员权益
@interface MGMEitherInfo : MGMBase

@property (nonatomic, copy) NSString *Description;
@property (nonatomic, copy) NSString *rightCode;
@property (nonatomic, copy) NSString *title;

@end

NS_ASSUME_NONNULL_END
