//
//  MGMFrameInfo.h
//  MGMHttpApi
//
//  Created by zhaohao on 2018/11/27.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MGMLegoAction.h"

NS_ASSUME_NONNULL_BEGIN

@class MGMFrame,MGMBottombar,MGMLegoButton,MGMTopbar,MGMLogo,MGMLegoButton;
@interface MGMInitInfo : NSObject

@end

@interface MGMFrame : NSObject

@property (nonatomic, strong) NSArray<MGMTopbar *> *topBars;

@property (nonatomic, copy) NSString *id;

@property (nonatomic, strong) MGMBottombar *bottomBar;

@property (nonatomic, copy) NSString *name;

@end

@interface MGMBottombar : NSObject

@property (nonatomic, strong) NSArray<MGMLegoButton *> *buttons;

@property (nonatomic, copy) NSString *backgroundImg;

@property (nonatomic, copy) NSString *compType;

@property (nonatomic, copy) NSString *compStyle;

@end

@interface MGMLegoButton : NSObject

@property (nonatomic, strong) MGMAction *action;

@property (nonatomic, copy) NSString *defaultImg;

@property (nonatomic, copy) NSString *activatedImg;

@property (nonatomic, copy) NSString *displayText;

@property (nonatomic, copy) NSString *defaultTextColor;

@property (nonatomic, copy) NSString *activatedTextColor;

@property (nonatomic, copy) NSString *topBarID;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *actionId;

@end

@interface MGMTopbar : NSObject

@property (nonatomic, copy) NSString *defaultSearchTxt;

@property (nonatomic, copy) NSString *filterButtonImg;

@property (nonatomic, copy) NSString *id;

@property (nonatomic, copy) NSString *backgroundImg;

@property (nonatomic, strong) NSArray<MGMLegoButton *> *buttons;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) MGMLogo *logo;

@property (nonatomic, copy) NSString *compType;

@property (nonatomic, copy) NSString *compStyle;

@property (nonatomic, assign) BOOL ipv6;

@end

@interface MGMLogo : NSObject

@property (nonatomic, strong) MGMAction *action;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *name;

@end

NS_ASSUME_NONNULL_END
