//
//  MGMInterestUserInfoModel.m
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/5/15.
//

#import "MGMInterestUserInfoModel.h"

@implementation MGMInterestUserInfoModel
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"body" : [MGMInterestUserInfoBody class],
             };
}
@end
@implementation MGMInterestUserInfoBody
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"data" : [MGMInterestUserInfoBodyData class],
             };
}
@end
@implementation MGMInterestUserInfoBodyData

@end
