//
//  MGMInterestUserInfoModel.h
//  AFNetworking
//
//  Created by 袁飞扬 on 2019/5/15.
//

#import "MGMBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@class MGMInterestUserInfoBody;
@class MGMInterestUserInfoBodyData;

@interface MGMInterestUserInfoModel : MGMBaseModel

@property (nonatomic, copy)NSString *timeStamp;

@property (nonatomic, copy)NSString *code;

@property (nonatomic, copy)NSString *message;

@property (nonatomic, copy)MGMInterestUserInfoBody *body;

@end



@interface MGMInterestUserInfoBody : MGMBaseModel

@property (nonatomic, copy)NSString *resultCode;

@property (nonatomic, copy)NSString *resultDesc;

@property (nonatomic, copy)NSArray<MGMInterestUserInfoBodyData*> *data;

@end

@interface MGMInterestUserInfoBodyData : MGMBaseModel

@property (nonatomic, copy)NSString *userId;

@property (nonatomic, copy)NSString *sname;

@property (nonatomic, copy)NSString *sign;

@property (nonatomic, copy)NSString *picture;

@property (nonatomic, copy)NSString *memberLevel;

@property (nonatomic, copy)NSString *fansCount;

@property (nonatomic, copy)NSString *relationType;

@end

NS_ASSUME_NONNULL_END
