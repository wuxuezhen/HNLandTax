//
//  MGMHttpApiDemo.m
//  MGMHttpApiModel
//
//  Created by RenYi on 2018/12/19.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMHttpApiDemo.h"
#import <MGUHttpApiCore/MGUHttpApiFactory.h>
#import <MGUHttpApiCore/MGUHttpApi.h>
#import <YYModel/NSObject+YYModel.h>
#import "MGMHttpResponse.h"
#define MGMTicketApiUrlPathParamKey  (@"MGMTicketApiUrlPathParamKey")
#define MGMTicketPathParmGenerate(value) (@{MGMTicketApiUrlPathParamKey : value})

#define MGMTicketApiHeaderParamsKey  (@"MGMTicketApiHeaderParamsKey")
#define MGMTicketHeaderParmGenerate(value) (@{MGMTicketApiHeaderParamsKey : value})

@interface MGMHttpApiDemo () <MGUHttpApiDelegate>

@end

@implementation MGMHttpApiDemo

#pragma mark - 获取城市信息

- (BOOL)fetchCityInfoWithName:(NSString *)cityName tag:(NSUInteger)tag
{
    if (cityName.length < 1)
    {
        return NO;
    }
    
    NSDictionary *params = MGMTicketPathParmGenerate(cityName);
    
    [self fetchDataWithApiName:@"MGM_Ticket_CityInfo" tag:tag parameters:params];
    return YES;
}


#pragma mark - 获取城市列表

- (BOOL)fetchCitieslistWithTag:(NSUInteger)tag
{
    [self fetchDataWithApiName:@"MGM_Ticket_CityList" tag:tag parameters:@{}];
    return YES;
}

#pragma mark - 获取城市区域列表

- (BOOL)fetchDistrictInCity:(NSUInteger)cityId tag:(NSUInteger)tag
{
    NSString *cityIdStr = [NSString stringWithFormat:@"%lu", (unsigned long)cityId];
    NSDictionary *params = MGMTicketPathParmGenerate(cityIdStr);
    
    [self fetchDataWithApiName:@"MGM_Ticket_DistrictInCity" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 获取可订票影院列表
// todo: 请求头添加clientId(手机唯一设备号) renyi
- (BOOL)fetchValidCinemasInCity:(NSString *)cityId
                       regionId:(nullable NSString *)regionId
                       showDate:(nullable NSString *)showDate
                        filmeId:(nullable NSString *)filmId
                      orderType:(nullable NSString *)orderType
                      longitude:(nullable NSString *)longitude
                       latitude:(nullable NSString *)latitude
                  cinemaCompany:(nullable NSString *)cinemaCompany
                     searchDate:(nullable NSString *)searchDate
                        feature:(nullable NSString *)feature
               businessAreaName:(nullable NSString *)businessAreaName
                 investmentName:(nullable NSString *)investmentName
                        pageNum:(NSInteger)pageNum
                       pageSize:(NSInteger)pageSize
                            tag:(NSUInteger)tag
{
    NSString *cityIdStr = [NSString stringWithFormat:@"%@", cityId];
    NSMutableDictionary *params = MGMTicketPathParmGenerate(cityIdStr).mutableCopy;
    
    NSMutableDictionary *argus = [NSMutableDictionary dictionary];
    if (regionId.length > 0)                 [argus setObject:regionId forKey:@"regionId"];//[paramPath appendFormat:@"%zd", regionId];
    if (showDate.length > 0)          [argus setObject:showDate forKey:@"showDate"];//[argus setObject:showDate forKey:@"showDate"];//[paramPath appendFormat:@"/%@", showDate];
    if (filmId.length > 0)                   [argus setObject:filmId forKey:@"filmId"];//[paramPath appendFormat:@"/%zd", filmId];
    if (orderType.length > 0)                [argus setObject:orderType  forKey:@"orderType"];//[paramPath appendFormat:@"/%zd", filmId];
    if (longitude.length > 0)         [argus setObject:longitude forKey:@"longitude"];//[paramPath appendFormat:@"/%@", longitude];
    if (latitude.length > 0)          [argus setObject:latitude forKey:@"latitude"];//[paramPath appendFormat:@"/%@", latitude];
    if (cinemaCompany.length > 0)     [argus setObject:cinemaCompany forKey:@"cinemaCompany"];//[paramPath appendFormat:@"/%@", cinemaCompany];
    if (searchDate.length > 0)        [argus setObject:searchDate forKey:@"searchDate"];//[paramPath appendFormat:@"/%@", searchDate];
    if (feature.length > 0)           [argus setObject:feature forKey:@"feature"];//[paramPath appendFormat:@"/%@", feature];
    if (businessAreaName.length > 0)  [argus setObject:businessAreaName forKey:@"businessCenterName"];//[paramPath appendFormat:@"/%@", businessAreaName];
    if (investmentName.length > 0)    [argus setObject:investmentName forKey:@"investmentName"];//[paramPath appendFormat:@"/%@", investmentName];
    if (pageNum >= 0)                  [argus setObject:@(pageNum) forKey:@"pageNum"];//[paramPath appendFormat:@"/%zd", pageNum];
    if (pageSize > 0)                 [argus setObject:@(pageSize) forKey:@"pageSize"];//[paramPath appendFormat:@"/%zd", pageSize];
    [params setObject:argus forKey:MGMTicketApiHeaderParamsKey];
    NSLog(@"%@",params);
    [self fetchDataWithApiName:@"MGM_Ticket_ValidCinemas" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 获取影院详情

- (BOOL)fetchCinemaInfo:(NSString *)cinemaId tag:(NSUInteger)tag
{
    NSString *cinemaIdStr = [NSString stringWithFormat:@"%@", cinemaId];
    NSMutableDictionary *params = MGMTicketPathParmGenerate(cinemaIdStr).mutableCopy;
    
    [self fetchDataWithApiName:@"MGM_Ticket_CinemaInfo" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 根据多个影院id获取多个影院信息

- (BOOL)batchFetchCinemasInfo:(NSString *)cinemaIds
                    longitude:(nullable NSString *)longitude
                     latitude:(nullable NSString *)latitude
                          tag:(NSUInteger)tag
{
    NSMutableDictionary *params = MGMTicketPathParmGenerate(cinemaIds).mutableCopy;
    
    NSMutableDictionary *argus = [NSMutableDictionary dictionary];
    if (longitude.length > 0)         [argus setObject:longitude forKey:@"longitude"];
    if (latitude.length > 0)          [argus setObject:latitude forKey:@"latitude"];
    [params setObject:argus forKey:MGMTicketApiHeaderParamsKey];
    
    [self fetchDataWithApiName:@"MGM_Ticket_BatchCinemaInfos" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 查询影院特色标签列表

- (BOOL)fetchSpecialListForCity:(NSString *)cityId tag:(NSUInteger)tag
{
    NSString *cityIdStr = [NSString stringWithFormat:@"%@", cityId];
    NSDictionary *params = MGMTicketPathParmGenerate(cityIdStr);
    
    [self fetchDataWithApiName:@"MGM_Ticket_CinemaTags" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 查询品牌（影投）列表
-(BOOL)fetchInvestmentListInCity:(NSUInteger)cityId tag:(NSUInteger)tag
{
    NSString *cityIdStr = [NSString stringWithFormat:@"%lu", (unsigned long)cityId];
    NSDictionary *params = MGMTicketPathParmGenerate(cityIdStr);
    
    [self fetchDataWithApiName:@"MGM_Ticket_InvestmentList" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 获取商圈列表

- (BOOL)fetchBusinessAreaInCity:(NSUInteger)cityId tag:(NSUInteger)tag
{
    NSString *cityIdStr = [NSString stringWithFormat:@"%lu", (unsigned long)cityId];
    NSDictionary *params = MGMTicketPathParmGenerate(cityIdStr);
    
    [self fetchDataWithApiName:@"MGM_Ticket_BusinessArea" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 正在上映

- (BOOL)fetchShowingMoviesWithCityId:(NSString *)cityId tag:(NSUInteger)tag
{
    if (cityId.length < 1)
    {
        return NO;
    }
    
    NSDictionary *params = MGMTicketPathParmGenerate(cityId);
    [self fetchDataWithApiName:@"MGM_Ticket_ShowingMovies" tag:tag parameters:params];
    return YES;
}

#pragma mark - 即将上映

- (BOOL)fetchUpcomingMoviesWithCityId:(NSString *)cityId pageNo:(NSInteger)pageNo pageSize:(NSInteger)pageSize tag:(NSUInteger)tag
{
    if (cityId.length < 1)
    {
        return NO;
    }
    
    NSMutableDictionary *params = MGMTicketPathParmGenerate(cityId).mutableCopy;
    [params setObject:@{@"pageNo":@(pageNo), @"pageSize":@(pageSize)}
               forKey:MGMTicketApiHeaderParamsKey];
    
    [self fetchDataWithApiName:@"MGM_Ticket_UpcomingMovies" tag:tag parameters:params];
    return YES;
}

#pragma mark - 场次微服务接口 -
#pragma mark - 影院上映列表

- (BOOL)fetchFilmsForCinema:(NSString *)cinemaId type:(NSString *)type tag:(NSUInteger)tag
{
    if ((cinemaId.length < 1)
        || (type.length < 1)) {
        return NO;
    }
    
    NSMutableDictionary *params = MGMTicketPathParmGenerate(cinemaId).mutableCopy;
    [params setObject:@{@"type":type} forKey:MGMTicketApiHeaderParamsKey];
    
    [self fetchDataWithApiName:@"MGM_Ticket_FilmsOnCinema" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 影片影院获取场次排片

- (BOOL)fetchScheduleForCinemaId:(NSString *)cinemaId WithFilmId:(NSString *)filmId tag:(NSUInteger)tag
{
    NSString *pathParams = [NSString stringWithFormat:@"%@/%@", cinemaId, filmId];
    
    NSDictionary *params = MGMTicketPathParmGenerate(pathParams);
    
    [self fetchDataWithApiName:@"MGM_Ticket_ScheduleForFilmsOnCinema" tag:tag parameters:params];
    return YES;
}

#pragma mark - 获取座位信息

- (BOOL)fetchSeatsInfoForCinemaId:(NSString *)cinemaId
                           hallId:(NSString *)hallId
                           showId:(NSString *)showId
                       accessorId:(NSString *)accessorid
                              tag:(NSUInteger)tag
{
    if ((cinemaId.length < 1)
        || (hallId.length < 1)
        || (showId.length < 1)
        || (accessorid.length < 1))
    {
        return NO;
    }
    
    //path: /{cinemaId}/{hallId}/{showId}/{accessorId}
    NSString *pathParams = [NSString stringWithFormat:@"%@/%@/%@/%@", cinemaId, hallId, showId, accessorid];
    
    NSDictionary *params = MGMTicketPathParmGenerate(pathParams);
    [self fetchDataWithApiName:@"MGM_Ticket_ShowSeats" tag:tag parameters:params];
    
    return YES;
}

#pragma mrak - 影片区域获取场次排片

- (BOOL)fetchScheduleForFilm:(NSString *)filmId inArea:(NSString *)regionId onDate:(NSString *)showDate tag:(NSUInteger)tag
{
//    NSString *pathParams = [NSString stringWithFormat:@"%@/%@/%@", filmId, regionId, showDate];
    NSMutableDictionary *argu = [NSMutableDictionary dictionary];
    [argu setObject:filmId forKey:@"filmId"];
    [argu setObject:regionId forKey:@"regionId"];
    [argu setObject:showDate forKey:@"showDate"];
    NSDictionary *params = MGMTicketHeaderParmGenerate(argu);
    
    [self fetchDataWithApiName:@"MGM_Ticket_ScheduleForFilmsOnArea" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 查询场次id

- (BOOL)fetchShowIdForCinemaId:(NSString *)cinemaId
                        filmId:(NSString *)filmId
                      showDate:(NSString *)showDate
                      showTime:(NSString *)showTime
                           tag:(NSUInteger)tag
{
    if ((showDate.length < 1)
        || (showTime.length < 1)
        || (cinemaId.length < 1)
        || (filmId.length < 1))
    {
        return NO;
    }
    
    //path: /{cinemaId}/{filmId}/{showDate}/{showTime}
    NSString *pathParams = [NSString stringWithFormat:@"%@/%@/%@/%@", cinemaId, filmId, showDate, showTime];
    
    NSDictionary *params = MGMTicketPathParmGenerate(pathParams);
    [self fetchDataWithApiName:@"MGM_Ticket_FetchShowId" tag:tag parameters:params];
    
    return YES;
}

#pragma mark - 查询影片排片信息

- (BOOL)fetchShowDatesForFilm:(NSString *)filmId
                       cityId:(NSString *)cityId
                     regionId:(nullable NSString *)regionId
                          tag:(NSUInteger)tag

{
    if ((filmId.length < 1)
        || (cityId.length < 1))
    {
        return NO;
    }
    
    NSMutableDictionary *argus = [NSMutableDictionary dictionary];
    [argus setObject:cityId forKey:@"cityId"];
    [argus setObject:filmId forKey:@"filmId"];
    if (regionId.length > 0)   [argus setObject:regionId forKey:@"regionId"];
    
    
    NSDictionary *params = MGMTicketHeaderParmGenerate(argus);
    [self fetchDataWithApiName:@"MGM_Ticket_ShowDatesForFilm" tag:tag parameters:params];
    
    return YES;
}



#pragma mark - 封装api 方法
- (void)fetchDataWithApiName:(NSString *)name tag:(NSUInteger)tag parameters:(id)params
{
    NSString *urlPathParam = ((NSDictionary *)params)[MGMTicketApiUrlPathParamKey];
    NSDictionary *headerParams = (NSDictionary *)((NSDictionary *)params)[MGMTicketApiHeaderParamsKey];
    
    MGUHttpApi *api = [[MGUHttpApiFactory apiFactory] createApiWithName:name parameters:headerParams urlPathParam:urlPathParam];
    api.tag = tag;
    api.apiDelegate = self;
    [api start];
}

#pragma mark - MGUHttpApiDelegate

- (void)httpApiFinished:(__kindof MGUHttpApi *)httpApi {
    MGMHttpResponse *response = [MGMHttpResponse yy_modelWithJSON:httpApi.responseJSONObject];
    if ([response.code isEqualToString:@"200"]) {
        if ([self.delegate respondsToSelector:@selector(dataManager:apiName:tag:didFetchData:error:)]) {
            [self.delegate dataManager:self
                               apiName:httpApi.apiName
                                   tag:httpApi.tag
                          didFetchData:response.body
                                 error:nil];
        }
    } else {
        if ([self.delegate respondsToSelector:@selector(dataManager:apiName:tag:didFetchData:error:)]) {
            [self.delegate dataManager:self
                               apiName:httpApi.apiName
                                   tag:httpApi.tag
                          didFetchData:nil
                                 error:[NSError errorWithDomain:@"" code:response.code userInfo:@{NSLocalizedDescriptionKey:response.message}]];
        }
    }
}

- (void)httpApiFailed:(__kindof MGUHttpApi *)httpApi {
    if ([self.delegate respondsToSelector:@selector(dataManager:apiName:tag:didFetchData:error:)]) {
        [self.delegate dataManager:self apiName:httpApi.apiName tag:httpApi.tag didFetchData:nil error:httpApi.error];
    }
}

@end
