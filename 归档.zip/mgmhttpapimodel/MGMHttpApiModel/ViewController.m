//
//  ViewController.m
//  MGMHttpApiModel
//
//  Created by zhaohao on 2018/12/11.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "ViewController.h"
#import "MGMHttpApiDemo.h"
#import "MGMTicketCurrentCityResponse.h"
#import "MGMTicketCityListResponse.h"
#import "MGMTicketCityAreaListResponse.h"
#import "MGMTicketValidCinemasResponse.h"
#import "MGMTicketCinemaDetailResponse.h"
#import "MGMTicketCinemaInfosResponse.h"
#import "MGMTicketCinemaTagListResponse.h"
#import "MGMTicketInvestListResponse.h"
#import "MGMTicketBusinessAreaRsponse.h"
#import "MGMTicketShowingMovieResponse.h"
#import "MGMTicketUpcomingMoviesResponse.h"

#import "MGMSceneShowListResponse.h"
#import "MGMSceneShowResponse.h"
#import "MGMSceneSeatInfoResponse.h"


@interface ViewController () <MGUPageDataManagerDelegate>

@property (nonatomic, strong) MGMHttpApiDemo *httpApiDateManager;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self refresh];
}

- (void)refresh {
    // 获取当前城市接口
//    [self.httpApiDateManager fetchCityInfoWithName:@"上海" tag:0]; // 4708
    // 获取城市列表接口
//    [self.httpApiDateManager fetchCitieslistWithTag:0]; //
    // 获取城市下区域列表接口
//    [self.httpApiDateManager fetchDistrictInCity:4708 tag:0]; 20110
    // 获取可订票影院接口
//    [self.httpApiDateManager fetchValidCinemasInCity:@"4708" regionId:@"20110" showDate:nil filmeId:nil orderType:nil longitude:nil latitude:nil cinemaCompany:nil searchDate:nil feature:nil businessAreaName:nil investmentName:nil pageNum:0 pageSize:20 tag:0];
    // 15348
    // 获取影院详情接口
//    [self.httpApiDateManager fetchCinemaInfo:@"15348" tag:0];
    // 获取多个影院信息
//    [self.httpApiDateManager batchFetchCinemasInfo:@"14323,15348" longitude:nil latitude:nil tag:0];
    // 查询影院特色标签列表
//    [self.httpApiDateManager fetchSpecialListForCity:@"4798" tag:0]; //20110 15348  4708
    // 查询品牌(影投)列表
//    [self.httpApiDateManager fetchInvestmentListInCity:4708 tag:0];
    // 查询商圈列表
//    [self.httpApiDateManager fetchBusinessAreaInCity:4708 tag:0];
    // 正在上映接口
//    [self.httpApiDateManager fetchShowingMoviesWithCityId:@"4708" tag:0]; // fileId 41436 1221日
    // 即将上映
//    [self.httpApiDateManager fetchUpcomingMoviesWithCityId:@"4938" pageNo:0 pageSize:20 tag:0];
    
    
    // 影院上映列表接口 有值
//    [self.httpApiDateManager fetchFilmsForCinema:@"15348" type:@"0" tag:0]; //filmId 40956
    
    // 场次排片接口 有值
//    [self.httpApiDateManager fetchScheduleForCinemaId:@"15348" WithFilmId:@"28587" tag:0]; // ...
    
    // 获取座位信息接口 有值
    [self.httpApiDateManager fetchSeatsInfoForCinemaId:@"15348" hallId:@"58883" showId:@"2090000000010675" accessorId:@"5" tag:0];
    
    // 查询影院场次信息 空
//    [self.httpApiDateManager fetchScheduleForFilm:@"40956" inArea:@"20110" onDate:@"2018-12-21" tag:0];
    
    // 场次id ..
//    [self.httpApiDateManager fetchShowIdForCinemaId:@"4326" filmId:@"40956" showDate:@"2018-03-19" showTime:@"1615" tag:0];
    
    // 影片排片日期 空
//    [self.httpApiDateManager fetchShowDatesForFilm:@"40227" cityId:@"5491" regionId:@"20110" tag:0];
}

- (void)dataManager:(MGUBasePageDataManager *)manager apiName:(NSString *)name tag:(NSUInteger)tag didFetchData:(id)data error:(NSError *)error {
    if (tag == 0) {
        // 获取当前城市接口
//        MGMTicketCurrentCityResponse *response  = [MGMTicketCurrentCityResponse yy_modelWithJSON:data];
        // 获取城市列表接口
//        MGMTicketCityListResponse *response = [MGMTicketCityListResponse yy_modelWithJSON:data];
        // 获取城市下区域列表接口
//        MGMTicketCityAreaListResponse *response  = [MGMTicketCityAreaListResponse yy_modelWithJSON:data];
        // 获取可订票影院接口
//        MGMTicketValidCinemasResponse *response = [MGMTicketValidCinemasResponse yy_modelWithJSON:data];
        // 获取影院详情接口
//        MGMTicketCinemaDetailResponse *response = [MGMTicketCinemaDetailResponse yy_modelWithJSON:data];
        // 获取多个影院信息
//        MGMTicketCinemaInfosResponse *response  = [MGMTicketCinemaInfosResponse yy_modelWithJSON:data];
        // 查询影院特色标签列表
//        MGMTicketCinemaTagListResponse *response = [MGMTicketCinemaTagListResponse yy_modelWithJSON:data];
        // 查询品牌(影投)列表
//        MGMTicketInvestListResponse *response = [MGMTicketInvestListResponse yy_modelWithJSON:data];
        // 查询商圈列表
//        MGMTicketBusinessAreaRsponse *response = [MGMTicketBusinessAreaRsponse yy_modelWithJSON:data];
        // 正在上映
//        MGMTicketShowingMovieResponse *response = [MGMTicketShowingMovieResponse yy_modelWithJSON:data];
        // 即将上映
//        MGMTicketUpcomingMoviesResponse *response = [MGMTicketUpcomingMoviesResponse yy_modelWithJSON:data];
        
        // 场次微服务
        // 上映列表接口
//        MGMSceneShowListResponse *response = [MGMSceneShowListResponse yy_modelWithJSON:data];
        //场次排片接口
//        MGMSceneShowResponse *response  = [MGMSceneShowResponse yy_modelWithJSON:data];
        // 座位信息
        MGMSceneSeatInfoResponse *response = [MGMSceneSeatInfoResponse yy_modelWithJSON:data];
        // 查询场次信息
//        NSLog(@"%@",response);
        
    }
}


- (MGMHttpApiDemo *)httpApiDateManager {
    if (!_httpApiDateManager) {
        _httpApiDateManager = [MGMHttpApiDemo new];
        _httpApiDateManager.delegate = self;
    }
    return _httpApiDateManager;
}


@end
