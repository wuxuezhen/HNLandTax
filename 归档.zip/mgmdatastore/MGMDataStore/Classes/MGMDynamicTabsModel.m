//
//  MGMDynamicTabsModel.m
//  MiguMovie
//
//  Created by YL on 2020/1/10.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDynamicTabsModel.h"

@implementation MGMDynamicTabsModel

@end
