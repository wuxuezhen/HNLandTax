//
//  MGMDEnvironment.h
//  MGMDataStore
//
//  Created by RenYi on 2019/3/5.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, MGMDEnvironmentType)
{
    MGMDEnvironmentTypePrd = 0,
    MGMDEnvironmentTypeDev,
    MGMDEnvironmentTypePreIPV6,
    MGMDEnvironmentTypeBuildPre,
    MGMDEnvironmentTypePre,
    MGMDEnvironmentTypeInvalid = INT_MAX
};

typedef NS_ENUM(NSInteger, MGMDEnvironmentIPVersion)
{
    MGMDEnvironmentIPVersionInvalid = 0,
    MGMDEnvironmentIPVersionV4,
    MGMDEnvironmentIPVersionV6
};


typedef void(^IPVersionCompletion)(MGMDEnvironmentIPVersion ipVersion);
typedef void(^MGMPlayerKeepLiveCompletion)(BOOL keepAlive);


@interface MGMDEnvironment : NSObject

+ (instancetype)shareEnvironment;


/**
 获取当前环境

 @return MGMDEnvironmentType
 */
- (MGMDEnvironmentType)environmentType;


/**
 设置当前环境

 @param environmentType MGMDEnvironmentType
 @return YES,设置成功;NO,设置失败
 */
- (BOOL)configEnvironmentType:(MGMDEnvironmentType)environmentType;

/**
获取ipversion, 如果从服务器获取失败，默认使用ipv4。
每次启动只会获取一次， 第一次获取成功之后会进行缓存，之后获取会直接返回


@param completion IPVersionCompletion
@return YES,发起获取成功;NO,发起获取失败失败
*/
- (BOOL)fetchIPVersionCompletion:(IPVersionCompletion)completion;
- (BOOL)fetchPlayerKeepLiveStatusWithCompletion:(MGMPlayerKeepLiveCompletion)completion;

@end


@interface MGMDEnvironment (MGMAppInfo)




/**
 对外app版本号。返回info.plist中定义的版本号
 */
- (NSString *)outerAppVersion;


/**
 内部版本号.
 */
- (NSString *)innerAppVersion;

/*
 If:
    innerAppVersion < comparedVersion   then return NSOrderedAscending. The left operand is smaller than the right operand.
    innerAppVersion > comparedVersion   then return NSOrderedDescending. The left operand is greater than the right operand.
    innerAppVersion == comparedVersion  then return NSOrderedSame. The operands are equal.
 */
- (NSComparisonResult)currenInnerAppVersionCompare:(NSString *)comparedVersion;

- (NSString *)uuid;

- (NSString *)clientId;

- (NSString *)SDKCEId;

- (NSString *)channelId;

/**
平台没有强制要求的使用
*/
- (NSString *)commonUniversalLink;

/**
qq
*/
- (NSString *)qqUniversalLink;

/*
 获取当前正在审核的版本号
 */
- (nullable NSString *)reviewVersion;

/*
 配置当前审核版本
 */
- (void)configReviewVersion:(NSString *)version;

@end




NS_ASSUME_NONNULL_END
