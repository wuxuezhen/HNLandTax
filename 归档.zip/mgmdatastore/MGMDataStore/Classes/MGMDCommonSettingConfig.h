//
//  MGMDCommonSettingConfig.h
//  MiguMovie
//  Created by YL on 2020/1/10.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class MGMDynamicTabsModel;

@interface MGMDCommonSettingConfig : NSObject

@property (nonatomic, copy) NSArray<MGMDynamicTabsModel *>*dynamicTabsArray;

@property (nonatomic, copy) NSArray <NSString *>*dynamicIdArray;
//观影任务是否未完成
@property (nonatomic, assign) BOOL              movieTaskDidUnComplete;

+ (instancetype)shareConfig;

- (void)configDynamicTabsArray:(NSArray <MGMDynamicTabsModel* >*)tabsArray;

@end

NS_ASSUME_NONNULL_END
