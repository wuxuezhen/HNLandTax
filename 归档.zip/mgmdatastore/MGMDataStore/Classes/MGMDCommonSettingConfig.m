//
//  MGMDCommonSettingConfig.m
//  MiguMovie
//
//  Created by YL on 2020/1/10.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDCommonSettingConfig.h"
#import "MGMDynamicTabsModel.h"

@interface MGMDCommonSettingConfig ()

@end

@implementation MGMDCommonSettingConfig

+ (instancetype)shareConfig {
    static MGMDCommonSettingConfig *_shareSettingConfig= nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        _shareSettingConfig = [[MGMDCommonSettingConfig alloc] init];
    });
    
    return _shareSettingConfig;
}

- (void)configDynamicTabsArray:(NSArray <MGMDynamicTabsModel* >*)tabsArray {
    if(tabsArray.count == 0) {
        MGMDynamicTabsModel *recommendTabsModel = [[MGMDynamicTabsModel alloc] init];
        recommendTabsModel.label = @"精选";
        recommendTabsModel.dynamicId = MGMDynamicRecommendId;
        
        MGMDynamicTabsModel *followTabsModel = [[MGMDynamicTabsModel alloc] init];
        followTabsModel.label = @"关注";
        followTabsModel.dynamicId = MGMDynamicFollowId;
        tabsArray = @[recommendTabsModel,followTabsModel];
    }
    NSMutableArray *tempArray = [[NSMutableArray alloc] init];
    NSMutableArray *tempTabArray = [[NSMutableArray alloc] init];
    for (MGMDynamicTabsModel *tabsModel in tabsArray) {
        if(tabsModel.dynamicId.length == 0) {
            continue;
        }
        if(tabsModel.icon.length == 0 && tabsModel.label.length == 0) {
            continue;
        }
        [tempArray addObject:tabsModel.dynamicId];
        [tempTabArray addObject:tabsModel];
    }
    self.dynamicTabsArray = tempTabArray;
    self.dynamicIdArray = tempArray;
}

@end
