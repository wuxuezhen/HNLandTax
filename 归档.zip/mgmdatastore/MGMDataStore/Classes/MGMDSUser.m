//
//  MGMDSUser.m
//  MGMDataStore
//
//  Created by RenYi on 2018/12/6.
//

#import "MGMDSUser.h"
#import <MGUKeyValueStore/MGUKeyValueStore.h>

#define MGMDSUser_StoreKey  (@"mgm_store_user")

@implementation MGMDSUser

+ (instancetype)user
{
    
    MGMDSUser *user = [[MGUKeyValueStore defaultStore] getObjectForKey:MGMDSUser_StoreKey];
    
    if (!user)
    {
        user = [[MGMDSUser alloc] init];
    }
    return user;
}

- (BOOL)save
{
    if (self.userId.length < 1) {
        
        return NO;
    }
    MGUKeyValueStore *store = [MGUKeyValueStore defaultStore];
    return [store setObject:self forKey:MGMDSUser_StoreKey];
}
- (void)deleteUser
{
    [[MGUKeyValueStore defaultStore] removeObjectForKey:MGMDSUser_StoreKey];
}

- (NSDictionary *)amberUserInfo {
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    if (self.token.length > 0)
    {
        if ([self.loginType isEqualToString:@"CMWAP"] || [self.loginType isEqualToString:@"PWD"] || [self.loginType isEqualToString:@"SMS_CODE"] || [self.loginType isEqualToString:@"MIGUTOKEN"])
        { //手机账号
            [dic setValue:@"1" forKey:@"account_type"];
            [dic setValue:self.mobile forKey:@"account"];
            [dic setValue:self.mobile forKey:@"phone_number"];
        }
        else if ([self.loginType isEqualToString:@"WEIXIN"])
        {//微信
            [dic setValue:@"3" forKey:@"account_type"];
            [dic setValue:self.loginId forKey:@"account"];
            [dic setValue:self.mobile?:@"" forKey:@"phone_number"];
        }
        else if ([self.loginType isEqualToString:@"QQ"])
        {
            [dic setValue:@"4" forKey:@"account_type"];
            [dic setValue:self.loginId forKey:@"account"];
            [dic setValue:self.mobile?:@"" forKey:@"phone_number"];
        }
        else if ([self.loginType isEqualToString:@"WEIBO"])
        {
            [dic setValue:@"5" forKey:@"account_type"];
            [dic setValue:self.loginId forKey:@"account"];
            [dic setValue:self.mobile?:@"" forKey:@"phone_number"];
        }
        else
        {
            [dic setValue:@"99" forKey:@"account_type"];
            [dic setValue:self.loginId forKey:@"account"];
            [dic setValue:self.mobile?:@"" forKey:@"phone_number"];
        }
    }
    else
    {//游客
        [dic setValue:@"0" forKey:@"account_type"];
        [dic setValue:@"" forKey:@"account"];
        [dic setValue:@"" forKey:@"phone_number"];
    }
    return dic;
}

@end









