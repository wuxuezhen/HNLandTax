//
//  MGMDSUser.h
//  MGMDataStore
//
//  Created by RenYi on 2018/12/6.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

@interface MGMDSUser : NSObject

@property (nonatomic, copy)   NSString * userId;
@property (nonatomic, copy)   NSString * certificationUrl;
@property (nonatomic, copy)   NSString * token;
@property (nonatomic, copy)   NSString * mobile;
@property (nonatomic, copy)   NSString * nickname;               // 昵称
@property (nonatomic, copy)   NSString * avatar;
@property (nonatomic, copy)   NSString * loginId;
@property (nonatomic, copy)   NSString * loginType;
@property (nonatomic, copy)   NSString * passId;
@property (nonatomic, copy)   NSString * userInfo;
@property (nonatomic, copy, getter=isSign)   NSString * sign;
@property (nonatomic, copy)   NSString * email;
@property (nonatomic, assign) BOOL isLogin;
@property (nonatomic, copy)   NSString * firstLevelToken;/**<一级token,只在支付时使用 */

+ (instancetype)user;

- (BOOL)save;
- (void)deleteUser;
- (NSDictionary *)amberUserInfo;
@end

//NS_ASSUME_NONNULL_END
