//
//  MGMDEnvironment.m
//  MGMDataStore
//
//  Created by RenYi on 2019/3/5.
//

#import "MGMDEnvironment.h"
#import <AdSupport/AdSupport.h>
#import <MGUHttpApiCore/MGUHttpApi.h>
#import <MGUHttpApiCore/MGUHttpApiFactory.h>
#import <MGUCategoryUtil/NSDictionary+MGUExtension.h>
#import <MGUKeyValueStore/MGUKeyValueStore.h>

#define MGMDEnvironment_envTypeKey  (@"mgm_store_env_typekey")
#define MGMDEnvironment_CLIENTID_KEY @"MGMCommonHeadersClientIdKey"
#define MGMDEnvironment_IPVERSION_KEY @"mgm_environment_ipversion"
#define MGMMoviePlayerStatusKey @"mgm_moviePlayer_status"

#define MGMDEnvironment_ReviewVersion @"mgm_environment_reviewversion"

#define KMGMIPVersionApi 10111444
#define MGMMoviePlayerAliveApi  10111445

typedef NS_ENUM(NSInteger, MGMPlayerKeepLiveStatus)
{
    MGMPlayerKeepLiveStatusUnknown,
    MGMPlayerKeepLiveStatusEnable,
    MGMPlayerKeepLiveStatusDisable
};

//5.0.x版本最大的versionCount  10位版本id的第8位和第9位
static NSInteger kMaxVersionsCountFor500 = 10;

@interface MGMDEnvironment ()<MGUHttpApiDelegate>

/**
 当前环境。默认为MGMDEnvironmentTypePrd
 */
@property (nonatomic, assign) MGMDEnvironmentType  environmentType;

@property (nonatomic, assign) MGMDEnvironmentIPVersion ipVersion;
@property (nonatomic, assign) MGMPlayerKeepLiveStatus keepLiveStatus;
@property (nonatomic, copy) IPVersionCompletion completion;
@property (nonatomic, copy) MGMPlayerKeepLiveCompletion keepLiveCompletion;

@end

@implementation MGMDEnvironment

+ (instancetype)shareEnvironment
{
    static MGMDEnvironment *_shareEnvironment = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        _shareEnvironment = [[MGMDEnvironment alloc] init];
    });
    
    return _shareEnvironment;
}

- (instancetype)init
{
    if (self = [super init]) {
        
        _ipVersion = MGMDEnvironmentIPVersionInvalid;
        _keepLiveStatus = MGMPlayerKeepLiveStatusUnknown;
    }
    
    return self;
}

#pragma mark - Environment

- (MGMDEnvironmentType)environmentType
{
    NSNumber * storeType = [[NSUserDefaults standardUserDefaults] objectForKey:MGMDEnvironment_envTypeKey];
    
    if (!storeType)
    {
        storeType = @(MGMDEnvironmentTypePrd);
        [[NSUserDefaults standardUserDefaults] setObject:storeType forKey:MGMDEnvironment_envTypeKey];
    }
    
    return (MGMDEnvironmentType)(storeType.integerValue);
}

- (BOOL)configEnvironmentType:(MGMDEnvironmentType)environmentType
{
    if ([self validateEnvironmentType:environmentType])
    {
        [[NSUserDefaults standardUserDefaults] setObject:@(environmentType) forKey:MGMDEnvironment_envTypeKey];
        [[NSUserDefaults standardUserDefaults] synchronize];
        return YES;
    }
    else
    {
        return NO;
    }
}

- (BOOL)validateEnvironmentType:(MGMDEnvironmentType)environmentType
{
    if ((environmentType >= MGMDEnvironmentTypePrd)
        && (environmentType <= MGMDEnvironmentTypePre))
    {
        return YES;
    }
    else
    {
        return NO;
    }
}


- (BOOL)fetchIPVersionCompletion:(IPVersionCompletion)completion
{
    //成功获取之后，每次启动只获取一次
    if (self.ipVersion != MGMDEnvironmentIPVersionInvalid) {
        
        if (completion)
        {
            completion([self getStoredIPVersion]);
        }
        return YES;
    }
    
    self.completion = completion;

    return [self startFetch];
}

- (BOOL)fetchPlayerKeepLiveStatusWithCompletion:(MGMPlayerKeepLiveCompletion)completion
{
    if (MGMPlayerKeepLiveStatusUnknown != self.keepLiveStatus)
    {
        MGMPlayerKeepLiveStatus keepLiveStatus = [self loaPlayerKeepLiveStatus];
        BOOL keepAlive = (MGMPlayerKeepLiveStatusEnable == keepLiveStatus);
        !completion ?: completion(keepAlive);
        return YES;
    }
    self.keepLiveCompletion = completion;
    return [self fetchPlayerKeepLiveStatus];
}

- (BOOL)startFetch
{
    MGUHttpApiFactory *factory = [MGUHttpApiFactory apiFactory];
    MGUHttpApi * ipAddressVersionApi = [factory createApiWithName:@"MGM_IPVersion_Api"
                                                 parameters:nil
                                               urlPathParam:nil];
    
    if (ipAddressVersionApi) {
        
        ipAddressVersionApi.tag = KMGMIPVersionApi;
        ipAddressVersionApi.apiDelegate = self;
        [ipAddressVersionApi start];
        return YES;
    }
    else
        return NO;

}

- (BOOL)fetchPlayerKeepLiveStatus
{
    MGUHttpApiFactory *factory = [MGUHttpApiFactory apiFactory];
    MGUHttpApi *moviePlayerAliveApi = [factory createApiWithName:@"MGM_Player_KeepAlive_Api"
                                                      parameters:nil
                                                    urlPathParam:nil];
    if (moviePlayerAliveApi)
    {
        moviePlayerAliveApi.tag = MGMMoviePlayerAliveApi;
        moviePlayerAliveApi.apiDelegate = self;
        [moviePlayerAliveApi start];
        return YES;
    }
    else
    {
        return NO;
    }
}

- (MGMPlayerKeepLiveStatus)loaPlayerKeepLiveStatus
{
    NSNumber *moviePlayerEnable = [[NSUserDefaults standardUserDefaults] objectForKey:MGMMoviePlayerStatusKey];
    if ([moviePlayerEnable isEqual:@(1)])
    {
        return MGMPlayerKeepLiveStatusEnable;
    }
    else
    {
        return MGMPlayerKeepLiveStatusDisable;
    }
}

- (void)savePlayerKeepLiveStatus:(MGMPlayerKeepLiveStatus)status
{
    if (MGMPlayerKeepLiveStatusUnknown == status) return;
    
    NSNumber *moviePlayerEnable = @(1);
    if (MGMPlayerKeepLiveStatusDisable == status)
    {
        moviePlayerEnable = @(0);
    }
    [[NSUserDefaults standardUserDefaults] setObject:moviePlayerEnable forKey:MGMMoviePlayerStatusKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (MGMDEnvironmentIPVersion)getStoredIPVersion
{
    NSInteger ipVersion = [[NSUserDefaults standardUserDefaults] integerForKey:MGMDEnvironment_IPVERSION_KEY];
    if (ipVersion == 0) {
        return MGMDEnvironmentIPVersionV4;
    }
    else
        return ipVersion;
}

- (void)configIPVersion:(MGMDEnvironmentIPVersion)ipVersion
{
    //检测合法性
    if ((ipVersion != MGMDEnvironmentIPVersionV4)
        &&(ipVersion != MGMDEnvironmentIPVersionV6))
    {
        return;
    }
    [[NSUserDefaults standardUserDefaults] setInteger:ipVersion forKey:MGMDEnvironment_IPVERSION_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

/*
 单元测试使用
 */
- (void)clearIPVersion
{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:MGMDEnvironment_IPVERSION_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark -  MGUHttpApiDelegate

- (void)httpApiFinished:(__kindof MGUHttpApi *)httpApi
{
    if (httpApi.tag == KMGMIPVersionApi)
    {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:httpApi.responseData
                                                            options:NSJSONReadingAllowFragments
                                                              error:nil];

        NSNumber *code = [dic mgu_objectOrNilForKey:@"code"];
        if (code.intValue == 200) {
         
            NSDictionary *body = [dic mgu_objectOrNilForKey:@"body"];
            NSDictionary *protocol = [body mgu_objectOrNilForKey:@"PROTOCOL_MOVIE"];
            NSString *paramValue = [protocol mgu_objectOrNilForKey:@"paramValue"];
            
            NSDictionary *paramValueDic = [NSDictionary mgu_dictionaryWithJSONString:paramValue];
            NSDictionary *defaultValue = [paramValueDic mgu_objectOrNilForKey:@"default"];
            NSString *version = [defaultValue mgu_objectOrNilForKey:@"PROTOCOL"];
            if ([version isEqualToString:@"V6"]) {
                self.ipVersion = MGMDEnvironmentIPVersionV6;
                [self configIPVersion:self.ipVersion];
            }
            else
            {
                self.ipVersion = MGMDEnvironmentIPVersionV4;
                [self configIPVersion:self.ipVersion];
            }
        }
        
        if (self.completion)
        {
            self.completion([self getStoredIPVersion]);
        }

    }
    else if (httpApi.tag == MGMMoviePlayerAliveApi)
    {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:httpApi.responseData
                                                            options:NSJSONReadingAllowFragments
                                                              error:nil];

        NSNumber *code = [dic mgu_objectOrNilForKey:@"code"];
        if (code.integerValue == 200)
        {
            NSDictionary *body = [dic mgu_objectOrNilForKey:@"body"];
            NSDictionary *playerInfo = [body mgu_objectOrNilForKey:@"PLAYER_KEEP_ALIVE_ENABLE_MOVIE"];
            NSString *paramValue = [playerInfo mgu_objectOrNilForKey:@"paramValue"];
            if (![paramValue isKindOfClass:[NSNull class]] && paramValue)
            {
                NSDictionary *paramInfo = [NSDictionary mgu_dictionaryWithJSONString:paramValue];
                NSString *result = [paramInfo mgu_objectOrNilForKey:@"httpKeepAlive"];
                if ([result isEqualToString:@"true"])
                {
                    self.keepLiveStatus = MGMPlayerKeepLiveStatusEnable;
                }
                else
                {
                    self.keepLiveStatus = MGMPlayerKeepLiveStatusDisable;
                }
            }
            else
            {
                self.keepLiveStatus = MGMPlayerKeepLiveStatusDisable;
            }
            [self savePlayerKeepLiveStatus:self.keepLiveStatus];
        }
        
        BOOL keepAlive = (MGMPlayerKeepLiveStatusEnable == self.keepLiveStatus);
        !self.keepLiveCompletion ?: self.keepLiveCompletion(keepAlive);
    }
}

- (void)httpApiFailed:(__kindof MGUHttpApi *)httpApi
{
    if (httpApi.tag == KMGMIPVersionApi)
    {
        //获取失败默认使用ipv4
        self.ipVersion = MGMDEnvironmentIPVersionV4;
        [self configIPVersion:MGMDEnvironmentIPVersionV4];
        if (self.completion)
        {
            self.completion([self getStoredIPVersion]);
        }
    }
    else if (httpApi.tag == MGMMoviePlayerAliveApi)
    {
        self.keepLiveStatus = MGMPlayerKeepLiveStatusDisable;
        [self savePlayerKeepLiveStatus:self.keepLiveStatus];
        !self.keepLiveCompletion ?: self.keepLiveCompletion(NO);
    }
}



@end

@implementation MGMDEnvironment (MGMAppInfo)


/*
 获取当前正在审核的版本号
 */
- (nullable NSString *)reviewVersion
{
    id version = [[MGUKeyValueStore defaultStore] getObjectForKey:MGMDEnvironment_ReviewVersion];
    if ([version isKindOfClass:[NSString class]])
    {
        NSString *fidddenVesrion = (NSString *)version;
        
        //当前版本为审核版本时，返回改版本
        if ([fidddenVesrion isEqualToString:[self innerAppVersion]]) {
            return  (NSString *)version;
        }
        else
            return nil;
        
    }
    else
    {
        return nil;
    }
}

/*
 配置当前审核版本
 */
- (void)configReviewVersion:(NSString *)version
{
    if (version.length > 0) {
        [[MGUKeyValueStore defaultStore] setObject:version forKey:MGMDEnvironment_ReviewVersion];
    }
}

- (NSComparisonResult)currenInnerAppVersionCompare:(NSString *)comparedVersion
{
    if (comparedVersion.length != 10 || self.innerAppVersion.length != 10) {
        return NSOrderedDescending;
    }
    
//    //取消最后两位 灰度标志和紧急版本号标志
//    NSMutableString *convertVerion = [NSMutableString stringWithString:comparedVersion];
//
//    //参照十位版本号定义，最后两位为灰度标志和紧急版本号标志
//    NSString *resutlVer = [convertVerion stringByReplacingCharactersInRange:NSMakeRange(8, 2) withString:@"00"];
    
    
//    NSString *currentResutVer = [[NSMutableString stringWithString:self.innerAppVersion] stringByReplacingCharactersInRange:NSMakeRange(8, 2) withString:@"0"];
    
    return [self.innerAppVersion compare:comparedVersion];
}

/**
 对外app版本号。 返回info.plist中定义的版本号
 */
- (NSString *)outerAppVersion
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"sys-clientVersion"];
}


/**
 内部版本号.
 */
- (NSString *)innerAppVersion
{
    return [self innerAppVersionFromOuter:[self outerAppVersion]];
}

- (NSString *)innerAppVersionFromOuter:(NSString *)outerVer
{
    NSString * innerVer = nil;
    NSInteger verCount = 0;
    NSArray *versionParts = [outerVer componentsSeparatedByString:@"."];
    
    NSInteger partCount = versionParts.count;
    
    //>=3 是为了支持中间小版本,比如5.0.2.1
    if (partCount >= 3)
    {
        NSString *bigVer = versionParts[0];
        NSString *midVer = versionParts[1];
        NSString *smallVer = versionParts[2];
        NSString *urgentIndex;
        if (partCount == 4) {
            urgentIndex = versionParts[3];
        }
        
        //5.0.x
        if ([bigVer isEqualToString:@"5"] && [midVer isEqualToString:@"0"])
        {
            verCount = smallVer.integerValue;
            
            //5.0.0 ~ 5.0.3
            if ((verCount >= 0) && (verCount <= 3))
            {
                if (verCount == 3)
                {
                    verCount -= 1;
                    innerVer = [NSString stringWithFormat:@"650000%02zd", verCount];
                }
                else
                {
                    innerVer = [NSString stringWithFormat:@"650000%02zd", verCount];
                }
            }
            else
            {
                innerVer = [self innerVersionWithVerCount:verCount urgentIndex:urgentIndex];

                
//                //紧急版本
//                if (urgentIndex.length > 0)
//                {
//                    //10位客户端id
//                    innerVer = [self urgentVersion10CodeWithCount:verCount index:urgentIndex.integerValue];
//
//                }
//                else
//                {
//                    //10位客户端id
//                    innerVer = [self version10CodeWithCount:verCount];
//
//                }
            }
        }
        
        //5.1.x
        else if ([bigVer isEqualToString:@"5"] && [midVer isEqualToString:@"1"])
        {
            verCount = kMaxVersionsCountFor500 + smallVer.integerValue + 1;
            
            //紧急版本
            innerVer = [self innerVersionWithVerCount:verCount urgentIndex:urgentIndex];
        }

    }
    
    //NSLog(@"outer = %@, innner = %@", outerVer, innerVer);
    if (!innerVer)
    {
        //NSLog(@"no innerVersior for outerVer:%@. configuration \"sys-clientVersion\" in info.plist", outerVer);
        assert(0);
    }
    
    return innerVer;
}


- (NSString *)innerVersionWithVerCount:(NSInteger)verCount urgentIndex:(NSString *)index
{
    NSString *innerVersion;
    if (index.length > 0) {
        innerVersion = [self urgentVersion10CodeWithCount:verCount index:index.integerValue];
    }
    else {
        innerVersion = [self version10CodeWithCount:verCount];
    }
    
    return innerVersion;
}

/*
 十位编码格式版本号
 */
- (NSString *)version10CodeWithCount:(NSInteger)verCount
{
    return [NSString stringWithFormat:@"650400%02zd00", verCount];
}

/*
 紧急十位编码格式版本号
 */
- (NSString *)urgentVersion10CodeWithCount:(NSInteger)verCount index:(NSInteger)index
{
    return [NSString stringWithFormat:@"650400%02zd%zd0", verCount, index];
}

- (NSString *)uuid
{
    CFUUIDRef uuidRef = CFUUIDCreate(kCFAllocatorDefault);
    CFStringRef strRef = CFUUIDCreateString(kCFAllocatorDefault , uuidRef);
    NSString *uuidString = [(__bridge NSString*)strRef stringByReplacingOccurrencesOfString:@"-" withString:@""];
    CFRelease(strRef);
    CFRelease(uuidRef);
    return uuidString;
}

- (NSString *)clientId
{
    NSString *clientId;

    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    if ([userDefault valueForKey:MGMDEnvironment_CLIENTID_KEY]) {
        clientId = [userDefault valueForKey:MGMDEnvironment_CLIENTID_KEY];
    } else {
        NSString *deviceId = [[UIDevice currentDevice].identifierForVendor UUIDString]?:[[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
        NSArray *strings = [deviceId componentsSeparatedByString:@"-"];
        clientId = [strings componentsJoinedByString:@""];
        [userDefault setValue:clientId forKey:MGMDEnvironment_CLIENTID_KEY];
        [userDefault synchronize];
    }
    
    return clientId;
}


- (NSString *)SDKCEId
{
    return @"d2855eb2-1d76-417e-a8f0-5e0b0fa3af6d";
}

- (NSString *)channelId
{
    return [NSString stringWithFormat:@"%@-99000-700200000000008",[self innerAppVersion]];
}

- (NSString *)commonUniversalLink
{
    return @"https://static.miguvideo.com/gotoapp/";
}

- (NSString *)qqUniversalLink
{
    return @"https://static.miguvideo.com/qq_conn/1106156089/";
}

@end








