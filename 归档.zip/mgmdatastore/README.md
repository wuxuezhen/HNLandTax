# MGMDataStore

[![CI Status](https://img.shields.io/travis/renyi/MGMDataStore.svg?style=flat)](https://travis-ci.org/renyi/MGMDataStore)
[![Version](https://img.shields.io/cocoapods/v/MGMDataStore.svg?style=flat)](https://cocoapods.org/pods/MGMDataStore)
[![License](https://img.shields.io/cocoapods/l/MGMDataStore.svg?style=flat)](https://cocoapods.org/pods/MGMDataStore)
[![Platform](https://img.shields.io/cocoapods/p/MGMDataStore.svg?style=flat)](https://cocoapods.org/pods/MGMDataStore)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MGMDataStore is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MGMDataStore'
```

## Author

renyi, renyi@migu.cn

## License

MGMDataStore is available under the MIT license. See the LICENSE file for more info.
