//
//  MGMDataStore_ExampleTests.m
//  MGMDataStore_ExampleTests
//
//  Created by RenYi on 2019/10/16.
//  Copyright © 2019 renyi. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <MGMDataStore/MGMDEnvironment.h>


@interface MGMDEnvironment (Test)

- (void)clearIPVersion;
- (MGMDEnvironmentIPVersion)getStoredIPVersion;
- (NSString *)innerAppVersionFromOuter:(NSString *)outerVer;
@end

@interface MGMDataStore_ExampleTests : XCTestCase

@property (nonatomic, copy) NSArray *versions;

@end

@implementation MGMDataStore_ExampleTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
    //初始化本地信息
    [[MGMDEnvironment shareEnvironment] clearIPVersion];
    NSLog(@"initial version = %zd", [[MGMDEnvironment shareEnvironment] getStoredIPVersion]);
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}


- (void)testInnerVersionCompareLittle
{
    self.versions = @[@"6504001700",@"6504001800",@"6504001701",@"6504001900",@"6504002000",@"6504009900",@"6504001601"];
    
    for (NSString *aVer in self.versions) {
        
        NSComparisonResult result = [[MGMDEnvironment shareEnvironment] currenInnerAppVersionCompare:aVer];
        
        XCTAssert(result == NSOrderedAscending, @"__func:%s__, %@ error", __func__, aVer);
    }
}

- (void)testInnerVersionCompareBig
{
    self.versions = @[@"6504001500",@"6504001500",@"6504000901",@"6504000100"];
    for (NSString *aVer in self.versions) {
        
        NSComparisonResult result = [[MGMDEnvironment shareEnvironment] currenInnerAppVersionCompare:aVer];
        
        XCTAssert(result == NSOrderedDescending, @"__func:%s__, %@ error", __func__, aVer);
    }

}

- (void)testInnerVersionCompareEqual
{
    self.versions = @[@"6504001600"];
    for (NSString *aVer in self.versions) {
        
        NSComparisonResult result = [[MGMDEnvironment shareEnvironment] currenInnerAppVersionCompare:aVer];
        
        XCTAssert(result == NSOrderedSame, @"__func:%s__, %@ error", __func__, aVer);
    }

}

- (void)testInnerVersionCompareFail
{
    
}

//- (void)testFirstFetch {
//
//    XCTestExpectation *expect = [self expectationWithDescription:@"time out"];
//
//    __block MGMDEnvironmentIPVersion remoteIPVersioin = MGMDEnvironmentIPVersionInvalid;
//    [[MGMDEnvironment shareEnvironment] fetchIPVersionCompletion:^(MGMDEnvironmentIPVersion ipVersion) {
//
//        remoteIPVersioin = ipVersion;
//        [expect fulfill];
//    }];
//
//    [self waitForExpectationsWithTimeout:10 handler:^(NSError * _Nullable error) {
//
//        MGMDEnvironmentIPVersion localVersion = [[MGMDEnvironment shareEnvironment] getStoredIPVersion];
//
//        XCTAssert(localVersion == remoteIPVersioin, @"localVersion = %ld, remoteIPVersioin = %ld", localVersion, remoteIPVersioin);
//
//    }];
//}
//
//- (void)testSecondFetch {
//
//    XCTestExpectation *expect = [self expectationWithDescription:@"time out"];
//
//    __block MGMDEnvironmentIPVersion remoteIPVersioin = MGMDEnvironmentIPVersionInvalid;
//    [[MGMDEnvironment shareEnvironment] fetchIPVersionCompletion:^(MGMDEnvironmentIPVersion ipVersion) {
//
//        remoteIPVersioin = ipVersion;
//        [expect fulfill];
//    }];
//
//    [self waitForExpectationsWithTimeout:10 handler:^(NSError * _Nullable error) {
//
//        MGMDEnvironmentIPVersion localVersion = [[MGMDEnvironment shareEnvironment] getStoredIPVersion];
//
//        XCTAssert(localVersion == remoteIPVersioin, @"localVersion = %ld, remoteIPVersioin = %ld", localVersion, remoteIPVersioin);
//
//    }];
//}
//
//- (void)test5092VerId
//{
//    NSString *outVersion = @"5.0.9.2";
//    NSString *innerVersion = [[MGMDEnvironment shareEnvironment] innerAppVersionFromOuter:outVersion];
//    XCTAssert([innerVersion isEqualToString:@"6504000920"], @"outVersion %@ with innerVersion %@ error", outVersion, innerVersion);
//}
//
//- (void)test5010VerId
//{
//    NSString *outVersion = @"5.0.10";
//    NSString *innerVersion = [[MGMDEnvironment shareEnvironment] innerAppVersionFromOuter:outVersion];
//    XCTAssert([innerVersion isEqualToString:@"6504001000"], @"outVersion %@ with innerVersion %@ error", outVersion, innerVersion);
//}
//
//- (void)test51xVerid
//{
//    NSDictionary *outAndIn = @{@"5.1.0":@"6504001100",
//                               @"5.1.1":@"6504001200",
//                               @"5.1.2":@"6504001300",
//                               @"5.1.3":@"6504001400",
//                               @"5.1.4":@"6504001500",
//                               @"5.1.5":@"6504001600",
//                               @"5.1.6":@"6504001700",
//                               @"5.1.7":@"6504001800",
//                               @"5.1.8":@"6504001900",
//                               @"5.1.9":@"6504002000"};
//    NSArray * outVersions = [outAndIn allKeys];
//
//    for (NSString *aOut in outVersions) {
//
//        NSString *innerVersion = [[MGMDEnvironment shareEnvironment] innerAppVersionFromOuter:aOut];
//        NSString *standInner = [outAndIn objectForKey:aOut];
//        XCTAssert([innerVersion isEqualToString:standInner], @"outVersion %@ with innerVersion %@ error", aOut, innerVersion);
//    }
//}


- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end


