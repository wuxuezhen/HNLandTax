//
//  main.m
//  MGMDataStore
//
//  Created by renyi on 12/06/2018.
//  Copyright (c) 2018 renyi. All rights reserved.
//

@import UIKit;
#import "MGMDSAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MGMDSAppDelegate class]));
    }
}
