//
//  MGMDSViewController.h
//  MGMDataStore
//
//  Created by renyi on 12/06/2018.
//  Copyright (c) 2018 renyi. All rights reserved.
//

@import UIKit;

@interface MGMDSViewController : UIViewController

@end
