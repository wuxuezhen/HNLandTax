//
//  MGMDSAppDelegate.h
//  MGMDataStore
//
//  Created by renyi on 12/06/2018.
//  Copyright (c) 2018 renyi. All rights reserved.
//

@import UIKit;

@interface MGMDSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
