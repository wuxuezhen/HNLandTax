//
//  MGMDSViewController.m
//  MGMDataStore
//
//  Created by renyi on 12/06/2018.
//  Copyright (c) 2018 renyi. All rights reserved.
//

#import "MGMDSViewController.h"

@interface MGMDSViewController ()

@end

@implementation MGMDSViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
