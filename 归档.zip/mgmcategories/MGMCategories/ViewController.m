//
//  ViewController.m
//  MGMCategories
//
//  Created by zhaohao on 2018/12/3.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "ViewController.h"
#import "UIControl+MGMExtension.h"
#import "NSString+MGMValidation.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    btn.backgroundColor = [UIColor redColor];
    [self.view addSubview:btn];
    btn.mgm_acceptEventInterval = 5;
    [btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    NSString *temp = nil;
    temp =@"  sfsff sff";
     NSString *ss = [temp mgm_stringByTrimmingLeftAndRightCharacters];
    NSLog(@"%@",ss);
}

- (void)btnclick
{
    NSLog(@"dayin");
}


@end
