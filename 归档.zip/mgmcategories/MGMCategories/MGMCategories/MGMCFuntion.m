//
//  MGMCFuntion.m
//  MGMCategories
//
//  Created by WangDa Mac on 2019/2/28.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCFuntion.h"
#import <Foundation/Foundation.h>
/**
 2019-02-28
 http://confluence.cmvideo.cn/confluence/pages/viewpage.action?pageId=18661289
 评分星星显示规则如下：
 <=3分，1星
 <=5分，2星
 <=7分，3星
 <=9分，4星
 >9分，5星
 
 
 2019-03-07
 评分星星显示规则如下：
 <=2分，1星  非常差
 <=4分，2星  比较差
 <=6分，3星  一般般「默认值」
 <=8分，4星  很不错
 >8分， 5星 非常棒
 */
extern int categories_starCountWithScore(double score);
