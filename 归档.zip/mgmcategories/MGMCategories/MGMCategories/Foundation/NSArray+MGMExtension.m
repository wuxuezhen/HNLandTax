//
//  NSArray+MGMExtension.m
//  BuDeJie
//
//  Created by MyMac on 2018/11/7.
//  Copyright © 2018年 L_m. All rights reserved.
//

#import "NSArray+MGMExtension.h"

@implementation NSArray (MGMExtension)

+ (NSArray *)mgm_arrayWithClassName:(NSString *)className
                          plistName:(NSString *)plistName
{
    Class cls = NSClassFromString(className);
    NSAssert(cls, @"class is not exist");
    
    NSString *path = [[NSBundle mainBundle] pathForResource:plistName ofType:nil];
    NSArray *array = [[NSArray alloc] initWithContentsOfFile:path];
    NSMutableArray *modelM = [NSMutableArray arrayWithCapacity:array.count];
    for (NSDictionary *dict in array) {
        id obj = [[cls alloc] init];
        [obj setValuesForKeysWithDictionary:dict];
        [modelM addObject:obj];
    }
    return [modelM copy];
}

#ifdef DEBUG

- (NSString *)descriptionWithLocale:(id)locale indent:(NSUInteger)level
{
    NSMutableString *mStr = [NSMutableString string];
    NSMutableString *tab = [NSMutableString stringWithString:@""];
    for (int i = 0; i < level; i++) {
        [tab appendString:@"\t"];
    }
    [mStr appendString:@"(\n"];
    for (int i = 0; i < self.count; i++) {
        NSString *lastSymbol = (self.count == i + 1) ? @"":@",";
        id value = self[i];
        if ([value respondsToSelector:@selector(descriptionWithLocale:indent:)]) {
            [mStr appendFormat:@"\t%@%@%@\n",tab,[value descriptionWithLocale:locale indent:level + 1],lastSymbol];
        } else {
            [mStr appendFormat:@"\t%@%@%@\n",tab,value,lastSymbol];
        }
    }
    [mStr appendFormat:@"%@)",tab];
    return mStr;
}

#endif

@end
