//
//  NSString+MGMDecimalNumber.m
//  MGMCategories
//
//  Created by ww on 2019/1/30.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "NSString+MGMDecimalNumber.h"

@implementation NSString (MGMDecimalNumber)
- (NSString *)priceByAdding:(NSString *)number
{
    NSDecimalNumber *numberA = [NSDecimalNumber decimalNumberWithString:self];
    NSDecimalNumber *numberB = [NSDecimalNumber decimalNumberWithString:number];
    if ([numberA compare:[NSDecimalNumber zero]] == NSOrderedSame || [[NSDecimalNumber notANumber] isEqualToNumber:numberA]) {
        return nil;
    }else{
        if ([numberB compare:[NSDecimalNumber zero]] == NSOrderedSame || [[NSDecimalNumber notANumber] isEqualToNumber:numberB]) {
            return numberA.stringValue;
        }
        NSDecimalNumber *result = [numberA decimalNumberByAdding:numberB];
        return result.stringValue;
        
    }
}

- (NSString *)priceBySubtracting:(NSString *)number
{
    NSDecimalNumber *numberA = [NSDecimalNumber decimalNumberWithString:self];
    NSDecimalNumber *numberB = [NSDecimalNumber decimalNumberWithString:number];
    if ([numberA compare:[NSDecimalNumber zero]] == NSOrderedSame || [[NSDecimalNumber notANumber] isEqualToNumber:numberA]) {
        return nil;
    }else{
        if ([numberB compare:[NSDecimalNumber zero]] == NSOrderedSame || [[NSDecimalNumber notANumber] isEqualToNumber:numberB]) {
            return numberA.stringValue;
        }
        NSDecimalNumber *result = [numberA decimalNumberBySubtracting:numberB];
        return result.stringValue;
        
    }
    
}

- (NSString *)priceByMultiplyingBy:(NSString *)number
{
    NSDecimalNumber *numberA = [NSDecimalNumber decimalNumberWithString:self];
    NSDecimalNumber *numberB = [NSDecimalNumber decimalNumberWithString:number];
    if ([numberA compare:[NSDecimalNumber zero]] == NSOrderedSame || [[NSDecimalNumber notANumber] isEqualToNumber:numberA]) {
        return nil;
    }else{
        if ([numberB compare:[NSDecimalNumber zero]] == NSOrderedSame || [[NSDecimalNumber notANumber] isEqualToNumber:numberB]) {
            return nil;
        }
        NSDecimalNumber *result = [numberA decimalNumberByMultiplyingBy:numberB];
        return result.stringValue;
        
    }
}

- (NSString *)priceByDividingBy:(NSString *)number
{
    NSDecimalNumber *numberA = [NSDecimalNumber decimalNumberWithString:self];
    NSDecimalNumber *numberB = [NSDecimalNumber decimalNumberWithString:number];
    if ([numberA compare:[NSDecimalNumber zero]] == NSOrderedSame || [[NSDecimalNumber notANumber] isEqualToNumber:numberA]) {
        return nil;
    }else{
        if ([numberB compare:[NSDecimalNumber zero]] == NSOrderedSame || [[NSDecimalNumber notANumber] isEqualToNumber:numberB]) {
            return nil;
        }
        NSDecimalNumber *result = [numberA decimalNumberByDividingBy:numberB];
        return result.stringValue;
        
    }
}
+(NSString *)notRounding:(NSString *)price afterPoint:(int)position roundingMode:(NSRoundingMode)roundingMode
{
    
    NSDecimalNumberHandler* roundingBehavior = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:roundingMode scale:position raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:YES];
    
    NSDecimalNumber *ouncesDecimal;
    
    NSDecimalNumber *roundedOunces;
    
    ouncesDecimal = [[NSDecimalNumber alloc] initWithString:price];
    
    roundedOunces = [ouncesDecimal decimalNumberByRoundingAccordingToBehavior:roundingBehavior];
    
    
    return [NSString stringWithFormat:@"%@",roundedOunces];
    
}
@end
