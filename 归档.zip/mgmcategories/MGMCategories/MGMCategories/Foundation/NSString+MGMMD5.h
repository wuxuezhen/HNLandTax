//
//  NSString+MGMMD5.h
//  MGMCategories
//
//  Created by MyMac on 2019/2/26.
//  Copyright © 2019年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MGMMD5)

/**
   MD5加密, 32位小写

 */
- (NSString *)mgm_md5ForLower32Bit;

/**
    MD5加密, 32位大写
 */
- (NSString *)mgm_md5ForUpper32Bit;

@end
