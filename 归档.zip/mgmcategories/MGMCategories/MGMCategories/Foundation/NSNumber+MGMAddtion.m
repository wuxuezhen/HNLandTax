//
//  NSNumber+MGMAddtion.m
//  MGMCategories
//
//  Created by YL on 2020/4/2.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "NSNumber+MGMAddtion.h"

@implementation NSNumber (MGMAddtion)

- (CGFloat)mgm_safe_divideBy:(CGFloat)divideNum {
    if(divideNum <= 0) {
        return self.floatValue;
    }
    return self.floatValue / divideNum;
}

@end
