//
//  NSObject+MGMSwizzle.m
//  MGMCategories
//
//  Created by YL on 2019/1/11.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "NSObject+MGMSwizzle.h"
#import <objc/runtime.h>

@implementation NSObject (MGMSwizzle)

+ (BOOL)overrideClass:(Class)aClass method:(SEL)aOrigSel withMethod:(SEL)aAltSel
{
    Method origMethod = class_getInstanceMethod(aClass, aOrigSel);
    if (!origMethod) {
        return NO;
    }
    
    Method altMethod = class_getInstanceMethod(aClass, aAltSel);
    if (!altMethod) {
        return NO;
    }
    
    method_setImplementation(origMethod, method_getImplementation(altMethod));
    
    return YES;
}

+ (BOOL)overrideClass:(Class)aClass classMethod:(SEL)aOrigSel withClassMethod:(SEL)aAltSel
{
    Method origMethod = class_getClassMethod(aClass, aOrigSel);
    if (!origMethod) {
        return NO;
    }
    
    Method altMethod = class_getClassMethod(aClass, aAltSel);
    if (!altMethod) {
        return NO;
    }
    
    method_setImplementation(origMethod, method_getImplementation(altMethod));
    
    return YES;
}

+ (BOOL)exchangeClass:(Class)aClass method:(SEL)aOrigSel withMethod:(SEL)aAltSel
{
    Method origMethod = class_getInstanceMethod(aClass, aOrigSel);
    if (!origMethod) {
        return NO;
    }
    
    Method altMethod = class_getInstanceMethod(aClass, aAltSel);
    if (!altMethod) {
        return NO;
    }
    
    method_exchangeImplementations(origMethod, altMethod);
    
    return YES;
}

+ (BOOL)exchangeClass:(Class)aClass classMethod:(SEL)aOrigSel withClassMethod:(SEL)aAltSel
{
    Method origMethod = class_getClassMethod(aClass, aOrigSel);
    if (!origMethod) {
        return NO;
    }
    
    Method altMethod = class_getClassMethod(aClass, aAltSel);
    if (!altMethod) {
        return NO;
    }
    
    method_exchangeImplementations(origMethod, altMethod);
    
    return YES;
}

@end
