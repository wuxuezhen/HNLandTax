//
//  NSAttributedString+MGMAttributeExtension.h
//  MGMTicket
//
//  Created by ww on 2018/11/28.
//  Copyright © 2018 wdlzh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSAttributedString (MGMAttributeExtension)

+ (NSAttributedString *)mgm_attributedStringWithStringArray:(NSArray<NSString *> *)stringArray attributedArray:(NSArray<NSDictionary *> *)attributedArray;

/**
    根据字符串生成富文本
 
 @param string              字符串
 @param color               颜色
 @param fontSize            字体尺寸
 @param fontName            字体名字
 @param lineSpace           行间距
 @param firstLineHeadIndent 首行缩进
 @return 富文本
 */
+ (NSAttributedString *)mgm_attrTextWithString:(NSString *)string
                                         color:(UIColor *)color
                                      fontSize:(CGFloat)fontSize
                                      fontName:(NSString *)fontName
                                     lineSpace:(CGFloat)lineSpace
                           firstLineHeadIndent:(CGFloat)firstLineHeadIndent;

/**
    计算富文本的显示尺寸
 
 @param containerSize 指定范围
 @param textRowNum    文本行数
 @return 文本显示范围
 */
- (CGSize)mgm_textBoundingSizeWithContainerSize:(CGSize)containerSize textRowNum:(NSInteger)textRowNum;

@end

NS_ASSUME_NONNULL_END
