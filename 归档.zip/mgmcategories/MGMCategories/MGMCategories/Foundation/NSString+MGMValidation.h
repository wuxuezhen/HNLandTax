//
//  NSString+MGMValidation.h
//  MGMCategories
//
//  Created by RenYi on 2018/12/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (MGMValidation)


/**
 去掉字符串中的所有空格

 @return 新生成的无空格的字符串
 */
- (NSString *)trimmingWhiteSpace;


/**
 检测是否为手机号

 @return YES 是手机号；NO不是手机号
 */
- (BOOL)isPhoneNumber;
///判断字符串是否是纯数字
- (BOOL)mgm_judgeIsNumberByRegularExpression;
///价格字符串 分为单位 传入1450 -> 14.5
-(NSString *)formatPriceStrWithDecimalPoint;

///去除字符串首尾连续字符（如空格）
- (NSString *)mgm_stringByTrimmingLeftAndRightCharacters;
/// 传入时间戳字符串 1577260235604 根据业务需求，获取对应的时间
- (NSString *)mgm_timeStampStrToUGCTimeString;

@end

NS_ASSUME_NONNULL_END
