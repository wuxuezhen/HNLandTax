//
//  NSArray+MGMExtension.h
//  BuDeJie
//
//  Created by MyMac on 2018/11/7.
//  Copyright © 2018年 L_m. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (MGMExtension)

/**
    将plist中的字典数组转为模型数组
 
 @param className 模型类名
 @param plistName plist名字
 @return 模型数组
 */
+ (NSArray *)mgm_arrayWithClassName:(NSString *)className
                          plistName:(NSString *)plistName;

@end
