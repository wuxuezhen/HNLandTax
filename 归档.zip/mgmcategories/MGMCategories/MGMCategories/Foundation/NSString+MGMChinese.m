//
//  NSString+MGMChinese.m
//  MGMCategories
//
//  Created by ww on 2019/8/7.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "NSString+MGMChinese.h"

@implementation NSString (MGMChinese)
- (BOOL)mgm_isChinese
{
    NSString *match = @"(^[\u4e00-\u9fa5]+$)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF matches %@", match];
    return [predicate evaluateWithObject:self];
}

- (BOOL)mgm_includeChinese
{
    for(int i=0; i< [self length];i++)
    {
        int a =[self characterAtIndex:i];
        if( a >0x4e00&& a <0x9fff){
            return YES;
        }
    }
    return NO;
}
@end
