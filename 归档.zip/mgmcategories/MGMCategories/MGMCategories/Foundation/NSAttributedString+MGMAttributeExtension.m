//
//  NSAttributedString+MGMAttributeExtension.m
//  MGMTicket
//
//  Created by ww on 2018/11/28.
//  Copyright © 2018 wdlzh. All rights reserved.
//

#import "NSAttributedString+MGMAttributeExtension.h"
#import <YYText/YYText.h>

@implementation NSAttributedString (MGMAttributeExtension)

+ (NSAttributedString *)mgm_attributedStringWithStringArray:(NSArray<NSString *> *)stringArray attributedArray:(NSArray<NSDictionary *> *)attributedArray
{
    NSAssert(stringArray.count == attributedArray.count, @"字符串数组和属性字典数组大小必须一致");
    NSMutableAttributedString *retStr = [[NSMutableAttributedString alloc] init];
    for (NSInteger i = 0; i < stringArray.count; i++) {
        NSString *str = stringArray[i];
        NSDictionary *dict = attributedArray[i];
        NSAttributedString *attributedString = [[NSAttributedString alloc] initWithString:str attributes:dict];
        [retStr appendAttributedString:attributedString];
    }
    return retStr;
}

+ (NSAttributedString *)mgm_attrTextWithString:(NSString *)string
                                         color:(UIColor *)color
                                      fontSize:(CGFloat)fontSize
                                      fontName:(NSString *)fontName
                                     lineSpace:(CGFloat)lineSpace
                           firstLineHeadIndent:(CGFloat)firstLineHeadIndent
{
    fontName = fontName ?: @"PingFangSC-Medium";
    NSMutableAttributedString *attrTitleM = [[NSMutableAttributedString alloc] initWithString:string];
    attrTitleM.yy_font = [UIFont fontWithName:fontName size:fontSize];
    attrTitleM.yy_color = color;
    attrTitleM.yy_lineSpacing = lineSpace;
    attrTitleM.yy_firstLineHeadIndent = firstLineHeadIndent;
    return attrTitleM;
}

- (CGSize)mgm_textBoundingSizeWithContainerSize:(CGSize)containerSize textRowNum:(NSInteger)textRowNum
{
    YYTextContainer *container = [YYTextContainer containerWithSize:containerSize];
    if (textRowNum)
    {
        container.maximumNumberOfRows = 2.f;
    }
    YYTextLayout *layout = [YYTextLayout layoutWithContainer:container text:self];
    return layout.textBoundingSize;
}

@end
