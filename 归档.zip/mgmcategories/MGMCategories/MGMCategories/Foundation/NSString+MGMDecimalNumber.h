//
//  NSString+MGMDecimalNumber.h
//  MGMCategories
//
//  Created by ww on 2019/1/30.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (MGMDecimalNumber)
/** 加*/
- (NSString *)priceByAdding:(NSString *)number;

/** 减*/
- (NSString *)priceBySubtracting:(NSString *)number;

/** 乘*/
- (NSString *)priceByMultiplyingBy:(NSString *)number;

/**除*/
- (NSString *)priceByDividingBy:(NSString *)number;

+(NSString *)notRounding:(NSString *)price afterPoint:(int)position roundingMode:(NSRoundingMode)roundingMode;
@end

NS_ASSUME_NONNULL_END
