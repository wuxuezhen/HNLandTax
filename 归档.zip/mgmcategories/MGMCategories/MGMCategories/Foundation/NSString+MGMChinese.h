//
//  NSString+MGMChinese.h
//  MGMCategories
//
//  Created by ww on 2019/8/7.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (MGMChinese)

///判断是否是纯汉字
- (BOOL)mgm_isChinese;

///判断是否含有汉字
- (BOOL)mgm_includeChinese;

@end

NS_ASSUME_NONNULL_END
