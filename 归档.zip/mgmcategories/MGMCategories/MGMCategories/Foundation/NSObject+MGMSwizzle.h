//
//  NSObject+MGMSwizzle.h
//  MGMCategories
//
//  Created by YL on 2019/1/11.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (MGMSwizzle)

+ (BOOL)overrideClass:(Class)aClass method:(SEL)aOrigSel withMethod:(SEL)aAltSel;

+ (BOOL)overrideClass:(Class)aClass classMethod:(SEL)aOrigSel withClassMethod:(SEL)aAltSel;

+ (BOOL)exchangeClass:(Class)aClass method:(SEL)aOrigSel withMethod:(SEL)aAltSel;

+ (BOOL)exchangeClass:(Class)aClass classMethod:(SEL)aOrigSel withClassMethod:(SEL)aAltSel;

@end

NS_ASSUME_NONNULL_END
