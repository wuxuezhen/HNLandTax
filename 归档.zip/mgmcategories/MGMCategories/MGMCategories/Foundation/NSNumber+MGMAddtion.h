//
//  NSNumber+MGMAddtion.h
//  MGMCategories
//
//  Created by YL on 2020/4/2.
//  Copyright © 2020 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSNumber (MGMAddtion)

/// NSNumber 值分割方法,除法运算
/// @param divideNum 等分数量
- (CGFloat)mgm_safe_divideBy:(CGFloat)divideNum;

@end

NS_ASSUME_NONNULL_END
