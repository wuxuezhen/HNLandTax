//
//  NSDictionary+MGMDictionaryExtension.h
//  MGMTicket
//
//  Created by 刘志辉 on 2018/11/26.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (MGMDictionaryExtension)

/**
 *  @method
 *
 *  @brief         获取字符串
 *  @param  key    key(NSString)值
 *  @return        NSString值
 */
- (NSString*)stringForKey:(NSString*)key;

/**
 *  @method
 *
 *  @brief         获取数组
 *  @param  key    key(NSString)值
 *  @return        NSArray值
 */
- (NSArray*)arrayForKey:(NSString*)key;

/**
 *  @method
 *
 *  @brief         获取字典
 *  @param  key    key(NSString)值
 *  @return        NSDictionary值
 */
- (NSDictionary*)dictionaryForKey:(NSString*)key;

/**
 *  @method
 *
 *  @brief         获取NSNumber类型值
 *  @param  key    key(NSString)值
 *  @return        NSNumber值
 */
- (NSNumber*)numberForKey:(NSString*)key;

/**
 *  @method
 *
 *  @brief         获取int值
 *  @param  key    key(NSString)值
 *  @return        int值
 */
- (int)intValueForKey:(NSString*)key;

/**
 *  @method
 *
 *  @brief         获取int64_t值
 *  @param  key    key(NSString)值
 *  @return        int64_t值
 */
- (int64_t)int64ValueForKey:(NSString*)key;

/**
 *  @method
 *
 *  @brief         获取BOOL值
 *  @param  key    key(NSString)值
 *  @return        BOOL值
 */
- (BOOL)boolValueForKey:(NSString*)key;

/**
 *  @method
 *
 *  @brief         获取NSInteger值
 *  @param  key    key(NSString)值
 *  @return        NSInteger值
 */
- (NSInteger)integerValueForKey:(NSString*)key;

@end

NS_ASSUME_NONNULL_END
