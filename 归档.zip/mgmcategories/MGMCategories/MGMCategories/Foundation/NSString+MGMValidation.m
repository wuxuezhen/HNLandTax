//
//  NSString+MGMValidation.m
//  MGMCategories
//
//  Created by RenYi on 2018/12/20.
//

#import "NSString+MGMValidation.h"

@implementation NSString (MGMValidation)

///价格字符串 分为单位
-(NSString *)formatPriceStrWithDecimalPoint
{
     NSString *priceStr;
    if( self.integerValue % 100  >= 1)
    {
        priceStr =  [NSString stringWithFormat:@"%.02f",self.integerValue/100.0];
        NSArray *array = [priceStr componentsSeparatedByString:@"."];
        NSString *str = array.lastObject;
        for(int i =0; i < [str length]; i++)
        {
            NSString *temp = [str substringWithRange:NSMakeRange(i, 1)];
            if (i == 1)
            {
                if([temp isEqualToString:@"0"])
                {
                    priceStr =  [NSString stringWithFormat:@"%.01f",self.integerValue/100.0];

                    break;
                }
            }
            
        }
        
    }
    else
    {
        priceStr =  [NSString stringWithFormat:@"%ld",self.integerValue/100];
    }
    return priceStr;
}

- (NSString *)trimmingWhiteSpace
{
    return [self stringByReplacingOccurrencesOfString:@" " withString:@""];
}

/**
 检测是否为手机号。目前需求为1开头11位数就可以。11.20 2018
 
 @return YES 是手机号；NO不是手机号
 */
- (BOOL)isPhoneNumber
{
    if ([self hasPrefix:@"1"] && (self.length == 11))
        return YES;
    else
        return NO;
    
}
- (BOOL)mgm_judgeIsNumberByRegularExpression
{
    if (self.length == 0) {
        return NO;
    }
    NSString *regex = @"[0-9]*";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([pred evaluateWithObject:self]) {
        return YES;
    }
    return NO;
}
///去除字符串首尾连续字符（如空格）
- (NSString *)mgm_stringByTrimmingLeftAndRightCharacters
{
    return [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (NSString *)mgm_timeStampStrToUGCTimeString
{
    NSString *timeSp = self;
    double beTime = [timeSp integerValue]/1000.0;

    NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
    double distanceTime = now - beTime;
    NSString * distanceStr;

    NSDate * beDate = [NSDate dateWithTimeIntervalSince1970:beTime];
    NSDateFormatter * df = [[NSDateFormatter alloc]init];
    [df setDateFormat:@"HH:mm"];
    // NSString * timeStr = [df stringFromDate:beDate];

    [df setDateFormat:@"dd"];
    NSString * nowDay = [df stringFromDate:[NSDate date]];
    NSString * lastDay = [df stringFromDate:beDate];

    [df setDateFormat:@"HH"];
    //计算时
    NSString * hourStr = [df stringFromDate:beDate];
//    NSString *nowHourStr = [df stringFromDate:[NSDate date]];

    [df setDateFormat:@"mm"];
    //计算时
//    NSString * minuteStr = [df stringFromDate:beDate];

    NSString *nowMinuteStr = [df stringFromDate:[NSDate date]];

     if (distanceTime < 60) {//小于一分钟
            distanceStr = @"刚刚";
        }
        else if (distanceTime <60*60) {//时间小于一个小时
            distanceStr = [NSString stringWithFormat:@"%ld分钟",(long)distanceTime/60];
        }
        else if(distanceTime <24*60*60){//时间小于一天
            distanceStr = [NSString stringWithFormat:@"%ld小时",(long)distanceTime/(60*60)];
        }
        else if (([nowDay integerValue] - [lastDay integerValue] ==1 || ([lastDay integerValue] - [nowDay integerValue] > 10 && [nowDay integerValue] == 1)) && distanceTime<48*60*60) {
            distanceStr = [NSString stringWithFormat:@"1天前"];//timeStr
        }
        else if ((([nowDay integerValue] - [lastDay integerValue] ==2) || ([lastDay integerValue] - [nowDay integerValue] > 10)) && (distanceTime <= (24*60*60*2 + [hourStr integerValue] *60*60 + [nowMinuteStr integerValue] *60 ))){
            distanceStr = [NSString stringWithFormat:@"2天前"];//timeStr
        }

    else
    {
        NSCalendar *calendar = [NSCalendar currentCalendar];
         int unit = NSCalendarUnitYear;
         // 1.获得当前时间的年月日
         NSDateComponents *nowCmps = [calendar components:unit fromDate:[NSDate date]];
         // 2.获得self的年月日
         NSDateComponents *selfCmps = [calendar components:unit fromDate:beDate];
        //判断是否是同一年的
        if (nowCmps.year == selfCmps.year) {
            [df setDateFormat:@"MM-dd"];
        }else{
            [df setDateFormat:@"yyyy-MM-dd"];
        }
        distanceStr = [df stringFromDate:beDate];
        

//        [df setDateFormat:@"MM-dd"];
//        distanceStr = [df stringFromDate:beDate];
    }

    return distanceStr;

    }

@end
