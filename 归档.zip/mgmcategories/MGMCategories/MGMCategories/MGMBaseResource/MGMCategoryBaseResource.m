//
//  MGMCategoryBaseResource.m
//  Test
//
//  Created by apple on 2018/12/10.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMCategoryBaseResource.h"

typedef NSString *MGMCategoryResourceKey NS_EXTENSIBLE_STRING_ENUM;

MGMCategoryResourceKey const MGMCategoryResourceKeyPNG = @"png";

@interface MGMCategoryBaseResource ()

@property (nonatomic, strong, class, readonly) NSBundle *bundle;

@end

@implementation MGMCategoryBaseResource

//MARK: - --------------------------------------------------------------------


+ (UIImage *)originalRenderingModeImageWithName:(NSString *)name {
    return [[self imageNamed:name] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

+ (UIImage *)imageNamed:(NSString *)name {
    CGFloat scale = [UIScreen mainScreen].scale;
    id image = [self imageWithPath:name scale:[UIScreen mainScreen].scale];
    return image;
}

+ (id)imageWithPath:(NSString *)path scale:(CGFloat)scale {
    if (scale == 0) {
        return nil;
    }
    NSInteger newScale = scale;
    if (scale > 3) {
        newScale = 3;
    }
    
    NSArray *scalePix = @[@"", @"@2x", @"@3x"];
    NSString *extension = scalePix[newScale-1];
    id image = nil;
    
    NSString *extensionPath = [path stringByAppendingString:extension];
    NSString *imagePath = [[self bundle]pathForResource:extensionPath ofType:MGMCategoryResourceKeyPNG];
    image = [UIImage imageWithContentsOfFile:imagePath];
    if (!image && newScale>1) {
        return [self imageWithPath:path scale:newScale-1];
    }
    return image;
}

+ (NSBundle *)bundle {
    NSAssert(![NSStringFromClass([self class]) isEqualToString:@"MGMCategoryBaseResource"], @"请使用 `MGMCategoryBaseResource`子类");
    NSString *bundlePath = [[NSBundle mainBundle]pathForResource:NSStringFromClass([self class]) ofType:@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    return bundle;
}

@end
