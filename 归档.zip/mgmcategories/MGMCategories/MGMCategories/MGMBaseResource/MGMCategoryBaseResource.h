/*
 
 使用 直接继承 `MGMCategoryBaseResource`, 新增资源加载方法
  ClassName <==> ClassName.bundle, 类名和bundle名字一致
 */

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMCategoryBaseResource : NSObject

+ (UIImage *)imageNamed:(NSString *)name;
+ (UIImage *)originalRenderingModeImageWithName:(NSString *)name;

@end

NS_ASSUME_NONNULL_END
