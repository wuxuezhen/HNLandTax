//
//  MGMCategories.h
//  MGMCategories
//
//  Created by zhaohao on 2018/12/3.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//


#define MAS_SHORTHAND_GLOBALS

#if __has_include(<MGMCategories/MGMCategories.h>)

#import <MGMCategories/MGMDateTool.h>
#import <MGMCategories/MGMDeviceAdapter.h>
#import <MGMCategories/MGMUIInitializer.h>
#import <MGMCategories/NSString+MGMMD5.h>
#import <MGMCategories/UIImage+MGMPlaceHolderImage.h>
#import <MGMCategories/UIBarButtonItem+MGMCustomerBack.h>
#import <MGMCategories/UIImage+MGMExtension.h>
#import <MGMCategories/UIView+MGMPosition.h>

#else

#import "MGMDateTool.h"
#import "MGMDeviceAdapter.h"
#import "MGMUIInitializer.h"
#import "NSString+MGMMD5.h"
#import "UIImage+MGMPlaceHolderImage.h"
#import "UIBarButtonItem+MGMCustomerBack.h"

#endif /* MGMCategories_h */
