//
//  UIImage+MGMPlaceHolderImage.m
//  AFNetworking
//
//  Created by 袁飞扬 on 2018/12/14.
//

#import "UIImage+MGMPlaceHolderImage.h"

@implementation UIImage (MGMPlaceHolderImage)

+ (instancetype)imageInBundleWithName:(NSString *)name{
    
    NSString *bundleName = @"PlaceHolderImageResource";
    NSString *imagePath = [NSString stringWithFormat:@"%@.bundle/%@", bundleName, name];
    return [UIImage imageNamed:imagePath];
    
}


+ (UIImage *)imageForMiGu{
    return [self imageInBundleWithName:@"placeholder_image"];
}

+ (UIImage *)imageForMiGuHeader{
    return [self imageInBundleWithName:@"placeholder_migu_image"];
}
    
+ (UIImage *)miguDefaultPortraitImage {
    return [self imageInBundleWithName:@"mgm_head_portrait_default"];
}

- (UIImage *)imageInSize:(CGSize)size {
    
    UIGraphicsBeginImageContext(size);
    
    UIGraphicsGetCurrentContext();
    CGPoint point = {(size.width-self.size.width)/2.0, (size.height-self.size.height)/2.0};
    [self drawAtPoint:point];
    [[UIColor redColor] setFill];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

+ (instancetype)imageForMiGuInSize:(CGSize)size {
    return [[self imageForMiGu] imageInSize:size];
}

+ (UIImage *)imageForMiGuHeaderInSize:(CGSize)size {
    return [[self imageForMiGuHeader] imageInSize:size];
}

+ (UIImage *)darkToLightMaskWithSize:(CGSize)size {
    UIImage *darkToLightImage = [UIImage imageInBundleWithName:@"gradient_dark_to_light_1_60"];
    return [darkToLightImage redrawImageInSize:size];
}

+ (UIImage *)lightToDarkMaskWithSize:(CGSize)size {
    UIImage *ligthToDarkImage = [UIImage imageInBundleWithName:@"gradient_light_to_dark1_60"];
    return [ligthToDarkImage redrawImageInSize:size];
}

- (UIImage *)redrawImageInSize:(CGSize)size {
    UIGraphicsBeginImageContext(size);
    UIGraphicsGetCurrentContext();
    [self drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}


+ (UIImage *)imageWithColor:(UIColor *)color {
    // 描述矩形
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    // 开启位图上下文
    UIGraphicsBeginImageContext(rect.size);
    // 获取位图上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    // 使用color演示填充上下文
    CGContextSetFillColorWithColor(context, [color CGColor]);
    // 渲染上下文
    CGContextFillRect(context, rect);
    // 从上下文中获取图片
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    // 结束上下文
    UIGraphicsEndImageContext();
    
    return theImage;
}



@end
