//
//  UIImage+MGMPlaceHolderImage.h
//  AFNetworking
//
//  Created by 袁飞扬 on 2018/12/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (MGMPlaceHolderImage)


/**
 咪咕图片占位图，白色头像

 @return UIImage
 */
+ (UIImage *)imageForMiGu;

/**
 咪咕影院 白色文字图片

 @return UIImage
 */
+ (UIImage *)imageForMiGuHeader;


/**
 咪咕影院默认头像

 @return UIImage
 */
+ (UIImage *)miguDefaultPortraitImage;
    
+ (instancetype)imageForMiGuInSize:(CGSize)size;
    
+ (instancetype)imageForMiGuHeaderInSize:(CGSize)size;

+ (UIImage *)darkToLightMaskWithSize:(CGSize)size;
    
+ (UIImage *)lightToDarkMaskWithSize:(CGSize)size;


+ (UIImage *)imageWithColor:(UIColor *)color;

@end

NS_ASSUME_NONNULL_END
