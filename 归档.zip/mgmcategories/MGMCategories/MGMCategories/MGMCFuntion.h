//
//  MGMCFuntion.h
//  MGMCategories
//
//  Created by WangDa Mac on 2019/2/28.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
/*
 <=2分，1星  非常差
 <=4分，2星  比较差
 <=6分，3星  一般般「默认值」
 <=8分，4星  很不错
 >8分， 5星 非常棒
 */
int categories_starCountWithScore(double score) {
    if (score <= 2.f) {
        return 1;
    } else if (score <= 4.f) {
        return 2;
    } else if (score <= 6.f) {
        return 3;
    } else if (score <= 8.f) {
        return 4;
    } else {
        return 5;
    }
}
