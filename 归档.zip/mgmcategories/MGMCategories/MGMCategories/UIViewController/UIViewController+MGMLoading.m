//
//  UIViewController+MGMLoading.m
//  MGMCategories
//
//  Created by MyMac on 2019/2/21.
//  Copyright © 2019年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIViewController+MGMLoading.h"
#import <objc/message.h>
#import <YYWebImage/YYWebImage.h>
#import <YYImage/YYAnimatedImageView.h>

@implementation UIViewController (MGMLoading)

- (UIImageView *)mgm_loadingView
{
    UIImageView *loadingView = objc_getAssociatedObject(self, _cmd);
    if (!loadingView)
    {
        UIImageView *loadingView = [[YYAnimatedImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
        loadingView.contentMode = UIViewContentModeScaleAspectFit;
        loadingView.center = self.view.center;
        NSString *path = [[[NSBundle mainBundle] pathForResource:@"MGMLoading" ofType:@"bundle"] stringByAppendingPathComponent:@"mgm_loading.gif"];
        loadingView.yy_imageURL = [NSURL fileURLWithPath:path];
        [self.view addSubview:loadingView];
        objc_setAssociatedObject(self, _cmd, loadingView, OBJC_ASSOCIATION_ASSIGN);
    }
    return loadingView;
}

@end
