//
//  UIColor+MGMColorExtension.h
//  MGMTicket
//
//  Created by 刘志辉 on 2018/11/26.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
/**
 渐变方式
 
 - MGMGradientChangeDirectionLevel:              水平渐变
 - MGMGradientChangeDirectionVertical:           竖直渐变
 - MGMGradientChangeDirectionUpwardDiagonalLine: 向下对角线渐变
 - MGMGradientChangeDirectionDownDiagonalLine:   向上对角线渐变
 */
typedef NS_ENUM(NSInteger, MGMGradientChangeDirection) {
    MGMGradientChangeDirectionLevel,
    MGMGradientChangeDirectionVertical,
    MGMGradientChangeDirectionUpwardDiagonalLine,
    MGMGradientChangeDirectionDownDiagonalLine,
};
@interface UIColor (MGMColorExtension)

/**
 *  @method
 *
 *  @brief       获取颜色
 *  @param  r    uint8_t数
 *  @param  g    uint8_t数
 *  @param  b    uint8_t数
 *  @return      颜色值
 */
+ (instancetype)r:(uint8_t)r g:(uint8_t)g b:(uint8_t)b a:(uint8_t)a;

/**
 *  @method
 *
 *  @brief          获取颜色
 *  @param  rgba    以0x开头的十六进制数
 *  @return         颜色值
 */
+ (instancetype)rgba:(NSUInteger)rgba;

/**
 *  @method
 *
 *  @brief          获取颜色
 *  @param  colorString    以#开头的十六进制数
 *  @return         颜色值
 */
+ (UIColor *)dealHexString:(NSString *)colorString;
+ (UIColor *)dealHexString:(NSString *)colorString alpha:(CGFloat)alpha;
/**
 创建渐变颜色
 
 @param size       渐变的size
 @param direction  渐变方式
 @param startcolor 开始颜色
 @param endColor   结束颜色
 
 @return 创建的渐变颜色
 */
+ (UIColor *)mgm_colorGradientChangeWithSize:(CGSize)size
                                   direction:(MGMGradientChangeDirection)direction
                                  startColor:(UIColor *)startcolor
                                    endColor:(UIColor *)endColor;

/**
 创建渐变颜色

 @param size 渐变的size
 @param startPoint 开始位置
 @param endPoint 结束位置
 @param startcolor 开始颜色
 @param endColor 结束颜色
 @return 创建的渐变颜色
 */
+ (UIColor *)mgm_colorGradientChangeWithSize:(CGSize)size
                                  startPoint:(CGPoint)startPoint
                                    endPoint:(CGPoint)endPoint
                                  startColor:(UIColor *)startcolor
                                    endColor:(UIColor *)endColor;
    
    
+ (UIColor *)mgm_blendColor:(UIColor *)currentColor
                   mixColor:(UIColor *)mixColor
                      ratio:(CGFloat)ratio;
    
- (UIColor *)mgm_blendDarken;
    
- (UIColor *)mgm_blendLighten;
    
@end

NS_ASSUME_NONNULL_END
