//
//  MGMFontAppearance.h
//  MGMCategories
//
//  Created by ww on 2019/4/24.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UILabel (FontAppearance)
@property (nonatomic, copy) UIFont * appearanceFont UI_APPEARANCE_SELECTOR;

@end

NS_ASSUME_NONNULL_END
