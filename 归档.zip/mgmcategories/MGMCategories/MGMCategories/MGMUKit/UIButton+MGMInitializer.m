//
//  UIButton+HBInitializer.m
//  Adapter
//
//  Created by apple on 2018/11/29.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIButton+MGMInitializer.h"
#import <objc/runtime.h>
#import <YYCategories/YYCategories.h>

@interface UIButton ()
@property (nonatomic,copy) void (^buttonDidClickCallBack)(id sender);

@end

@implementation UIButton (MGMConfig)

- (void)mgm_setFont:(UIFont *)font {
    self.titleLabel.font = font? font : [UIFont systemFontOfSize:17];
}

- (void)mgm_setNormalTitle:(NSString *)title {
    [self setTitle:title forState:UIControlStateNormal];
}

- (void)mgm_setHighlightedTitle:(NSString *)highlightedTitle {
    [self setTitle:highlightedTitle forState:UIControlStateHighlighted];
}

- (void)mgm_setSelectedTitle:(NSString *)selectedTitle {
    [self setTitle:selectedTitle forState:UIControlStateSelected];
}

- (void)mgm_setTitle:(NSString *)title titleColor:(UIColor *)titleColor forState:(UIControlState)state {
    [self setTitle:title forState:state];
    [self setTitleColor:titleColor forState:state];
}
- (void)mgm_setTitleNormalColor:(UIColor *)normalColor
              highlightedColor:(UIColor *)highlightedColor
                 selectedColor:(UIColor *)selectedColor{
    if (normalColor) {
        [self setTitleColor:normalColor forState:UIControlStateNormal];
    }
    if (highlightedColor) {
        [self setTitleColor:highlightedColor forState:UIControlStateHighlighted];
    }
    if (selectedColor) {
        [self setTitleColor:selectedColor forState:UIControlStateSelected];
    }
}

- (void)mgm_countDouwnTimeout:(NSInteger)timeout
        coutDownCallBack:(void(^)(UIButton *btn))coutDownCallBack
         coutingCallBack:(void(^)(UIButton *btn,NSString *countStr))coutingCallBack
{
    __block int  count = timeout; // 倒计时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_source_set_timer(timer,dispatch_walltime(NULL, 0),1.0 * NSEC_PER_SEC,0);
    @weakify(self);
    dispatch_source_set_event_handler(timer, ^{
        @strongify(self);
         @weakify(self);
        if (count <= 0) { // 倒计时结束 ,关闭
            dispatch_source_cancel(timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                @strongify(self);
                 
                if (coutDownCallBack) {
                    coutDownCallBack(self);
                }
    
            });
        }else {
            NSString *strTime = [NSString stringWithFormat:@"%d", count];
            dispatch_async(dispatch_get_main_queue(), ^{
                @strongify(self);
                if (coutingCallBack) {
                    coutingCallBack(self,strTime);
                }
 
                
            });
            count--;
        }
    });
    dispatch_resume(timer);
}



-(void)mgm_withBlock:(void (^)(id))tapBlock
{
    [self addTarget:self action:@selector(buttonDidClick:) forControlEvents:UIControlEventTouchUpInside];
    self.buttonDidClickCallBack = tapBlock;
}
- (void)buttonDidClick:(UIButton *)btn
{
    if (self.buttonDidClickCallBack) {
        self.buttonDidClickCallBack(btn);
    }
}
- (void)setButtonDidClickCallBack:(void (^)(id))buttonDidClickCallBack
{
    objc_setAssociatedObject(self, @selector(buttonDidClickCallBack), buttonDidClickCallBack, OBJC_ASSOCIATION_COPY);

}
-(void (^)(id))buttonDidClickCallBack
{
    return objc_getAssociatedObject(self, _cmd);
}
@end

@implementation UIButton (MGMInitializer)

+ (instancetype)mgm_customTypeButtonWith:(id)target
                              action:(SEL)action
                       controlEvents:(UIControlEvents)controlEvent {
    UIButton *button = [[self class] buttonWithType:UIButtonTypeCustom];
    [button addTarget:target action:action forControlEvents:controlEvent];
    return button;
}

+ (instancetype)mgm_addRoundCornerButtonOnContainerView:(UIView *)containerView
                                        backgroundColor:(UIColor *)backgroundColor
                                                 target:(id)target
                                                 action:(SEL)action
                                                   font:(UIFont *)font
                                                  title:(NSString *)title
                                           cornerRadius:(CGFloat)cornerRadius
                                             constraint:(void (^)(MASConstraintMaker *make))constraint
{
    UIButton *btn = [[self alloc] init];
    btn.exclusiveTouch = YES;
    [btn setBackgroundColor:backgroundColor];
    [btn setTitle:title forState:(UIControlStateNormal)];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.titleLabel.font = font;
    
    [btn addTarget:target
            action:action
  forControlEvents:UIControlEventTouchUpInside];
    [containerView addSubview:btn];
    
    [btn mas_makeConstraints:constraint];
    
    [btn layoutIfNeeded];
    
    UIBezierPath *roundPath = [UIBezierPath bezierPathWithRoundedRect:btn.bounds cornerRadius:cornerRadius];
    CAShapeLayer *maskLayer = [CAShapeLayer layer];
    maskLayer.path = roundPath.CGPath;
    btn.layer.mask = maskLayer;
    return btn;
}

@end
