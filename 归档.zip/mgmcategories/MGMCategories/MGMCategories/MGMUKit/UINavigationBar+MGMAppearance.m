//
//  UINavigationBar+MGMAppearance.m
//  MGMTicket
//
//  Created by MyMac on 2018/12/4.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UINavigationBar+MGMAppearance.h"

@implementation UINavigationBar (MGMAppearance)

- (void)mgm_setContentAlpha:(CGFloat)alpha translationY:(CGFloat)translationY
{
    for (UIView *subview in self.subviews) {
        if (@available(iOS 11, *))
        {
            if (![subview isMemberOfClass:NSClassFromString(@"_UINavigationBarContentView")]) continue;
            [self adjustSubview:subview alpha:alpha translationY:translationY];
            break;
        }
        else
        {
            if ([subview isMemberOfClass:NSClassFromString(@"_UINavigationBarBackground")] || [subview isMemberOfClass:NSClassFromString(@"_UIBarBackground")]) continue;
            
            [self adjustSubview:subview alpha:alpha translationY:translationY];
        }
    }
}

#pragma mark - Private

- (void)adjustSubview:(UIView *)subview
                alpha:(CGFloat)alpha
         translationY:(CGFloat)translationY
{
    subview.alpha = alpha;
    if (translationY <= 0)
    {
        subview.transform = CGAffineTransformIdentity;
    }
    else
    {
        subview.transform = CGAffineTransformMakeTranslation(0, -translationY);
    }
}

@end
