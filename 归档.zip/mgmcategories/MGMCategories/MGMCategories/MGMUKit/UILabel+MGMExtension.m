//
//  UILabel+MGMExtension.m
//  MGMCategories
//
//  Created by ww on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UILabel+MGMExtension.h"

@implementation UILabel (MGMExtension)
+ (instancetype)mgm_labelWithText:(NSString *)text fontSize:(NSInteger)fontSize textColor:(UIColor *)color {
    UILabel *label = [[UILabel alloc] init];
    label.textColor = color;
    label.text = text;
    label.font = [UIFont systemFontOfSize:fontSize];
    return label;
}

+ (instancetype)mgm_labelWithText:(NSString *)text boldFontSize:(NSInteger)fontSize textColor:(UIColor *)color
{
    UILabel *label = [[UILabel alloc] init];
    label.textColor = color;
    label.text = text;
    label.font = [UIFont boldSystemFontOfSize:fontSize];
    return label;
}

+ (void)mgm_changeLineSpaceForLabel:(UILabel *)label WithSpace:(float)space autoHeight:(BOOL)autoHeight{
    
    NSString *labelText = label.text;
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:labelText];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:space];
    paragraphStyle.lineBreakMode =NSLineBreakByTruncatingTail;
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [labelText length])];
    label.attributedText = attributedString;
//    [label sizeToFit];
    
}

+ (void)mgm_changeWordSpaceForLabel:(UILabel *)label WithSpace:(float)space autoHeight:(BOOL)autoHeight{
    
    NSString *labelText = label.text;
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:labelText attributes:@{NSKernAttributeName:@(space)}];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode =NSLineBreakByTruncatingTail;

    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [labelText length])];
    label.attributedText = attributedString;
    if (autoHeight) {
        [label sizeToFit];
    }
//    [label sizeToFit];
    
}

+ (void)mgm_changeSpaceForLabel:(UILabel *)label withLineSpace:(float)lineSpace WordSpace:(float)wordSpace {
    
    NSString *labelText = label.text;
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:labelText attributes:@{NSKernAttributeName:@(wordSpace)}];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:lineSpace];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [labelText length])];
    label.attributedText = attributedString;
    [label sizeToFit];
    
}

- (UILabel *(^)(NSTextAlignment))mgm_align {
    return ^(NSTextAlignment align) {
        self.textAlignment = align;
        return self;
    };
}

- (UILabel *(^)(NSInteger))mgm_numberOfLines {
    return ^(NSInteger num) {
        self.numberOfLines = num;
        return self;
    };
}

- (UILabel *(^)(UIFont *font))mgm_font {
    return ^(UIFont *font) {
        self.font = font;
        return self;
    };
}

@end
