//
//  UIView+MGMSubview.h
//  MGMCategories
//
//  Created by Loser_me on 2019/1/20.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (MGMSubview)

- (void)mgm_enumerateSubviewUsingBlock:(void(^)(UIView * _Nonnull view, BOOL * _Nonnull stop))block;

@end
