//
//  UIImage+MGMUIKit.h
//  MGMSocialModule
//
//  Created by RenYi on 2019/8/1.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (MGMUIKit)


/**
根据图片大小限制获取图片数据。 当图片数据大于sizelimt，会将图片压缩后返回图片数据；
 否则直接返回图片数据

 @param sizeLimit 图片大小限制 单位兆M
 @return nil时，获取失败；
 */
- (NSData *)fetchImageDataOnSizeLimit:(CGFloat)sizeLimit;

/**
 获取图片大小
 
 @return 0时获取失败， 单位字节byte；
 */
- (double)getImageSize;


@end

NS_ASSUME_NONNULL_END
