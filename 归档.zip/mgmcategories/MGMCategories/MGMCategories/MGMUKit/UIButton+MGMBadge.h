//
//  UIButton+MGMBadge.h
//  MGMCategories
//
//  Created by YL on 2019/5/23.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (MGMBadge)

- (void)setBadgeValue:(NSString *)badgeValue
         badgeBgColor:(UIColor *)badgeBgColor
           badgeColor:(UIColor *)badgeColor
                 font:(NSInteger)font;

- (void)setBadgeValue:(NSString *)badgeValue
         badgeBgColor:(UIColor *)badgeBgColor
           badgeColor:(UIColor *)badgeColor
                 font:(NSInteger)font
           buttonSize:(CGSize)buttonSize;


@end

NS_ASSUME_NONNULL_END
