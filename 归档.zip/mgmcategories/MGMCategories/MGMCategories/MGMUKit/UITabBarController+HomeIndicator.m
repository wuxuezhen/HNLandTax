//
//  UITabBarController+HomeIndicator.m
//  MGMCategories
//
//  Created by YL on 2019/3/18.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UITabBarController+HomeIndicator.h"

@implementation UITabBarController (HomeIndicator)

- (UIViewController *)childViewControllerForHomeIndicatorAutoHidden {
    return self.selectedViewController;
}

- (BOOL)prefersHomeIndicatorAutoHidden {
    return self.selectedViewController.prefersHomeIndicatorAutoHidden;
}

@end
