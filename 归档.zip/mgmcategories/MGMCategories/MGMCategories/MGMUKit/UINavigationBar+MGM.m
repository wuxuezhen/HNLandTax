//
//  UINavigationBar+MGM.m
//  MGMCategories
//
//  Created by RenYi on 2019/1/3.
//

#import "UINavigationBar+MGM.h"
#import "UIView+MGMSubview.h"

@implementation UINavigationBar (MGM)

/** 设置当前 NavigationBar 背景透明度*/
- (void)mgm_setBackgroundAlpha:(CGFloat)alpha
{
    //     [self setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
//    self.backgroundImageView.alpha = alpha;
//    self.backgroundView.alpha      = alpha;
    UIView *barBackgroundView = self.subviews.firstObject;
    barBackgroundView.alpha = alpha;
    if (@available(iOS 11.0, *)) {  // iOS11 下 UIBarBackground -> UIView/UIImageViwe
        for (UIView *view in self.subviews) {
            if ([NSStringFromClass([view class]) containsString:@"_UIBarBackground"]) {
                view.alpha = alpha;
                break;
                //                    view.backgroundColor = [UIColor clearColor];
            }
        }
        // iOS 下如果不设置 UIBarBackground 下的UIView的透明度，会显示不正常
        if (barBackgroundView.subviews.firstObject) {
            barBackgroundView.subviews.firstObject.alpha = alpha;
        }
    }
}

- (void)setNavigationBarTranslationY:(CGFloat)navigationBarTranslationY
{
    if (navigationBarTranslationY > 0)
    {
        self.transform = CGAffineTransformMakeTranslation(0, -navigationBarTranslationY);
    }
    else
    {
        self.transform = CGAffineTransformIdentity;
    }
}

- (void)mgm_setBackIndicatorImage:(UIImage *)image
{
    self.backIndicatorImage = image;
    self.backIndicatorTransitionMaskImage = image;
}

- (void)setMgm_hideShadowImage:(BOOL)mgm_hideShadowImage
{
    UIView *shadowImgView = [self mgm_shadowImageView];
    shadowImgView.hidden = mgm_hideShadowImage;
}

- (BOOL)mgm_hideShadowImage
{
    UIView *shadowImgView = [self mgm_shadowImageView];
    return shadowImgView.hidden;
}

- (UIView *)mgm_shadowImageView
{
    static UIView *_shadowImageView = nil;
    if (!_shadowImageView)
    {
        [self mgm_enumerateSubviewUsingBlock:^(UIView * _Nonnull view, BOOL * _Nonnull stop) {
            if (view.frame.size.height <= 1)
            {
                _shadowImageView = view;
                *stop = YES;
            }
        }];
    }
    return _shadowImageView;
}

@end
