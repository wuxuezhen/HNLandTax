//
//  UIView+LMFrame.h
//  Foot Lottery
//
//  Created by applemini2 on 17/2/6.
//  Copyright © 2017年 sofmit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (MGMFrame)

@property (nonatomic, assign) CGFloat mgm_x;

@property (nonatomic, assign) CGFloat mgm_y;

@property (nonatomic, assign) CGFloat mgm_width;

@property (nonatomic, assign) CGFloat mgm_height;

@property (nonatomic, assign) CGSize  mgm_Size;

@property (nonatomic, assign) CGFloat mgm_centerX;

@property (nonatomic, assign) CGFloat mgm_centerY;

@property (nonatomic, assign) CGFloat mgm_bottom;

@property (nonatomic, assign) CGFloat mgm_trail;

@end
