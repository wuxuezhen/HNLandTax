//
//  UIView+MGMSubview.m
//  MGMCategories
//
//  Created by Loser_me on 2019/1/20.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIView+MGMSubview.h"

@implementation UIView (MGMSubview)

- (void)mgm_enumerateSubviewUsingBlock:(void (^)(UIView * _Nonnull, BOOL * _Nonnull))block
{
    static BOOL stop = NO;

    for (UIView *view in self.subviews) {
        if (stop) return;
        
        !block ?: block(view, &stop);
        [view mgm_enumerateSubviewUsingBlock:block];
    }
}

@end
