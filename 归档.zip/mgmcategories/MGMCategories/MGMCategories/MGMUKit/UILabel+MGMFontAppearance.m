//
//  MGMFontAppearance.m
//  MGMCategories
//
//  Created by ww on 2019/4/24.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UILabel+MGMFontAppearance.h"

@implementation UILabel (FontAppearance)

-(void)setAppearanceFont:(UIFont *)font {
    if (font)
        [self setFont:font];
}

-(UIFont *)appearanceFont {
    return self.font;
}

@end
