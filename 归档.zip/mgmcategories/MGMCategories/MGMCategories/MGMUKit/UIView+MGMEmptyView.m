//
//  UIView+MGMEmptyView.m
//  MGMCategories
//
//  Created by YL on 2019/4/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIView+MGMEmptyView.h"
#import <objc/runtime.h>

@interface UIView()

@property (nonatomic, copy) dispatch_block_t    emptyBtnHandler;

@end

@implementation UIView (MGMEmptyView)

- (void)showEmptyViewWithImage:(UIImage *)emptyImage
                         title:(NSString *)emptyTitle {
    [self showEmptyViewWithImage:emptyImage
                           title:emptyTitle
                     buttonTitle:@""
                   buttonHandler:NULL];
}

- (void)showEmptyViewWithImage:(UIImage *)emptyImage
                         title:(NSString *)emptyTitle
                   buttonTitle:(NSString *)buttonTitle
                 buttonHandler:(void(^)(void))handler {
    
    [self showEmptyViewWithImage:emptyImage
                           title:emptyTitle
                   titleDistance:20
                     buttonTitle:buttonTitle
                  buttonDistance:15
                   buttonHandler:handler];
}

- (void)showEmptyViewWithImage:(UIImage *)emptyImage
                         title:(NSString *)emptyTitle
                 titleDistance:(CGFloat)titleDistance
                   buttonTitle:(NSString *)buttonTitle
                buttonDistance:(CGFloat)buttonDistance
                 buttonHandler:(void(^)(void))handler {
    
    self.emptyBtnHandler = handler;
    CGFloat emptyH = emptyImage.size.height + 15 + 40 + titleDistance + buttonDistance;
    UIImageView *emptyImageView = [[UIImageView alloc] init];
    emptyImageView.image = emptyImage;
    emptyImageView.frame = CGRectMake(self.frame.size.width/ 2 - emptyImage.size.width/2 , self.frame.size.height/2-emptyH/2, emptyImage.size.width, emptyImage.size.height);
    [self addSubview:emptyImageView];
    
    UILabel *emptyLabel = [[UILabel alloc] init];
    emptyLabel.frame = CGRectMake(0, emptyImageView.frame.origin.y+emptyImageView.frame.size.height+titleDistance, self.frame.size.width, 15);
    emptyLabel.backgroundColor = [UIColor clearColor];
    emptyLabel.font = [UIFont systemFontOfSize:15];
    emptyLabel.textAlignment = NSTextAlignmentCenter;
    emptyLabel.textColor = [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1.0 ];
    emptyLabel.text = emptyTitle;
    [self addSubview:emptyLabel];
    
    if(buttonTitle.length > 0) {
        UIButton *emptyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [emptyBtn setTitle:buttonTitle forState:UIControlStateNormal];
        emptyBtn.frame = CGRectMake(self.frame.size.width/2-50, emptyLabel.frame.origin.y+emptyLabel.frame.size.height+buttonDistance, 100, 40);
        emptyBtn.layer.cornerRadius = 20;
        emptyBtn.layer.masksToBounds = YES;
        emptyBtn.backgroundColor = [UIColor colorWithRed:255/255.0 green:62/255.0 blue:64/255.0 alpha:1.0];
        [emptyBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        emptyBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size: 16];
        emptyBtn.adjustsImageWhenHighlighted = NO;
        emptyBtn.exclusiveTouch = YES;
        [emptyBtn addTarget:self
                     action:@selector(emptyBtnDidPressed:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:emptyBtn];
    }
}

- (void)emptyBtnDidPressed:(id)sender {
    if(self.emptyBtnHandler) {
        self.emptyBtnHandler();
    }
}

- (dispatch_block_t)emptyBtnHandler {
    return objc_getAssociatedObject(self, _cmd);
}

- (void)setEmptyBtnHandler:(dispatch_block_t)emptyBtnHandler {
    objc_setAssociatedObject(self, @selector(emptyBtnHandler), emptyBtnHandler, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

@end
