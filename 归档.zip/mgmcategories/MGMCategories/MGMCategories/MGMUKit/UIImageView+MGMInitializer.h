//
//  UIImageView+HBInitializer.h
//  Adapter
//
//  Created by apple on 2018/11/29.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (MGMInitializer)

- (instancetype)mgm_initWithImage:(UIImage *)image contentMode:(UIViewContentMode)contentMode;

@end
