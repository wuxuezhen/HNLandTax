//
//  UIView+HBRemoveSubviews.m
//  Adapter
//
//  Created by apple on 2018/11/29.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIView+MGMRemoveSubviews.h"

@implementation UIView (MGMRemoveSubviews)

- (void)mgm_removeAllSubviews {
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
}

@end
