//
//  UIButton+MGMLayout.h
//  MGMCategories
//
//  Created by YL on 2019/1/11.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, MGMUIButtonLayoutStyle) {
    MGMDefalutStyle = 0,//默认的方式
    MGMImageLeftTitleRightStyle = 1, // image左 title右
    MGMTitleLeftImageRightStyle = 2, // image右,title左
    MGMImageTopTitleBottomStyle = 3, //image上，title下
    MGMTitleTopImageBottomStyle = 4, // image下,title上
};

@interface UIButton (MGMLayout)

/**
 *  图片和文字显示方向
 */
@property(nonatomic)IBInspectable MGMUIButtonLayoutStyle layoutStyle;

/**
 *  图片和文字之间的间距
 */
@property (nonatomic, assign) IBInspectable CGFloat layoutSpacing;

/**
 *    功能:设置UIButton的布局，图片和文字按照指定方向显示
 *
 *    @param aLayoutStyle 参见OTSUIButtonLayoutStyle
 *    @param aSpacing 图片和文字之间的间隔
 */
- (void)setLayout:(MGMUIButtonLayoutStyle )aLayoutStyle
          spacing:(CGFloat)aSpacing;

@end

NS_ASSUME_NONNULL_END
