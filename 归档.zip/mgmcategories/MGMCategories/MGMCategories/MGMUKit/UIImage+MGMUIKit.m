//
//  UIImage+MGMUIKit.m
//  MGMSocialModule
//
//  Created by RenYi on 2019/8/1.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIImage+MGMUIKit.h"

@implementation UIImage (MGMUIKit)

- (NSData *)fetchImageDataOnSizeLimit:(CGFloat)sizeLimit{
    //计算图片大小
    NSData *imageData = nil;
    imageData = UIImageJPEGRepresentation(self, 0.5);
    CGFloat imageSize = imageData.length;
    //判断是否大于sizeLimit 大于则压缩到sizeLimit的x大小返回，否则就原图返回
    if (imageSize>sizeLimit*1024*1024) {
        //开始压缩
        imageData = [self compressImageSize:self toByte:sizeLimit*1024*1024];
        imageSize = imageData.length/(1024.0*1024.0);
        return imageData;
    }
    return imageData;
}

/**
 判断图片宽高比 >5:1 返回YES else 返回NO
 
 @return Yes 长图，No 方图
 */
- (BOOL)fetchImageFlag{
    CGFloat fixelW = CGImageGetWidth(self.CGImage);
    CGFloat fixelH = CGImageGetHeight(self.CGImage);
    CGFloat flag = fixelW/fixelH;
    if (flag>5.0) {
        return YES;
    }
    return NO;
}

- (double)getImageSize{
    if (!self) {
        return 0;
    }
    //计算图片大小
    NSData *imageData = nil;
    imageData = UIImageJPEGRepresentation(self, 0.5);
    double imageSize = imageData.length;
    return imageSize;
}

/*!
 *  @brief 使图片压缩后刚好小于指定大小
 *
 *  @param image 当前要压缩的图 maxLength 压缩后的大小 单位byte
 *
 *  @return 图片对象
 */
//图片质量压缩到某一范围内，如果后面用到多，可以抽成分类或者工具类,这里压缩递减比二分的运行时间长，二分可以限制下限。
- (NSData *)compressImageSize:(UIImage *)image toByte:(NSUInteger)maxLength{
    CGFloat quality = 0.5;
    NSData *data = UIImageJPEGRepresentation(image, quality);
    if (data.length < maxLength) return data;
    //原图大小超过范围，先进行“压处理”，这里 压缩比 采用二分法进行处理，6次二分后的最小压缩比是0.015625，已经够小了
    CGFloat max = 1;
    CGFloat min = 0;
    for (int i = 0; i < 6; ++i) {
        quality = (max + min) / 2;
        data = UIImageJPEGRepresentation(image, quality);
        if (data.length < maxLength) {
            min = quality;
        } else if (data.length > maxLength) {
            max = quality;
        } else {
            break;
        }
    }
    //判断“压处理”的结果是否符合要求，符合要求就over
    if (data.length < maxLength) return data;
    
    UIImage *resultImage = [UIImage imageWithData:data];
    //缩处理，直接用大小的比例作为缩处理的比例进行处理，因为有取整处理，所以一般是需要两次处理
    NSUInteger lastDataLength = 0;
    while (data.length > maxLength && data.length != lastDataLength) {
        lastDataLength = data.length;
        //获取处理后的尺寸
        CGFloat ratio = (CGFloat)maxLength / data.length;
        CGSize size = CGSizeMake((NSUInteger)(resultImage.size.width * sqrtf(ratio)),
                                 (NSUInteger)(resultImage.size.height * sqrtf(ratio)));
        //通过图片上下文进行处理图片
        UIGraphicsBeginImageContext(size);
        [resultImage drawInRect:CGRectMake(0, 0, size.width, size.height)];
        resultImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        //获取处理后图片的大小
        data = UIImageJPEGRepresentation(resultImage, 0.5);
    }
    return data;
}

@end
