//
//  UIBarButtonItem+MGMCustomerBack.m
//  MGMCategories
//
//  Created by WangDa Mac on 2019/1/18.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIBarButtonItem+MGMCustomerBack.h"

@implementation UIBarButtonItem (MGMCustomerBack)

//+ (instancetype)mgm_grayBackItemWithHandler:(void(^)(id sender))action {
//    return [[self class] p_barButtonItemWithImageName:@"categroy_gray_back" handler:action];
//}
//+ (instancetype)mgm_whiteBackItemWithHandler:(void(^)(id sender))action {
//    return [[self class] p_barButtonItemWithImageName:@"icon_back_white" handler:action];
//}
//
//+ (instancetype)mgm_whiteCloseItemWithHandler:(void(^)(id sender))action {
//    return [[self class] p_barButtonItemWithImageName:@"icon_close_white" handler:action];
//}
//+ (instancetype)p_barButtonItemWithImageName:(NSString *)imageName handler:(void(^)(id sender))action {
//    UIImage *backImage = [[UIImage imageNamed:[NSString stringWithFormat:@"PlaceHolderImageResource.bundle/%@", imageName]]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
//    UIBarButtonItem *item = [[UIBarButtonItem alloc] bk_initWithImage:backImage style:UIBarButtonItemStylePlain handler:action];
//    return item;
//}

@end
