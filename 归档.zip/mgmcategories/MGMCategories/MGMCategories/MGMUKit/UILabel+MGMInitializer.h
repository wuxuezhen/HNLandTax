//
//  UILabel+HBInitializer.h
//  Adapter
//
//  Created by apple on 2018/11/29.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (MGMConfig)

- (void)mgm_setFont:(UIFont *)font
         textColor:(UIColor *)textColor
     textAlignment:(NSTextAlignment)textAlignment
     lineBreakMode:(NSLineBreakMode)lineBreakMode;
- (void)mgm_setText:(NSString *)text textColor:(UIColor *)textColor;

@end

@interface UILabel (MGMInitializer)

+ (instancetype)mgm_lableWithFont:(UIFont *)font
                       textColor:(UIColor *)textColor
                   textAlignment:(NSTextAlignment)textAlignment
                   lineBreakMode:(NSLineBreakMode)lineBreakMode;

@end
