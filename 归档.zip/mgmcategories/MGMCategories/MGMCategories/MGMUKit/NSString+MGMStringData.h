//
//  NSString+MGMStringData.h
//  MGMCategories
//
//  Created by 袁飞扬 on 2018/12/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (MGMStringData)
//判断某个时间是否在现在之前或之后  之前返回1。之后返回0
+ (NSInteger)mgm_categoriesTimeToFrontOrAround:(NSString *)time;

//截取时间20181217-->12月17日
+ (NSString *)mgm_categoriesTimeToDataString:(NSString *)time;

//时间戳返回时间
+ (NSString *)mgm_categoriesTimeStampToDataString:(NSString *)timeStamp;

/**
    根据时间戳计算当前时间(1495453213000 --> 1小时前、1天前)

 @param timeStamp  时间戳
 @return  当前时间
 */
+ (NSString *)mgm_dateFromTimeStamp:(NSString *)timeStamp;

//改变时间显示的方法。2018-11-30 16:11:33。--》 11月30日

+ (NSString *)mgm_categoriesDataToData : (NSString *)time;

//返回更新时间 一小时前。一天前 。。
+ (NSString *)mgm_categoriesDataTotimeString : (NSString *)time;
//时间戳返回时间 返回标准时间yyyy-MM-dd HH:mm:ss
+ (NSString *)mgm_categoriesTimeStampToDataStringBiaoZhun:(NSString *)timeStamp;
///根据时间字符串 转成对应格式
+(NSString *)mgm_timeStrTransformToTimeFomatString:(NSString *)timeFormat timeSourceStr:(NSString *)timeStr;
//返回更新时间 一小时前。一天前 。。 消息中心，带分秒
+ (NSString *)mgm_messageCenterCategoriesDataTotimeString : (NSString *)time;
//返回年月日
+(NSString *)mgm_getCurrentData;

@end

NS_ASSUME_NONNULL_END
