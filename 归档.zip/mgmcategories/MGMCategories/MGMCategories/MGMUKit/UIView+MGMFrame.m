

//
//  UIView+LMFrame.m
//  Foot Lottery
//
//  Created by applemini2 on 17/2/6.
//  Copyright © 2017年 sofmit. All rights reserved.
//

#import "UIView+MGMFrame.h"

@implementation UIView (MGMFrame)

- (void)setMgm_x:(CGFloat)mgm_x
{
    self.frame = CGRectMake(mgm_x, self.frame.origin.y, self.frame.size.width, self.frame.size.height);
}

- (CGFloat)mgm_x
{
    return self.frame.origin.x;
}

- (void)setMgm_y:(CGFloat)mgm_y
{
    self.frame = CGRectMake(self.frame.origin.x, mgm_y, self.frame.size.width, self.frame.size.height);
}

- (CGFloat)mgm_y
{
    return self.frame.origin.y;
}

- (void)setMgm_trail:(CGFloat)mgm_trail
{
    self.mgm_x = mgm_trail - self.mgm_width;
}

- (CGFloat)mgm_trail
{
    return CGRectGetMaxX(self.frame);
}

- (void)setMgm_bottom:(CGFloat)mgm_bottom
{
    self.mgm_y= mgm_bottom - self.mgm_height;
}

- (CGFloat)mgm_bottom
{
    return CGRectGetMaxY(self.frame);
}

- (void)setMgm_width:(CGFloat)mgm_width
{
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, mgm_width, self.frame.size.height);
}

- (CGFloat)mgm_width
{
    return self.frame.size.width;
}

- (void)setMgm_height:(CGFloat)mgm_height
{
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, mgm_height);
}

- (CGFloat)mgm_height
{
    return self.frame.size.height;
}

- (void)setMgm_Size:(CGSize)mgm_Size
{
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, mgm_Size.width, mgm_Size.height);
}

- (CGSize)mgm_Size
{
    return self.frame.size;
}

- (void)setMgm_centerX:(CGFloat)mgm_centerX
{
    self.center = CGPointMake(mgm_centerX, self.center.y);
}

- (CGFloat)mgm_centerX
{
    return self.center.x;
}

- (void)setMgm_centerY:(CGFloat)mgm_centerY
{
    self.center = CGPointMake(self.center.x, mgm_centerY);
}

- (CGFloat)mgm_centerY
{
    return self.center.y;
}

@end
