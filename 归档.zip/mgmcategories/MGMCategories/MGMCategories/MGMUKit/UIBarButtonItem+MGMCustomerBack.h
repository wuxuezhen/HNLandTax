//
//  UIBarButtonItem+MGMCustomerBack.h
//  MGMCategories
//
//  Created by WangDa Mac on 2019/1/18.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIBarButtonItem (MGMCustomerBack)
//+ (instancetype)mgm_grayBackItemWithHandler:(void(^)(id sender))action;
//+ (instancetype)mgm_whiteBackItemWithHandler:(void(^)(id sender))action;
//+ (instancetype)mgm_whiteCloseItemWithHandler:(void(^)(id sender))action;
@end

NS_ASSUME_NONNULL_END
