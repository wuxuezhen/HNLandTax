//
//  UINavigationController+HomeIndicator.m
//  MGMCategories
//
//  Created by YL on 2019/3/18.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UINavigationController+HomeIndicator.h"

@implementation UINavigationController (HomeIndicator)

- (UIViewController *)childViewControllerForHomeIndicatorAutoHidden {
    return self.topViewController;
}

- (BOOL)prefersHomeIndicatorAutoHidden {
    return self.topViewController.prefersHomeIndicatorAutoHidden;
}
- (UIViewController *)childViewControllerForStatusBarStyle {
    return self.topViewController;
}
@end
