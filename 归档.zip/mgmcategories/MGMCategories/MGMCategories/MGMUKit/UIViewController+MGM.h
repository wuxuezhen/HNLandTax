//
//  UIViewController+MGM.h
//  MGMCategories
//
//  Created by RenYi on 2019/1/4.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (MGM)

- (CGFloat)navigationBarAndStatusBarHeight;

-(void)mgm_dismissCurrentVCWithCallBack:(void (^)(void))callBack;

+ (UIViewController *)mgm_getRootViewController;

+ (UIViewController *)mgm_getCurrentViewController;

@end

NS_ASSUME_NONNULL_END
