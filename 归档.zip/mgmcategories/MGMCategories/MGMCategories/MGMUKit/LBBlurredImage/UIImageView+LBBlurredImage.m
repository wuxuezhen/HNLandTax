//
//  UIImageView+LBBlurredImage.m
//  LBBlurredImage
//
//  Created by Luca Bernardi on 11/11/12.
//  Copyright (c) 2012 Luca Bernardi. All rights reserved.
//

#import "UIImageView+LBBlurredImage.h"
#import "UIImage+ImageEffects.h"

CGFloat const kLBBlurredImageDefaultBlurRadius            = 20.0;
CGFloat const kLBBlurredImageDefaultSaturationDeltaFactor = 1.8;

@implementation UIImageView (LBBlurredImage)

#pragma mark - LBBlurredImage Additions

- (void)setImageToBlur:(UIImage *)image
       completionBlock:(LBBlurredImageCompletionBlock)completion
{
    [self setImageToBlur:image
              blurRadius:kLBBlurredImageDefaultBlurRadius
                   async:YES
         completionBlock:completion];
}

- (void)setImageToBlur:(UIImage *)image
            blurRadius:(CGFloat)blurRadius
                 async:(BOOL)async
       completionBlock:(LBBlurredImageCompletionBlock)completion
{
    NSParameterAssert(image);
    NSParameterAssert(blurRadius >= 0);
    if (async) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            
            UIImage *blurredImage = [image applyBlurWithRadius:blurRadius
                                                     tintColor:nil
                                         saturationDeltaFactor:kLBBlurredImageDefaultSaturationDeltaFactor
                                                     maskImage:nil];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                self.image = blurredImage;
                if (completion) {
                    completion();
                }
            });
        });
    }else{
        UIImage *blurredImage = [image applyBlurWithRadius:blurRadius
                                                 tintColor:nil
                                     saturationDeltaFactor:kLBBlurredImageDefaultSaturationDeltaFactor
                                                 maskImage:nil];
        self.image = blurredImage;
    }

}

@end
