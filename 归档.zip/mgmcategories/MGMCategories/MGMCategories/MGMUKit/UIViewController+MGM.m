//
//  UIViewController+MGM.m
//  MGMCategories
//
//  Created by RenYi on 2019/1/4.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIViewController+MGM.h"


@implementation UIViewController (MGM)

/** 获取导航栏加状态栏高度*/
- (CGFloat)navigationBarAndStatusBarHeight {
    return CGRectGetHeight(self.navigationController.navigationBar.bounds) +
    CGRectGetHeight([UIApplication sharedApplication].statusBarFrame);
}

-(void)mgm_dismissCurrentVCWithCallBack:(void (^)(void))callBack
{
    if (self.presentedViewController) {
        [self dismissViewControllerAnimated:YES completion:^{
            if (callBack) {
                callBack();
            }
        }];
    }else{
        if (callBack) {
            callBack();
        }
        
    }
}

+ (UIViewController *)mgm_getRootViewController{
    
    UIWindow* window = [[[UIApplication sharedApplication] delegate] window];
    NSAssert(window, @"The window is empty");
    return window.rootViewController;
}

+ (UIViewController *)mgm_getCurrentViewController{
    
    UIViewController* currentViewController = [self mgm_getRootViewController];
    BOOL runLoopFind = YES;
    while (runLoopFind) {
        if (currentViewController.presentedViewController) {
            
            currentViewController = currentViewController.presentedViewController;
        } else if ([currentViewController isKindOfClass:[UINavigationController class]]) {
            
            UINavigationController* navigationController = (UINavigationController* )currentViewController;
            currentViewController = [navigationController.childViewControllers lastObject];
            
        } else if ([currentViewController isKindOfClass:[UITabBarController class]]) {
            
            UITabBarController* tabBarController = (UITabBarController* )currentViewController;
            currentViewController = tabBarController.selectedViewController;
        } else {
            
            NSUInteger childViewControllerCount = currentViewController.childViewControllers.count;
            if (childViewControllerCount > 0) {
                
                currentViewController = currentViewController.childViewControllers.lastObject;
                
                return currentViewController;
            } else {
                
                return currentViewController;
            }
        }
        
    }
    return currentViewController;
}

@end
