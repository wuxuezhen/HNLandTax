//
//  UIImage+MGMExtension.m
//  MGMCategories
//
//  Created by ww on 2019/4/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIImage+MGMExtension.h"
#import <AVFoundation/AVFoundation.h>

@implementation UIImage (MGMExtension)


/**
 裁剪图片
 
 @param rect 裁剪区域
 @return 裁剪后图片
 */
- (UIImage *)croppedToRect:(CGRect)rect {
    CGFloat scale = self.scale;
    CGRect cropRect = (CGRect){CGRectGetMinX(rect) * scale, CGRectGetMinY(rect) * scale, CGRectGetWidth(rect) * scale, CGRectGetHeight(rect) * scale};
    CGImageRef imageRef = CGImageCreateWithImageInRect([self CGImage], cropRect);
    UIImage *cropped = [UIImage imageWithCGImage:imageRef scale:self.scale orientation:self.imageOrientation];
    CGImageRelease(imageRef);
    return cropped;
}


- (UIImage *)scaleToSize:(CGSize)size {
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    [self drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

- (UIImage *)scaleToSizeAspectFit:(CGSize)size {
    CGRect newRect = AVMakeRectWithAspectRatioInsideRect(self.size, CGRectMake(0, 0, size.width, size.height));
    return [self scaleToSize:size];
}

- (UIImage *)scaleToSizeAspectFill:(CGSize)size {
    CGRect newRect = AVMakeRectWithAspectRatioInsideRect(size, CGRectMake(0, 0, self.size.width, self.size.height));
    return [[self croppedToRect:newRect] scaleToSize:size];
}


@end
