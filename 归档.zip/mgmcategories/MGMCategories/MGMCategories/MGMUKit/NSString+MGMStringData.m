//
//  NSString+MGMStringData.m
//  MGMCategories
//
//  Created by 袁飞扬 on 2018/12/26.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "NSString+MGMStringData.h"

@implementation NSString (MGMStringData)
//时间戳返回时间
+ (NSString *)mgm_categoriesTimeStampToDataString:(NSString *)timeStamp{
    // timeStampString 是服务器返回的13位时间戳
    //NSString *timeStampString  = @"1495453213000";
    
    // iOS 生成的时间戳是10位
    NSTimeInterval interval =[timeStamp doubleValue] / 1000.0;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:interval];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSString *dateString = [formatter stringFromDate: date];
    
    return dateString;
    
}

//时间戳返回时间 返回标准时间yyyy-MM-dd HH:mm:ss
+ (NSString *)mgm_categoriesTimeStampToDataStringBiaoZhun:(NSString *)timeStamp{
    // timeStampString 是服务器返回的13位时间戳
    //NSString *timeStampString  = @"1495453213000";
    
    // iOS 生成的时间戳是10位
    NSTimeInterval interval =[timeStamp doubleValue] / 1000.0;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:interval];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateString = [formatter stringFromDate: date];
    
    return dateString;
    
}

//判断某个时间是否在现在之前或之后  之前返回1（购票）。之后返回0（预售）
+ (NSInteger)mgm_categoriesTimeToFrontOrAround:(NSString *)time{
    NSString *timeSp = [NSString categoriesTransTotimeSp:time];
    double beTime = [timeSp integerValue];
    
    NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
    double distanceTime = now - beTime;
    
    if (distanceTime > 0) {
        return 1;
    }else{
        return 0;
    }
}

//截取时间20181217-->12月17日
+ (NSString *)mgm_categoriesTimeToDataString:(NSString *)time{
    NSString *stringMM = [time substringWithRange:NSMakeRange(4, 2)];
    NSString *isString = [time substringWithRange:NSMakeRange(4, 1)];
    if ([isString isEqualToString:@"0"]) {
        stringMM = [time substringWithRange:NSMakeRange(5, 1)];
    }
    
    NSString *stringdd = [time substringWithRange:NSMakeRange(6, 2)];
    
    return [NSString stringWithFormat:@"%@月%@日",stringMM,stringdd];
    
}


+ (NSString *)mgm_categoriesDataToData : (NSString *)time{
    //时间戳
    NSString *timesp = [self categoriesTransTotimeSp:time];
    
    NSString *string = [self categoriesTransToDate:timesp];
    
    return string;
    
}

+ (NSString *)mgm_dateFromTimeStamp:(NSString *)timeStamp
{
    NSString *dateString = [self mgm_categoriesTimeStampToDataStringBiaoZhun:timeStamp];
    return [self mgm_categoriesDataTotimeString:dateString];
}
//返回更新时间 一小时前。一天前 。。  消息中心。带分秒
+ (NSString *)mgm_messageCenterCategoriesDataTotimeString : (NSString *)time{
    NSString *timeSp = [NSString categoriesTransTotimeSp:time];
    double beTime = [timeSp integerValue];
    
    NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
    double distanceTime = now - beTime;
    NSString * distanceStr;
    
    NSDate * beDate = [NSDate dateWithTimeIntervalSince1970:beTime];
    NSDateFormatter * df = [[NSDateFormatter alloc]init];
    [df setDateFormat:@"HH:mm"];
    NSString * timeStr = [df stringFromDate:beDate];
    
    [df setDateFormat:@"dd"];
    NSString * nowDay = [df stringFromDate:[NSDate date]];
    NSString * lastDay = [df stringFromDate:beDate];
    
     [df setDateFormat:@"HH"];
     //计算时
     NSString * hourStr = [df stringFromDate:beDate];
     NSString *nowHourStr = [df stringFromDate:[NSData data]];
     [df setDateFormat:@"mm"];
     //计算时
     NSString * minuteStr = [df stringFromDate:beDate];
     NSString *nowMinuteStr = [df stringFromDate:[NSData data]];
    if (distanceTime < 60) {//小于一分钟
        distanceStr = @"刚刚";
    }
    else if (distanceTime <60*60) {//时间小于一个小时
        distanceStr = [NSString stringWithFormat:@"%ld分钟前",(long)distanceTime/60];
    }
//    distanceTime <24*60*60 && [nowDay integerValue] == [lastDay integerValue]
    else if(distanceTime <24*60*60){//时间小于一天
        distanceStr = [NSString stringWithFormat:@"%ld小时前",(long)distanceTime/(60*60)];
    }
    else if (([nowDay integerValue] - [lastDay integerValue] ==1 || ([lastDay integerValue] - [nowDay integerValue] > 10 && [nowDay integerValue] == 1)) && distanceTime<48*60*60) {
        distanceStr = [NSString stringWithFormat:@"昨天"];//timeStr
    }
    else if ((([nowDay integerValue] - [lastDay integerValue] ==2) || ([lastDay integerValue] - [nowDay integerValue] > 10)) && (distanceTime <= (24*60*60*2 + [hourStr integerValue] *60*60 + [nowMinuteStr integerValue] *60 ))){
        distanceStr = [NSString stringWithFormat:@"前天"];//timeStr
    }
    
//    else if(distanceTime<(24*60*60*2 + [hourStr integerValue] * 60*60 + [minuteStr integerValue] * 60) && [nowDay integerValue] != [lastDay integerValue]){
//
//        if ([nowDay integerValue] - [lastDay integerValue] ==1 || ([lastDay integerValue] - [nowDay integerValue] > 10 && [nowDay integerValue] == 1)) {
//            distanceStr = [NSString stringWithFormat:@"昨天"];//timeStr
//        }else if ([nowDay integerValue] - [lastDay integerValue] ==2 || distanceTime >= 24*60*60*2){
//            distanceStr = [NSString stringWithFormat:@"前天"];//timeStr
//        }
//    }
    else{
        
        NSCalendar *calendar = [NSCalendar currentCalendar];
         int unit = NSCalendarUnitYear;
         // 1.获得当前时间的年月日
         NSDateComponents *nowCmps = [calendar components:unit fromDate:[NSDate date]];
         // 2.获得self的年月日
         NSDateComponents *selfCmps = [calendar components:unit fromDate:beDate];
        //判断是否是同一年的
         if (nowCmps.year == selfCmps.year) {
             [df setDateFormat:@"MM-dd HH:mm"];
         }else{
             [df setDateFormat:@"yyyy-MM-dd HH:mm"];
         }
        distanceStr = [df stringFromDate:beDate];
    }
    //        else if(distanceTime <24*60*60*365){
    //            [df setDateFormat:@"MM月dd日 HH:mm"];
    //            distanceStr = [df stringFromDate:beDate];
    //        }
    //        else{
    //            [df setDateFormat:@"yyyy-MM-dd HH:mm"];
    //            distanceStr = [df stringFromDate:beDate];
    //        }
    return distanceStr;
    
}

//返回更新时间 一小时前。一天前 。。
+ (NSString *)mgm_categoriesDataTotimeString : (NSString *)time{
    //NSString *timeSp = [NSString categoriesTransTotimeSp:time];
    NSString *timeSp = time;
    double beTime = [timeSp doubleValue]/1000;
    
    NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
    double distanceTime = now - beTime;
    NSString * distanceStr;
    
    NSDate * beDate = [NSDate dateWithTimeIntervalSince1970:beTime];
    NSDateFormatter * df = [[NSDateFormatter alloc]init];
    [df setDateFormat:@"HH:mm"];
    NSString * timeStr = [df stringFromDate:beDate];
    
    [df setDateFormat:@"dd"];
    NSString * nowDay = [df stringFromDate:[NSDate date]];
    NSString * lastDay = [df stringFromDate:beDate];
    
     [df setDateFormat:@"HH"];
     //计算时
     NSString * hourStr = [df stringFromDate:beDate];
     NSString *nowHourStr = [df stringFromDate:[NSData data]];
     [df setDateFormat:@"mm"];
     //计算时
     NSString * minuteStr = [df stringFromDate:beDate];
     NSString *nowMinuteStr = [df stringFromDate:[NSData data]];
    if (distanceTime < 60) {//小于一分钟
        distanceStr = @"刚刚";
    }
    else if (distanceTime <60*60) {//时间小于一个小时
        distanceStr = [NSString stringWithFormat:@"%ld分钟前",(long)distanceTime/60];
    }
//    distanceTime <24*60*60 && [nowDay integerValue] == [lastDay integerValue]
    else if(distanceTime <24*60*60 && [nowDay integerValue] == [lastDay integerValue]){//时间小于一天
        distanceStr = [NSString stringWithFormat:@"%ld小时前",(long)distanceTime/(60*60)];
    }
    else if (([nowDay integerValue] - [lastDay integerValue] ==1 || ([lastDay integerValue] - [nowDay integerValue] > 10 && [nowDay integerValue] == 1)) && distanceTime<48*60*60) {
        distanceStr = [NSString stringWithFormat:@"昨天"];//timeStr
    }
    else if ((([nowDay integerValue] - [lastDay integerValue] ==2) || ([lastDay integerValue] - [nowDay integerValue] > 10)) && (distanceTime <= (24*60*60*2 + [hourStr integerValue] *60*60 + [nowMinuteStr integerValue] *60 ))){
        distanceStr = [NSString stringWithFormat:@"前天"];//timeStr
    }
    
//    else if(distanceTime<(24*60*60*2 + [hourStr integerValue] * 60*60 + [minuteStr integerValue] * 60) && [nowDay integerValue] != [lastDay integerValue]){
//
//        if ([nowDay integerValue] - [lastDay integerValue] ==1 || ([lastDay integerValue] - [nowDay integerValue] > 10 && [nowDay integerValue] == 1)) {
//            distanceStr = [NSString stringWithFormat:@"昨天"];//timeStr
//        }else if ([nowDay integerValue] - [lastDay integerValue] ==2 || distanceTime >= 24*60*60*2){
//            distanceStr = [NSString stringWithFormat:@"前天"];//timeStr
//        }
//    }
    else{
        
//        NSCalendar *calendar = [NSCalendar currentCalendar];
//         int unit = NSCalendarUnitYear;
//         // 1.获得当前时间的年月日
//         NSDateComponents *nowCmps = [calendar components:unit fromDate:[NSDate date]];
//         // 2.获得self的年月日
//         NSDateComponents *selfCmps = [calendar components:unit fromDate:beDate];
//        //判断是否是同一年的
//         if (nowCmps.year == selfCmps.year) {
//             [df setDateFormat:@"MM-dd"];
//         }else{
             [df setDateFormat:@"yyyy-MM-dd"];
//         }
        distanceStr = [df stringFromDate:beDate];
    }
    //        else if(distanceTime <24*60*60*365){
    //            [df setDateFormat:@"MM月dd日 HH:mm"];
    //            distanceStr = [df stringFromDate:beDate];
    //        }
    //        else{
    //            [df setDateFormat:@"yyyy-MM-dd HH:mm"];
    //            distanceStr = [df stringFromDate:beDate];
    //        }
    return distanceStr;
    
}

//时间戳--->日期
+ (NSString *)categoriesTransToDate:(NSString *)timsp{
    NSTimeInterval time=[timsp doubleValue]/1000.0;//如果不使用本地时区,因为时差问题要加8小时 == 28800 sec
    NSDate *detaildate=[NSDate dateWithTimeIntervalSince1970:time];
    
    //实例化一个NSDateFormatter对象
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone localTimeZone]];//设置本地时区
    //设定时间格式,这里可以设置成自己需要的格式
    [dateFormatter setDateFormat:@"MM月dd日"];
    
    NSString *currentDateStr = [dateFormatter stringFromDate: detaildate];
    
    //处理月数
    NSString *str1 = [currentDateStr substringToIndex:2];
    NSString *str2 = nil;
    if ([str1 integerValue]<10) {
        str2 = [str1 substringFromIndex:1];
    }else{
        str2 = str1;
    }
    NSString *endString = [NSString stringWithFormat:@"%@%@",str2,[currentDateStr substringFromIndex:2]];
    
    return endString;
}

//时间---->时间戳
+ (NSString *)categoriesTransTotimeSp:(NSString *)time{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone localTimeZone]]; //设置本地时区
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *date = [dateFormatter dateFromString:time];
    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[date timeIntervalSince1970]];//时间戳
    return timeSp;
}

+(NSString *)mgm_timeStrTransformToTimeFomatString:(NSString *)timeFormat timeSourceStr:(NSString *)timeStr
{
    NSTimeInterval interval    =[timeStr doubleValue] / 1000.0;
    NSDate *date               = [NSDate dateWithTimeIntervalSince1970:interval];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:timeFormat];
    
    
    NSString *openDate = [dateFormatter stringFromDate:date];
    return openDate;
}


- (BOOL)isThisYear:(NSData *)selfTimeData

{
    
        NSCalendar *calendar = [NSCalendar currentCalendar];
    
        int unit = NSCalendarUnitYear;
    
        
    
        // 1.获得当前时间的年月日
    
        NSDateComponents *nowCmps = [calendar components:unit fromDate:[NSDate date]];
    
        
    
        // 2.获得self的年月日
    
        NSDateComponents *selfCmps = [calendar components:unit fromDate:selfTimeData];
    
        
    
        return nowCmps.year == selfCmps.year;
    
}


//返回年月日
+ (NSString *)mgm_getCurrentData{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    
    [formatter setDateFormat:@"YYYY-MM-dd"];
    
    //现在时间,你可以输出来看下是什么格式
    
    NSDate *datenow = [NSDate date];
    
    //----------将nsdate按formatter格式转成nsstring
    
    NSString *currentTimeString = [formatter stringFromDate:datenow];
    
    return currentTimeString;
    
}



@end

