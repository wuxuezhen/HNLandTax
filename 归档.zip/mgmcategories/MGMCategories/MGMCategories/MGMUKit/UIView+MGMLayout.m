//
//  UIView+MGMLayout.m
//  MGMCategories
//
//  Created by ww on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIView+MGMLayout.h"
#define MAS_SHORTHAND_GLOBALS
#import <Masonry/Masonry.h>
#import <objc/runtime.h>

@interface UIView ()

@property (nonatomic,copy) void (^tapViewCallBack)(void);

@end

@implementation UIView (MGMLayout)

- (UIView *)mgm_scrollContentView
{
    return [self mgm_scrollContentViewColor:[UIColor whiteColor]];
}

- (UIView *)mgm_scrollContentViewColor:(UIColor *)color
{
    UIScrollView *scroll = [[UIScrollView alloc] init];
    scroll.alwaysBounceVertical = YES;
    scroll.bounces = YES;
    scroll.backgroundColor = color;
    [self addSubview:scroll];
    
    [scroll mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    UIView *contentView = [[UIView alloc] init];
    contentView.backgroundColor = [UIColor clearColor];
    [scroll addSubview:contentView];
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.width.bottom.equalTo(scroll);
    }];
    contentView.clipsToBounds = YES;
    return contentView;
}


/** 使用示例
 [self pe_addSubviewsWithVerticalLayout:@[[topLine pe_wrapperWithFixHeight:0.5],[titleLabel pe_wrapperWithEdgeInsets:UIEdgeInsetsMake(0, RANK_EXAM_ANALYSIS_MARGIN, 0, RANK_EXAM_ANALYSIS_MARGIN)],self.scoreAndTimeView,[resultLabel pe_wrapperWithEdgeInsets:UIEdgeInsetsMake(0, RANK_EXAM_ANALYSIS_MARGIN, 0, RANK_EXAM_ANALYSIS_MARGIN)],[correctAnswerLabel pe_wrapperWithEdgeInsets:UIEdgeInsetsMake(0, RANK_EXAM_ANALYSIS_MARGIN, 0, RANK_EXAM_ANALYSIS_MARGIN)],[yourAnswerLabel pe_wrapperWithEdgeInsets:UIEdgeInsetsMake(0, RANK_EXAM_ANALYSIS_MARGIN, 0, RANK_EXAM_ANALYSIS_MARGIN)],[solutionLabel pe_wrapperWithEdgeInsets:UIEdgeInsetsMake(0, RANK_EXAM_ANALYSIS_MARGIN, 0, RANK_EXAM_ANALYSIS_MARGIN)],[langPointView pe_wrapperWithEdgeInsets:UIEdgeInsetsMake(0, RANK_EXAM_ANALYSIS_MARGIN, 0, RANK_EXAM_ANALYSIS_MARGIN)]] offsets:@[@0,@15,@15,@15,@15,@15,@15,@5]];
 */
- (UIView *)mgm_addSubviewsWithVerticalLayout:(NSArray<UIView *> *)viewsArray offsets:(NSArray<NSNumber *> *)offsetsArray
{
    return [self mgm_addSubviewsWithVerticalLayout:viewsArray offsets:offsetsArray contentViewHeightArray:@[]];
}
- (UIView *)mgm_addSubviewsWithVerticalLayout:(NSArray<UIView *> *)viewsArray offsets:(NSArray<NSNumber *> *)offsetsArray contentViewHeightArray:( NSArray <NSNumber *> * )contentViewHeightArray
{
    NSAssert(viewsArray.count == offsetsArray.count, @"待布局的数组大小应该与间距数组大小保持一致");
    
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    NSInteger n = viewsArray.count;
    if (n > 0) {
        UIView* lastView = viewsArray[0];
        for (NSInteger i = 0 ; i < n ; i++) {
            UIView *v = viewsArray[i];
            [self addSubview:v];
            CGFloat offset = [offsetsArray[i] floatValue];
            
            [v mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.right.equalTo(self);
                if (contentViewHeightArray.count > 0) {
                    NSNumber *nb = contentViewHeightArray[i];
                    if (nb.floatValue>=0) {
                        make.height.equalTo(@(nb.floatValue)).priority(999);
                    }
                }
                if (i==0) {
                    make.top.equalTo(self).offset(offset);
                }else{
                    make.top.equalTo(lastView.mas_bottom).offset(offset);
                }
                if(i == n-1) {
                    make.bottom.equalTo(self);
                }
            }];
            lastView = v;
        }
    }
    return self;
}
- (UIView *)mgm_addSubviewsWithHorizontalLayout:(NSArray<UIView *> *)viewsArray offsets:(NSArray<NSNumber *> *)offsetsArray
{
    return [self mgm_addSubviewsWithHorizontalLayout:viewsArray offsets:offsetsArray contentViewWidthArray:@[]];
}
- (UIView *)mgm_addSubviewsWithHorizontalLayout:(NSArray<UIView *> *)viewsArray offsets:(NSArray<NSNumber *> *)offsetsArray contentViewWidthArray:( NSArray <NSNumber *> * )contentViewWidthArray
{
    NSAssert(viewsArray.count == offsetsArray.count, @"待布局的数组大小应该与间距数组大小保持一致");

    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    NSInteger n = viewsArray.count;
    if (n > 0) {
        UIView* lastView = viewsArray[0];
        for (NSInteger i = 0 ; i < n ; i++) {
            UIView *v = viewsArray[i];
            [self addSubview:v];
            CGFloat offset = [offsetsArray[i] floatValue];
            
            [v mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.bottom.equalTo(self);
                if (contentViewWidthArray.count > 0) {
                    NSNumber *nb = contentViewWidthArray[i];
                    if (nb.floatValue>=0) {
                        make.width.equalTo(@(nb.floatValue)).priority(999);
                    }
                }
               
                if (i==0) {
                    make.left.equalTo(self).offset(offset);
                }else{
                    make.left.equalTo(lastView.mas_right).offset(offset);
                }
                if(i == n-1) {
                    make.right.equalTo(self);
                }
            }];
            lastView = v;
        }
    }
    return self;
}

- (UIView *)mgm_wrapperWithFixHeight:(CGFloat)height
{
    UIView *ret = [[UIView alloc] init];
    [ret addSubview:self];
    [self mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@(height)).priority(999);
        make.edges.equalTo(ret);
    }];
    return ret;
}
- (UIView *)mgm_wrapperWithFixWidth:(CGFloat)width
{
    UIView *ret = [[UIView alloc] init];
    [ret addSubview:self];
    [self mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(width)).priority(999);
        make.edges.equalTo(ret);
    }];
    return ret;
}
-(UIView*)mgm_wrapperWithEdgeInsets:(UIEdgeInsets)padding
{
    UIView *ret = [[UIView alloc] init];
    [ret addSubview:self];
    [self mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(ret).with.insets(padding);
    }];
    return ret;
}

- (void)mgm_tapGestureRecognizerBlock:(void (^)(void))tapBlock
{
    self.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapView)];
    [self addGestureRecognizer:tap];
    self.tapViewCallBack = tapBlock;

}

- (void)tapView
{
    if (self.tapViewCallBack) {
        self.tapViewCallBack();
    }
}

- (void)setTapViewCallBack:(void (^)(void))tapViewCallBack
{
    objc_setAssociatedObject(self, @selector(tapViewCallBack), tapViewCallBack, OBJC_ASSOCIATION_COPY);
}


- (void (^)(void))tapViewCallBack
{
    return objc_getAssociatedObject(self, _cmd);
}
@end
