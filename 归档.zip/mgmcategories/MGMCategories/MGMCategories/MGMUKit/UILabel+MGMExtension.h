//
//  UILabel+MGMExtension.h
//  MGMCategories
//
//  Created by ww on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UILabel (MGMExtension)
/// 设置label，默认系统字体
+ (instancetype)mgm_labelWithText:(NSString *)text fontSize:(NSInteger)fontSize textColor:(UIColor *)color;
/// 设置label，默认系统加粗字体
+ (instancetype)mgm_labelWithText:(NSString *)text boldFontSize:(NSInteger)fontSize textColor:(UIColor *)color;

/**
 *  改变行间距
 */
+ (void)mgm_changeLineSpaceForLabel:(UILabel *)label WithSpace:(float)space autoHeight:(BOOL)autoHeight;
/**
 *  改变字间距
 */
+ (void)mgm_changeWordSpaceForLabel:(UILabel *)label WithSpace:(float)space autoHeight:(BOOL)autoHeight;

/**
 *  改变行间距和字间距
 */
+ (void)mgm_changeSpaceForLabel:(UILabel *)label withLineSpace:(float)lineSpace WordSpace:(float)wordSpace;

- (UILabel *(^)(NSTextAlignment align))mgm_align;
- (UILabel *(^)(NSInteger num))mgm_numberOfLines;
- (UILabel *(^)(UIFont *font))mgm_font;
@end

NS_ASSUME_NONNULL_END
