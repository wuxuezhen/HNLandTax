//
//  UIImage+MGMExtension.h
//  MGMCategories
//
//  Created by ww on 2019/4/16.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (MGMExtension)

- (UIImage *)croppedToRect:(CGRect)rect;

- (UIImage *)scaleToSize:(CGSize)size;

- (UIImage *)scaleToSizeAspectFit:(CGSize)size;

- (UIImage *)scaleToSizeAspectFill:(CGSize)size;

@end

NS_ASSUME_NONNULL_END
