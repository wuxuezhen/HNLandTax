//
//  UIView+MGMToast.h
//  MGMCategories
//
//  Created by YL on 2018/12/27.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (MGMToast)

/**
 toast提示

 @param text 提示文案
 */
- (void)showToastWithText:(NSString *)text;


/**
 toast提示
 
 @param text 提示文案
 */
- (void)showAutoHideToastWithText:(NSString *)text;


/**
 window上显示toast
 
 @param text 提示文案
 */
- (void)showAutoToastInWindowWithText:(NSString *)text;

/**
 删除toast提示
 */
- (void)removeToast;


/// 遮挡点击事件 不可点击
- (void)showLoadingView;

- (void)dismissLoadingView;

/**
 window上的loading操作
 */
- (void)showLoadingInWindow;

- (void)dismissLoadingInWindow;


- (void)showHudActivityIndicator;

- (void)showHorizontalActivityToast;

@end

NS_ASSUME_NONNULL_END
