//
//  MGMUIInitializer.h
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#if __has_include(<MGMCategories/MGMUIInitializer.h>)

#import <MGMCategories/UILabel+MGMInitializer.h>
#import <MGMCategories/UIButton+MGMInitializer.h>
#import <MGMCategories/UIImageView+MGMInitializer.h>
#import <MGMCategories/UIView+MGMRemoveSubviews.h>
#import <MGMCategories/UIView+MGMLayout.h>
#import <MGMCategories/UILabel+MGMExtension.h>
#import <MGMCategories/UILabel+YBAttributeTextTapAction.h>
#else

#import "UILabel+MGMInitializer.h"
#import "UIButton+MGMInitializer.h"
#import "UIImageView+MGMInitializer.h"
#import "UIView+MGMRemoveSubviews.h"

#endif /* MGMUInitializer_h */
