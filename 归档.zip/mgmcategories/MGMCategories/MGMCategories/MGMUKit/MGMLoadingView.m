//
//  MGMLoadingView.m
//  MGMCategories
//
//  Created by wdlzh on 2019/7/25.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMLoadingView.h"

@implementation MGMLoadingView

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return self;
}

- (CGSize)intrinsicContentSize {
    return CGSizeMake(self.bounds.size.width, self.bounds.size.height);
}

@end
