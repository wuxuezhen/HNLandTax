//
//  UINavigationBar+MGMAppearance.h
//  MGMTicket
//
//  Created by MyMac on 2018/12/4.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (MGMAppearance)

- (void)mgm_setContentAlpha:(CGFloat)alpha translationY:(CGFloat)translationY;

@end
