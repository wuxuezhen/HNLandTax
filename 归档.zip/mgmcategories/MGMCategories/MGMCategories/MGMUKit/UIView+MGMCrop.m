//
//  UIView+MGMCrop.m
//  MGMCategories
//
//  Created by YL on 2019/5/23.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIView+MGMCrop.h"

@implementation UIView (MGMCrop)

- (UIImage *)snapshotImage {
    UIGraphicsBeginImageContext(self.bounds.size);
    [self.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

- (UIImage *)snapshotImageWithScrollView:(UIScrollView *)scrollView {
    UIImage* image = nil;
    
//    UIGraphicsBeginImageContext(scrollView.contentSize);
    UIGraphicsBeginImageContextWithOptions(scrollView.contentSize, YES, [UIScreen mainScreen].scale);
    CGPoint savedContentOffset = scrollView.contentOffset;
    CGRect savedFrame = scrollView.frame;
    
    scrollView.contentOffset = CGPointZero;
    self.frame = CGRectMake(0, 0, scrollView.contentSize.width, scrollView.contentSize.height);
    
    [self.layer renderInContext: UIGraphicsGetCurrentContext()];
    image = UIGraphicsGetImageFromCurrentImageContext();
    scrollView.contentOffset = savedContentOffset;
    self.frame = savedFrame;
    UIGraphicsEndImageContext();
    return image;
}

@end
