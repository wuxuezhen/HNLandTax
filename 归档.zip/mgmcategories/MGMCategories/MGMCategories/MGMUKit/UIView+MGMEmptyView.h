//
//  UIView+MGMEmptyView.h
//  MGMCategories
//
//  Created by YL on 2019/4/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (MGMEmptyView)

- (void)showEmptyViewWithImage:(UIImage *)emptyImage
                         title:(NSString *)emptyTitle;


- (void)showEmptyViewWithImage:(UIImage *)emptyImage
                         title:(NSString *)emptyTitle
                   buttonTitle:(NSString *)buttonTitle
                 buttonHandler:(void(^)(void))handler;


- (void)showEmptyViewWithImage:(UIImage *)emptyImage
                         title:(NSString *)emptyTitle
                 titleDistance:(CGFloat)titleDistance
                   buttonTitle:(NSString *)buttonTitle
                buttonDistance:(CGFloat)buttonDistance
                 buttonHandler:(void(^)(void))handler;

@end

NS_ASSUME_NONNULL_END
