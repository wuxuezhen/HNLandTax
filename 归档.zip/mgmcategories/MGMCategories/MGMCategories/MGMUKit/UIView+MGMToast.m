//
//  UIView+MGMToast.m
//  MGMCategories
//
//  Created by YL on 2018/12/27.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIView+MGMToast.h"
#import <MBProgressHUD/MBProgressHUD.h>
#import <YYWebImage/YYWebImage.h>
#import <YYImage/YYAnimatedImageView.h>
#import "MGMLoadingView.h"

@interface MGMActivityToastView : UIView

@property (nonatomic, strong) UIActivityIndicatorView   *activityView;

@property (nonatomic,strong) UILabel                    *activityTipLabel;

@property (nonatomic,copy)   NSString                   *toast;

@end

@implementation MGMActivityToastView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        self.activityView.frame  = CGRectMake(0, 0, 20, 20);
        self.activityTipLabel.frame = CGRectMake(30 , 3.5, 0, 13);
        [self.activityView startAnimating];
        [self addSubview:self.activityView];
        [self addSubview:self.activityTipLabel];
    }
    return self;
}

- (void)setToast:(NSString *)toast {
    _toast = toast;
    self.activityTipLabel.text = toast;
    [self.activityTipLabel sizeToFit];
}

- (CGSize)intrinsicContentSize {
    return self.frame.size;
}

- (UIActivityIndicatorView *)activityView {
    if(!_activityView) {
        _activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    }
    return _activityView;
}

- (UILabel *)activityTipLabel {
    if(!_activityTipLabel) {
        _activityTipLabel = [[UILabel alloc] init];
        _activityTipLabel.textColor = [UIColor whiteColor];
        _activityTipLabel.font = [UIFont systemFontOfSize:13];
    }
    return _activityTipLabel;
}


@end

@implementation UIView (MGMToast)

- (void)showToastWithText:(NSString *)text  {
    [self removeToast];
    if(text.length == 0) {
        return;
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self animated:YES];
    hud.userInteractionEnabled = NO;
    hud.mode = MBProgressHUDModeText;
    [self mgm_settingHUD:hud text:text];
}

- (void)showLoadingView {
    [self removeToast];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self animated:YES];
    [self addLoadingViewInHud:hud];
}

- (void)dismissLoadingView {
    [MBProgressHUD hideHUDForView:self animated:YES];
}

- (void)showAutoHideToastWithText:(NSString *)text {
    [self showToastWithText:text];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:self animated:YES];
    });
}

- (void)showAutoToastInWindowWithText:(NSString *)text {
    if(text.length == 0) {
        return;
    }
    UIWindow *lastWindow =  [UIApplication sharedApplication].windows.lastObject;
    [MBProgressHUD hideHUDForView:lastWindow animated:NO];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:lastWindow animated:YES];
    hud.userInteractionEnabled = NO;
    hud.mode = MBProgressHUDModeText;
    [self mgm_settingHUD:hud text:text];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:lastWindow animated:YES];
    });
}

- (void)showHudActivityIndicator {
    [self showHudActivityIndicatorWithText:@"加载中..."];
}

- (void)showHudActivityIndicatorWithText:(NSString *)text {
    [self removeToast];
    UIWindow *lastWindow =  [UIApplication sharedApplication].windows.lastObject;
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:lastWindow animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.activityIndicatorColor = [UIColor whiteColor];
    hud.userInteractionEnabled = NO;
    [self mgm_settingHUD:hud text:text];
}

- (void)showToastWithText:(NSString *)text delayHidden:(CGFloat)delay {
    [self showToastWithText:text];
    if (delay <= 0.0)
    {
        delay = 1.0;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:self animated:YES];
    });
}

- (void)removeToast {
    MBProgressHUD *existsHud = [MBProgressHUD HUDForView:self];
    if (existsHud) {
        [MBProgressHUD hideHUDForView:self animated:NO];
    }
    UIWindow *lastWindow =  [UIApplication sharedApplication].windows.lastObject;
    MBProgressHUD *existsWindowHud = [MBProgressHUD HUDForView:lastWindow];
    if(existsWindowHud) {
        [MBProgressHUD hideHUDForView:lastWindow animated:NO];
    }
}

- (void)showLoadingInWindow {
    [self removeToast];
    UIWindow *lastWindow =  [UIApplication sharedApplication].windows.lastObject;
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:lastWindow animated:YES];
    [self addLoadingViewInHud:hud];
}

- (void)dismissLoadingInWindow {
    UIWindow *lastWindow =  [UIApplication sharedApplication].windows.lastObject;
    [MBProgressHUD hideHUDForView:lastWindow animated:YES];
}

//hud上添加 loading.gif
- (void)addLoadingViewInHud:(MBProgressHUD *)hud {
    
    UIImageView *loadimgimgView = [[YYAnimatedImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    loadimgimgView.contentMode = UIViewContentModeScaleAspectFit;
    
    NSString *path = [[[NSBundle mainBundle] pathForResource:@"MGMLoading" ofType:@"bundle"] stringByAppendingPathComponent:@"mgm_loading.gif"];
    loadimgimgView.yy_imageURL = [NSURL fileURLWithPath:path];
    
    MGMLoadingView *loadingView = [[MGMLoadingView alloc]initWithFrame:loadimgimgView.frame];
    [loadingView addSubview:loadimgimgView];
    
    hud.customView = loadingView;
    
    // Set custom view mode
    hud.mode = MBProgressHUDModeCustomView;
    hud.bezelView.color = [UIColor clearColor];
    hud.contentColor = [UIColor clearColor];
    
    hud.minSize = CGSizeMake(self.bounds.size.width, self.bounds.size.height);
    UIView *effView = [hud.bezelView subviews].firstObject;
    //    hud.userInteractionEnabled = NO;
    //设置yes 遮挡点击事件
    hud.userInteractionEnabled = YES;
    
    effView.alpha = 0;
}

- (void)showHorizontalActivityToast {
    [self showHorizontalActivityToast:@"加载中"];
}

- (void)showHorizontalActivityToast:(NSString *)text {
    [self removeToast];
    UIWindow *lastWindow =  [UIApplication sharedApplication].windows.lastObject;
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:lastWindow animated:YES];
    hud.mode = MBProgressHUDModeCustomView;
    hud.userInteractionEnabled = NO;
    CGSize textSize = [text boundingRectWithSize:CGSizeMake(1000, 1000) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13]} context:nil].size;
    CGFloat toastWidth = textSize.width+30 > [UIScreen mainScreen].bounds.size.width - 100 ?[UIScreen mainScreen].bounds.size.width - 100 :textSize.width+30;
    MGMActivityToastView *avtivityToastView = [[MGMActivityToastView alloc] initWithFrame:CGRectMake(0, 0,toastWidth , 20)];
    avtivityToastView.toast = text;
    hud.customView = avtivityToastView;
    
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:.7];
    hud.layer.cornerRadius = 4.0f;
    hud.margin = 8.5;
    hud.minSize = CGSizeMake(textSize.width+56, 33);
}

- (void)mgm_settingHUD:(MBProgressHUD *)HUD
                  text:(NSString *)text {
    CGSize textSize = [text boundingRectWithSize:CGSizeMake(1000, 1000) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13]} context:nil].size;
    if(textSize.height > 20) { //需要换行
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        [paragraphStyle setLineSpacing:6];
        NSMutableAttributedString *toastText = [[NSMutableAttributedString alloc] initWithString:text attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13],NSParagraphStyleAttributeName:paragraphStyle}];
        HUD.label.attributedText = toastText;
    }
    else {
        HUD.label.text = text;
    }
    HUD.label.font = [UIFont systemFontOfSize:13];
    HUD.label.textColor = [UIColor whiteColor];
    HUD.label.numberOfLines = 0;
    HUD.label.textAlignment = NSTextAlignmentCenter;
    HUD.label.lineBreakMode = NSLineBreakByWordWrapping;
    HUD.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    HUD.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:.7];
    HUD.layer.cornerRadius = 4.0f;
    HUD.margin = 8.5;
    HUD.minSize = CGSizeMake(textSize.width+36, textSize.height> 20 ? 61 : 33);
}

@end


