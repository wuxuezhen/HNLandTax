//
//  UIImageView+HBInitializer.m
//  Adapter
//
//  Created by apple on 2018/11/29.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIImageView+MGMInitializer.h"

@implementation UIImageView (MGMInitializer)

- (instancetype)mgm_initWithImage:(UIImage *)image contentMode:(UIViewContentMode)contentMode {
    UIImageView *imageView = [[[self class] alloc] initWithImage:image];
    imageView.contentMode = contentMode;
    return imageView;
}

@end
