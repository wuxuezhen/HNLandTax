//
//  UIView+MGMPosition.m
//  MGMCategories
//
//  Created by YL on 2019/7/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIView+MGMPosition.h"

@implementation UIView (MGMPosition)

- (BOOL)isVisible {
    return nil != [self window];
}

- (BOOL)isVisibleOnScreen
{
    if (self == nil)
    {
        return NO;
    }
    
    if (self.isHidden)
    {
        return NO;
    }
    
    if (self.superview==nil)
    {
        return NO;
    }
    
    if (CGSizeEqualToSize(self.bounds.size, CGSizeZero)) {
        return NO;
    }
    
    CGRect screenRect = [UIScreen mainScreen].bounds;
    CGRect frameInWindow = [self convertRect:self.bounds toView:nil];
    
    if (!CGRectIntersectsRect(screenRect, frameInWindow))
    {
        return NO;
    }
    
    return YES;
}
@end
