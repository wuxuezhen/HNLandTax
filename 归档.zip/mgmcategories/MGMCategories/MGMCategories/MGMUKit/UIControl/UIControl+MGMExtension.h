//
//  UIControl+MGMExtension.h
//  MGMCategories
//
//  Created by ww on 2019/7/29.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIControl (MGMExtension)
/// 可以用这个给重复点击加间隔
@property (nonatomic, assign) NSTimeInterval mgm_acceptEventInterval;

@end

NS_ASSUME_NONNULL_END
