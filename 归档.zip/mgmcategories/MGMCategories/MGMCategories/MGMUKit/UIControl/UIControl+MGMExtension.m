//
//  UIControl+MGMExtension.m
//  MGMCategories
//
//  Created by ww on 2019/7/29.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIControl+MGMExtension.h"
#import <objc/runtime.h>

@interface UIControl()

@property (nonatomic, assign) BOOL mgm_ignoreEvent;

@end



@implementation UIControl (MGMExtension)

static const char *UIControl_acceptEventInterval = "UIControl_acceptEventInterval";
static const char *UIControl_ignoreEvent = "UIControl_ignoreEvent";

- (NSTimeInterval)mgm_acceptEventInterval
{
    return [objc_getAssociatedObject(self, UIControl_acceptEventInterval) doubleValue];
}

- (void)setMgm_acceptEventInterval:(NSTimeInterval)mgm_acceptEventInterval
{
    objc_setAssociatedObject(self, UIControl_acceptEventInterval, @(mgm_acceptEventInterval), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (BOOL)mgm_ignoreEvent
{
    return [objc_getAssociatedObject(self, UIControl_ignoreEvent) boolValue];
}

- (void)setMgm_ignoreEvent:(BOOL)mgm_ignoreEvent
{
    objc_setAssociatedObject(self, UIControl_ignoreEvent, @(mgm_ignoreEvent), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

+ (void)load
{
    Method a = class_getInstanceMethod(self, @selector(sendAction:to:forEvent:));
    Method b = class_getInstanceMethod(self, @selector(mgm_sendAction:to:forEvent:));
    method_exchangeImplementations(a, b);
}

- (void)mgm_sendAction:(SEL)action to:(id)target forEvent:(UIEvent *)event
{
    if (self.mgm_ignoreEvent) {
        return;
    }
    if (self.mgm_acceptEventInterval > 0) {
        self.mgm_ignoreEvent = YES;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(self.mgm_acceptEventInterval * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.mgm_ignoreEvent = NO;
        });
    }
    [self mgm_sendAction:action to:target forEvent:event];
}

@end

