//
//  UIView+MGMPosition.h
//  MGMCategories
//
//  Created by YL on 2019/7/12.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (MGMPosition)

- (BOOL)isVisible;

- (BOOL)isVisibleOnScreen;

@end

NS_ASSUME_NONNULL_END
