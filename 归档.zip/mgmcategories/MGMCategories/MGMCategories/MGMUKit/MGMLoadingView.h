//
//  MGMLoadingView.h
//  MGMCategories
//
//  Created by wdlzh on 2019/7/25.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MGMLoadingView : UIView

@end

NS_ASSUME_NONNULL_END
