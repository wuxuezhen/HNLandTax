//
//  UINavigationBar+MGM.h
//  MGMCategories
//
//  Created by RenYi on 2019/1/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UINavigationBar (MGM)

@property (nonatomic, assign) BOOL mgm_hideShadowImage;

- (void)mgm_setBackgroundAlpha:(CGFloat)alpha;

- (void)setNavigationBarTranslationY:(CGFloat)navigationBarTranslationY;

- (void)mgm_setBackIndicatorImage:(UIImage *)image;

//- (CGFloat)navigationBarAndStatusBarHeight;

@end

NS_ASSUME_NONNULL_END
