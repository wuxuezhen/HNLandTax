//
//  UIView+MGMLayout.h
//  MGMCategories
//
//  Created by ww on 2019/1/10.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (MGMLayout)
/// 返回可以滚动的contentView 默认白色
- (UIView *)mgm_scrollContentView;

/// 返回可以滚动的contentView 自定义scollView的背景色
- (UIView *)mgm_scrollContentViewColor:(UIColor *)color;

/**
 快速垂直布局
 
 @param viewsArray 待布局的view数组
 @param offsetsArray 距离上个view的垂直间距数组
 @return 快速垂直布局view
 */
- (UIView *)mgm_addSubviewsWithVerticalLayout:(NSArray<UIView *> *)viewsArray offsets:(NSArray<NSNumber *> *)offsetsArray;

//- (UIView *)mgm_addSubviewsWithVerticalLayout:(NSArray<UIView *> *)viewsArray offsets:(NSArray<NSNumber *> *)offsetsArray contentViewHeightArray:( NSArray <NSNumber *> * )contentViewHeightArray;
/**
 快速水平布局

 @param viewsArray 待布局的view数组
 @param offsetsArray 距离上个view的水平间距数组
 @param contentViewWidthArray 数组里面每一个元素的宽度
 @return 快速水平布局view
 */
//- (UIView *)mgm_addSubviewsWithHorizontalLayout:(NSArray<UIView *> *)viewsArray offsets:(NSArray<NSNumber *> *)offsetsArray contentViewWidthArray:(NSArray<NSNumber *> *)contentViewWidthArray;

/**
 快速水平布局
 
 @param viewsArray 待布局的view数组
 @param offsetsArray 距离上个view的水平间距数组
 @return 快速水平布局view
 */
- (UIView *)mgm_addSubviewsWithHorizontalLayout:(NSArray<UIView *> *)viewsArray offsets:(NSArray<NSNumber *> *)offsetsArray;
/**
 四边紧贴、高度指定外壳
 
 @param height 指定高度
 @return 指定高度的view
 */
- (UIView *)mgm_wrapperWithFixHeight:(CGFloat)height;
/**
 四边紧贴、高度指定外壳
 
 @param width 指定宽度
 @return 指定宽度的view
 */
- (UIView *)mgm_wrapperWithFixWidth:(CGFloat)width;

/**
 *  指定padding、中心对齐外壳
 */
-(UIView*)mgm_wrapperWithEdgeInsets:(UIEdgeInsets)padding;

/// 添加点击手势事件
- (void)mgm_tapGestureRecognizerBlock:(void (^)(void))tapBlock;

@end

NS_ASSUME_NONNULL_END
