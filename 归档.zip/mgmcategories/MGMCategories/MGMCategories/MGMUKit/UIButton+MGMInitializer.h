//
//  UIButton+HBInitializer.h
//  Adapter
//
//  Created by apple on 2018/11/29.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#define MAS_SHORTHAND_GLOBALS

#import <Masonry/Masonry.h>

@interface UIButton (MGMConfig)

- (void)mgm_setNormalTitle:(NSString *)title;
- (void)mgm_setHighlightedTitle:(NSString *)highlightedTitle;
- (void)mgm_setSelectedTitle:(NSString *)selectedTitle;

- (void)mgm_setFont:(UIFont *)font;

- (void)mgm_setTitle:(NSString *)title
         titleColor:(UIColor *)titleColor
           forState:(UIControlState)state;
- (void)mgm_setTitleNormalColor:(UIColor *)normalColor
              highlightedColor:(UIColor *)highlightedColor
                 selectedColor:(UIColor *)selectedColor;
- (void)mgm_withBlock:(void (^)(id sender))tapBlock;

/// button倒计时
/// @param timeout 超时s时间
/// @param coutDownCallBack 倒计时结束调用
/// @param coutingCallBack 倒计时过程调用
- (void)mgm_countDouwnTimeout:(NSInteger)timeout
         coutDownCallBack:(void(^)(UIButton *btn))coutDownCallBack
          coutingCallBack:(void(^)(UIButton *btn,NSString *countStr))coutingCallBack;
@end

@interface UIButton (MGMInitializer)


+ (instancetype)mgm_customTypeButtonWith:(id)target
                                 action:(SEL)action
                          controlEvents:(UIControlEvents)controlEvent;

+ (instancetype)mgm_addRoundCornerButtonOnContainerView:(UIView *)containerView
                                        backgroundColor:(UIColor *)backgroundColor
                                                 target:(id)target
                                                 action:(SEL)action
                                                   font:(UIFont *)font
                                                  title:(NSString *)title
                                           cornerRadius:(CGFloat)cornerRadius
                                             constraint:(void (^)(MASConstraintMaker *make))constraint;

@end
