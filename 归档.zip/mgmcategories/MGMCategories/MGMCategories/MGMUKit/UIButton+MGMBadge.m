//
//  UIButton+MGMBadge.m
//  MGMCategories
//
//  Created by YL on 2019/5/23.
//  Copyright © 2019 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIButton+MGMBadge.h"
#import <objc/runtime.h>

@interface UIButton()

@property (nonatomic, strong) UILabel  *badgeLabel;

@property (nonatomic, assign) CGSize     badgeSize;

@end

@implementation UIButton (MGMBadge)

- (void)setBadgeValue:(NSString *)badgeValue
         badgeBgColor:(UIColor *)badgeBgColor
           badgeColor:(UIColor *)badgeColor
                 font:(NSInteger)font {
    
    if(badgeValue.integerValue == 0){
        if(self.badgeLabel){
            [self.badgeLabel removeFromSuperview];
            self.badgeLabel = nil;
        }
        return;
    }
    
    CGSize size = [badgeValue boundingRectWithSize:CGSizeMake(1000, 1000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont fontWithName:@"PingFangSC-Semibold" size:font]} context:nil].size;
    
    self.badgeSize = badgeValue.integerValue < 100 ? CGSizeMake(23, 16) : CGSizeMake(size.width+8, size.height+4);
    
    if(!self.badgeLabel){
        self.badgeLabel = [[UILabel alloc] init];
        self.badgeLabel.textAlignment = NSTextAlignmentCenter;
        self.badgeLabel.font = [UIFont fontWithName:@"PingFangSC-Semibold" size: font];
        self.badgeLabel.backgroundColor = badgeBgColor;
        self.badgeLabel.textColor = badgeColor;
        self.badgeLabel.layer.cornerRadius = self.badgeSize.height/2;
        self.badgeLabel.layer.masksToBounds = YES;
        [self addSubview:self.badgeLabel];
    }
    self.badgeLabel.frame = CGRectMake(self.frame.size.width-self.badgeSize.width/2, -self.badgeSize.height/2, self.badgeSize.width, self.badgeSize.height);
    self.badgeLabel.text = badgeValue;
}

- (void)setBadgeValue:(NSString *)badgeValue
         badgeBgColor:(UIColor *)badgeBgColor
           badgeColor:(UIColor *)badgeColor
                 font:(NSInteger)font
           buttonSize:(CGSize)buttonSize {
    
    [self setBadgeValue:badgeValue
           badgeBgColor:badgeBgColor
             badgeColor:badgeColor
                   font:font];
    self.badgeLabel.frame = CGRectMake(buttonSize.width-self.badgeSize.width/2, -5, self.badgeSize.width, self.badgeSize.height);
}


- (void)setBadgeLabel:(UILabel *)badgeLabel{
    objc_setAssociatedObject(self, @selector(badgeLabel), badgeLabel, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UILabel *)badgeLabel{
    return objc_getAssociatedObject(self, @selector(badgeLabel));
}


- (void)setBadgeSize:(CGSize)badgeSize {
    objc_setAssociatedObject(self, @selector(badgeSize), NSStringFromCGSize(badgeSize), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (CGSize)badgeSize {
    NSString *sizeString = objc_getAssociatedObject(self, @selector(badgeSize));
    return CGSizeFromString(sizeString);
}

@end

