//
//  UILabel+HBInitializer.m
//  Adapter
//
//  Created by apple on 2018/11/29.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UILabel+MGMInitializer.h"


@implementation UILabel (MGMConfig)

- (void)mgm_setFont:(UIFont *)font
         textColor:(UIColor *)textColor
     textAlignment:(NSTextAlignment)textAlignment
     lineBreakMode:(NSLineBreakMode)lineBreakMode{
    if (font) {
        self.font = [UIFont systemFontOfSize:17];
    }
    if (textColor) {
        self.textColor = textColor? textColor : [UIColor blackColor];
    }
    self.textAlignment = textAlignment;
    self.lineBreakMode = lineBreakMode;
}

- (void)mgm_setText:(NSString *)text textColor:(UIColor *)textColor {
    self.text = text;
    self.textColor = textColor;
}

@end

@implementation UILabel (MGMInitializer)

+ (instancetype)mgm_lableWithFont:(UIFont *)font
                       textColor:(UIColor *)textColor
                   textAlignment:(NSTextAlignment)textAlignment
                   lineBreakMode:(NSLineBreakMode)lineBreakMode {
    UILabel *lable = [[[self class] alloc] init];
    [lable mgm_setFont:font textColor:textColor textAlignment:textAlignment lineBreakMode:lineBreakMode];
    return lable;
}

@end
