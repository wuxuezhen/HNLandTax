//
//  UIColor+MGMColorExtension.m
//  MGMTicket
//
//  Created by 刘志辉 on 2018/11/26.
//  Copyright © 2018 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "UIColor+MGMColorExtension.h"

@implementation UIColor (MGMColorExtension)

+ (instancetype)r:(uint8_t)r g:(uint8_t)g b:(uint8_t)b a:(uint8_t)a{
    return [UIColor colorWithRed:r/255. green:g/255. blue:b/255. alpha:a/255.];
}

+ (instancetype)rgba:(NSUInteger)rgba{
    return [self r:(rgba >> 24)&0xFF g:(rgba >> 16)&0xFF b:(rgba >> 8)&0xFF a:rgba&0xFF];
}

+(UIColor *)dealHexString:(NSString *)colorString{
    NSString *cString = [[colorString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) {
        return [UIColor clearColor];
    }
    // 判断前缀
    if ([cString hasPrefix:@"0X"])
        cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor clearColor];
    // 从六位数值中找到RGB对应的位数并转换
    NSRange range;
    range.location = 0;
    range.length = 2;
    //R、G、B
    NSString *rString = [cString substringWithRange:range];
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f) green:((float) g / 255.0f) blue:((float) b / 255.0f) alpha:1.0f];
    
}
+ (UIColor *)dealHexString:(NSString *)colorString alpha:(CGFloat)alpha {
    //去除空格
    NSString *cString = [[colorString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    //把开头截取
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"]) cString = [cString substringFromIndex:1];
    //6位或8位(带透明度)
    if ([cString length] < 6) {
        return nil;
    }
    //取出透明度、红、绿、蓝
    unsigned int a, r, g, b;
    NSRange range;
    range.location = 0;
    range.length = 2;
    if (cString.length == 8) {
        //a
        NSString *aString = [cString substringWithRange:range];
        //r
        range.location = 2;
        NSString *rString = [cString substringWithRange:range];
        //g
        range.location = 4;
        NSString *gString = [cString substringWithRange:range];
        //b
        range.location = 6;
        NSString *bString = [cString substringWithRange:range];
        
        [[NSScanner scannerWithString:aString] scanHexInt:&a];
        [[NSScanner scannerWithString:rString] scanHexInt:&r];
        [[NSScanner scannerWithString:gString] scanHexInt:&g];
        [[NSScanner scannerWithString:bString] scanHexInt:&b];
        
        return [UIColor colorWithRed:(r / 255.0f) green:(g / 255.0f) blue:(b / 255.0f) alpha:(a / 255.0f)];
    } else {
        //r
        NSString *rString = [cString substringWithRange:range];
        //g
        range.location = 2;
        NSString *gString = [cString substringWithRange:range];
        //b
        range.location = 4;
        NSString *bString = [cString substringWithRange:range];
        
        [[NSScanner scannerWithString:rString] scanHexInt:&r];
        [[NSScanner scannerWithString:gString] scanHexInt:&g];
        [[NSScanner scannerWithString:bString] scanHexInt:&b];
        
        return [UIColor colorWithRed:(r / 255.0f) green:(g / 255.0f) blue:(b / 255.0f) alpha:alpha];
    }
}
+ (UIColor *)mgm_colorGradientChangeWithSize:(CGSize)size
                                   direction:(MGMGradientChangeDirection)direction
                                  startColor:(UIColor *)startcolor
                                    endColor:(UIColor *)endColor {
    
    if (CGSizeEqualToSize(size, CGSizeZero) || !startcolor || !endColor) {
        return nil;
    }
    
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = CGRectMake(0, 0, size.width, size.height);
    
    CGPoint startPoint = CGPointZero;
    if (direction == MGMGradientChangeDirectionDownDiagonalLine) {
        startPoint = CGPointMake(0.0, 1.0);
    }
    gradientLayer.startPoint = startPoint;
    
    CGPoint endPoint = CGPointZero;
    switch (direction) {
        case MGMGradientChangeDirectionLevel:
            endPoint = CGPointMake(1.0, 0.0);
            break;
        case MGMGradientChangeDirectionVertical:
            endPoint = CGPointMake(0.0, 1.0);
            break;
        case MGMGradientChangeDirectionUpwardDiagonalLine:
            endPoint = CGPointMake(1.0, 1.0);
            break;
        case MGMGradientChangeDirectionDownDiagonalLine:
            endPoint = CGPointMake(1.0, 0.0);
            break;
        default:
            break;
    }
    gradientLayer.endPoint = endPoint;
    
    gradientLayer.colors = @[(__bridge id)startcolor.CGColor, (__bridge id)endColor.CGColor];
    UIGraphicsBeginImageContext(size);
    [gradientLayer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage*image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return [UIColor colorWithPatternImage:image];
}

+ (UIColor *)mgm_colorGradientChangeWithSize:(CGSize)size
                                  startPoint:(CGPoint)startPoint
                                    endPoint:(CGPoint)endPoint
                                  startColor:(UIColor *)startcolor
                                    endColor:(UIColor *)endColor {
    
    if (CGSizeEqualToSize(size, CGSizeZero) || !startcolor || !endColor) {
        return nil;
    }
    
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = CGRectMake(0, 0, size.width, size.height);
    
    gradientLayer.startPoint = startPoint;
    
    gradientLayer.endPoint = endPoint;
    
    gradientLayer.colors = @[(__bridge id)startcolor.CGColor, (__bridge id)endColor.CGColor];
    UIGraphicsBeginImageContext(size);
    [gradientLayer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage*image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return [UIColor colorWithPatternImage:image];
}
  
- (UIColor *)mgm_blendDarken { //变暗
    const CGFloat * components1 = CGColorGetComponents(self.CGColor);
    CGFloat r = components1[0] * 0.618;
    CGFloat g = components1[1] * 0.618;
    CGFloat b = components1[2] * 0.618;
    return  [UIColor colorWithRed:r green:g blue:b alpha:1];;
}
    
    /// 加亮
- (UIColor *)mgm_blendLighten {
    const CGFloat * components1 = CGColorGetComponents(self.CGColor);
    CGFloat r = components1[0] * 0.618;
    CGFloat g = components1[1] * 0.618;
    CGFloat b = components1[2] * 0.618;
    
    r = r + (1 - r) / 6.18;
    g = g + (1 - g) / 6.18;
    b = b + (1 - b) / 6.18;
    return [UIColor colorWithRed:r green:g blue:b alpha:1];
}
    
//混合颜色,ratio 0~1
+ (UIColor *)mgm_blendColor:(UIColor *)currentColor
                   mixColor:(UIColor *)mixColor
                      ratio:(CGFloat)ratio {
    if(ratio > 1) {
        ratio = 1;
    }
    if(ratio < 0) {
        ratio = 0;
    }
    const CGFloat * components1 = CGColorGetComponents(currentColor.CGColor);
    const CGFloat * components2 = CGColorGetComponents(mixColor.CGColor);
    CGFloat r = components1[0]*(1-ratio) + components2[0]* ratio;
    CGFloat g = components1[1]*(1-ratio) + components2[1]* ratio;
    CGFloat b = components1[2]*(1-ratio) + components2[2]* ratio;
    return [UIColor colorWithRed:r green:g blue:b alpha:1];
}

    
@end
