//
//  NSDate+MGMDateUnit.m
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "NSDate+MGMDateUnit.h"

static NSCalendar *sharedCalendar = nil;

@implementation NSCalendar (SYDateUnit)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedCalendar = [NSCalendar currentCalendar];
    });
}

+ (NSCalendar *)shared {
    return sharedCalendar;
}

@end

@implementation NSDate (MGMDateUnit)


- (NSArray *)p_allMonth {
    static NSArray *allMonth;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        allMonth = @[@{@"cn":@"一月", @"en_short": @"Jan.", @"en_full":@"January"},
                     @{@"cn":@"二月", @"en_short": @"Feb.", @"en_full": @"February"},
                     @{@"cn":@"三月", @"en_short": @"Mar.", @"en_full":@"March"},
                     @{@"cn":@"四月", @"en_short": @"Apr.", @"en_full":@"April"},
                     @{@"cn":@"五月", @"en_short": @"May.", @"en_full":@"May"},
                     @{@"cn":@"六月", @"en_short": @"Jun.", @"en_full":@"June"},
                     @{@"cn":@"七月", @"en_short": @"Jul.", @"en_full": @"Jule"},
                     @{@"cn":@"八月", @"en_short": @"Aug.", @"en_full":@"August"},
                     @{@"cn":@"九月", @"en_short": @"Sept.", @"en_full":@"September"},
                     @{@"cn":@"十月", @"en_short": @"Oct.", @"en_full":@"October"},
                     @{@"cn":@"十一月", @"en_short": @"Nov.", @"en_full":@"November"},
                     @{@"cn":@"十二月", @"en_short": @"Dec.", @"en_full":@"December"}];
    });
    
    return allMonth;
}

- (NSDateComponents *)p_dateComponents {
    NSCalendarUnit unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond | NSCalendarUnitWeekOfMonth | NSCalendarUnitWeekOfYear|NSCalendarUnitWeekday;
    
    return [sharedCalendar components:unitFlags fromDate:self];
}

- (NSInteger)mgm_year {
    return [self p_dateComponents].year;
}

- (NSString *)mgm_enShortMonth {
    NSDictionary *monthInfo = [[self p_allMonth] objectAtIndex:[self mgm_month]-1];
    return monthInfo[@"en_short"];
}

- (NSInteger)mgm_month {
    return [self p_dateComponents].month;
}


- (NSInteger)mgm_day {
    return [self p_dateComponents].day;
}


- (NSInteger)mgm_hour {
    return [self p_dateComponents].hour;
}


- (NSInteger)mgm_minute {
    return [self p_dateComponents].minute;
}


- (NSInteger)mgm_second {
    return [self p_dateComponents].second;
}

- (NSInteger)mgm_weekday {
    return [self p_dateComponents].weekday;
}

- (NSString *)mgm_weekDayWithFor:(NSString *)format {
    static NSArray *weeks;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        weeks = @[@"日",@"一", @"二", @"三", @"四", @"五", @"六"];
    });
    NSInteger index = [self mgm_weekday];
    NSString *week = [format stringByReplacingOccurrencesOfString:@"MGMWK" withString:weeks[index-1]];
//    NSString
    return week;
}

- (NSInteger)mgm_weekOfMonth {
    return [self p_dateComponents].weekOfMonth;
}


- (NSInteger)mgm_weakOfYear {
    return [self p_dateComponents].weekOfYear;
}


- (NSDate *)mgm_dateByAddingUnit:(NSCalendarUnit)unit value:(NSInteger)value {
    return [sharedCalendar dateByAddingUnit:unit value:value toDate:self options:NSCalendarWrapComponents];
}


- (NSDate *)mgm_dateBySettingUnit:(NSCalendarUnit)unit value:(NSInteger)v  {
    return [sharedCalendar dateBySettingUnit:unit value:v ofDate:self options:NSCalendarWrapComponents];
}


- (NSDate *)mgm_dateBySettingHour:(NSInteger)h minute:(NSInteger)m second:(NSInteger)s {
    return [sharedCalendar dateBySettingHour:h minute:m second:s ofDate:self options:NSCalendarWrapComponents];
}

@end
