//
//  NSDate+MGMCompare.h
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef struct MGMDate {
    NSInteger era;
    NSInteger year;
    NSInteger month;
    NSInteger day;
    NSInteger hour;
    NSInteger minute;
    NSInteger second;
} MGMDateComponents;

@interface NSDate (MGMCompare)


- (BOOL)mgm_isDateInToday;
- (BOOL)mgm_isDateInYesterday;
- (BOOL)mgm_isDateInTomorrow;
- (BOOL)mgm_isDateInWeekend;

- (BOOL)mgm_isInSameWith:(NSDate *)date;
- (BOOL)mgm_isEqualToDate:(NSDate *)date in:(NSCalendarUnit)unit;
- (NSInteger)mgm_daysToDate:(NSDate *)date;
- (void)mgm_timeIntervalToDate:(NSDate *)date callback:(void(^)(MGMDateComponents dateComponents))callback;
- (NSDateComponents *)mgm_components:(NSCalendarUnit)unitFlags fromDate:(NSDate *)startingDate toDate:(NSDate *)resultDate;

@end
