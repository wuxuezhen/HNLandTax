//
//  NSDate+MGMCompare.m
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "NSDate+MGMCompare.h"
#import "NSDate+MGMDateUnit.h"


@implementation NSDate (MGMCompare)

- (NSDateComponents *)mgm_components {
    return [[NSCalendar shared]componentsInTimeZone:[NSCalendar shared].timeZone fromDate:self];
}

- (NSDateComponents *)mgm_components:(NSCalendarUnit)unitFlags fromDate:(NSDate *)startingDate toDate:(NSDate *)resultDate {
    return [[NSCalendar shared]components:unitFlags fromDate:startingDate toDate:resultDate options:NSCalendarWrapComponents];
}

- (void)mgm_timeIntervalToDate:(NSDate *)date callback:(void(^)(MGMDateComponents dateComponents))callback {
    NSCalendarUnit calendarUnits = NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    NSDateComponents *components = [self mgm_components:calendarUnits fromDate:self toDate:date];
    MGMDateComponents dateComponent = {};
    dateComponent.era = dateComponent.era;
    dateComponent.year = [components year];
    dateComponent.month = [components month];
    dateComponent.day = [components day];
    dateComponent.hour = [components hour];
    dateComponent.minute = [components minute];
    dateComponent.second = [components second];
    callback? callback(dateComponent) : nil;
}

- (NSInteger)mgm_daysToDate:(NSDate *)date {
    return [self mgm_components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:self toDate:date].day;
}


- (BOOL)mgm_isEqualToDate:(NSDate *)date in:(NSCalendarUnit)unit {
    return [[NSCalendar shared]isDate:self equalToDate:date toUnitGranularity:unit];
}

- (BOOL)mgm_isInSameWith:(NSDate *)date {
    return [[NSCalendar shared]isDate:self inSameDayAsDate:date];
}


- (BOOL)mgm_isDateInToday {
    return [[NSCalendar shared] isDateInToday:self];
}


- (BOOL)mgm_isDateInYesterday {
    return [[NSCalendar shared]isDateInYesterday:self];
}


- (BOOL)mgm_isDateInTomorrow {
    return [[NSCalendar shared]isDateInTomorrow:self];
}


- (BOOL)mgm_isDateInWeekend {
    return [[NSCalendar shared]isDateInWeekend:self];
}

@end
