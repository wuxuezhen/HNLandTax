//
//  NSDate+MGMConversion.h
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (MGMConversion)

- (NSString *)mgm_publishTime;
- (NSString *)mgm_stringValueWithFormat:(NSString *)format;
+ (NSString *)mgm_stringFromDate:(NSDate *)date format:(NSString *)format;
+ (NSDate *)mgm_dateWithString:(NSString *)dateString format:(NSString *)format;
+ (NSDate *)mgm_dateWithTimestamp:(id)timestamp;
+ (NSDate *)mgm_zeroTime;
+ (NSDate *)mgm_getTimeAfterNowWithDay:(NSInteger)day;
+ (NSString *)mgm_getweekDayStringWithDate:(NSDate *) date;
///匹配 年月日 是否相等
+ (BOOL)mgm_isSameDay:(NSDate *)firstDate lastDate:(NSDate *)lastDate;
@end

@interface NSString (MGMConversion)

- (NSDate *)mgm_dateVlaueFromFormat:(NSString *)format;
+ (NSString *)mgm_stringFromTimestamp:(double)timestamp format:(NSString *)format;

@end
