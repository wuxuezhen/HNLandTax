//
//  NSDate+MGMDateUnit.h
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSCalendar (SYDateUnit)

+ (NSCalendar *)shared;

@end

@interface NSDate (MGMDateUnit)

- (NSInteger)mgm_year;
- (NSInteger)mgm_month;
- (NSString *)mgm_enShortMonth;
- (NSInteger)mgm_day;
- (NSInteger)mgm_hour;
- (NSInteger)mgm_minute;
- (NSInteger)mgm_second;
- (NSInteger)mgm_weekday;
///< 例如 @"星期五" <==> @"星期MGMWK"
- (NSString *)mgm_weekDayWithFor:(NSString *)format;
- (NSInteger)mgm_weekOfMonth;
- (NSInteger)mgm_weakOfYear;

- (NSDate *)mgm_dateByAddingUnit:(NSCalendarUnit)unit value:(NSInteger)value;
- (NSDate *)mgm_dateBySettingUnit:(NSCalendarUnit)unit value:(NSInteger)v;
- (NSDate *)mgm_dateBySettingHour:(NSInteger)h minute:(NSInteger)m second:(NSInteger)s;

@end
