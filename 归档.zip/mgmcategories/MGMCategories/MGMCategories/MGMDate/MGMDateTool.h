//
//  MGMDateTool.h
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#if __has_include(<MGMCategories/MGMDateTool.h>)

#import <MGMCategories/NSDate+MGMConversion.h>
#import <MGMCategories/NSDate+MGMCompare.h>
#import <MGMCategories/NSDate+MGMDateUnit.h>

#else

#import "NSDate+MGMConversion.h"
#import "NSDate+MGMCompare.h"
#import "NSDate+MGMDateUnit.h"

#endif /* MGMDateTool_h */
