//
//  NSDate+MGMConversion.m
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "NSDate+MGMConversion.h"

static NSDateFormatter * sharedDateFormatter = nil;
static NSCalendar *shareCalender = nil;

NSDateFormatter *SYDateFormatter(void) {
    return sharedDateFormatter;
}

@implementation NSDate (MGMConversion)

+ (NSString *)mgm_stringFromDate:(NSDate *)date format:(NSString *)format
{
    sharedDateFormatter.dateFormat = format;
    NSTimeZone *timeZone = [NSTimeZone systemTimeZone];
    NSInteger seconds = [timeZone secondsFromGMTForDate:date];
    NSDate *currentDate = [date dateByAddingTimeInterval:seconds];
    NSString *currentDateStr = [sharedDateFormatter stringFromDate:currentDate];
    return currentDateStr;
}

- (NSString *)mgm_stringValueWithFormat:(NSString *)format {
    NSString *dateString = nil;
    NSDate *date = self;
    @synchronized (sharedDateFormatter) {
        sharedDateFormatter.dateFormat = format;
        dateString = [sharedDateFormatter stringFromDate:date];
    }
    return dateString;
}

- (NSString *)mgm_publishTime
{
    NSInteger timeInterval = - [self timeIntervalSinceNow];
    
    if (timeInterval <= 60) return @"刚刚";
    if (timeInterval <= 60*60) return [NSString stringWithFormat:@"%d分钟前", (int)(timeInterval/60)];
    if (timeInterval <= 24*60*60) return [NSString stringWithFormat:@"%d小时前", (int)(timeInterval/60/60)];
    if ([self mgm_isYesterday]) return @"昨天";
    if ([self mgm_isDayBeforeYesterday]) return @"前天";
    return [self mgm_stringValueWithFormat:@"yyyy-MM-dd"];
}

+ (NSDate *)mgm_getTimeAfterNowWithDay:(NSInteger)day
{
    NSDate *nowDate = [NSDate date];
    NSDate *theDate;
    
    if(day!=0)
    {
        NSTimeInterval  oneDay = 24*60*60*1;  //1天的长度
        
        theDate = [nowDate initWithTimeIntervalSinceNow: +oneDay*day ];
        //or
        //theDate = [nowDate initWithTimeIntervalSinceNow: -oneDay*day ];
    }
    else
    {
        theDate = nowDate;
    }
    return theDate;
}

+ (NSDate *)mgm_dateWithString:(NSString *)dateString format:(NSString *)format {
    NSDate *date = nil;
    @synchronized (sharedDateFormatter) {
        sharedDateFormatter.dateFormat = format;
        date = [sharedDateFormatter dateFromString:dateString];
    }
    return date;
}

+ (NSDate *)mgm_dateWithTimestamp:(id)timestamp {
    double timeInterval = [timestamp doubleValue];
    return [NSDate dateWithTimeIntervalSince1970:timeInterval];
}

+ (NSDate *)mgm_zeroTime
{
    NSDate* now = [NSDate date];
    unsigned int unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour |NSCalendarUnitSecond;
    NSDateComponents *zerocompents = [shareCalender components:unitFlags fromDate:now];
    zerocompents.hour = 0;
    zerocompents.minute = 0;
    zerocompents.second = 0;
    return [shareCalender dateFromComponents:zerocompents];
}
+ (NSString *) mgm_getweekDayStringWithDate:(NSDate *) date
{
    NSCalendar * calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    // 指定日历的算法
    NSDateComponents *comps = [calendar components:NSWeekdayCalendarUnit fromDate:date];
    // 1 是周日，2是周一 3.以此类推
    NSNumber * weekNumber = @([comps weekday]);
    NSInteger weekInt = [weekNumber integerValue];
    NSString *weekDayString = @"周一";
    switch (weekInt) {
        case 1:{weekDayString = @"周日";}break;
        case 2:{weekDayString = @"周一";}break;
        case 3:{weekDayString = @"周二";}break;
        case 4:{weekDayString = @"周三";}break;
        case 5:{weekDayString = @"周四";}break;
        case 6:{weekDayString = @"周五";}break;
        case 7:{weekDayString = @"周六";}break;
        default:break;
            
    }
    return weekDayString;
    
}
+ (BOOL)mgm_isSameDay:(NSDate *)firstDate lastDate:(NSDate *)lastDate
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    unsigned unitFlag = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
    NSDateComponents *comp1 = [calendar components:unitFlag fromDate:firstDate];
    NSDateComponents *comp2 = [calendar components:unitFlag fromDate:lastDate];
    return (([comp1 day] == [comp2 day]) && ([comp1 month] == [comp2 month]) && ([comp1 year] == [comp2 year]));
}

- (BOOL)mgm_isYesterday
{
    NSDateComponents *comps = [self dateComponentsBetweenTwoContinuousDates];
    return (!comps.year &&
            !comps.month &&
            (1 == comps.day));
}

- (BOOL)mgm_isDayBeforeYesterday
{
    NSDateComponents *comps = [self dateComponentsBetweenTwoContinuousDates];
    return (!comps.year &&
            !comps.month &&
            (2 == comps.day));
}

#pragma mark - Private

- (NSDateComponents *)dateComponentsBetweenTwoContinuousDates
{
    sharedDateFormatter.dateFormat = @"yyyy-MM-dd";
    NSString *nowDateStr = [sharedDateFormatter stringFromDate:[NSDate date]];
    NSString *compareDateStr = [sharedDateFormatter stringFromDate:self];
    NSDate *nowDate = [sharedDateFormatter dateFromString:nowDateStr];
    NSDate *compareDate = [sharedDateFormatter dateFromString:compareDateStr];
    return [[NSCalendar currentCalendar] components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay)
                                           fromDate:compareDate
                                             toDate:nowDate
                                            options:(NSCalendarWrapComponents)];
}

@end

@implementation NSString (MGMConversion)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedDateFormatter = [[NSDateFormatter alloc]init];
        [sharedDateFormatter setLocale:[NSLocale currentLocale]];
        sharedDateFormatter.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
        shareCalender = [NSCalendar currentCalendar];
    });
}

- (NSDate *)mgm_dateVlaueFromFormat:(NSString *)format {
    NSDate *date = nil;
    NSString *dateValue = [self copy];
    @synchronized (sharedDateFormatter) {
        sharedDateFormatter.dateFormat = format;
        date = [sharedDateFormatter dateFromString:dateValue];
    }
    return date;
}

+ (NSString *)mgm_stringFromTimestamp:(double)timestamp format:(NSString *)format{
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timestamp];
    return [date mgm_stringValueWithFormat:format];
}


@end

