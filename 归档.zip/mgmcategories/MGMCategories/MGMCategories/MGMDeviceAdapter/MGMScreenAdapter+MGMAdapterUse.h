//
//  MGMScreenAdapter+MGMAdapterUse.h
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMScreenAdapter.h"

CGFloat fitLenthWithStandardLenth(CGFloat px);
CGFloat fitHeightWithStandardHeight(CGFloat px);
CGFloat virtualHomeHeight(void);
CGFloat statusBarHeight(void);
CGFloat tabarHeight(void);
CGSize mainScreenSize(void);
CGFloat mainScreenWidth(void);
CGFloat mainScreenHeight(void);
BOOL isIPad(void);
BOOL isIPhone(void);
BOOL isIPhone8OrLater(void);
BOOL isIPhoneXOrLater(void);

/// 与原来代码兼容
CGFloat fitLenth(CGFloat stdLenth);

#define kMGMHBL(x) fitLenthWithStandardLenth((x))
#define kMGMHBH(value) fitHeightWithStandardHeight((value))

#define kVirtualHomeHeight virtualHomeHeight()
#define kStatusBarHeight statusBarHeight()
#define kTabarHeight tabarHeight()
#define kMainScreenSize mainScreenSize()
#define kMainScreenWidth mainScreenWidth()
#define kMainScreenHeight mainScreenHeight()
#define kIsIPad isIPad()
#define kIsIPhone isIPhone()
#define kIsIPhone8OrLater isIPhone8OrLater()
#define kIsIPhoneXOrLater isIPhoneXOrLater()

#define kMGMHBL2X(x) kMGMHBL((x)*2)
#define kMGMHBH2X(x) kMGMHBH((x)*2)

CG_INLINE CGSize
MGMSizeMake(CGFloat width, CGFloat height) {
    CGSize size; size.width = kMGMHBL(width); size.height = kMGMHBL(height); return size;
}

CG_INLINE CGRect
MGMRectMake(CGFloat x, CGFloat y, CGFloat width, CGFloat height)
{
    CGRect rect;
    rect.origin.x = kMGMHBL(x); rect.origin.y = kMGMHBL(y);
    rect.size.width = kMGMHBL(width); rect.size.height = kMGMHBL(height);
    return rect;
}

UIKIT_STATIC_INLINE UIEdgeInsets MGMEdgeInsetsMake(CGFloat top, CGFloat left, CGFloat bottom, CGFloat right) {
    UIEdgeInsets insets = {kMGMHBL(top), kMGMHBL(left), kMGMHBL(bottom), kMGMHBL(right)};
    return insets;
}

@interface MGMScreenAdapter (MGMAdapterUse)

@end
