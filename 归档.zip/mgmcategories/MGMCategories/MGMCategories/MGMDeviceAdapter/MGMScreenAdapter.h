//
//  MGMScreenAdapter.h
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MGMDeviceModel;

@interface MGMScreenAdapter : NSObject

+ (instancetype)defaultAdapterWithStandartSize:(CGSize)size;

- (instancetype)init NS_UNAVAILABLE;

@property (nonatomic, assign, readonly) CGSize stdSize;
@property (nonatomic, strong, readonly) MGMDeviceModel *currentModel;

- (CGFloat)virtualHomeHeight;
- (CGFloat)statusBarHeight;
- (CGFloat)tabarHeight;
- (CGSize)mainScreenSize;
- (CGFloat)mainScreenWidth;
- (CGFloat)mainScreenHeight;

- (CGFloat)fitLenthWithStandardLenth:(CGFloat)stdLenth;
- (CGFloat)fitHeightWithStandardHeight:(CGFloat)stdHeight;

- (BOOL)isIPad;
- (BOOL)isIPhone;
- (BOOL)isIPhone8OrLater;
- (BOOL)isIPhoneXOrLater;

@end
