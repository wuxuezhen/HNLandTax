//
//  MGMDeviceModel.m
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMDeviceModel.h"


static NSMutableArray *hb_allModes;

@interface MGMDeviceModel ()

@property (nonatomic, assign, readwrite) CGSize px;
@property (nonatomic, assign, readwrite) CGSize pt;
@property (nonatomic, assign, readwrite) HBDevicType deviceType;
@property (nonatomic, assign, readwrite) HBDeviceVersion version;

@end

@implementation MGMDeviceModel

- (instancetype)initWithPx:(CGSize)px pt:(CGSize)pt
{
    self = [super init];
    if (self) {
        _px = px;
        _pt = pt;
        _version = HBDeviceVersionIPhone_Unknow;
        _deviceType = UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad? HBDevicTypeIPad: HBDevicTypeIPhone;
    }
    return self;
}

+ (NSArray *)hb_allModes {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString *filePath = [[NSBundle mainBundle]pathForResource:@"HBDeviceModel" ofType:@"plist"];
        NSArray *modeInfos = [NSArray arrayWithContentsOfFile:filePath];
        hb_allModes = [NSMutableArray arrayWithCapacity:modeInfos.count];
        for (NSDictionary *info in modeInfos) {
            MGMDeviceModel *mode = [[MGMDeviceModel alloc] init];
            [mode setValuesForKeysWithDictionary:info];
            [hb_allModes addObject:mode];
        }
    });
    return hb_allModes;
}

- (void)setValue:(id)value forKey:(NSString *)key {
    if ([key isEqualToString:@"pt"]) {
        _pt = CGSizeFromString(value);
        return;
    }
    
    if ([key isEqualToString:@"px"]) {
        _px = CGSizeFromString(value);
        return;
    }
    [super setValue:value forKey:key];
}

- (BOOL)isEqual:(MGMDeviceModel *)object {
    return CGSizeEqualToSize(self.pt, object.pt) && CGSizeEqualToSize(self.px, object.px);
}

- (NSString *)description {
    return [NSString stringWithFormat:@"name:%@, px:%@, pt:%@", _name, NSStringFromCGSize(_px), NSStringFromCGSize(_pt)];
}

@end
