//
//  MGMScreenAdapter.m
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMScreenAdapter.h"
#import "MGMDeviceModel.h"


@interface MGMScreenAdapter ()

@property (nonatomic, assign, readwrite) CGSize stdSize;
@property (nonatomic, strong, readwrite) MGMDeviceModel *currentModel;

@end

@implementation MGMScreenAdapter

+ (instancetype)defaultAdapterWithStandartSize:(CGSize)size {
    static MGMScreenAdapter *_defaultAdapter = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _defaultAdapter = [[MGMScreenAdapter alloc] initWithStandartSize:size];
    });
    return _defaultAdapter;
}

- (CGFloat)fitLenthWithStandardLenth:(CGFloat)stdLenth {
    if ([self isIPhone]) {
        return [self p_fitByIPhoneWidthWithStandardLehth:stdLenth];
    } else if ([self isIPad]) {
        return [self p_fitByIPadWidthWithStandardLehth:stdLenth];
    }
    return stdLenth/2.0;
}

- (CGFloat)fitHeightWithStandardHeight:(CGFloat)stdHeight {
    if ([self isIPhone]) {
        return [self p_fitByHeightWithStandardLehth:stdHeight];
    } else if ([self isIPad]) {
        return [self p_fitByIPadWithStandardLehth:stdHeight];
    }
    return stdHeight/2.0;
}

- (CGFloat)virtualHomeHeight {
    return [self isIPhoneXOrLater] ? 34.f : 0.f;
}
- (CGFloat)tabarHeight {
    return [self isIPhoneXOrLater]? 83.0f:49.0f;
}

- (CGFloat)statusBarHeight {
    // CGFloat height = [self isIPhoneXOrLater]? 44 : 20;
    return [[UIApplication sharedApplication] statusBarFrame].size.height;
}

- (BOOL)isIPhone {
    return UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone;
}
- (BOOL)isIPad {
    return UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad;
}

- (CGSize)mainScreenSize {
    static CGSize mainScreenSize;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mainScreenSize = [UIScreen mainScreen].bounds.size;
    });
    return mainScreenSize;
}

- (CGFloat)mainScreenWidth {
    static CGFloat mainScreenWidth;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mainScreenWidth = [self mainScreenSize].width;
    });
    return mainScreenWidth;
}

- (CGFloat)mainScreenHeight {
    static CGFloat mainScreenHeight;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mainScreenHeight = [self mainScreenSize].height;
    });
    return mainScreenHeight;
}

- (BOOL)isRetina {
    return [[UIScreen mainScreen] scale] >= 2.0;
}

- (BOOL)isIPhone8OrLater {
    return self.currentModel.version >= HBDeviceVersionIPhone_8 && [self isIPhone];
}

- (BOOL)isIPhoneXOrLater {
    return self.currentModel.version >= HBDeviceVersionIPhone_X && [self isIPhone];
}

- (MGMDeviceModel *)currentModel {
    if (!_currentModel) {
        _currentModel = [self p_currentModel];
    }
    return _currentModel;
}

- (MGMDeviceModel *)p_currentModel {
    CGSize px = [[UIScreen mainScreen] currentMode].size;
    CGSize pt = [UIScreen mainScreen].bounds.size;
    __block MGMDeviceModel *model = [[MGMDeviceModel alloc] initWithPx:px pt:pt];
    [[self p_knewModeSizes] enumerateObjectsUsingBlock:^(MGMDeviceModel *obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([model isEqual:obj]) {
            model = obj;
            *stop = YES;
        }
    }];
    return model;
}

//MARK: - private method
- (instancetype)initWithStandartSize:(CGSize)size {
    self = [super init];
    if (self) {
        self.stdSize = size;
    }
    return self;
}

/// 根据 宽度适配 IPhone
- (CGFloat)p_fitByIPhoneWidthWithStandardLehth:(CGFloat)stdLenth {
    
    CGSize screenSize = [self p_deviceSize];
    CGFloat mainWidth = MIN(screenSize.width, screenSize.height);
    CGFloat fitLenth = stdLenth * mainWidth / self.stdSize.width;
    return fitLenth;
}

/// 根据 高度适配 IPhone
- (CGFloat)p_fitByHeightWithStandardLehth:(CGFloat)stdLenth {
    CGSize screenSize = [self p_deviceSize];
    CGFloat mainHeight = MAX(screenSize.width, screenSize.height);
    CGFloat fitLenth = stdLenth * mainHeight / self.stdSize.height;
    return fitLenth;
}

/// 根据 宽度适配 IPad
- (CGFloat)p_fitByIPadWidthWithStandardLehth:(CGFloat)stdLenth {
    return stdLenth/2.0;
}

/// 根据 高度适配 IPad
- (CGFloat)p_fitByIPadWithStandardLehth:(CGFloat)stdLenth {
    return stdLenth/2.0;
}

- (CGSize)p_deviceSize {
    return [UIScreen mainScreen].bounds.size;
}

- (NSArray *)p_knewModeSizes {
    NSArray *allModeSize = [MGMDeviceModel hb_allModes];
    return allModeSize;
}

@end

