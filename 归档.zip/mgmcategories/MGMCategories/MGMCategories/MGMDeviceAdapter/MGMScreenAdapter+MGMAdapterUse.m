//
//  MGMScreenAdapter+MGMAdapterUse.m
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import "MGMScreenAdapter+MGMAdapterUse.h"

@implementation MGMScreenAdapter (MGMAdapterUse)

@end


MGMScreenAdapter *adapter() {
    static MGMScreenAdapter *adapter;
    if (!adapter) {
        adapter = [MGMScreenAdapter defaultAdapterWithStandartSize:CGSizeMake(750, 1334)];
    }
    return adapter;
}

CGFloat fitLenthWithStandardLenth(CGFloat px) {
    return [adapter() fitLenthWithStandardLenth:px];
}

CGFloat fitHeightWithStandardHeight(CGFloat px) {
    return [adapter() fitHeightWithStandardHeight:px];
}

CGFloat fitLenth(CGFloat stdLenth) {
    return fitLenthWithStandardLenth(stdLenth);
}

CGFloat virtualHomeHeight() {
    return [adapter() virtualHomeHeight];
}

CGFloat statusBarHeight() {
    return [adapter() statusBarHeight];
}

CGFloat tabarHeight() {
    return [adapter() tabarHeight];
}

CGSize mainScreenSize() {
    return [adapter() mainScreenSize];
}
CGFloat mainScreenWidth(void) {
    return [adapter() mainScreenWidth];
}
CGFloat mainScreenHeight(void) {
    return [adapter() mainScreenHeight];
}

BOOL isIPad() {
    return [adapter() isIPad];
}

BOOL isIPhone() {
    return [adapter() isIPhone];
}

BOOL isIPhone8OrLater() {
    return [adapter() isIPhone8OrLater];
}

BOOL isIPhoneXOrLater() {
    return [adapter() isIPhoneXOrLater];
}
