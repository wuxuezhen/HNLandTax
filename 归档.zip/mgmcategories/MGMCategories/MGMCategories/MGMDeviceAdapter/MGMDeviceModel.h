//
//  MGMDeviceModel.h
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef NS_ENUM(NSInteger,HBDevicType){
    HBDevicTypeIPhone = 0, // iPhone or iPod
    HBDevicTypeIPad = 1,
};

typedef NS_ENUM(NSInteger, HBDeviceVersion) {
    HBDeviceVersionIPhone_SE = 0,
    HBDeviceVersionIPhone_4 = 1,
    HBDeviceVersionIPhone_4S = 2,
    HBDeviceVersionIPhone_5 = 3,
    HBDeviceVersionIPhone_5S = 4,
    HBDeviceVersionIPhone_5C = 5,
    HBDeviceVersionIPhone_6 = 6,
    HBDeviceVersionIPhone_6S = 7,
    HBDeviceVersionIPhone_6_SP = 8,
    HBDeviceVersionIPhone_7 = 9,
    HBDeviceVersionIPhone_7_Plus = 10,
    HBDeviceVersionIPhone_8 = 11,
    HBDeviceVersionIPhone_8_Plus = 12,
    HBDeviceVersionIPhone_X = 13,
    HBDeviceVersionIPhone_XR = 14,
    HBDeviceVersionIPhone_XS = 15,
    HBDeviceVersionIPhoneXS_Mas = 16,
    HBDeviceVersionIPad,
    HBDeviceVersionIPod,
    HBDeviceVersionIPhone_Unknow = HBDeviceVersionIPhone_8
};

@interface MGMDeviceModel : NSObject


@property (nonatomic, copy, readonly) NSString *name;

@property (nonatomic, assign, readonly) CGSize px;
@property (nonatomic, assign, readonly) CGSize pt;
@property (nonatomic, assign, readonly) HBDevicType deviceType;
@property (nonatomic, assign, readonly) HBDeviceVersion version;

- (instancetype)initWithPx:(CGSize)px pt:(CGSize)pt;

+ (NSArray *)hb_allModes;

@end
