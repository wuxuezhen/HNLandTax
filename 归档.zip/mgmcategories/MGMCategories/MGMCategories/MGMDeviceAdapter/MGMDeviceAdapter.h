//
//  MGMDeviceAdapter.h
//  Test
//
//  Created by apple on 2018/12/2.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#if __has_include(<MGMCategories/MGMDeviceAdapter.h>)

#import <MGMCategories/MGMScreenAdapter+MGMAdapterUse.h>
#import <MGMCategories/MGMDeviceModel.h>

#else

#import "MGMScreenAdapter+MGMAdapterUse.h"
#import "MGMDeviceModel.h"

#endif /* MGMDeviceAdapter_h */
