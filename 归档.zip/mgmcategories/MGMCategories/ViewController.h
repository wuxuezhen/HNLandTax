//
//  ViewController.h
//  MGMCategories
//
//  Created by zhaohao on 2018/12/3.
//  Copyright © 2018年 MIGU VIDEO Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

