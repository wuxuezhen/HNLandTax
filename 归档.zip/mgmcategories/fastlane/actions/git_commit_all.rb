module Fastlane
  module Actions
    module SharedValues
      GIT_COMMIT_ALL_CUSTOM_VALUE = :GIT_COMMIT_ALL_CUSTOM_VALUE
    end

    class GitCommitAllAction < Action
      def self.run(params)
      
      Actions.sh "git commit -am \"#{params[:message]}\""
      
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "A short description with <= 80 characters of what this action does"
      end

      def self.details
        # Optional:
        # this is your chance to provide a more detailed description of this action
        "git commit -am"
      end

      def self.available_options
        # Define all options your action supports. 
        
        [
          FastlaneCore::ConfigItem.new(key: :message,
          env_name: "FL_GIT_COMMIT_ALL",
          description: "The git message for the commit",
          is_string: true)
        ]
      end

      def self.output
        # Define the shared values you are going to provide
        # Example
        [
          ['GIT_COMMIT_ALL_CUSTOM_VALUE', 'A description of what this value contains']
        ]
      end

      def self.return_value
        # If your method provides a return value, you can describe here what it does
      end

      def self.authors
        # So no one will ever forget your contribution to fastlane :) You are awesome btw!
        ["renyi"]
      end

      def self.is_supported?(platform)
        # you can do things like
        # 
        #  true
        # 
        #  platform == :ios
        # 
        #  [:ios, :mac].include?(platform)
        # 

        platform == :ios
      end
    end
  end
end
