#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_MGMCategories : NSObject
@end
@implementation PodsDummy_Pods_MGMCategories
@end
